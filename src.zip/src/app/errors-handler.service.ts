import { ErrorHandler, Injectable, isDevMode } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';

declare const alertify;
@Injectable()
export class ErrorsHandlerService implements ErrorHandler {

    private timeoutId: any;
    private timeout = 500;

    constructor(private translateService: TranslateService) { }

    handleError(error: any): void {
        if (isDevMode()) {
            console.log(error);
        }
        if (error instanceof HttpErrorResponse) {
            // Server or connection error happened
            if (!navigator.onLine) {
                alertify.error(this.translateService.instant('No internet connection'));
            } else {
                this.showAlert(error);
            }
        } else if (error && error.promise && error.promise.__zone_symbol__value instanceof HttpErrorResponse) {
            const errObj = error.promise.__zone_symbol__value as HttpErrorResponse;
            this.showAlert(errObj);
        } else {
            this.someThingWentWrong('Something went wrong please try again');
        }

    }

    private showAlert(error: HttpErrorResponse) {
        const exempErrCodes = ['1017'];
        if (!(error.status === 404 && error.error && exempErrCodes.indexOf(error.error.code))) {
            if (error.status >= 400 && error.status <= 511) {
                /* reissue token */
                if (error.error && error.error.code) {
                    alertify.error(this.translateService.instant(error.error.code.toString()));
                } else {
                    alertify.error(this.translateService.instant(error.status.toString()));
                }
            } else {
                this.someThingWentWrong();
            }
        }
    }

    // Sliding timer. Something went wrong can only be called
    // once in a set interval of time
    private someThingWentWrong(message?: string) {
        const showMessage = message || 'Something went wrong.';
        const wentWrong = this.translateService.instant(showMessage);
        if (!!this.timeoutId) {
            clearTimeout(this.timeoutId);
            this.timeoutId = null;
        }
        this.timeoutId = setTimeout(() => {
            alertify.error(wentWrong);
            this.timeoutId = null;
        }, this.timeout);
    }


}
