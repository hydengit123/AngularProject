import { FormControl, ValidationErrors, ValidatorFn } from "@angular/forms";
import { TranslateService } from "@ngx-translate/core";
import { PersistenceService, StorageType } from "angular-persistence";
import { CMUICONFIGKEY } from 'dxp-common';
import { REGEX } from "../../../application-constants";


export function rechargeOthersValidator(persistenceService: PersistenceService, translate: TranslateService, message: any): ValidatorFn {
    return (control: FormControl): ValidationErrors | null => {
        const maxRechargeLimit = parseInt(persistenceService.get(CMUICONFIGKEY.RECHARGE_LIMIT, StorageType.SESSION)) || null;
        let isError: boolean;
        let errors = {
            requiredError: false,
            'amountRequiredError': false,
            'amountFormatError': false,
            'maxAdjustAmountError': false
        };

        const amountRegEx = /^\d*\.?\d+$/g;

        if (control && !control.value && control.dirty) {
            message.error = "Please enter valid amount";
            message.sucess = null;
            isError = true;
        }

        if (control && !control.value) {
            message.error = "Please enter valid amount";
            message.sucess = null;
            isError = true;
        }

        if (control && control.value && maxRechargeLimit && parseInt(control.value) > maxRechargeLimit) {
            message.error = `${translate.instant('Maximum Recharge limit')} ${maxRechargeLimit} ${translate.instant('is exceeded')}`;
            message.sucess = null;
            isError = true;
        }

        else if (control && control.value && !control.value.match(REGEX.FLOATNUMBER)) {
            message.error = translate.instant('Please enter valid amount');
            message.sucess = null;
            isError = true;
        }
        else {
            message.error = null;
            message.success = '';
        }

        return isError ? errors : null;

    }
};



export function rechargeMobileValidator(translate: TranslateService,  persistenceService:PersistenceService, message: any): ValidatorFn {
    return (control: FormControl): ValidationErrors | null => {
        let isError: boolean;
        let errors = {
            requiredError: false
        };

        const phoneNumberLength = parseInt(persistenceService.get(
            CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION
          )) || null;
        const phoneNumberMaxLength = parseInt(persistenceService.get(
            CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION
        )) || null;
          if(control && !control.value){
            message.error = translate.instant('Please enter valid MSISDN');
            isError = true;
            errors.requiredError = true;
          }
        
          else if(control && (control.value.length < phoneNumberLength || control.value.length > phoneNumberMaxLength) ){
            if (phoneNumberLength === phoneNumberMaxLength) {
                message.error = `${translate.instant('Please enter only')} ${phoneNumberLength} ${translate.instant('digits')} `;
            } else {
                message.error = `${translate.instant('Please enter only')} ${phoneNumberLength} - ${phoneNumberMaxLength} ${translate.instant('digits')} `;
            }
            isError = true;
            errors.requiredError = true;
          }
        
          else if(control && !control.value.match(REGEX.ONLYDIGIT) ){
            message.error = translate.instant('Please enter only digits');
            isError = true;
            errors.requiredError = true;
          }
          else{
            message.error = null;
            message.success = '';
          }
        return isError ? errors : null;

    }
};


