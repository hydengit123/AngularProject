import { FormGroup, ValidationErrors, ValidatorFn } from "@angular/forms";
import { PersistenceService } from "angular-persistence";
import { REGEX } from "../../../application-constants";

export function resetValidator(persistenceService: PersistenceService): ValidatorFn {
    return (control: FormGroup): ValidationErrors | null => {
        const password = control.get('password');
        const confirm_password = control.get('confirm_password');

      
        let isError = false;
        let errors = {
           
            "passwordRequiredError": false,
            "confirm_passwordRequiredError": false,
            "passwordMismatchError": false,
            "generalError": false,
            "passwordFormatError":false
        }

        let formcontrolvalue = control.controls;

        
        if (password && !password.value && password.dirty) {
            errors.passwordRequiredError = true;
            isError = true;
        }
        if(password && password.value && !password.value.match(REGEX.PASSWORD)){
            errors.passwordFormatError = true;
            isError = true;
        }
       
        if (confirm_password && !confirm_password.value && confirm_password.dirty) {
            errors.confirm_passwordRequiredError = true;
            isError = true;
        }
        if(password && password.value && confirm_password && confirm_password.value){
            if(password.value !== confirm_password.value){
                errors.passwordMismatchError = true;
                isError = true;
            }
        }

        return isError ? errors : null;
    }
};
