import { FormGroup, ValidationErrors, ValidatorFn } from "@angular/forms";
import { PersistenceService, StorageType } from "angular-persistence";
import { CMUICONFIGKEY } from 'dxp-common';
import { REGEX } from "../../../application-constants";

export function registerValidator(persistenceService: PersistenceService): ValidatorFn {
    return (control: FormGroup): ValidationErrors | null => {
        const username = control.get('username');
        const password = control.get('password');
        
        const user_otp = control.get('user_otp');
        const confirm_password = control.get('confirm_password');
        const phoneNumberLength = parseInt(persistenceService.get(
            CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION
        )) || null;
        const phoneNumberMaxLength = parseInt(persistenceService.get(
            CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION
        )) || null;
        let isError = false;
        let errors = {
            "usernameRequiredError": false,
            "user_otpRequiredError": false,
            "passwordRequiredError": false,
            "confirm_passwordRequiredError": false,
            "usernameLengthError": false,
            "usernameFormatError": false,
            "usernameEmailFormatError": false,
            "passwordMismatchError": false,
            "emailAlreadyExists": false,
            "generalError": false,
            "passwordFormatError":false,
            "user_otpInvalidError":false

        }
         
        let formcontrolvalue = control.controls;

        if (username && !username.value && username.dirty) {
            errors.usernameRequiredError = true;
            isError = true;
        }

        if (password && !password.value && password.dirty) {
            errors.passwordRequiredError = true;
            isError = true;
        }
        if(password && password.value && !password.value.match(REGEX.PASSWORD)){
            errors.passwordFormatError = true;
            isError = true;
        }
        if (user_otp && !user_otp.value && user_otp.dirty) {
            errors.user_otpRequiredError = true;
            isError = true;
        }
        if (confirm_password && !confirm_password.value && confirm_password.dirty) {
            errors.confirm_passwordRequiredError = true;
            isError = true;
        }
        if(password && password.value && confirm_password && confirm_password.value){
            if(password.value !== confirm_password.value){
                errors.passwordMismatchError = true;
                isError = true;
            }
        }

        if (username.value.match(REGEX.ONLYDIGIT)) {
            if (username && username.value
                && phoneNumberLength && (username.value.length < phoneNumberLength || username.value.length > phoneNumberMaxLength)) {
                errors.usernameLengthError = true;
                isError = true;
            }

            if (username && username.value && !username.value.match(REGEX.ONLYDIGIT)) {
                errors.usernameFormatError = true;
                isError = true;
            }
        }else{
            if (username && username.value && !username.value.match(REGEX.EMAIL)) {
                errors.usernameEmailFormatError = true;
                isError = true;
            }
        }
        return isError ? errors : null;
    }
};
