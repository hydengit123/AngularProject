import { AsyncValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { Observable ,  of } from "rxjs";
import { RegisterService } from '../../services/register.service';
import { map } from 'rxjs/operators';

export function EmailCheckValidator(RegisterService: RegisterService): AsyncValidatorFn {
  return (control: AbstractControl): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> => {
    const usernm = control.get('username');  
    if (control.value && control.value.username) {
      return RegisterService.emailCheck(control.value.username).pipe(map(
        data => {
          return (data && data.message === 'Success') ? null : {'isTaken': true};
        }
      ));
    }
    return of(null); 
  };
}
