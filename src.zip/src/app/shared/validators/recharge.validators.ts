import { ValidatorFn, AbstractControl, FormControl, ValidationErrors } from "@angular/forms";
import { TranslateService } from "@ngx-translate/core";
import { REGEX } from "../../../application-constants";
import { PersistenceService, StorageType } from "angular-persistence";
import { CMUICONFIGKEY } from 'dxp-common';


export function rechargeValidator(persistenceService: PersistenceService, translate: TranslateService, message: any): ValidatorFn {
    return (control: FormControl): ValidationErrors | null => {
        let isError: boolean;
        const maxRechargeLimit = parseInt(persistenceService.get(CMUICONFIGKEY.RECHARGE_LIMIT, StorageType.SESSION)) || null;
        let errors = {
            requiredError: false,
            'amountRequiredError': false,
            'amountFormatError': false,
            'maxRechargeLimitError': false
        };

        const amountRegEx = /^\d*\.?\d+$/g;

        // if (control && !control.value && control.dirty) {
        //     message.error = "Please enter valid amount";
        //     message.sucess = null;
        //     isError = true;
        // }

        // if (control && !control.value) {
        //     message.error = "Please enter valid amount";
        //     message.sucess = null;
        //     isError = true;
        // }

        if (control && control.value && maxRechargeLimit && parseInt(control.value) > maxRechargeLimit) {
            message.error = `${translate.instant('Maximum Recharge limit')} ${maxRechargeLimit} ${translate.instant('is exceeded')}`;
            message.sucess = null;
            isError = true;
        }

        else if (control && control.value && !control.value.toString().match(REGEX.FLOATNUMBER)) {
            message.error = translate.instant('Please enter valid amount');
            message.sucess = null;
            isError = true;
        }
        else {
            message.error = null;
            message.success = '';
        }

        return isError ? errors : null;

    }
};

export function rechargeWithVoucherCodeValidator(translate: TranslateService, persistenceService:PersistenceService, message: any): ValidatorFn {
    return (control: FormControl): ValidationErrors | null => {
        let isError: boolean;
        let errors = {
            requiredError: false
        };
        // const voucherCodeLength = 16;

        const voucherCodeMinLength = parseInt(persistenceService.get(
            CMUICONFIGKEY.VOUCHERCODEMINLENGTH, StorageType.SESSION
          )) || null;

        const voucherCodeMaxLength = parseInt(persistenceService.get(
            CMUICONFIGKEY.VOUCHERCODEMAXLENGTH, StorageType.SESSION
          )) || null;

        
          if(control && control.value && (control.value.length < voucherCodeMinLength || control.value.length > voucherCodeMaxLength) ){
            message.error = `${translate.instant('Voucher code must be between')} ${voucherCodeMinLength} - ${voucherCodeMaxLength} ${translate.instant('digits')} `;
            isError = true;
          }
        
          else if(control && control.value && !control.value.toString().match(REGEX.ONLYDIGIT) ){
            message.error = `${translate.instant('Voucher code must be between')} ${voucherCodeMinLength} - ${voucherCodeMaxLength} ${translate.instant('digits')} `;
            isError = true;
          }
          else{
            message.error = null;
            message.success = '';
          }
        return isError ? errors : null;

    }
};


export function rechargeNumberValidator(persistenceService: PersistenceService, translate: TranslateService, message: any): ValidatorFn {
    return (control: FormControl): ValidationErrors | null => {
        let isError: boolean;
        const phoneNumber = control.value;
        const mobileNumberLength = parseInt(persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION)) || null;
        const mobileNumberMaxLength = parseInt(persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION)) || null;
        const maxRechargeLimit = parseInt(persistenceService.get(CMUICONFIGKEY.RECHARGE_LIMIT, StorageType.SESSION)) || null;
        let errors = {
            requiredError: false,
        };

        if (phoneNumber && mobileNumberLength && (phoneNumber.length < mobileNumberLength || phoneNumber.length > mobileNumberMaxLength) && phoneNumber.match(REGEX.ONLYDIGIT)) {
            if (mobileNumberLength != mobileNumberMaxLength) {
                message.error = `${translate.instant('Phone Number must be')} ${mobileNumberLength} -  ${mobileNumberMaxLength} ${translate.instant('digits')}`;
            } else {
                message.error = `${translate.instant('Phone Number must be')} ${mobileNumberLength} ${translate.instant('digits')}`;
            }
            message.sucess = null;
            isError = true;
        } else if (phoneNumber && !phoneNumber.match(REGEX.ONLYDIGIT)) {
            message.error = `${translate.instant('Only numbers are allowed')}`;
            message.sucess = null;
            isError = true;
        } 
        // else if (!phoneNumber) {
        //     message.error = `${translate.instant('Phone Number is required')}`;
        //     isError = true;
        // } 
        else {
            message.error = null;
            message.success = '';
        }

        return isError ? errors : null;

    }
};

