import { FormGroup, ValidationErrors, ValidatorFn } from "@angular/forms";
import { PersistenceService, StorageType } from "angular-persistence";
import { CMUICONFIGKEY } from 'dxp-common';
import { REGEX } from "../../../application-constants";

export function loginValidator(persistenceService: PersistenceService): ValidatorFn {
    return (control: FormGroup): ValidationErrors | null => {
        const username = control.get('username');
        const password = control.get('password');
        

        const phoneNumberLength = parseInt(persistenceService.get(
            CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION
        )) || null;
        const phoneNumberMaxLength = parseInt(persistenceService.get(
            CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION
        )) || null;
        let isError = false;
        let errors = {
            "usernameLengthError":false,
            "usernameRequiredError": false,
            "passwordRequiredError": false,
            "usernameFormatError": false,
            "usernameEmailFormatError": false,
            "generalError": false,
        }
         
        let formcontrolvalue = control.controls;

        if (username && !username.value && username.dirty) {
            errors.usernameRequiredError = true;
            isError = true;
        }

        if (password && !password.value && password.dirty) {
            errors.passwordRequiredError = true;
            isError = true;
        }
       

        if (username.value.trim().match(REGEX.ONLYDIGIT)) {
            if (username && username.value
                && phoneNumberLength && (username.value.trim().length < phoneNumberLength || username.value.trim().length > phoneNumberMaxLength)) {
                errors.usernameLengthError = true;
                isError = true;
            }

            if (username && username.value && !username.value.trim().match(REGEX.ONLYDIGIT)) {
                errors.usernameFormatError = true;
                isError = true;
            }
        }else{
            if (username && username.value && !username.value.trim().match(REGEX.EMAIL)) {
                errors.usernameEmailFormatError = true;
                isError = true;
            }
        }
        return isError ? errors : null;
    }
};
