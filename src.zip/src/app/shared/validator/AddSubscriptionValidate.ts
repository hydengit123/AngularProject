import { FormGroup, ValidationErrors, ValidatorFn } from "@angular/forms";
import { PersistenceService, StorageType } from "angular-persistence";
import { CMUICONFIGKEY } from 'dxp-common';
import { REGEX } from "../../../application-constants";

export function addSubscriptionValidator(persistenceService:PersistenceService): ValidatorFn {
  return (control: FormGroup): ValidationErrors | null => {
  const mobileNumber = control.get('mobileNumber');
  const verficationCode = control.get('verficationCode');
  const mobileNumberLength = parseInt(persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION)) || null;
  const mobileNumberMaxLength = parseInt(persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION)) || null;
  let isError=false;
  let errors={
    "mobileNumberRequiredError":false,
    "mobileNumberLengthError":false,
    "mobileNumberFormatError":false
  };

  let contactPhoneRegex = /^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$/g;


  if(mobileNumber && !mobileNumber.value && mobileNumber.dirty){
    errors.mobileNumberRequiredError = true;
    isError = true;
  }

  if(mobileNumber && mobileNumber.value &&  mobileNumberLength && (mobileNumber.value.length < mobileNumberLength || mobileNumber.value.length > mobileNumberMaxLength) && mobileNumber.value.match(REGEX.ONLYDIGIT) ){
    errors.mobileNumberLengthError = true;
    isError = true;
  }

  if(mobileNumber && mobileNumber.value &&  mobileNumberLength && (mobileNumber.value.length < mobileNumberLength || mobileNumber.value.length > mobileNumberMaxLength) && !mobileNumber.value.match(REGEX.ONLYDIGIT) ){
    errors.mobileNumberLengthError = false;
    isError = true;
  }

  if(mobileNumber && mobileNumber.value && !mobileNumber.value.match(REGEX.ONLYDIGIT) ){
    errors.mobileNumberFormatError = true;
    isError = true;
  }


  if((mobileNumber && !mobileNumber.value)) {
    isError = true;
  }

  return isError ? errors: null;
 
}
};
