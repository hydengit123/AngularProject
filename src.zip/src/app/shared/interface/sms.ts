
export interface Sms {
    unit: number;
    unitType: string;
  }
  