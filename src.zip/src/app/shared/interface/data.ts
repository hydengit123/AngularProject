export interface Data {
    unit: number;
    unitType: string;
  }
  