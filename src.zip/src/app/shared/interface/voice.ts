
export interface Voice {
    unit: number;
    unitType: string;
  }
  