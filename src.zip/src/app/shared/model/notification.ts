export class Notification {
    lastModifiedDate: string;
    time: string;
    deliveredMessage: string;
}