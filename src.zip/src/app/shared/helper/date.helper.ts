import * as moment from 'moment';
export class DateHelper {

    private static getFormattedDate(date: string) {
        let dtISOString = (date !== '') ? date : new Date().toISOString(),
            dtToks = dtISOString.split('T'),
            dateToks = dtToks[0].split("-"),
            timeToks = dtToks[1].split(":"),
            tzToks = timeToks[2].split("."),
            second = tzToks[0],
            timezone = tzToks[1];

        return {
            year: dateToks[0],
            month: dateToks[1],
            day: dateToks[2],
            hour: timeToks[0],
            minute: timeToks[1],
            second: second,
            timezone: timezone
        }
    }

    public static getDateTime(date: string = '') {
        return moment(date).format('YYYY-MM-DD h:mm:ss');
    }
}
