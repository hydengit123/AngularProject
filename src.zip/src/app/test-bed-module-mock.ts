import { Router } from '@angular/router';
import { Pipe, PipeTransform } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ReplaySubject } from 'rxjs';
import { ProductService } from './services/product.service';
import { DataClientService } from './data-client.service';
import { AuthService } from './services/auth.service';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { PersistenceService } from 'angular-persistence';
import { EventListenerService } from './event-listener.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ErrorsHandlerService } from './errors-handler.service';
import { CustomerOnboardService } from './services/customer-onboard.service';
import { FormMessageService } from './customer-onboarding/services/form-message.service';
import { MDBBootstrapModulesPro } from 'ng-uikit-pro-standard';

@Pipe({ name: 'translate' })
export class MockTranslatePipe implements PipeTransform {
    transform(value: number): number {
        return value;
    }
}

@Pipe({ name: 'getLocalTime' })
class MockGetLocalTimePipe implements PipeTransform {
    transform(value: number): number {
        // Do stuff here
        return value;
    }
}

@Pipe({ name: 'activePageRecords' })
export class CustomPaginatedCollectionPipe implements PipeTransform {
    transform(value: number): number {
        return value;
    }
}

@Pipe({ name: 'filterByKeys' })
export class CustomFilterByKeyPipe implements PipeTransform {
    transform(value: number): number {
        return value;
    }
}

@Pipe({ name: 'dataFormatter' })
class MockDataFormatterPipe implements PipeTransform {
    transform(value: number): number {
        return value;
    }
}

@Pipe({ name: 'pager' })
export class CustomPaginationPipe implements PipeTransform {
    transform(value: number): number {
        return value;
    }
}

export function testBedModule() {

    const spies = {
        RouterSpy: jasmine.createSpyObj('Router', ['navigate', 'root' ] ),
        PersistenceServiceSpy: jasmine.createSpyObj('PersistenceService', ['get', 'set', 'removeAll']),
        AuthServiceSpy: jasmine.createSpyObj('AuthService', ['logout']),
        ProductServiceSpy: jasmine.createSpyObj('ProductService', ['getPersonalisedOffers', 'getInsightURL', 'getAllProducts']),
        CustomerServiceSpy: jasmine.createSpyObj('CustomerService', ['getCustomerInfo']),
        DataClientServiceSpy: jasmine.createSpyObj('CustomerService', ['']),
        CustomerOnboardServiceSpy: jasmine.createSpyObj('CustomerOnBoardService', ['customerOnBoardingData']),
        FormMessageServiceSpy: jasmine.createSpyObj('FormMessageService', ['getFormDataFromParent']),

        EventListenerServiceSpy: {
            profileEvent: {
                subscribe: jasmine.createSpy()
            },
            lanuageChangeEvent: {
                subscribe: jasmine.createSpy()
            }
        },
        TranslateServiceSpy: {
            setDefaultLang: () => { },
            getBrowserCultureLang: () => 'de-DE',
            use: () => new ReplaySubject(1),
            instant: ( key ) => key,
        }
    };

    const testBedModules: any = {
        imports: [
            // RouterTestingModule,
            ReactiveFormsModule,
            FormsModule,
            HttpClientTestingModule,
            MDBBootstrapModulesPro.forRoot(),
        ],
        declarations: [
            MockTranslatePipe,
            MockGetLocalTimePipe,
            CustomPaginatedCollectionPipe,
            CustomFilterByKeyPipe,
            CustomPaginationPipe
        ],
        providers: [
            { provide: Router, useValue: spies.RouterSpy },
            { provide: TranslateService, useValue: spies.TranslateServiceSpy },
            { provide: ProductService, useValue: spies.ProductServiceSpy },
            { provide: DataClientService, useValue: spies.DataClientServiceSpy },
            { provide: AuthService, useValue: spies.AuthServiceSpy },
            { provide: PersistenceService, useValue: spies.PersistenceServiceSpy },
            { provide: EventListenerService, useValue: spies.EventListenerServiceSpy },
            { provide: Router, useValue: spies.RouterSpy },
            { provide: CustomerOnboardService, useValue: spies.CustomerOnboardServiceSpy },
            FormBuilder,
            ErrorsHandlerService,
            FormMessageService
        ]
    };

    return {
        testBedModules: testBedModules,
        spies: spies
    };
}
