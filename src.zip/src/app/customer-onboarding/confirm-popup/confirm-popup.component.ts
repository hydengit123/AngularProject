import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY, customerOnboard } from 'dxp-common';
import { PERSISTANCEKEY } from '../../../application-constants';
import { EventListenerService } from '../../event-listener.service';
import { CartService } from '../../services/cart.service';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { PaymentGatewayService } from '../../services/payment-gateway.service';
import { FormMessageService } from '../services/form-message.service';

@Component({
  selector: 'app-confirm-popup',
  templateUrl: './confirm-popup.component.html',
  styleUrls: ['./confirm-popup.component.scss']
})
export class ConfirmPopupComponent implements OnInit {

  public customerOnboardService: CustomerOnboardService;
  public formMessageService: FormMessageService;
  public retainState:boolean;

  constructor(private router: Router,
    private eventListenerService: EventListenerService,
    private paymentGatewayService: PaymentGatewayService,
    private persistenceService: PersistenceService,
    private cartService:CartService
    ) { }

    ngOnInit() {
    }

    onDiscard() {
      this.formMessageService.onboardingForm.reset();
      this.eventListenerService.closeCustomerOnBoardPopup();
      this.cartService.cartDetails = null;
     // const allLanguages = this.persistenceService.get(CMUICONFIGKEY.LANGUAGES, StorageType.SESSION);
     // const allLocations = this.persistenceService.get(CMUICONFIGKEY.LOCATION, StorageType.SESSION);
     // const allPlans = this.persistenceService.get(CMUICONFIGKEY.NUMBEROFPLANSPERPAGE, StorageType.SESSION);
      this.persistenceService.remove(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
      this.persistenceService.remove(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
      this.persistenceService.remove(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
      this.router.navigate(['/public']);
    }

    onSave() {

      const onBoardData = this.formMessageService.onboardingForm.value as customerOnboard;
      if(onBoardData && onBoardData.journeySessionId){
        this.customerOnboardService.updateSaveCartJourneySessionInteraction(onBoardData,this.cartService.cartDetails, null).subscribe((data)=>{
          this.eventListenerService.closeCustomerOnBoardPopup();

          this.router.navigate(['/public']);
          this.cartService.cartDetails = null;
          this.formMessageService.onboardingForm.reset();
          this.formMessageService.saveCartForm.reset();

        });
      }
      else{
        this.eventListenerService.saveCartDetailsPopup(this.customerOnboardService, this.formMessageService, this.retainState);
        this.formMessageService.saveCartForm.reset();
      }

    }

}
