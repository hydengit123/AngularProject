import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY, customerOnboard } from 'dxp-common';
import { ONBOARDPERSISTANCEKEY } from '../../../application-constants';
import { CartService } from '../../services/cart.service';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { FormMessageService } from '../services/form-message.service';
import { EventEnum } from './../../enum/EventEnum';
import { EventListenerService } from './../../event-listener.service';

declare const alertify;

@Component({
  selector: 'app-stepper',
  templateUrl: './app-stepper.component.html',
  styleUrls: ['./app-stepper.component.scss']
})
export class StepperComponent implements OnInit {

  @Input() step: string;
  enableRegister = false;
  enableAddOn = false;
  enableDelivery = false;
  enableMsisdn = false;
  enableCheckout = false;
  selectedTitle: string;
  stepperHide: Boolean = false;
  onboardingForm: FormGroup;
  enableValidation: Boolean = true;
  fraudcheckOption: string;
  enableOTP: Boolean;



  @Input() stock: number;
  constructor(private router: Router,
    private persistenceService: PersistenceService,
    private translate: TranslateService,
    private customerOnBoardService: CustomerOnboardService,
    private formMessageService: FormMessageService,
    private eventListenerService: EventListenerService,
    private cartService: CartService) { }

  ngOnInit() {
    this.eventListenerService.lanuageChangeEvent.subscribe(data => {
      if (data && data === EventEnum.languageUpdated) {
        this.setTitle(this.step);
      }
    });
    this.eventListenerService.updateStepperInfoEvent.subscribe(data => {
      //this.eventListenerService.closeCustomerOnBoardPopupEvent.closeCustomerOnBoardPopup();
      if (data && data.eventType == EventEnum.stepperUpdated && data.step) {
        if (data.step == 99) {
          this.stepperHide = true;
        } else {
          this.stepperHide = false;
        }
        this.openRoute(data.step.toString());
      }
    });
    this.enableRegister = this.persistenceService.get(ONBOARDPERSISTANCEKEY.ENABLEREGISTER, StorageType.SESSION);
    this.enableDelivery = this.persistenceService.get(ONBOARDPERSISTANCEKEY.ENABLEDELIVERY, StorageType.SESSION);
    this.enableCheckout = this.persistenceService.get(ONBOARDPERSISTANCEKEY.ENABLECHECKOUT, StorageType.SESSION);
    this.enableAddOn = this.persistenceService.get(ONBOARDPERSISTANCEKEY.ENABLEADDON, StorageType.SESSION);
    this.setStep(this.router.url);
    this.stepperShowHide();
    this.enableOTP = this.persistenceService.get(CMUICONFIGKEY.ENABLEOTP, StorageType.SESSION);

  }

  setStep(url) {
    let isValid: boolean = false;
    this.enableValidation = this.checkValidationStatus();
    switch (url) {
      case '/customerOnboard/ActivationDetails':
        this.step = '1';
        break;
      case '/customerOnboard/Plan':
        if (this.enableValidation) {
          this.formMessageService.validateActivationDetails(2);
          this.step = '1';
          this.openRoute(1);
        } else {
          this.step = '2';
          this.openRoute(2);
        }
        break;
      case '/customerOnboard/AdditionalServices':
        if (this.enableValidation) {
          this.formMessageService.validateActivationDetails(3);
          this.step = '1';
          this.openRoute(1);
        } else {
          this.step = '3';
          this.openRoute(3);
        }
        break;
      case '/customerOnboard/ContactDetails':
        if (this.enableValidation) {
          this.formMessageService.validateActivationDetails(4);
          this.step = '1';
          this.openRoute(1);
        } else {
          this.step = '4';
          this.openRoute(4);
        }
        break;
      // case '/customerOnboard/AccountDetails':
      // this.step = '5';
      // break;
      case '/customerOnboard/checkout':
        if (this.enableValidation) {
          this.formMessageService.validateActivationDetails(5);
          this.step = '1';
          this.openRoute(1);
        } else {
          this.step = '5';
          this.openRoute(5);
        }
        break;
      default:
        this.step = '1';
        break;
    }
    this.setTitle(this.step);
  }

  openRoute(step) {
    let routeUrl = '';
    this.step = step;
    //this line is important for saving the journey
    if (parseInt(step) >= 1 && parseInt(step) <= 5) {
      this.formMessageService.onboardingForm.controls.currentStep.setValue(parseInt(step));
      //initiate implicit save 
      this.formMessageService.implictSaveJourney();
    }
    this.setTitle(this.step);
    routeUrl = this.formMessageService.getStepURL(step);
    this.router.navigate(routeUrl.split('/'));
  }

  setTitle(step) {
    let title = '';
    switch (parseInt(step)) {
      case 1:
        title = 'Activation Details';
        break;
      case 2:
        title = 'Plan';
        break;
      case 3:
        title = 'Add Ons';
        break;
      case 4:
        title = 'Contact Details';
        break;
      // case 5:
      // title = 'Account Details';
      // break;
      case 5:
        title = 'Checkout';
        break;
      default:
        title = 'Activation Details';
        break;
    }
    this.selectedTitle = this.translate.instant(title);
  }

  onBackButtonClicked() {
    if (this.step != '1') {
      let stepp = parseInt(this.step);
      stepp--;
      this.step = stepp.toString();
      this.openRoute(this.step);
    }
  }



  async onNextButtonClicked() {
    let isValid: boolean = false;
    this.enableValidation = this.checkValidationStatus();
    switch (parseInt(this.step)) {
      case 1:
        if (this.enableValidation) {
          this.formMessageService.validateActivationDetails(2);
        } else isValid = true;
        break;
      case 2:
        this.formMessageService.validatePlanSelection(3);
        break;
      case 3:
        isValid = true;//no vlaidation for add on when user clicks next button
        break;
      case 4:
        if (this.enableValidation) {
          if (this.formMessageService.validateContactDetails()) {
            isValid = true;
          }
        } else isValid = true;
        break;
    }
    if (this.step != '6' && isValid) {
      let stepp = parseInt(this.step);
      stepp++;
      this.step = stepp.toString();
      this.openRoute(this.step);
    }
  }

  onCancelButtonClicked() {
    this.eventListenerService.customerIsAbortingJourney();
  }

  async onSaveButtonClicked() {
    //enforce explict save by retaining state
    if (this.cartService.cartDetails && this.cartService.cartDetails.cartList
      && this.cartService.cartDetails.cartList.length > 0) {
      const customerOnBoardData: customerOnboard = this.formMessageService.onboardingForm.value as customerOnboard;
      if (customerOnBoardData && customerOnBoardData.journeySessionId) {
        const saveCartWithJourneySessionData = await this.customerOnBoardService.updateSaveCartJourneySessionInteraction(this.formMessageService.onboardingForm.value,
          this.cartService.cartDetails, null).toPromise();
          alertify.success(this.translate.instant('Saved Journey'));
      }
      else {
        this.eventListenerService.customerIsSavingJourneyExplicitly(true);
      }
    }
  }

  stepperShowHide() {
    if (this.router.url.indexOf('/customerOnboard/ContinueJourney') != -1) {
      this.stepperHide = true;
    } else {
      this.stepperHide = false;
    }
  }

  checkValidationStatus() {
    this.onboardingForm = this.formMessageService.onboardingForm;
    if (this.onboardingForm && this.onboardingForm.controls.journeySessionId.value) {
      return false;
    } else {
      return true;
    }
  }

  moveToStep(step) {
    let currentStep = this.step;
  }

  disableStatusCheck() {
    this.fraudcheckOption = this.persistenceService.get(CMUICONFIGKEY.FRAUDCHECKOPTION, StorageType.SESSION);
    if (this.step == "1" && (this.formMessageService.activationDetails.status == "PENDING" || this.formMessageService.activationDetails.status == "INVALID" || !this.formMessageService.activationDetails.controls.phoneNumber.value || !this.formMessageService.activationDetails.controls.simCardNumber.value || !this.formMessageService.activationDetails.controls.location.value || (this.fraudcheckOption == 'ACTIVATION_CODE_REQUIRED' && !this.formMessageService.activationDetails.controls.activationCode.value))) {
      return true;
    } else if (this.step == "4" && (this.formMessageService.contactDetails.status == "PENDING" || this.formMessageService.contactDetails.status == "INVALID" || (this.formMessageService.signUInfo.errors && !this.enableOTP) || !this.formMessageService.personalInformation.controls.firstName.value || !this.formMessageService.personalInformation.controls.lastName.value || !this.formMessageService.personalInformation.controls.email.value || !this.formMessageService.personalInformation.controls.contactPhone.value || !this.formMessageService.personalInformation.controls.prefferedLanguage.value || !this.formMessageService.personalInformation.controls.dateOfBirth.value)) {
      return true;
    } else return false;
  }


}
