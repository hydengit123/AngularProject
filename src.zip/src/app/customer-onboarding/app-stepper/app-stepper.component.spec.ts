import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StepperComponent } from './app-stepper.component';
import { testBedModule } from '../../test-bed-module-mock';

describe('StepperComponent', () => {
  let component: StepperComponent;
  let fixture: ComponentFixture<StepperComponent>;
  const testBedModules = testBedModule().testBedModules;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StepperComponent, ...testBedModules.declarations],
      providers: [...testBedModules.providers],
      imports: [...testBedModules.imports],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
