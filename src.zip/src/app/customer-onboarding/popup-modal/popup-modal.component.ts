import { Component, OnInit, ComponentFactoryResolver, ViewContainerRef, Input, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { EventListenerService } from '../../event-listener.service';
import { ModalDirective } from 'ng-uikit-pro-standard';
import { TranslateService } from '@ngx-translate/core';
import { SaveCartDetailsComponent } from '../save-cart-details/save-cart-details.component';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { FormMessageService } from '../services/form-message.service';
import { ConfirmPopupComponent } from '../confirm-popup/confirm-popup.component';
import { EventEnum } from '../../enum/EventEnum';
import { PaymentGatewayService } from '../../services/payment-gateway.service';
import { CustomerSearchDataService } from '../../services/customer-search-data.service';
import { StorageType, PersistenceService } from 'angular-persistence';
import { Router } from '@angular/router';
import { PERSISTANCEKEY } from '../../../application-constants';
import { CartService } from '../../services/cart.service';
@Component({
  selector: 'app-popup-modal',
  templateUrl: './popup-modal.component.html',
  styleUrls: ['./popup-modal.component.scss']
})
export class PopupModalComponent implements OnInit {
 
  public title: string;
  public popUpSize: Boolean = true;

  @ViewChild('modalBody', {read:ViewContainerRef}) modalBody: ViewContainerRef;
  @ViewChild('modalFooter', {read:ViewContainerRef}) modalFooter: ViewContainerRef;
  @Input() modalBodyComponent:any;
  @ViewChild('basicModal') basicModal:ModalDirective;
  showImage: boolean = true;
  public retainState: boolean;
  
  constructor(private componentFactoryResolver: ComponentFactoryResolver,
    private eventService:EventListenerService,
    private translateService:TranslateService,
    private paymentGatewayService: PaymentGatewayService,
    private customerSearchDataService: CustomerSearchDataService,
    private persistenceService: PersistenceService,
    private router:Router,
    private formMessageService: FormMessageService,
    private customerOnboardService: CustomerOnboardService,
    private cartService: CartService
  ) { 
    }

  onClose(e){
    this.basicModal.hide();
    
  }

  // whenPopUpShown(popup:any){
  //   popup.removeBackdrop();
  // }


  ngOnInit() {
    //this.basicModal.config = {backdrop:false};

    this.eventService.saveCartDetailsPopupEvent.subscribe(d=>{

      const accessToken = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
      const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
      const customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
     const username =  this.persistenceService.get(PERSISTANCEKEY.REGISTEREMAILMSISDN, StorageType.SESSION );
  
     
     if(d && d.eventType === EventEnum.saveCartDetails){
        if(accessToken && partyId && customerId && username){
          this.save(username, customerId, partyId);
        }
        else  {
          this.showSaveCartDetailsPopup(d.customerOnBoard, d.formMessage, d.retainState);
        }
      }
     
      
    });

    //closing popup modal
    this.eventService.closeCustomerOnBoardPopupEvent.subscribe(d=>{
      this.basicModal.hide();
    })

    this.eventService.confirmPopupEvent.subscribe(d => {
      if(d && d.eventType === EventEnum.confirmPopup){
        this.showConfirmPopup(d.customerOnBoard, d.formMessage, d.retainState);
      }
    });
    
  }

  async save(username, customerIdparam, partyID) {
    this.formMessageService.onboardingForm.controls.partyId.setValue(partyID);
    this.formMessageService.onboardingForm.controls.userId.setValue(username);
    this.formMessageService.onboardingForm.controls.customerId.setValue(customerIdparam);

    const saveCartWithJourneySessionData = await this.customerOnboardService.createSaveCartJourneySessionInteraction(this.formMessageService.onboardingForm.value,
    this.cartService.cartDetails, null).toPromise();

    this.eventService.closeCustomerOnBoardPopup();
    if (!this.retainState) {
      this.persistenceService.removeAll(StorageType.SESSION);
      this.router.navigate(['/public']);
    }
    this.formMessageService.onboardingForm.reset();


  }


  showSaveCartDetailsPopup(customerOnBoard:CustomerOnboardService, formMessage:FormMessageService, retainState:boolean){
    this.popUpSize = false;
    //set title
    this.title = this.translateService.instant("Save");

    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(SaveCartDetailsComponent);

    let viewContainerRef = this.modalBody;
    viewContainerRef.clear();

    

    let componentRef: any = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.basicModal = this.basicModal;
    componentRef.instance.formMessageService = formMessage;
    componentRef.instance.customerOnboardService = customerOnBoard;
    componentRef.instance.retainState = retainState;
    this.basicModal.show();
}

showConfirmPopup(customerOnBoard:CustomerOnboardService, formMessage:FormMessageService, retainState:boolean){
  // set title
  this.popUpSize = true;
  this.title = this.translateService.instant('Confirmation');
  const componentFactory = this.componentFactoryResolver.resolveComponentFactory(ConfirmPopupComponent);
  const viewContainerRef = this.modalBody;
  viewContainerRef.clear();
  const componentRef = viewContainerRef.createComponent(componentFactory);
  componentRef.instance.formMessageService = formMessage;
  componentRef.instance.customerOnboardService = customerOnBoard;
  componentRef.instance.retainState = retainState;
  this.basicModal.show();
}

ngOnDestroy(){
  this.basicModal.hide();
}

}
