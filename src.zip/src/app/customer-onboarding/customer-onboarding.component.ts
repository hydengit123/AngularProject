import { CurrencyPipe } from '@angular/common';
import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { Subscription } from 'rxjs';
import { ANNONYMOUSUSER, LOCALIZATIONPERSISTANCEKEY, PERSISTANCEKEY, WEBCONTENTPERSISTANCEKEY } from '../../application-constants';
import { environment } from '../../environments/environment';
import { EventEnum } from '../enum/EventEnum';
import { EventListenerService } from '../event-listener.service';
import { WebContent } from '../interface/web.content';
import { CartService } from '../services/cart.service';
import { CMSContentService } from '../services/cms-content.service';
import { CustomerOnboardService } from '../services/customer-onboard.service';
import { FormMessageService } from './services/form-message.service';


@Component({
  selector: 'customer-onboarding',
  templateUrl: './customer-onboarding.component.html',
  styleUrls: ['./customer-onboarding.component.scss'],
  providers: [CMSContentService, CurrencyPipe]
})
export class CustomerOnboardingComponent implements OnInit, OnDestroy {
  webContent: WebContent;
  public bkimg;
  isRTL: boolean = false;
  formSubscription: Subscription;
  formDataFromAPI: any;
  customerOnBoardingSubscription: Subscription;
  implicitSaveSubscription: Subscription;

  onboardingForm: FormGroup;
  isDebug: boolean;
  url: any;
  loggedIn: boolean = false;


  constructor(private cmsService: CMSContentService,
    private translate: TranslateService,
    private persistenceService: PersistenceService,
    private formBuilder: FormBuilder,
    private formMessageService: FormMessageService,
    private customerOnBoardService: CustomerOnboardService,
    private event: EventListenerService,
    private router: Router,
    private cartService: CartService) {
    this.webContent = this.persistenceService.get(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, StorageType.SESSION);
    if (this.webContent && this.webContent.footerImage) {
      this.bkimg = this.webContent.footerImage.url;
    }

    this.event.lanuageChangeEvent.subscribe(data => {
      if (data && data.eventType && data.eventType === EventEnum.languageUpdated) {
        const language = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
        this.loadLanguage(language);
      }
    });

    this.onboardingForm = this.formMessageService.onboardingForm;
  }

  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler($event) {
    //trigger implicit save logic in service file
    this.formMessageService.implictSaveJourney();
    $event.returnValue = this.event.customerIsAbortingJourney();
    return (this.translate.instant('Changes you made may not be saved.'));
  }

  ngOnInit() {
    const accessToken = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
    const dummyToken = this.persistenceService.get(PERSISTANCEKEY.DUMMYTOKEN, StorageType.SESSION);
    this.url = this.router.url;
    this.isDebug = environment.enableDebug;
    if (accessToken) {
      this.loggedIn = this.formMessageService.isUserLoggedIn = true;
      // route it to step
    } else if (dummyToken) {
      this.loggedIn = this.formMessageService.isUserLoggedIn = false;
    } else {
      this.loggedIn = this.formMessageService.isUserLoggedIn = false;
      this.customerOnBoardService.loginDummyUser(ANNONYMOUSUSER.USERNAME, ANNONYMOUSUSER.PASSWORD).subscribe(data => {
        this.persistenceService.set(PERSISTANCEKEY.DUMMYTOKEN, data.access_token, { type: StorageType.SESSION });
      });
    }

    // implict save listener
    // this.onboardingForm.valueChanges.subscribe(data => {
    //   this.implictSaveJourney();
    // });
    this.event.notifyCartUpdateEvent.subscribe((data) => {
      if (data && data.eventType) {
        if (data.eventType === EventEnum.notifyCartUpdated) {
          this.formMessageService.implictSaveJourney();
        }
      }
    });
    // implict save listener
  }

  

  get formValidate() {
    return this.onboardingForm.controls;
  }

  loadLanguage(language: string) {
    this.translate.use(language).subscribe(
      (res) => {
        //check for RTL
      }
    );

  }

  onBoardingFormSubmit(e) {
    if (this.onboardingForm.invalid) {
      return;
    }
  }


  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    // this.formSubscription.unsubscribe();
    // this.customerOnBoardingSubscription.unsubscribe();
  }
}
