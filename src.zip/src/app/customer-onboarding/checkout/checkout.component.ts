import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { cartDetails, CMUICONFIGKEY, customerOnboard, PaymentRequestInfo, PRICETYPE } from 'dxp-common';
import { Subscription } from 'rxjs';
import { } from '../../../application-constants';
import { CartService } from '../../services/cart.service';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { CustomerSearchService } from '../../services/customer-search.service';
import { DealsForYouService } from '../../services/dfy.service';
import { PaymentGatewayService } from '../../services/payment-gateway.service';
import { ShareWithConsumerService } from '../../services/share-with-consumer.service';
import { FormMessageService } from '../services/form-message.service';
import { EventEnum } from './../../enum/EventEnum';
import { EventListenerService } from './../../event-listener.service';

declare const alertify;

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit, OnDestroy {
  public notifyCartUpdatedEventEnum: number = EventEnum.notifyCartUpdated;
  public paymentGateWayList: any;
  public showPaymentList: boolean;
  public contactDetails: any;
  public onBoardData: customerOnboard;
  public enablePayment: boolean;
  private abortJourney: Subscription;
  private saveJourney: Subscription;
  public setOneTimeCol: boolean = true;
  public paymentRequestInfo: PaymentRequestInfo = {
    key: '',
    hash: '',
    txnid: '',
    amount: 0,
    productinfo: '',
    firstname: '',
    lastname: '',
    email: '',
    phone: '',
    surl: '',
    furl: '',
    address1: '',
    address2: '',
    city: '',
    state: '',
    country: '',
    zipcode: '',
    salt: ''
  };
  constructor(public paymentService: PaymentGatewayService,
    public formService: FormMessageService,
    public router: Router,
    public eventListenerService: EventListenerService,
    public translateService: TranslateService,
    public customerOnBoardService: CustomerOnboardService,
    public formMessageService: FormMessageService,
    public cartService: CartService,
    public shareWithConsumerService: ShareWithConsumerService,
    public customerSearchService: CustomerSearchService,
    public dealsForYouService: DealsForYouService,
    public persistenceService: PersistenceService) { }
  ngOnInit() {
    this.contactDetails = this.formService.contactDetails.value;
    this.paymentService.paymentGatewayList().subscribe(data => {
      this.paymentGateWayList = data;
      this.showPaymentList = this.paymentGateWayList && this.paymentGateWayList.length && this.paymentGateWayList.length > 1;
    });
    this.onBoardData = this.formService.onboardingForm.value;
    this.paymentRequestInfo.address1 = this.onBoardData.contactDetails.address.addressLine1;
    this.paymentRequestInfo.address2 = this.onBoardData.contactDetails.address.addressLine2;
    this.paymentRequestInfo.city = this.onBoardData.contactDetails.address.city;
    // this.paymentRequestInfo.country = this.formService.address.value.addressLine1;
    this.paymentRequestInfo.email = this.onBoardData.contactDetails.personalInformation.email;
    this.paymentRequestInfo.firstname = this.onBoardData.contactDetails.personalInformation.firstName;
    this.paymentRequestInfo.lastname = this.onBoardData.contactDetails.personalInformation.lastName;
    this.paymentRequestInfo.phone = this.onBoardData.contactDetails.personalInformation.contactPhone;
    // this.paymentRequestInfo.state =
    // when customer clicks cancel to abort journey
    this.abortJourney = this.eventListenerService.customerOnAbortJourneyEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.customerOnAbortJourney) {
        if (this.cartService.cartDetails && this.cartService.cartDetails.cartList
          && this.cartService.cartDetails.cartList.length > 0) {
          this.eventListenerService.confirmPopup(this.customerOnBoardService, this.formMessageService, data.retainState);
        } else {
          this.router.navigate(['/public']);
        }
      }
    });

    this.saveJourney = this.eventListenerService.customerOnSaveJourneyExplicitlyEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.customerOnSaveJourneyExplicitly && data.retainState) {
        this.eventListenerService.saveCartDetailsPopup(this.customerOnBoardService, this.formMessageService, data.retainState);
        this.formMessageService.saveCartForm.reset();
      }
    });
  }
  onCartUpdated(cartDetails: cartDetails) {
    if (cartDetails && cartDetails.totalPrice && cartDetails.totalPrice.length > 0) {
      const isTotalPrice = cartDetails.totalPrice.filter(x => x.price.amount > 0);
      if (isTotalPrice && isTotalPrice.length > 0) {
        this.enablePayment = true;
      } else {
        this.enablePayment = false;
      }
    }
  }
  async validateContract() {
    const validatedContract = await this.shareWithConsumerService.validateMSISDN('msisdn', this.onBoardData.activationDetails.phoneNumber).toPromise();
    return validatedContract[0].status.toLowerCase() === 'active' ? false : true;
  }
  async doPayment(e) {
    const selectedPayments = this.paymentGateWayList.filter(item => item.checked === true);
    if (selectedPayments && selectedPayments[0] && selectedPayments[0].value) {
      const isInvalidPlanOrAddOn = await this.isThereInvalidPlanOrAddOns();
      if (!isInvalidPlanOrAddOn) {
        const onboardData = this.formService.onboardingForm.value;
        const successURL = '/customerOnboard/paymentsuccessful';
        const failureURL = '/customerOnboard/paymentsuccessful';
        this.paymentRequestInfo.amount = this.cartService.getTotalPrice(PRICETYPE.ONETIME);
        this.paymentRequestInfo.productinfo = 'ProductItem';
        this.paymentRequestInfo.firstname = onboardData.contactDetails.personalInformation.firstName;
        this.paymentRequestInfo.lastname = onboardData.contactDetails.personalInformation.lastName;
        this.paymentRequestInfo.email = onboardData.contactDetails.personalInformation.email;
        this.paymentService.launchPaymentBolt(this.paymentRequestInfo,
          selectedPayments[0].value,
          onboardData.activationDetails.phoneNumber,
          this.cartService.cartDetails.cartList[0].itemPrice[0].price.currency,
          successURL,
          failureURL,
          this.customerOnBoardService.paymentResponseHandler(onboardData, this.paymentRequestInfo)
        );
      }
    }
    else {
      alertify.error(this.translateService.instant('Please Select Payment Option'));
    }
  }
  private async isThereInvalidPlanOrAddOns(): Promise<boolean> {
    const productCategory = this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMES_FORADDONQUERY, StorageType.SESSION).concat(this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMESFORVASEOFFERQUERY, StorageType.SESSION));
    const isInvalidPlanOrAddOn = await this.cartService.isInvalidPlanOrAddonAvailableInCart(productCategory, (this.formMessageService.onboardingForm.value as customerOnboard).activationDetails.location);
    const cartDetails = this.cartService.cartDetails;
    //to refresh cart list
    this.eventListenerService.notifyCartUpdate(cartDetails);
    const invalidMessageOnPlan = this.formMessageService.showAlertOnInvalidPlan(cartDetails);
    if (invalidMessageOnPlan) {
      alertify.error(invalidMessageOnPlan.invalidMessage);
      if (invalidMessageOnPlan.allowActivation) {
        return false;
      }
    }
    return isInvalidPlanOrAddOn;
  }
  async submitCustomerInteraction(e) {
    const isInvalidPlanOrAddOn = await this.isThereInvalidPlanOrAddOns();
    if (!isInvalidPlanOrAddOn) {
      this.customerOnBoardService.createCustomerInteraction(this.formService.onboardingForm.value,
        null).subscribe(res => {
          this.customerOnBoardService.redirectToSucessView(res);
        });
    }
  }
  paymentGatewayRadioClicked(paymentGatewaySelected) {
    const list = this.paymentGateWayList.map(d => {
      d.value === paymentGatewaySelected.value ? d.checked = !d.checked : d.checked = false;
      return d;
    });
    this.paymentGateWayList = [...list];
  }
  onCancelButtonClicked() {
    this.eventListenerService.customerIsAbortingJourney();
  }
  onBackButtonClicked() {
    this.eventListenerService.updateStepperInfo(4);
  }

  ngOnDestroy() {
    if (this.abortJourney) {
      this.abortJourney.unsubscribe();
    }
    if (this.saveJourney) {
      this.saveJourney.unsubscribe();
    }
  }
}