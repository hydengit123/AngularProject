import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivationDetailsComponent } from './activation-details.component';
import { testBedModule } from '../../test-bed-module-mock';

describe('ActivationDetailsComponent', () => {
  let component: ActivationDetailsComponent;
  let fixture: ComponentFixture<ActivationDetailsComponent>;
  const testBedModules = testBedModule().testBedModules;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ActivationDetailsComponent, ...testBedModules.declarations],
      providers: [...testBedModules.providers],
      imports: [...testBedModules.imports],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivationDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
