import { Component, ElementRef, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY } from 'dxp-common';
import { Subscription } from 'rxjs';
import { EventListenerService } from '../../event-listener.service';
import { CartService } from '../../services/cart.service';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { FormMessageService } from '../services/form-message.service';
import { activationDetailsValidator } from '../validation/ActivationDetailsValidate';
import { EventEnum } from './../../enum/EventEnum';


@Component({
  selector: 'app-activation-details',
  templateUrl: './activation-details.component.html',
  styleUrls: ['./activation-details.component.scss'],
  encapsulation: ViewEncapsulation.None,
})

export class ActivationDetailsComponent implements OnInit, OnDestroy {
  @ViewChild('phonenumber') private elementRef: ElementRef;
  submitted = false;
  activationDetails: FormGroup;
  activationCodeLength: number;
  phoneNumberLength: number;
  phoneNumberMaxLength: number;
  simCardNumberLength: number;
  simCardNumberMaxLength: number;
  fraudcheckOption: string;
  locationSelect: Array<any>;
  abortJourney: Subscription;
  saveJourney: Subscription;
  languageChange: Subscription;
  onboardingForm: FormGroup;
  enableField: Boolean = true;



  constructor(private router: Router,
    private formBuilder: FormBuilder,
    private formMessageService: FormMessageService,
    private customerOnBoardingService: CustomerOnboardService,
    private persistenceService: PersistenceService,
    private translate: TranslateService,
    private event: EventListenerService,
    private cartService: CartService) {
    this.activationDetails = this.formMessageService.activationDetails;
    this.onboardingForm = this.formMessageService.onboardingForm;
  }

  ngOnInit() {

    this.onboardingForm = this.formMessageService.onboardingForm;
    if ((this.onboardingForm && this.onboardingForm.controls.journeySessionId.value) || (this.onboardingForm && this.onboardingForm.controls.shoppingCartId.value)) {
      this.enableField = false;
    } else this.enableField = true;
    this.languageChange = this.event.lanuageChangeEvent.subscribe(data => {
      if (data && data.eventType && data.eventType === EventEnum.languageUpdated) {
        this.locationSelect = this.getLocations();
      }
    });

    //populate location drop down values
    this.locationSelect = this.getLocations();

    //get length for activation code
    this.activationCodeLength = this.persistenceService.get(CMUICONFIGKEY.ACTIVATIONCODELENGTH, StorageType.SESSION);
    this.phoneNumberLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION);
    this.phoneNumberMaxLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION);
    this.simCardNumberLength = this.persistenceService.get(CMUICONFIGKEY.MINLENGTH, StorageType.SESSION);
    this.simCardNumberMaxLength = this.persistenceService.get(CMUICONFIGKEY.MAXLENGTH, StorageType.SESSION);
    this.fraudcheckOption = this.persistenceService.get(CMUICONFIGKEY.FRAUDCHECKOPTION, StorageType.SESSION);

    //when customer clicks cancel to abort journey
    this.abortJourney = this.event.customerOnAbortJourneyEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.customerOnAbortJourney) {
        if (this.cartService.cartDetails && this.cartService.cartDetails.cartList
          && this.cartService.cartDetails.cartList.length > 0) {
          this.event.confirmPopup(this.customerOnBoardingService, this.formMessageService, data.retainState);
        }
        else {
          this.formMessageService.onboardingForm.reset();
          this.formMessageService.saveCartForm.reset();
          this.router.navigate(['/public']);
        }
      }
    });
    this.saveJourney = this.event.customerOnSaveJourneyExplicitlyEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.customerOnSaveJourneyExplicitly && data.retainState) {
        this.event.saveCartDetailsPopup(this.customerOnBoardingService, this.formMessageService, data.retainState);
        this.formMessageService.saveCartForm.reset();
      }
    });
    // Updating the stepper when Activate Sim is clicked in between journey
    this.event.updateStepperInfo('1');
  }

  getLocations() {
    let allLocation = this.persistenceService.get(CMUICONFIGKEY.LOCATION, StorageType.SESSION);
    if (allLocation) {
      let locationSelect = allLocation.map(item => {
        return { value: item.locationCode, label: this.translate.instant(item.locationName) };
      });
      return locationSelect;
    }
  }

  redirectTo(route) {
    this.router.navigate(route.split('/'));
  }

  ngOnDestroy() {
    if (this.abortJourney) {
      this.abortJourney.unsubscribe();
    }
    if (this.saveJourney) {
      this.saveJourney.unsubscribe();
    }
    if (this.languageChange) {
      this.languageChange.unsubscribe();
    }
  }

  // convenience getter for easy access to form fields
  get formValidate() {
    return this.activationDetails;
  }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.activationDetails.invalid) {
      return;
    }
    this.router.navigate(['/customerOnboard/Plan']);
  }

  ngAfterViewInit() {
    if (this.elementRef && this.elementRef.nativeElement) {
      this.elementRef.nativeElement.focus();
    }
  }

  onBlurValidation(fieldName) {
    activationDetailsValidator(this.persistenceService);
    let isError = false;
    const errors = this.activationDetails.errors;
    const phoneNumber = this.formMessageService.activationDetails.controls.phoneNumber.touched;
    const simCardNumber = this.formMessageService.activationDetails.controls.simCardNumber.touched;
    const activationCode = this.formMessageService.activationDetails.controls.activationCode.touched;
    const location = this.formMessageService.activationDetails.controls.location.touched;

    if (fieldName && !this.formMessageService.activationDetails.controls[fieldName].value) {
      errors[fieldName + 'RequiredError'] = true;
      isError = true;
    }
  }

}
