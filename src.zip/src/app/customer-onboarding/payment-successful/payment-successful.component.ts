import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PaymentGatewayService } from '../../services/payment-gateway.service';
import { FormMessageService } from '../services/form-message.service';
import { EventListenerService } from '../../event-listener.service';
import { PersistenceService, StorageType } from 'angular-persistence';
import { PERSISTANCEKEY } from '../../../application-constants';
import { CartService } from '../../services/cart.service';

@Component({
  selector: 'app-payment-successful',
  templateUrl: './payment-successful.component.html',
  styleUrls: ['./payment-successful.component.scss']
})
export class PaymentSuccessfulComponent implements OnInit {
  public orderId: string;
  public flag: boolean = false;

  constructor(private paymentGateWayService: PaymentGatewayService,
    private router: Router,
    private formMessageService: FormMessageService,
    private event: EventListenerService,
    private persistenceService: PersistenceService,
    private cartService: CartService) {

  }

  ngOnInit() {
    //clear on bording form
    this.formMessageService.resetServiceData();
    this.cartService.resetServiceData();
    this.event.notifyCartUpdate(null);

    this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION) ? this.flag = true : this.flag = false;
    if (this.paymentGateWayService.orderId) {
      this.orderId = this.paymentGateWayService.orderId;
    }
    else {
      this.router.navigate(('/public').split('/'));
    }
  }

  navigateToDashboard(route) {
    this.router.navigate(route.split('/'));
  }

}
