import { AsyncValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { Observable ,  of } from "rxjs";
import {PersistenceService, StorageType} from 'angular-persistence';
import {PERSISTANCEKEY} from '../../../application-constants';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { FormMessageService } from '../services/form-message.service';
import { map } from 'rxjs/operators';

export function customerSearchValidator(persistenceService: PersistenceService,customerOnBoardService: CustomerOnboardService, formMessageService: FormMessageService): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> => {
        if (control.value && control.value.phoneNumber && control.value.simCardNumber) {
            return customerOnBoardService.customerSearch(control.value).pipe(map(
                data => {
                    if (data && data.statusCode === '1040') {
                        return null;
                    } else if (data && data.statusCode === '1045') {
                        if (data.details) {
                            formMessageService.setJourneyData(data.details);
                        }
                        return null;
                    } else if (data && data.statusCode === '1041') {
                        return { 'isTaken': true, 'code': data.statusCode };
                    } else if (data && data.statusCode === '1042') {
                        return { 'isTaken': true, 'code': data.statusCode };
                    } else if (data && data.statusCode === '1043') {
                        return { 'isTaken': true, 'code': data.statusCode };
                    } else if (data && data.statusCode === '1044') {
                        return { 'isTaken': true, 'code': data.statusCode };
                    } else if (data && data.statusCode === '1046') {
                        if (data.details) {
                            const accessToken = persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
                            if(accessToken){
                                persistenceService.set(PERSISTANCEKEY.PARTYID, data.details.partyId, { type: StorageType.SESSION });
                                persistenceService.set(PERSISTANCEKEY.CUSTOMERID, data.details.customerId, { type: StorageType.SESSION });
                                persistenceService.set(PERSISTANCEKEY.USERPROFILEID, data.details.userProfileId, { type: StorageType.SESSION });                                                              
                            }
                            return { 'isTaken': true, 'code': data.statusCode };
                        }
                    }
                }
            ));
        }
        return of(null);
    };
}
