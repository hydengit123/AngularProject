import { FormGroup, ValidationErrors, ValidatorFn } from "@angular/forms";
import { PersistenceService, StorageType } from "angular-persistence";
import { CMUICONFIGKEY, CONTACTDETAILSCONSTS } from "dxp-common";
import { REGEX } from "../../../application-constants";

/** A hero's name can't match the hero's alter ego */
export function contactDetailsValidator(persistenceService: PersistenceService, activationDetails): ValidatorFn {
  return (control: FormGroup): ValidationErrors | null => {
    const firstName = control.get('firstName');
    const lastName = control.get('lastName');
    const dob = control.get('dateOfBirth');
    const dobValid = control.get('validDOB');
    const contactPhone = control.get('contactPhone');
    const prefferedLanguage = control.get('prefferedLanguage');
    const zip = control.get('zip');
    const city = control.get('city');
    const email = control.get('email');
    const signUpEmail = control.get('signUpEmail');
    const signupForOnlineManagement = control.get('signupForOnlineManagement');
    const addressLine1 = control.get('addressLine1');
    const addressLine2 = control.get('addressLine2');
    const typeofIdentity = control.get('typeofIdentity');
    const identificationNumber = control.get('identificationNumber');
    const regMandatory = persistenceService.get(CMUICONFIGKEY.REGISTRATIONMANDATORY, StorageType.SESSION);
    const enableOTP = persistenceService.get(CMUICONFIGKEY.ENABLEOTP, StorageType.SESSION);
    const contactNumberLength = parseInt(persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION)) || null;
    const contactNumberMaxLength = parseInt(persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION)) || null;
    const addressLine1MaxLength = parseInt(persistenceService.get(CMUICONFIGKEY.ADDRESSLINE1MAXLENGTH, StorageType.SESSION)) || null;
    const addressLine2MaxLength = parseInt(persistenceService.get(CMUICONFIGKEY.ADDRESSLINE2MAXLENGTH, StorageType.SESSION)) || null;
    const passwordMinLength = parseInt(persistenceService.get(CMUICONFIGKEY.PASSWORDMINLENGTH, StorageType.SESSION)) || null;
    const passwordMaxLength = parseInt(persistenceService.get(CMUICONFIGKEY.PASSWORDMAXLENGTH, StorageType.SESSION)) || null;
    const cityMaxLength = parseInt(persistenceService.get(CMUICONFIGKEY.CITYMAXLENGTH, StorageType.SESSION), 10) || null;
    const zipMaxLength = parseInt(persistenceService.get(CONTACTDETAILSCONSTS.ZIPCODEMAXLENGTH, StorageType.SESSION), 10) || null;
    const zipCharsAllowed = persistenceService.get(CONTACTDETAILSCONSTS.ZIPCHARSALLOWED, StorageType.SESSION);
    const password = control.get('password');
    const confirmpassword = control.get('repassword');
    let isError = false;
    let errors = {
      "firstNameRequiredError": false,
      "firstNamePatternError": false,
      "lastNameRequiredError": false,
      "lastNamePatternError": false,
      "dobValidityError": false,
      'dobRequiredError': false,
      "emailRequiredError": false,
      "emailFormatError": false,
      "contactPhoneRequiredError": false,
      "contactPhoneLengthError": false,
      "contactPhoneAlphaError": false,
      "prefferedLanguageRequiredError": false,
      'zipPatternError': false,
      'zipLengthError': false,
      "signUpEmailFormatError": false,
      "passwordRequiredError": false,
      "confirmPassRequiredError": false,
      "passwordMatchError": false,
      "generalError": false,
      "passwordFormatError":false,
      'passwordLengthError': false,
      'addressLine1FormatError': false,
      'addressLine2FormatError': false,
      'cityLengthError': false,
      'cityPatternError': false,
      'selectIdentityType': false,
      'identityLengthError': false,
      'identityPatternError': false
    }
    let nameRegex = /^[A-Za-z_ ]+$/;
    let contactPhoneRegex = /^[0-9]+$/g;
    let emailRegex = /\S+@\S+\.\S+/;
    const alphanumericRegex = /^[A-Za-z0-9]+$/;
    const alphaRegex = /^[A-Za-z]+$/;
    const numericRegex = /^[0-9]+$/;

    if (firstName && !firstName.value && firstName.dirty) {
      errors.firstNameRequiredError = true;
      isError = true;
    }
    if (firstName && firstName.value && !firstName.value.match(nameRegex)) {
      errors.firstNamePatternError = true;
      isError = true;
    }
    if (lastName && !lastName.value && lastName.dirty) {
      errors.lastNameRequiredError = true;
      isError = true;
    }
    if (lastName && lastName.value && !lastName.value.match(nameRegex)) {
      errors.lastNamePatternError = true;
      isError = true;
    }
    if (dob && dob.value && dobValid && !dobValid.value) {
      errors.dobValidityError = true;
      isError = true;
    }
    if (dob && !dob.value && dob.touched) {
      errors.dobRequiredError = true;
      isError = true;
    }
    if (contactPhone && !contactPhone.value && contactPhone.dirty) {
      errors.contactPhoneRequiredError = true;
      isError = true;
    }
    if (contactPhone && contactPhone.value && contactPhone.value.match(contactPhoneRegex) && (contactPhone.value.length > contactNumberMaxLength || contactPhone.value.length < contactNumberLength)) {
      errors.contactPhoneLengthError = true;
      isError = true;
    }
    if (contactPhone && contactPhone.value && !contactPhone.value.match(contactPhoneRegex)) {
      errors.contactPhoneAlphaError = true;
      isError = true;
    }
    if (prefferedLanguage && !prefferedLanguage.value && prefferedLanguage.dirty) {
      errors.prefferedLanguageRequiredError = true;
      isError = true;
    }
    if (addressLine1 && addressLine1.value && addressLine1.value.length > addressLine1MaxLength) {
      errors.addressLine1FormatError = true;
      isError = true;
    }
    if (addressLine2 && addressLine2.value && addressLine2.value.length > addressLine2MaxLength) {
      errors.addressLine2FormatError = true;
      isError = true;
    }
    if (zip && zip.value) {
      let regEx: any;
      if (zipCharsAllowed === 'alphanumeric') {
        regEx = alphanumericRegex;
      } else {
        regEx = numericRegex;
      }
      if (zip.value.length > zipMaxLength) {
        errors.zipLengthError = true;
        isError = true;
      } else if (!zip.value.match(regEx)) {
        errors.zipPatternError = true;
        isError = true;
      }
    }
    if (city && city.value) {
      if (city.value.length > cityMaxLength) {
        errors.cityLengthError = true;
        isError = true;
      } else if (!city.value.match(alphaRegex)) {
        errors.cityPatternError = true;
        isError = true;
      }
    }
    if (identificationNumber && identificationNumber.value) {
      if (typeofIdentity && typeofIdentity.value) {
        let allowedMaxLength = 0;
        for (let i = 0; i < persistenceService.get(CMUICONFIGKEY.IDENTITYDOCTYPE, StorageType.SESSION).length; i++) {
          if (persistenceService.get(CMUICONFIGKEY.IDENTITYDOCTYPE, StorageType.SESSION)[i]['identityDocumentCode'] === typeofIdentity.value) {
            allowedMaxLength = persistenceService.get(CMUICONFIGKEY.IDENTITYDOCTYPE, StorageType.SESSION)[i]['identificationNumberMaxLength'];
            break;
          }
        }
        if (identificationNumber.value.length > allowedMaxLength) {
          errors.identityLengthError = true;
          isError = true;
        } else if (!identificationNumber.value.match(alphanumericRegex)) {
          errors.identityPatternError = true;
          isError = true;
        }
      } else {
        errors.selectIdentityType = true;
        isError = true;
      }
    }
    if (email && !email.value && email.dirty) {
      errors.emailRequiredError = true;
      isError = true;
    }
    if (email && email.value && !email.value.match(emailRegex)) {
      errors.emailFormatError = true;
      isError = true;
    }
    if (signUpEmail && signUpEmail.value && !signUpEmail.value.match(emailRegex) && signupForOnlineManagement && signupForOnlineManagement.value) {
      errors.signUpEmailFormatError = true;
      isError = true;
    }
    if (signUpEmail && signUpEmail.value && !signUpEmail.value.match(emailRegex) && signupForOnlineManagement && !signupForOnlineManagement.value) {
      errors.signUpEmailFormatError = false;
      isError = false;
    }
    if (!enableOTP && signupForOnlineManagement && signupForOnlineManagement.value) {
      if (password && !password.value && password.dirty) {
        errors.passwordRequiredError = true;
        isError = true;
      }
      if (confirmpassword && !confirmpassword.value && confirmpassword.dirty) {
        errors.confirmPassRequiredError = true;
        isError = true;
      }
      if ((password && password.value) && (confirmpassword && confirmpassword.value) && (password.value != confirmpassword.value)) {
        errors.passwordMatchError = true;
        isError = true;
      }
      if (password && password.value) {
        if (password.value.length < passwordMinLength || password.value.length > passwordMaxLength) {
          errors.passwordLengthError = true;
          isError = true;
        } else if (!password.value.match(REGEX.PASSWORD)) {
          errors.passwordFormatError = true;
          isError = true;
        }
      }
    }
    if (!enableOTP && regMandatory) {
      if (password && !password.value && password.dirty) {
        errors.passwordRequiredError = true;
        isError = true;
      }
      if (confirmpassword && !confirmpassword.value && confirmpassword.dirty) {
        errors.confirmPassRequiredError = true;
        isError = true;
      }
      if ((password && password.value) && (confirmpassword && confirmpassword.value) && (password.value != confirmpassword.value)) {
        errors.passwordMatchError = true;
        isError = true;
      }
    }

    if((firstName && !firstName.value) || (lastName && !lastName.value) || (email && !email.value) || (contactPhone && !contactPhone.value) || (prefferedLanguage && !prefferedLanguage.value) || ((signupForOnlineManagement && !enableOTP && signupForOnlineManagement.value) && password && !password.value) || ((signupForOnlineManagement && !enableOTP && signupForOnlineManagement.value) && confirmpassword && !confirmpassword.value)) {
      errors.generalError = true;
      isError = true;
    }

    return isError ? errors : null;
  }
};
