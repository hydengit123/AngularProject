import {AbstractControl} from '@angular/forms';
import { ValidatorFn, FormGroup, ValidationErrors } from "@angular/forms";
import { PersistenceService, StorageType } from "angular-persistence";
import { REGEX } from "../../../application-constants";
import { CMUICONFIGKEY } from "dxp-common";

export function saveCartDetailsValidator(persistenceService: PersistenceService): ValidatorFn {
  return (control: FormGroup): ValidationErrors | null => {
    const firstName = control.get('firstName');
    const lastName = control.get('lastName');
    const email = control.get('identifier');
    const credential = control.get('credential');
    const confirm = control.get('confirm');
    const enableOTP = persistenceService.get(CMUICONFIGKEY.ENABLEOTP, StorageType.SESSION);

    let isError = false;
    let errors = {
      "firstNameRequiredError": false,
      "firstNamePatternError": false,
      "lastNameRequiredError": false,
      "lastNamePatternError": false,
      "emailFormatError": false,
      "credentialRequiredError": false,
      "confirmRequiredError": false,
      "passwordMatchError": false,
      "credentialFormatError":false,

    }
    let nameRegex = /^[A-Za-z_ ]+$/;
    let emailRegex = /\S+@\S+\.\S+/;

    if (firstName && !firstName.value && firstName.dirty) {
      errors.firstNameRequiredError = true;
      isError = true;
    }
    if (firstName && firstName.value && !firstName.value.match(nameRegex)) {
      errors.firstNamePatternError = true;
      isError = true;
    }
    if (lastName && !lastName.value && lastName.dirty) {
      errors.lastNameRequiredError = true;
      isError = true;
    }
    if (lastName && lastName.value && !lastName.value.match(nameRegex)) {
      errors.lastNamePatternError = true;
      isError = true;
    }
    
    if (email && email.value && !email.value.match(emailRegex)) {
      errors.emailFormatError = true;
      isError = true;
    }
    if (!enableOTP) {
      if (credential && !credential.value && credential.dirty) {
        errors.credentialRequiredError = true;
        isError = true;
      }
      if (confirm && !confirm.value && confirm.dirty) {
        errors.confirmRequiredError = true;
        isError = true;
      }
      if ((credential && credential.value) && (confirm && confirm.value) && (credential.value != confirm.value)) {
        errors.passwordMatchError = true;
        isError = true;
      }
      if(credential && credential.value && !credential.value.match(REGEX.PASSWORD)){
        errors.credentialFormatError = true;
        isError = true;
    }
    }

    return isError ? errors : null;
  }
};
