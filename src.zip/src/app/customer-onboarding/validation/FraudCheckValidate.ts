import { AsyncValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { Observable ,  of } from "rxjs";
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { map } from 'rxjs/operators';

export function fraudCheckValidator(customerOnBoardService: CustomerOnboardService): AsyncValidatorFn {
  return (control: AbstractControl): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> => {
    if (control.value && control.value.phoneNumber && control.value.simCardNumber) {
      return customerOnBoardService.fraudCheck(control.value).pipe(map(
        data => {
          return (data && data.message === 'Success') ? null : {'isTaken': true};
        }
      ));
    }
    return of(null);
  };
}