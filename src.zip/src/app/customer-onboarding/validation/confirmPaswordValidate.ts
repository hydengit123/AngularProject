import {AbstractControl} from '@angular/forms';

export class ConfirmPasswordValidate {
    static MatchPassword(control: AbstractControl) {
       let password = control.get('password').value;

       let confirm = control.get('confirm').value;

        if(password != confirm) {
            control.get('confirm').setErrors( {confirm: true} );
        } else {
            return null
        }
    }
}