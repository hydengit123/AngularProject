import { ValidatorFn, FormGroup, ValidationErrors } from "@angular/forms";
import { PersistenceService, StorageType } from "angular-persistence";
import { REGEX } from "../../../application-constants";
import { CMUICONFIGKEY } from 'dxp-common';

export function activationDetailsValidator(persistenceService: PersistenceService): ValidatorFn {
  return (control: FormGroup): ValidationErrors | null => {
    const phoneNumber = control.get('phoneNumber');
    const simCardNumber = control.get('simCardNumber');
    const activationCode = control.get('activationCode');
    const location = control.get('location');
    const activationCodeLength = parseInt(persistenceService.get(
      CMUICONFIGKEY.ACTIVATIONCODELENGTH, StorageType.SESSION
    )) || null;
    const phoneNumberLength = parseInt(persistenceService.get(
      CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION
    )) || null;
    const phoneNumberMaxLength = parseInt(persistenceService.get(
      CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION
    )) || null;
    const simCardNumberLength = parseInt(persistenceService.get(
      CMUICONFIGKEY.MINLENGTH, StorageType.SESSION
    )) || null;
    const simCardNumberMaxLength = parseInt(persistenceService.get(
      CMUICONFIGKEY.MAXLENGTH, StorageType.SESSION
    )) || null;
    let isError = false;
    let errors = {
      "phoneNumberRequiredError": false,
      "simCardNumberRequiredError": false,
      "activationCodeRequiredError": false,
      "locationRequiredError": false,
      "activationCodeLengthError": false,
      "phoneNumberLengthError": false,
      "simCardNumberLengthError": false,
      "activationCodeFormatError": false,
      "phoneNumberFormatError": false,
      "simCardFormatError": false,
      "simCardNumberMaxLengthError": false,
      "generalError": false
    }

    let formcontrolvalue = control.controls;


    if (phoneNumber && !phoneNumber.value && phoneNumber.dirty) {
      errors.phoneNumberRequiredError = true;
      isError = true;
    }

    if (phoneNumber && phoneNumber.value
      && phoneNumberLength && (phoneNumber.value.length < phoneNumberLength || phoneNumber.value.length > phoneNumberMaxLength)) {
      errors.phoneNumberLengthError = true;
      isError = true;
    }

    if (phoneNumber && phoneNumber.value && !phoneNumber.value.match(REGEX.ONLYDIGIT)) {
      errors.phoneNumberFormatError = true;
      isError = true;
    }


    if (simCardNumber && !simCardNumber.value && simCardNumber.dirty) {
      errors.simCardNumberRequiredError = true;
      isError = true;
    }

    if (simCardNumber && simCardNumber.value
      && simCardNumberLength && simCardNumber.value.length < simCardNumberLength) {
      errors.simCardNumberLengthError = true;
      isError = true;
    }

    if (simCardNumber && simCardNumber.value
      && simCardNumberLength && simCardNumber.value.length > simCardNumberMaxLength) {
      errors.simCardNumberMaxLengthError = true;
      isError = true;
    }

    if (simCardNumber && simCardNumber.value
      && simCardNumberLength && !simCardNumber.value.match(REGEX.ONLYDIGIT)) {
      errors.simCardFormatError = true;
      isError = true;
    }

    if (activationCode && !activationCode.value && activationCode.dirty) {
      errors.activationCodeRequiredError = true;
      isError = true;
    }

    if (activationCode && activationCode.value
      && activationCodeLength && activationCode.value.length != activationCodeLength) {
      errors.activationCodeLengthError = true;
      isError = true;
    }

    if (activationCode && activationCode.value && !activationCode.value.match(REGEX.ALPHANUMERIC)) {
      errors.activationCodeFormatError = true;
      isError = true;
    }

    if (location && !location.value && !location.dirty) {
      errors.locationRequiredError = true;
      isError = true;
    }

    // if((phoneNumber && !phoneNumber.value) || (location && !location.value) || (activationCode && !activationCode.value) || (simCardNumber && !simCardNumber.value)) {
    //   errors.generalError = true;
    //   isError = true;
    // }

    return isError ? errors : null;

  }
};
