
import {map} from 'rxjs/operators';
import { AsyncValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { Observable } from "rxjs";
import { CustomerOnboardService } from '../../services/customer-onboard.service';

export function signUpEmailExistValidator(customerOnBoardService: CustomerOnboardService): AsyncValidatorFn {
  return (control: AbstractControl): Promise<ValidationErrors | null> | Observable<ValidationErrors | null> => {
    return customerOnBoardService.signUpEmailExist(control.value, control.value).pipe(map(
      data => {
        return (data && data.message=="success") ? null : {"isTaken": true};
      }
    ));
  };
} 