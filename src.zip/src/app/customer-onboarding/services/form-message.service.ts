import { Injectable } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { cartDetails, CARTACTION, CARTITEM, CMUICONFIGKEY, customerOnboard, invalidPlanMessageOnStep, planoffer } from 'dxp-common';
import { LOCALIZATIONPERSISTANCEKEY, PERSISTANCEKEY } from '../../../application-constants';
import { EventListenerService } from '../../event-listener.service';
import { CartService } from '../../services/cart.service';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { activationDetailsValidator } from '../validation/ActivationDetailsValidate';
import { contactDetailsValidator } from '../validation/ContactDetailsValidate';
import { customerSearchValidator } from '../validation/customerSearchValidate';
import { fraudCheckValidator } from '../validation/FraudCheckValidate';
import { saveCartDetailsValidator } from '../validation/SaveCartDetailsValidation';



declare const alertify;
@Injectable()
export class FormMessageService {

    public journeySessionData: any;
    public isUserLoggedIn: boolean;
    public lastSavedOnBoardingData:customerOnboard;

    constructor(private customerService: CustomerOnboardService,
        private persistenceService: PersistenceService,
        private translateService: TranslateService,
        private event: EventListenerService,
        private cartService: CartService,
        private router: Router) { }

    public activationDetails: FormGroup = new FormGroup({
        phoneNumber: new FormControl(),
        simCardNumber: new FormControl(),
        activationCode: new FormControl(),
        location: new FormControl()
    },
        [activationDetailsValidator(this.persistenceService)]);

    public personalInformation: FormGroup = new FormGroup({
        firstName: new FormControl(),
        lastName: new FormControl(),
        dateOfBirth: new FormControl(),
        email: new FormControl(null, { updateOn: 'blur' }),
        contactPhone: new FormControl(),
        prefferedLanguage: new FormControl(),
        nationality: new FormControl(),
        validDOB: new FormControl()
    },
        [contactDetailsValidator(this.persistenceService, this.activationDetails)]);

    public address: FormGroup = new FormGroup({
        addressLine1: new FormControl(),
        addressLine2: new FormControl(),
        zip: new FormControl(),
        city: new FormControl()
    },
        [contactDetailsValidator(this.persistenceService, this.activationDetails)]);

    public identity: FormGroup = new FormGroup({
        typeofIdentity: new FormControl(),
        identificationNumber: new FormControl(),
        expiryDate: new FormControl()
    },
        [contactDetailsValidator(this.persistenceService, this.identity)]);

    public signUInfo: FormGroup = new FormGroup({
        signupForOnlineManagement: new FormControl(),
        signUpEmail: new FormControl(null, { updateOn: 'blur' }),
        password: new FormControl(),
        repassword: new FormControl(),
        enableOTP: new FormControl(),
        phoneNumber: new FormControl()
    },
        [contactDetailsValidator(this.persistenceService, this.activationDetails)],
        // [signUpEmailExistValidator(this.customerService)]
    );

    public contactDetails = new FormGroup({
        personalInformation: this.personalInformation,
        address: this.address,
        identity: this.identity,
        signUInfo: this.signUInfo
    });

    public onboardingForm: FormGroup = new FormGroup({
        activationDetails: this.activationDetails,
        contactDetails: this.contactDetails,
        customerId: new FormControl(),
        userId: new FormControl(),
        partyId: new FormControl(),
        customerStatus: new FormControl(),
        contractId: new FormControl(),
        contractStatus: new FormControl(),
        journeySessionId: new FormControl(),
        shoppingCartId: new FormControl(),
        preActivatedBaseOffer: new FormGroup({
            id: new FormControl(),
            name: new FormControl(),
            offerType: new FormControl()
        }),
        currentStep: new FormControl()
    });

    public saveCartForm: FormGroup = new FormGroup({
        firstName: new FormControl(),
        lastName: new FormControl(),
        identifier: new FormControl(null, { updateOn: 'blur' }),
        credential: new FormControl(),
        confirm: new FormControl(),
        optedForSelfcareRegistration: new FormControl()
    },
        [saveCartDetailsValidator(this.persistenceService)]);

    public resetServiceData() {
        this.onboardingForm.reset();
        this.journeySessionData = null;
        this.isUserLoggedIn = null;
        this.lastSavedOnBoardingData = null;
        this.saveCartForm.reset();
    }


    validateActivationDetails(step: number) {
        this.activationDetails.setAsyncValidators(
            [fraudCheckValidator(this.customerService),
            customerSearchValidator(this.persistenceService, this.customerService, this)
            ]);
        this.activationDetails.updateValueAndValidity();
        const activationFormStatusSubsription = this.activationDetails.statusChanges.subscribe(status => {
            this.activationDetails.clearAsyncValidators();
            activationFormStatusSubsription.unsubscribe();
            if (this.activationDetails.errors && this.activationDetails.errors.code) {
                const accessToken = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
                const userProfileId = this.persistenceService.get(PERSISTANCEKEY.USERPROFILEID, StorageType.SESSION);
                if (accessToken && userProfileId) {
                    if (this.activationDetails.errors.code === '1046') {
                        this.event.updateStepperInfo(step);
                    }
                } else {
                    alertify.error(this.translateService.instant(this.activationDetails.errors.code));
                }
            } else if (status === "VALID") {
                this.event.updateStepperInfo(step);
            }
        });
    }

    async validatePlanSelection(step: number) {
        const customerData: customerOnboard = this.onboardingForm.value as customerOnboard;
        if (customerData && customerData.shoppingCartId) {
            const cartDetails: cartDetails = await this.cartService.getCartDetails().toPromise();
            if (cartDetails && cartDetails.cartList) {
                const plansIncart = cartDetails.cartList.filter(x => x.productOffering.offerType !== CARTITEM.ADDON);
                if (plansIncart.length > 0) {
                    const invalidMessageOnPlan = this.showAlertOnInvalidPlan(cartDetails);
                    if (invalidMessageOnPlan) {
                        alertify.error(invalidMessageOnPlan.invalidMessage);
                        if(invalidMessageOnPlan.allowActivation){
                            this.event.updateStepperInfo(step);
                        }
                    }
                    else {
                        this.event.updateStepperInfo(step);
                    }
                }
            }
        }
        if (customerData && !customerData.shoppingCartId) {
            alertify.error(this.translateService.instant("Please select a Plan"));
        }
    }

    // TODO : Please FIX, this method will always return false
    validateContactDetails(): boolean {
        if (this.signUInfo.controls.signupForOnlineManagement.value) {
            this.customerService.signUpEmailExist(this.signUInfo.value, this.activationDetails.value).subscribe(data => {
                let response = data;
                if (data) {
                    alertify.error(this.translateService.instant("Email Id already exists. Please use another Email Id"));
                    // what this return do? this is not a return of validateContactDetails() function.
                    return false;
                }
            },
                error => {
                    if (error.status === 404 && error.error && error.error.code === "1036" && this.contactDetails.valid) {
                        this.event.updateStepperInfo(5);
                    }
                }
            );
        } else {
            this.event.updateStepperInfo(5);
        }
        // This method will alsways return false.
        return false;
    }

    public async setJourneyData(preProvisionedData) {
        let productOffering = {
            "id": preProvisionedData.customerContracts[0].products[0]['id'],//API now returns id so mapping id instead of name
            "name": preProvisionedData.customerContracts[0].products[0]['name'],
            "offerType": preProvisionedData.customerContracts[0].products[0]['type']
        }
        this.onboardingForm.patchValue(preProvisionedData);
        this.onboardingForm.controls.preActivatedBaseOffer.patchValue(productOffering);
        this.onboardingForm.controls.contractId.setValue(preProvisionedData.customerContracts[0].id);
        const lang = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
        // todo market segment
        const offerType = this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMESFORVASEOFFERQUERY, StorageType.SESSION);
        const plansInXchannel: planoffer[] = await this.customerService.getPlanAddonsDetails(lang, offerType, this.onboardingForm.value as customerOnboard).toPromise();
        const preActivatePlans = plansInXchannel.filter(x => x.id === productOffering.id);
        if (preActivatePlans && preActivatePlans[0]) {
            const cartItem = this.customerService.convertXChannelPlanToCartProductItem(preActivatePlans[0], CARTACTION.ACTIVE, this.onboardingForm.value as customerOnboard);
            const cartResponse: any = await this.cartService.createCart([cartItem], this.customerService.createCartDetailsWithResource(this.onboardingForm.value as customerOnboard)).toPromise();
            this.onboardingForm.controls.shoppingCartId.setValue(cartResponse.id);
            const cartDetails: cartDetails = await this.cartService.getCartDetails().toPromise();
            this.event.notifyCartUpdate(cartDetails);
        }
    }

    public getStepURL(step: string) {
        let routeUrl = '';
        switch (parseInt(step)) {
            case 99:
                routeUrl = 'customerOnboard/ContinueJourney';
                break;
            case 1:
                routeUrl = 'customerOnboard/ActivationDetails';
                break;
            case 2:
                routeUrl = 'customerOnboard/Plan';
                break;
            case 3:
                routeUrl = 'customerOnboard/AdditionalServices';
                break;
            case 4:
                routeUrl = 'customerOnboard/ContactDetails';
                break;
            case 5:
                routeUrl = 'customerOnboard/checkout';
                break;
            case 6:
                routeUrl = 'dashboard/dfy';
                break;
            default:
                routeUrl = 'customerOnboard/ActivationDetails';
                break;
        }
        return routeUrl;
    }

    public implictSaveJourney() {
        const onBoardData: customerOnboard = this.onboardingForm.value as customerOnboard;
        if (this.isUserLoggedIn && onBoardData && this.cartService.cartDetails 
            && this.cartService.cartDetails.id
            && (!this.lastSavedOnBoardingData || JSON.stringify(onBoardData) !== JSON.stringify(this.lastSavedOnBoardingData))) {
            this.onboardingForm.get('shoppingCartId').setValue(this.cartService.cartDetails.id);
            this.lastSavedOnBoardingData = this.onboardingForm.value as customerOnboard;
            if (this.lastSavedOnBoardingData.journeySessionId) {
                this.customerService.updateSaveCartJourneySessionInteraction(this.lastSavedOnBoardingData, this.cartService.cartDetails, null).subscribe((data) => {
                });
            }
            if (!this.lastSavedOnBoardingData.journeySessionId) {
                this.customerService.createSaveCartJourneySessionInteraction(this.lastSavedOnBoardingData, this.cartService.cartDetails, null).subscribe((data) => {
                    if(data && data.id){
                        this.onboardingForm.get('journeySessionId').setValue(data.id);
                    }
                });
            }
        }
    }

    public showAlertOnInvalidPlan(cartDetails: cartDetails): invalidPlanMessageOnStep {
        const invalidPlan = this.cartService.isInvalidPlanInCartList(cartDetails);
        const invalidAddOnPlans = this.cartService.isInvalidAddOnInCartList(cartDetails);
        let invalidPlanMessageOnStepObj:invalidPlanMessageOnStep = {
            invalidMessage:'',
            step:'',
            allowActivation: false
        }
        if (invalidPlan) {
            let messageForInvalidPlan = this.translateService.instant('ONBOARDING_INVALID_BASEOFFER_MSG', { baseOfferName: invalidPlan.productOffering.name });
            const invalidPreActivatedPlan = this.cartService.isInvalidPreActivatedPlanInCartList(cartDetails);
            const invalidSwapPlan = this.cartService.isInvalidSwapPlanInCartList(cartDetails);
            const validSwapPlan = this.cartService.isValidSwapPlanInCartList(cartDetails);
            if (invalidPreActivatedPlan) {
                messageForInvalidPlan = this.translateService.instant('ONBOARDING_INVALID_PRE_BASEOFFER_MSG', { baseOfferName: invalidPreActivatedPlan.productOffering.name });
                if(validSwapPlan){
                    invalidPlanMessageOnStepObj.allowActivation = true;
                }
            }
            else if (invalidSwapPlan) {
                messageForInvalidPlan = this.translateService.instant('ONBOARDING_INVALID_SWAP_BASEOFFER_MSG', { baseOfferName: invalidSwapPlan.productOffering.name });
            }
            invalidPlanMessageOnStepObj.invalidMessage = messageForInvalidPlan;
            invalidPlanMessageOnStepObj.step = '2';
            //navigate to plan
            return invalidPlanMessageOnStepObj;
        }
        if (invalidAddOnPlans) {
            const invalidAddOnPlanNames = invalidAddOnPlans.map(item => { return item.productOffering.name }).join(',');
            invalidPlanMessageOnStepObj.invalidMessage = this.translateService.instant('ONBOARDING_INVALID_ADDONS_MSG', { addonOffersNames: invalidAddOnPlanNames });
            invalidPlanMessageOnStepObj.step = '3';
            invalidPlanMessageOnStepObj.allowActivation = false;
            return invalidPlanMessageOnStepObj;//navigate to add-on
        }
        return null;
    }



}
