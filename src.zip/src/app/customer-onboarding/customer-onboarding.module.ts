import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { DxpPipeModule, DxpCommonModule } from 'dxp-common';
import { MDBBootstrapModulesPro } from 'ng-uikit-pro-standard';
import { AuthInterceptorService } from '../auth-interceptor.service';
import { CommonNavigationFormModule } from '../custom-component/common-navigation-form.module';
import { CustomPipeModule } from '../custom-pipe/custom-pipe.module';
import { SharedModuleModule } from '../shared-module/shared-module.module';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { ActivationDetailsComponent } from './activation-details/activation-details.component';
import { AdditionalServicesComponent } from './additional-services/additional-services.component';
import { StepperComponent } from './app-stepper/app-stepper.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { ConfirmPopupComponent } from './confirm-popup/confirm-popup.component';
import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { CutomerOnboardingRouting } from './customer-onboarding-routing.module';
import { CustomerOnboardingComponent } from './customer-onboarding.component';
import { PaymentSuccessfulComponent } from './payment-successful/payment-successful.component';
import { PlanListComponent } from './plan-list/plan-list.component';
import { PopupModalComponent } from './popup-modal/popup-modal.component';
import { SaveCartDetailsComponent } from './save-cart-details/save-cart-details.component';


@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    CutomerOnboardingRouting,
    FormsModule,
    SharedModuleModule,
    ReactiveFormsModule,
    TranslateModule,
    MDBBootstrapModulesPro,
    CustomPipeModule,
    DxpPipeModule,
    CommonNavigationFormModule,
    DxpCommonModule
  ],
  declarations: [CustomerOnboardingComponent,
    ActivationDetailsComponent,
    PlanListComponent,
    AdditionalServicesComponent,
    ContactDetailsComponent,
    AccountDetailsComponent,
    CheckoutComponent,
    StepperComponent,
    PaymentSuccessfulComponent,
    PaymentSuccessfulComponent,
    PopupModalComponent,
    SaveCartDetailsComponent,
    ConfirmPopupComponent,
  ],
  entryComponents: [StepperComponent, SaveCartDetailsComponent, ConfirmPopupComponent],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptorService,
      multi: true
    }
  ]
})
export class CustomerOnboardingModule { }
