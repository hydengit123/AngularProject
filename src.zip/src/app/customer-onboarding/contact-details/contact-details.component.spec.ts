import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactDetailsComponent } from './contact-details.component';
import { testBedModule } from '../../test-bed-module-mock';

describe('ContactDetailsComponent', () => {
  let component: ContactDetailsComponent;
  let fixture: ComponentFixture<ContactDetailsComponent>;

  const testBedModules = testBedModule().testBedModules;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ContactDetailsComponent, ...testBedModules.declarations],
      imports: [...testBedModules.imports],
      providers: [...testBedModules.providers]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
