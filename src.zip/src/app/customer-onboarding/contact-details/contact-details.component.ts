import { Component, ElementRef, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY, CONTACTDETAILSCONSTS } from 'dxp-common';
import { IMyOptions } from 'ng-uikit-pro-standard';
import { Subscription } from 'rxjs';
import { PERSISTANCEKEY, REGEX } from '../../../application-constants';
import { CartService } from '../../services/cart.service';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { CustomerSearchService } from '../../services/customer-search.service';
import { FormMessageService } from '../services/form-message.service';
import { contactDetailsValidator } from '../validation/ContactDetailsValidate';
import { EventEnum } from './../../enum/EventEnum';
import { EventListenerService } from './../../event-listener.service';


@Component({
  selector: 'app-contact-details',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ContactDetailsComponent implements OnInit, OnDestroy {
  
  @ViewChild('firstName') private elementRef: ElementRef;
  @ViewChild('dateOfBirth') private datePickerRef: ElementRef;
  @ViewChild('expiryDate') private identityDatePickerRef: ElementRef;


  contactSubscription: Subscription;
  formMessageSubscription: Subscription;
  isLogin: boolean=false;
  languageSelect: Array<any>;
  nationalitySelect: Array<any>;
  typeofIdentitySelect: Array<any>;
  enableOTP: Boolean;
  regMandatory: Boolean;
  today;
  phoneNumber: any;
  activationDetails: FormGroup;
  contactDetails: FormGroup;
  personalInformation: FormGroup;
  address: FormGroup;
  identity: FormGroup;
  signUInfo: FormGroup;
  onboardingForm: FormGroup;
  signUpCheckboxValue: Boolean = false;
  abortJourney:Subscription;
  saveJourney:Subscription;
  enableField:Boolean = true;
  contactNumberLength: number;
  contactNumberMaxLength: number;
  addressLine1MaxLength: number;
  addressLine2MaxLength: number;
  passwordMinLength: number;
  passwordMaxLength: number;
  zipMaxLength: number;
  zipAllowedChars: string;
  cityMaxLength: number;
  saveCartForm: FormGroup;
  signupForOnlineManagement: Boolean = false;
  editableCheckbox: Boolean = false;
  pendingJourney = false;
  identityMaxLength: number;

  public currentYear:any = new Date().getFullYear();

  acesstoken:any;
  partyId:any;

  public dobDatePicker: IMyOptions = {
    // Your options
    disableSince: this.getDOBDateDisableUntil(),
    dateFormat: 'yyyy-mm-dd',
    minYear: this.persistenceService.get(CMUICONFIGKEY.DATEOFBIRTHMINYEAR, StorageType.SESSION),
    maxYear: this.currentYear 
  
  }
  public expiryDateDatePicker: IMyOptions = {
    // Your options
    
    disableUntil: this.getExpiryDateDisableUntil(),
    dateFormat: 'yyyy-mm-dd',
    minYear: this.currentYear,
    maxYear: this.persistenceService.get(CMUICONFIGKEY.IDENTITYDOCEXPIRYDATEMAXYEAR, StorageType.SESSION)
  };

  constructor(private formBuilder: FormBuilder,
    private formMessageService: FormMessageService,
    private customerOnBoardService: CustomerOnboardService,
    private translateService: TranslateService,
    private persistenceService: PersistenceService,
    private eventListenerService: EventListenerService,
    private router: Router,
    private cartService: CartService,
    private customerSearchService: CustomerSearchService) {
    this.contactDetails = this.formMessageService.contactDetails;
    this.personalInformation = this.formMessageService.personalInformation;
    this.address = this.formMessageService.address;
    this.identity = this.formMessageService.identity;
    this.signUInfo = this.formMessageService.signUInfo;
    if(this.signUInfo.controls.password.value && !this.signUInfo.controls.password.value.match(REGEX.PASSWORD)) {
      this.signUInfo.controls.password.setValue(atob(this.signUInfo.controls.password.value));
    }
    if(this.signUInfo.controls.repassword.value && !this.signUInfo.controls.repassword.value.match(REGEX.PASSWORD)) {
      this.signUInfo.controls.repassword.setValue(atob(this.signUInfo.controls.repassword.value));
    }
    this.saveCartForm = this.formMessageService.saveCartForm;
  }

  ngOnInit() {
    if(this.signUInfo && this.signUInfo.controls.signupForOnlineManagement) {
      this.signupForOnlineManagement = this.signUInfo.controls.signupForOnlineManagement.value;
    }
    this.acesstoken = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
    this.partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
    //when login happens
    this.eventListenerService.notifyLoginEvent.subscribe((data)=>{
      this.isLogin = data.isLogin;
    })
     //when login is already completed
    if(this.acesstoken && this.partyId){
      this.isLogin=true;
    }
    this.eventListenerService.lanuageChangeEvent.subscribe(data => {
      if (data && data === EventEnum.languageUpdated) {
        this.languageSelect = this.getAllLanguages();
        this.typeofIdentitySelect = this.getAllIdentity();
        this.nationalitySelect = this.getAllNationality();
      }
    });
    this.activationDetails = this.formMessageService.activationDetails.value;
    this.onboardingForm = this.formMessageService.onboardingForm;
    this.enableOTP = this.persistenceService.get(CMUICONFIGKEY.ENABLEOTP, StorageType.SESSION);
    this.regMandatory = this.persistenceService.get(CMUICONFIGKEY.REGISTRATIONMANDATORY, StorageType.SESSION);
    this.contactNumberLength = parseInt(this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION)) || null;
    this.contactNumberMaxLength = parseInt(this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION)) || null;
    this.addressLine1MaxLength = parseInt(this.persistenceService.get(CMUICONFIGKEY.ADDRESSLINE1MAXLENGTH, StorageType.SESSION)) || null;
    this.addressLine2MaxLength = parseInt(this.persistenceService.get(CMUICONFIGKEY.ADDRESSLINE2MAXLENGTH, StorageType.SESSION)) || null;
    this.passwordMinLength = parseInt(this.persistenceService.get(CMUICONFIGKEY.PASSWORDMINLENGTH, StorageType.SESSION)) || null;
    this.passwordMaxLength = parseInt(this.persistenceService.get(CMUICONFIGKEY.PASSWORDMAXLENGTH, StorageType.SESSION)) || null;
    this.cityMaxLength = parseInt(this.persistenceService.get(CMUICONFIGKEY.CITYMAXLENGTH, StorageType.SESSION), 10) || null;
    this.zipMaxLength = parseInt(this.persistenceService.get(CONTACTDETAILSCONSTS.ZIPCODEMAXLENGTH, StorageType.SESSION), 10) || null;
    this.zipAllowedChars = this.translateService.instant(this.persistenceService.get(CONTACTDETAILSCONSTS.ZIPCHARSALLOWED, StorageType.SESSION));
    this.languageSelect = this.getAllLanguages();
    this.typeofIdentitySelect = this.getAllIdentity();
    this.nationalitySelect = this.getAllNationality();
    this.passwordShowStatus();
    if (this.regMandatory) {
      this.editableCheckbox = false;
    } else {
      if (this.onboardingForm && this.onboardingForm.controls.journeySessionId.value) {
        this.enableField = false; // disable field true
        this.editableCheckbox = false;
      } else {
        this.editableCheckbox = true;
        this.enableField = true; // disable field false
      }
    }

     //when customer clicks cancel to abort journey
     this.abortJourney = this.eventListenerService.customerOnAbortJourneyEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.customerOnAbortJourney) {
        if(this.cartService.cartDetails && this.cartService.cartDetails.cartList
          && this.cartService.cartDetails.cartList.length > 0){
            this.eventListenerService.confirmPopup(this.customerOnBoardService, this.formMessageService, data.retainState);     
          }
          else{
            this.formMessageService.onboardingForm.reset();
            this.router.navigate(['/public']);
          }
      }
    });

    this.saveJourney = this.eventListenerService.customerOnSaveJourneyExplicitlyEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.customerOnSaveJourneyExplicitly && data.retainState) {
        this.eventListenerService.saveCartDetailsPopup(this.customerOnBoardService, this.formMessageService, data.retainState);
        this.formMessageService.saveCartForm.reset();
      }
    });

    // bind first name and last name from personal information to pop up save cart fields
    this.formMessageService.saveCartForm.controls.firstName.valueChanges.subscribe(data => {
      if (this.formMessageService && this.formMessageService.saveCartForm && this.formMessageService.saveCartForm.controls.firstName.value){
        this.formMessageService.personalInformation.controls.firstName.setValue(this.formMessageService.saveCartForm.controls.firstName.value);
      }
      });

    this.formMessageService.saveCartForm.controls.lastName.valueChanges.subscribe(data => {
      if (this.formMessageService && this.formMessageService.saveCartForm && this.formMessageService.saveCartForm.controls.lastName.value) {
      this.formMessageService.personalInformation.controls.lastName.setValue(this.formMessageService.saveCartForm.controls.lastName.value);
    }
    });

    this.formMessageService.personalInformation.controls.email.valueChanges.subscribe(data => {
      if (this.formMessageService && this.formMessageService.personalInformation && this.formMessageService.personalInformation.controls.email.value && !this.formMessageService.signUInfo.controls.signUpEmail.value) {
            this.formMessageService.signUInfo.controls.signUpEmail.setValue(this.formMessageService.personalInformation.controls.email.value);
          }
    });

  this.formMessageService.saveCartForm.controls.identifier.valueChanges.subscribe(data => {
    if (this.formMessageService && this.formMessageService.saveCartForm && this.formMessageService.saveCartForm.controls.identifier.value) {
    this.formMessageService.signUInfo.controls.signUpEmail.setValue(this.formMessageService.saveCartForm.controls.identifier.value);
    }
    });

    
    this.personalInformation.controls.dateOfBirth.valueChanges.subscribe(data => {
      if(data) {
        let dobValid = this.checkDOBValidity(this.personalInformation.controls.dateOfBirth.value);
        this.personalInformation.controls.validDOB.setValue(dobValid);
      }
    });

    if (this.formMessageService && this.formMessageService.saveCartForm && this.formMessageService.saveCartForm.controls.firstName.value){
      this.formMessageService.personalInformation.controls.firstName.setValue(this.formMessageService.saveCartForm.controls.firstName.value);
    }

    if (this.formMessageService && this.formMessageService.saveCartForm && this.formMessageService.saveCartForm.controls.lastName.value) {
      this.formMessageService.personalInformation.controls.lastName.setValue(this.formMessageService.saveCartForm.controls.lastName.value);
    }

    if (this.formMessageService && this.formMessageService.saveCartForm && this.formMessageService.saveCartForm.controls.identifier.value) {
      this.formMessageService.signUInfo.controls.signUpEmail.setValue(this.formMessageService.saveCartForm.controls.identifier.value);
      }

    this.pendingJourney = this.customerSearchService.getpendingJourneyStatus();
    
  }

  getAllLanguages() {
    let allLanguages = this.persistenceService.get(CMUICONFIGKEY.LANGUAGES, StorageType.SESSION);
    let languageSelect = allLanguages.map(item => {
      return { value: item.languageCode, label: this.translateService.instant(item.language) };
    });
    return languageSelect;
  }
  
  showLogin(){
    this.eventListenerService.showLoginPopupDetails(false);
  }

  getAllIdentity() {
    let allIdentity = this.persistenceService.get(CMUICONFIGKEY.IDENTITYDOCUMENTYPE, StorageType.SESSION);
    let typeofIdentitySelect = allIdentity.map(item =>{
      return {value: item.identityDocumentCode, label: this.translateService.instant(item.identityDocumentName)};
    });
    return typeofIdentitySelect;
  }

  getAllNationality() {
    let allNationality = this.persistenceService.get(CMUICONFIGKEY.NATIONALITY, StorageType.SESSION);
    let nationalitySelect = allNationality.map(item =>{
      return {value: item.nationalityCode, label: this.translateService.instant(item.nationalityName)};
    });
    return nationalitySelect;
  }

  ngOnDestroy() {
    if(this.abortJourney){
      this.abortJourney.unsubscribe();
    }
    if(this.saveJourney){
      this.saveJourney.unsubscribe();
    }
  }

  private getExpiryDateDisableUntil() {
    let dateObj = new Date();
    dateObj.setDate(dateObj.getDate() - 1);
    let dateOptions = { year: 'numeric', month: 'numeric', day: 'numeric' };
    let month = parseInt(dateObj.toLocaleDateString(undefined, dateOptions).split('/')[0]);
    let day = parseInt(dateObj.toLocaleDateString(undefined, dateOptions).split('/')[1]);
    let year = dateObj.getFullYear();
    this.today = month + "-" + day + "-" + year;
    return { year: year, month: month, day: day };
  }

  getCheckboxValue() {
    this.signUpCheckboxValue = this.signUInfo.value.signupForOnlineManagement || false;
  }

  passwordShowStatus() {
    if(this.regMandatory) {
      this.signUInfo.controls.signupForOnlineManagement.setValue(this.regMandatory);
      this.signUpCheckboxValue = true;
    }
    if(!this.regMandatory) {
      if(this.signUInfo && this.signUInfo.value.signupForOnlineManagement) {
        this.signUpCheckboxValue = this.signUInfo.value.signupForOnlineManagement;
      } else {
        this.signUpCheckboxValue = false;
        this.signUInfo.controls.signupForOnlineManagement.setValue(this.regMandatory);
      }
    }
    if(this.signUInfo) {
      this.signUpCheckboxValue = this.signUInfo.value.signupForOnlineManagement || false;
    }
  }

  private getDOBDateDisableUntil() {
    let dateObj = new Date();
    dateObj.setDate(dateObj.getDate());
    let dateOptions = { year: 'numeric', month: 'numeric', day: 'numeric' };
    let month = parseInt(dateObj.toLocaleDateString(undefined, dateOptions).split('/')[0]);
    let day = parseInt(dateObj.toLocaleDateString(undefined, dateOptions).split('/')[1]);
    let year = dateObj.getFullYear();
    this.today = month + "-" + day + "-" + year;
    return { year: year, month: month, day: day };
  }

  private checkDOBValidity(selectedDate) {
    let dateSelected = selectedDate.replace(/-/g,'/');
    let dateObj = new Date();
    dateObj.setDate(dateObj.getDate());
    let dateOptions = { year: 'numeric', month: 'numeric', day: 'numeric' };
    let month = parseInt(dateObj.toLocaleDateString(undefined, dateOptions).split('/')[0]);
    let day = parseInt(dateObj.toLocaleDateString(undefined, dateOptions).split('/')[1]);
    let year = dateObj.getFullYear() - 18;
    let eighteenYrsOldDate = year + '/' + month + '/' + day;
    if(dateSelected < eighteenYrsOldDate) {
      return true;
    } else  {
      return false;
    }
  }

  setIdentificationLimit() {
    if (this.identity.controls['typeofIdentity'] && this.identity.controls['typeofIdentity'].value) {
      for (let i = 0; i < this.persistenceService.get(CMUICONFIGKEY.IDENTITYDOCTYPE, StorageType.SESSION).length; i++) {
        if (this.persistenceService.get(CMUICONFIGKEY.IDENTITYDOCTYPE, StorageType.SESSION)[i]['identityDocumentCode'] === this.identity.controls['typeofIdentity'].value) {
          this.identityMaxLength = this.persistenceService.get(CMUICONFIGKEY.IDENTITYDOCTYPE, StorageType.SESSION)[i]['identificationNumberMaxLength'];
          break;
        }
      }
    }
  }

  onBlurValidation( fieldName ) {
    contactDetailsValidator(this.persistenceService, this.activationDetails);
    let isError = false;
      const errors = this.personalInformation.errors;
      const firstName = this.formMessageService.personalInformation.controls.firstName.touched;
      const lastName = this.formMessageService.personalInformation.controls.lastName.touched;
      const contactPhone = this.formMessageService.personalInformation.controls.contactPhone.touched;

      if( fieldName && !this.formMessageService.personalInformation.controls[fieldName].value) {
        errors[fieldName + 'RequiredError'] = true;
        isError = true;
      }
  }

  ngAfterViewInit(){
    if(this.elementRef && this.elementRef.nativeElement) {
      this.elementRef.nativeElement.focus();
    }
    if(this.datePickerRef && this.datePickerRef['elem'].nativeElement) {
      this.datePickerRef['elem'].nativeElement.querySelectorAll('[class*="mydp-date"]')[0].setAttribute('readonly', 'readonly');
    }
    if(this.identityDatePickerRef && this.identityDatePickerRef['elem'].nativeElement) {
      this.identityDatePickerRef['elem'].nativeElement.querySelectorAll('[class*="mydp-date"]')[0].setAttribute('readonly', 'readonly');
    }
  }
  

}
