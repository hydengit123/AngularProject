import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { cartDetails, CARTITEM, CMUICONFIGKEY, customerOnboard, planoffer, productBucket } from 'dxp-common';
import { Subscription } from 'rxjs';
import { LOCALIZATIONPERSISTANCEKEY, WEBCONTENTPERSISTANCEKEY } from '../../../application-constants';
import { EventEnum } from '../../enum/EventEnum';
import { EventListenerService } from '../../event-listener.service';
import { WebContent } from '../../interface/web.content';
import { AuthService } from '../../services/auth.service';
import { CartService } from '../../services/cart.service';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { CustomerSearchService } from '../../services/customer-search.service';
import { DealsForYouService } from '../../services/dfy.service';
import { FormMessageService } from '../services/form-message.service';

declare const alertify;
@Component({
  selector: 'app-additional-services',
  templateUrl: './additional-services.component.html',
  styleUrls: ['./additional-services.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AdditionalServicesComponent implements OnInit, OnDestroy {
  public planList: planoffer[];
  // public planList2:any;
  public tempPlanList: any;
  // sortByMinMax: Array<any>;
  public noOfPages: any;
  // public offerType:any;


  public sortByMinMax;
  public serviceNames;
  private selectedAddOns;
  abortJourney: Subscription;
  saveJourney: Subscription;
  languageChange: Subscription;
  public path1: string[] = ['productOfferingPrice']; // empty error
  public order1: number = 1; //1 asc, -1 desc, undefined no sort

  public productActivePage: number = 1;
  public productMaxVisibleItems: number;

  constructor(private router: Router, private formBuilder: FormBuilder,
    private customerOnBoardService: CustomerOnboardService,
    private persistenceService: PersistenceService,
    private authService: AuthService,
    private translate: TranslateService,
    private event: EventListenerService,
    private formMessageService: FormMessageService,
    private customerSearchService: CustomerSearchService,
    private dealsForYouService: DealsForYouService,
    private cartService: CartService) {
    this.serviceNames = this.customerOnBoardService.productBucketArray;
  }
  ///////////=============////////////


  // order1: number;
  contractActive: boolean = true;//checks if contract is active
  showrecommendation: boolean = false; //check if to show recommendations or not
  currentSelection = null; //selected addon/deal
  searchKey = '';
  recommendationList: any = [];//raw recommendations
  slidesRecommend: any[];//recommendations coverted to 2d array
  slides: any = [[]];//deals coverted to 2d array

  webContent: WebContent;
  bottomRightImageURL: string;

  public currentContract: any;
  public userProfile: any;




  // public offerType:any;
  public offerList: any = [];



  // public sortByMinMax;
  // public serviceNames;
  // private selectedAddOns;
  quantityMap: any = {};

  createQuantityMap(products) {
    this.cartService.createQuantityMap();
  }

  getQuantity(name) {
    return this.cartService.getQuantity(name);
  }

  chunk(arr, chunkSize) {
    let R = [];
    for (let i = 0, len = arr.length; i < len; i += chunkSize) {
      R.push(arr.slice(i, i + chunkSize));
    }
    return R;
  }

  // renderAddon(event) {
  //   this.searchKey = event;
  // }

  async addToCart(productItem) {
    let createSaveCart = true;
    // this.notificationCount++;
    if (this.cartService.cartDetails && this.cartService.cartDetails.id) {
      createSaveCart = false;
    }
    let contractDetails = this.customerSearchService.getCurrentContract();
    let userProfile = this.customerSearchService.getUserProfile();
    const cartInfo = await this.dealsForYouService.addToCart(productItem, contractDetails, userProfile).toPromise();
    const cartDetails: cartDetails = await this.cartService.getCartDetails().toPromise();
    const saveCart = await this.dealsForYouService.createSaveCartJourney(contractDetails, cartDetails, userProfile, null, createSaveCart).toPromise();
    alertify.success(this.translate.instant('Added to cart'));
    this.event.notifyCartUpdate(cartDetails);
  }

  renderSearch(event) {
    let resultArray = [];
    let list = this.slides;

    for (let i = 0; i < list.length; i++) {
      for (let j = 0; j < list[i].length; j++) {
        resultArray.push(list[i][j]);
      }
    }

    let temp = resultArray.sort((a, b) => {
      return ((a.productOfferingPrice) < (b.productOfferingPrice)) ? (1 * event) : (-1 * event);
    });
    this.slides = this.chunk(temp, 4);
    ///sort simialr offer

    if (this.slidesRecommend && this.slidesRecommend.length != 0) {
      let resultArrayrecommend = [];
      let listrecommend = this.slidesRecommend;

      for (let i = 0; i < listrecommend.length; i++) {
        for (let j = 0; j < listrecommend[i].length; j++) {
          resultArrayrecommend.push(listrecommend[i][j]);
        }
      }

      let temprecommend = resultArrayrecommend.sort((a, b) => {
        return ((a.productOfferingPrice) < (b.productOfferingPrice)) ? (1 * event) : (-1 * event);
      });
      this.slidesRecommend = this.chunk(temprecommend, 4);

    }
  }
  async loadPlans() {

    const lang = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
    let addOns = this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMES_FORADDONQUERY, StorageType.SESSION);

    const planData = await this.customerOnBoardService.getPlanAddonsDetails(lang, addOns, this.formMessageService.onboardingForm.value as customerOnboard).toPromise();
    const planWithDigitalData = await this.dealsForYouService.getCMSDigitalAssets(planData, lang, addOns).toPromise();

    try {
      this.offerList = await this.dealsForYouService.loadPromotedOffers().toPromise();
    } catch (error) {
      // alertify.error('No Recommended Offers');
    }


    const plansAddOnDataAllItems = planData.map((item) => {
      let isItemInCMS = planWithDigitalData.filter(x => x.id === item.id);
      let CMSOffer: planoffer;
      if (isItemInCMS && isItemInCMS[0]) {
        CMSOffer = isItemInCMS[0];
      }
      else {
        CMSOffer = {
          "title": item.name || "",
          "summary": item.description || "",
          "coverImage": "assets/imgs/no-image-icon.png",
          "frontImage": "",
          "backImage": "",
          "id": item['id'] || "",
          "name": item['name'] || "",
          "description": item.description || "",

          "offerType": item['offerType'] || "",

          "productOfferingPrice": item['productOfferingPrice']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']['price']
            && item['productOfferingPrice']['0']['price']['amount']
            ? item['productOfferingPrice']['0']['price']['amount'] : 0,
          "priceType": item['productOfferingPrice']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']['priceType']
            ? item['productOfferingPrice']['0']['priceType'] : null,
          "productBuckets": item['productBuckets'] ?
            item['productBuckets'].map(item => {
              const productBucket: productBucket = this.customerOnBoardService.calculateDisplay(item);
              return productBucket;
            }) : null,

          periodTypes: item['productOfferingPrice']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']['priceType']
            ? item['productOfferingPrice']['0']['priceType'] : null,
          recurrencePeriod: item['productOfferingPrice']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']['recurrencePeriod']
            ? item['productOfferingPrice']['0']['recurrencePeriod'] : null,
          currency: item['productOfferingPrice']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']['price']
            && item['productOfferingPrice']['0']['price']['currency'] ?
            item['productOfferingPrice']['0']['price']['currency']
            : null
        }
      }
      return CMSOffer;
    });
    this.planList = [...plansAddOnDataAllItems];

    this.planList.forEach(plan => {
      if (this.offerList.indexOf(plan.id) != -1) {
        plan["deal"] = true;
      }
    });

    this.planList.sort((x, y) => {
      if (x.deal < y.deal) {
        return 1;
      }
      if (x.deal > y.deal) {
        return -1;
      }
      return 0;
    });
    this.slides = this.chunk(this.planList, 4);
  }


  async showrecommendations(card, showrecommendation) {
    this.currentSelection = card.name;

    this.recommendationList = [];
    let recommendationListIds = [];
    try {
      recommendationListIds = await this.dealsForYouService.loadRecommendedOffers(card.id).toPromise();

      for (let i = 0; i < recommendationListIds.length; i++) {
        let addon = this.planList.filter((plan) => {
          return plan.id == recommendationListIds[i].productOfferID;
        });
        if (addon.length != 0) {
          this.recommendationList.push(addon[0]);
        }


      }
      if (this.recommendationList.length != 0) {
        this.slidesRecommend = this.chunk(this.recommendationList, 4);
        this.showrecommendation = showrecommendation;
      } else {
        this.showrecommendation = false;
      }
    } catch (error) {
      this.showrecommendation = false;
      // alertify.error('No Similar Offers');
    }
  }

  loadSortData() {
    const sortData = [
      { value: -1, label: this.translate.instant('Price(min-max)') },
      { value: 1, label: this.translate.instant('Price(max-min)') }
    ];
    this.sortByMinMax = [...sortData];
  }

  redirectTo(route) {
    this.router.navigate(route.split('/'));
  }


  public searchProductText: string = "";




  selectedValue = -1;


  private prefillAddOnFromCart(cartDetails: cartDetails) {
    this.selectedAddOns = cartDetails.cartList.filter(x => x.productOffering.offerType === CARTITEM.ADDON);
    this.quantityMap = {};
    this.createQuantityMap(cartDetails.cartList);

  }


  ////////////////////=============///////////////////
  ngOnInit() {

    // this.cartService.cartDetails = null;
    // this.event.notifyCartUpdate(this.cartService.cartDetails);
    // this.cartService.quantityMap = {};

    this.planList = [];

    // this.productMaxVisibleItems = this.persistenceService.get(CMUICONFIGKEY.NUMBEROFADDONSPERPAGE, StorageType.SESSION);
    this.webContent = this.persistenceService.get(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, StorageType.SESSION);
    if (this.webContent && this.webContent.bottomRightImage) {
      this.bottomRightImageURL = this.webContent.bottomRightImage.url;
    }

    //on language update
    this.languageChange = this.event.lanuageChangeEvent.subscribe(data => {
      if (data && data.isUserSelected && data.eventType && data.eventType === EventEnum.languageUpdated) {
        this.loadPlans();
        this.loadSortData();
      }
    });

    this.event.notifyCartUpdateEvent.subscribe((data) => {
      if (data && data.eventType) {
        if (data.eventType == EventEnum.notifyCartUpdated) {
          if (data.cartDetails) {
            this.prefillAddOnFromCart(data.cartDetails);
          }
        }
      }
    });

    // this.currentContract = this.customerSearchService.getCurrentContract();
    // this.userProfile = this.customerSearchService.getUserProfile();
    this.loadPlans();
    this.loadSortData();

    //when customer clicks cancel to abort journey
    this.abortJourney = this.event.customerOnAbortJourneyEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.customerOnAbortJourney) {
        if (this.cartService.cartDetails && this.cartService.cartDetails.cartList
          && this.cartService.cartDetails.cartList.length > 0) {
          this.event.confirmPopup(this.customerOnBoardService, this.formMessageService, data.retainState);
        }
        else {
          this.router.navigate(['/public']);
        }
      }
    });

    this.saveJourney = this.event.customerOnSaveJourneyExplicitlyEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.customerOnSaveJourneyExplicitly && data.retainState) {
        this.event.saveCartDetailsPopup(this.customerOnBoardService, this.formMessageService, data.retainState);
        this.formMessageService.saveCartForm.reset();
      }
    });

    //prefill addon from cart
    // this.cartService.getCartDetails().subscribe(data => {
    //   this.prefillAddOnFromCart(data);
    // });


    //highlight add on plans added and deselect from tiles when deleted from cart
    // this.event.notifyCartUpdateEvent.subscribe((data) => {
    //   if (data && data.eventType) {
    //     if (data.eventType == EventEnum.notifyCartUpdated) {
    //       if (data.cartDetails) {
    //         this.prefillAddOnFromCart(data.cartDetails);
    //       }
    //     }
    //   }
    // });


  }

  serviceParsed(prodBuckets: productBucket[], serviceName): any {
    if (!prodBuckets) {
      return "<p>&nbsp;</p>";
    }
    else {
      const prodBucket = prodBuckets.filter(x => x.serviceName === serviceName);
      if (prodBucket && prodBucket[0]) {
        return prodBucket[0].forDisplay;
      }
      else {
        return "<p>&nbsp;</p>";
      }
    }
  }

  // async loadPlans() {
  //   const lang = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
  //   //todo market segment
  //   let addOns = this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMES_FORADDONQUERY, StorageType.SESSION)

  //   const planData = await this.customerOnBoardService.getPlanAddonsDetails(lang, addOns, this.formMessageService.onboardingForm.value as customerOnboard).toPromise();
  //   const planWithDigitalData = await this.customerOnBoardService.getCMSDigitalAssets(planData, lang, addOns).toPromise();

  //   const plansAddOnDataAllItems = planData.map((item) => {
  //     let isItemInCMS = planWithDigitalData.filter(x => x.id === item.id);
  //     let CMSOffer: planoffer;
  //     if (isItemInCMS && isItemInCMS[0]) {
  //       CMSOffer = isItemInCMS[0];
  //     }
  //     else {
  //       CMSOffer = {
  //         "title": item.name || "",
  //         "summary": item.description || "",
  //         "coverImage": "assets/imgs/no-image-icon.png",
  //         "frontImage": "",
  //         "backImage": "",
  //         "id": item['id'] || "",
  //         "name": item['name'] || "",
  //         "description": item.description || "",

  //         "offerType": item['offerType'] || "",
  //         "productOfferingPrice": item['productOfferingPrice']
  //           && item['productOfferingPrice']['0']
  //           && item['productOfferingPrice']['0']['price']
  //           && item['productOfferingPrice']['0']['price']['amount']
  //           ? item['productOfferingPrice']['0']['price']['amount'] : 0,
  //         "productBuckets": item['productBuckets'] ?
  //           item['productBuckets'].map(item => {
  //             const productBucket: productBucket = this.customerOnBoardService.calculateDisplay(item);
  //             return productBucket;
  //           }) : null,
  //         periodTypes: item['productOfferingPrice']
  //           && item['productOfferingPrice']['0']
  //           && item['productOfferingPrice']['0']['priceType']
  //           ? item['productOfferingPrice']['0']['priceType'] : null,
  //         recurrencePeriod: item['productOfferingPrice']
  //           && item['productOfferingPrice']['0']
  //           && item['productOfferingPrice']['0']['recurrencePeriod']
  //           ? item['productOfferingPrice']['0']['recurrencePeriod'] : null,
  //         currency: item['productOfferingPrice']
  //           && item['productOfferingPrice']['0']
  //           && item['productOfferingPrice']['0']['price']
  //           && item['productOfferingPrice']['0']['price']['currency'] ?
  //           item['productOfferingPrice']['0']['price']['currency']
  //           : null
  //       }
  //     }
  //     return CMSOffer;
  //   });
  //   this.planList = [...plansAddOnDataAllItems];
  // }

  // loadSortData() {
  //   const sortData = [
  //     { value: -1, label: this.translate.instant('Price(min-max)') },
  //     { value: 1, label: this.translate.instant('Price(max-min)') }
  //   ];
  //   this.sortByMinMax = [...sortData];
  // }

  // redirectTo(route) {
  //   this.router.navigate(route.split('/'));
  // }


  // public searchProductText: string = "";
  public productSearch(searchText) {
    this.searchKey = searchText;
  }
  public productSearchUpdatedValue(v: any) {
    this.productActivePage = 1;
  }
  changePage(event: any) {
    this.productActivePage = +event.target.text;
  }
  nextPage() {
    this.productActivePage += 1;
  }
  previousPage() {
    this.productActivePage -= 1;
  }

  private productOffersList(item, event) {
    let activeEle = event.srcElement.offsetParent.querySelector('table [class*="active"]');
    if (activeEle != null)
      activeEle.classList.remove('active');
    event.srcElement.parentElement.classList.add('active');
  }



  // selectedValue = -1;
  getSelectedValue(val: number): boolean {
    this.order1 = val * (-1); // change order
    return false; // do not reload
  }


  isActive(item) {
    return this.selectedAddOns && this.selectedAddOns.filter(x => x.productOffering.id === item.id).length === 1;
  };

  getRecurrencePeriod(item) {
    return item.recurrencePeriod ? 'for ' + item.recurrencePeriod.periodType : null
  }

  // async addToCart(item: planoffer) {
  //   const cartInfo = await this.customerOnBoardService.addToCart(item, this.formMessageService.onboardingForm.value as customerOnboard).toPromise();
  //   const cartDetails: cartDetails = await this.cartService.getCartDetails().toPromise();
  //   alertify.success(this.translate.instant('Added to cart'));
  //   this.event.notifyCartUpdate(cartDetails);
  // }

  // private prefillAddOnFromCart(cartDetails: cartDetails) {
  //   this.selectedAddOns = cartDetails.cartList.filter(x => x.productOffering.offerType === CARTITEM.ADDON);
  // }


  ngOnDestroy() {
    if (this.abortJourney) {
      this.abortJourney.unsubscribe();
    }
    if (this.saveJourney) {
      this.saveJourney.unsubscribe();
    }
    if (this.languageChange) {
      this.languageChange.unsubscribe();
    }
  }

}
