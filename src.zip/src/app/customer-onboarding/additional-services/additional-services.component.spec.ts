import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalServicesComponent } from './additional-services.component';
import { testBedModule } from '../../test-bed-module-mock';

describe('AdditionalServicesComponent', () => {
  let component: AdditionalServicesComponent;
  let fixture: ComponentFixture<AdditionalServicesComponent>;

  beforeEach(async(() => {
    const testBedModules = testBedModule().testBedModules;
    TestBed.configureTestingModule({
      declarations: [AdditionalServicesComponent, ...testBedModules.declarations],
      providers: [...testBedModules.providers],
      imports: [...testBedModules.imports],
    }).compileComponents();

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
