import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PlanListComponent } from './plan-list.component';
import { testBedModule } from '../../test-bed-module-mock';
import { Pipe, PipeTransform } from '@angular/core';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';

fdescribe('PlanListComponent', () => {
  let component: PlanListComponent;
  let fixture: ComponentFixture<PlanListComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let customerOnboardServiceSpy: jasmine.SpyObj<CustomerOnboardService>;
  let translateServiceSpy: TranslateService;
  const testBedModules = testBedModule().testBedModules;

  beforeEach(async(() => {
    const CustomerOnboardServiceSpy = jasmine.createSpyObj('CustomerOnboardService', ['getPlanAddonsDetails ','getCMSDigitalAssets']);
    TestBed.configureTestingModule({
      declarations: [PlanListComponent, ...testBedModules.declarations],
      providers: [...testBedModules.providers],
      imports: [...testBedModules.imports],
    }).overrideComponent(PlanListComponent, {
      set: {
        providers: [
          { provide: CustomerOnboardService, useValue: CustomerOnboardServiceSpy },
        ]
      }
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanListComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
    translateServiceSpy = TestBed.get(TranslateService);
    customerOnboardServiceSpy = fixture.debugElement.injector.get(CustomerOnboardService) as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
