import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { cartDetails, CARTITEM, CARTACTION, CMUICONFIGKEY, customerOnboard, planoffer, productBucket, PLANTYPE, productItem } from 'dxp-common';
import * as _ from 'lodash';
import { Subscription } from 'rxjs';
import { LOCALIZATIONPERSISTANCEKEY } from '../../../application-constants';
import { EventEnum } from '../../enum/EventEnum';
import { EventListenerService } from '../../event-listener.service';
import { AuthService } from '../../services/auth.service';
import { CartService } from '../../services/cart.service';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { FormMessageService } from '../services/form-message.service';

declare const alertify;

@Component({
  selector: 'app-plan-list',
  templateUrl: './plan-list.component.html',
  styleUrls: ['./plan-list.component.scss'],
  providers: [CustomerOnboardService]
})
export class PlanListComponent implements OnInit, OnDestroy {
  public planList: planoffer[];
  public tempPlanList: any;
  public noOfPages: any;
  abortJourney: Subscription;
  languageChange: Subscription;
  saveJourney: Subscription;
  private customChannelSubscription: Subscription;
  private customCmsSubscription: Subscription;
  public preActivatedPlanOffer: planoffer;
  public preActivatedPlanId: string; // = "CM_Combo_555";
  public first = true;

  public sortByMinMax;
  // public serviceNames;
  /* Plan Params*/
  dataSelect: any = [];
  voiceSelect: any = [];
  smsSelect: any = [];
  dataSelectDisplay: any = [];
  voiceSelectDisplay: any = [];
  smsSelectDisplay: any = [];
  customPriceCalculator: Number = 0;
  selectedCustomdata: String = '';
  selectedCustomvoice: String = '';
  selectedCustomsms: String = '';
  tempCustomizePlanObj: any = {};
  customPlansList: any;
  showCustomRecurrencePeriod:boolean = false;
  dataSelectArrow = false;
  smsSelectArrow = false;
  voiceSelectArrow = false;
  dataLabel: string;
  voiceLabel: string;
  smsLabel: string;
  customMappedData: planoffer = {
    'title': '',
    'summary': '',
    'coverImage': '',
    'frontImage': '',
    'backImage': '',
    'id': '',
    'name': '',
    'description': '',
    'offerType': PLANTYPE.CUSTOMIZEPLANOFFER,
    'productOfferingPrice': 0,
    'productBuckets': null,
    'periodTypes': null,
    currency: null,
    recurrencePeriod: null
  };

  public path1: string[] = ['productOfferingPrice']; // empty error
  public order1 = 1; // 1 asc, -1 desc, undefined no sort

  public productActivePage = 1;
  public productMaxVisibleItems: number;
  public searchProductText = '';

  selectedValue = -1;

  selectedCustomPlans: productItem[];
  selectedBasePlan: productItem;
  tooltipData: String = "";


  constructor(private router: Router, private formBuilder: FormBuilder,
    private customerOnBoardService: CustomerOnboardService,
    private persistenceService: PersistenceService,
    private authService: AuthService,
    private translate: TranslateService,
    private event: EventListenerService,
    private formMessageService: FormMessageService,
    private cartService:CartService) {

  }

  ngOnInit() {
    this.planList = [];
    this.productMaxVisibleItems = this.persistenceService.get(CMUICONFIGKEY.NUMBEROFPLANSPERPAGE, StorageType.SESSION);
    this.productMaxVisibleItems = this.productMaxVisibleItems - 1;
    // on language update
    this.languageChange = this.event.lanuageChangeEvent.subscribe(data => {
      if (data && data.isUserSelected && data.eventType && data.eventType === EventEnum.languageUpdated) {
        this.loadPlans(false);
        this.loadSortData();
      }
    });

    //select pre-activated plan
    const journeyData: customerOnboard = this.formMessageService.onboardingForm.value as customerOnboard;
    if (journeyData && journeyData.preActivatedBaseOffer && journeyData.preActivatedBaseOffer.id) {
      this.preActivatedPlanId = journeyData.preActivatedBaseOffer.id;
      this.productMaxVisibleItems = this.productMaxVisibleItems - 1;
    }

    //load plans
    this.loadPlans(true);
    //load sort
    this.loadSortData();

    // when customer clicks cancel to abort journey
    this.abortJourney = this.event.customerOnAbortJourneyEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.customerOnAbortJourney) {
        if (this.cartService.cartDetails && this.cartService.cartDetails.cartList
          && this.cartService.cartDetails.cartList.length > 0) {
          this.event.confirmPopup(this.customerOnBoardService, this.formMessageService, data.retainState);
        } else {
          this.formMessageService.onboardingForm.reset();
          this.router.navigate(['/public']);
        }
      }
    });

    //when user clicks save button
    this.saveJourney = this.event.customerOnSaveJourneyExplicitlyEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.customerOnSaveJourneyExplicitly && data.retainState) {
        this.event.saveCartDetailsPopup(this.customerOnBoardService, this.formMessageService, data.retainState);
        this.formMessageService.saveCartForm.reset();
      }
    });


    //highlight add on plans added and deselect from tiles when deleted from cart
    this.event.notifyCartUpdateEvent.subscribe((data) => {
      if (data && data.eventType) {
        if (data.eventType == EventEnum.notifyCartUpdated) {
          if (data.cartDetails) {
            this.cartId = data.cartDetails.id;
            this.prefillCustomDropDown(data.cartDetails);
            this.preselectBasePlan(data.cartDetails);
          }
        }
      }
    });

  }

 resetCustomDropDownValues(){
   const selectLabel = this.translate.instant("Select");
   this.selectedCustomdata = '';
   this.selectedCustomvoice = '';
   this.selectedCustomsms = '';
   this.selectedCustomPlans = null;
   this.customPriceCalculator = 0;
   this.showCustomRecurrencePeriod = false;
 }

  getSelectedCustomeValue(planType: string, planId: string, price, from: string) {
    this.tempCustomizePlanObj[planType] = planId;
    if (this['selectedCustom' + planType] !== '' && this['selectedCustom' + planType] === planId && from === 'view') {
      this['selectedCustom' + planType] = '';
      delete this.tempCustomizePlanObj[planType];
    } else {
      this['selectedCustom' + planType] = planId;
    }
    // if (!planId) {
    //   delete this.tempCustomizePlanObj[planType];
    // }
    // this.tempCustomizePlanObj[planType] = planId;
    this.customPriceCalculator = this.priceCalculator(price);
  }

  changeDisplay(planType: string, operation: string) {
    let startIndex: number;
    for (let i = 0; i < this[planType + 'Select'].length; i++) {
      if (this[planType + 'Select'][i].value === this[planType + 'SelectDisplay'][0].value) {
        startIndex = i;
      }
    }
    if (operation === 'right') {
      if (startIndex === this[planType + 'Select'].length - 1) {
        startIndex = -1;
      }
      this[planType + 'SelectDisplay'] = this[planType + 'Select'].slice(startIndex + 1, startIndex + 7);
      if (this[planType + 'SelectDisplay'].length < 6) {
        this[planType + 'SelectDisplay'] = this[planType + 'SelectDisplay'].concat(this[planType + 'Select'].slice(0, 6 - this[planType + 'SelectDisplay'].length));
      }
    } else {
      if (startIndex === 0) {
        startIndex = this[planType + 'Select'].length;
      }
      this[planType + 'SelectDisplay'] = this[planType + 'Select'].slice(startIndex - 1, startIndex + 5);
      const arrLen = this[planType + 'SelectDisplay'].length;
      if (arrLen < 6) {
        let j = 0;
        for (let i = arrLen; i < 6; i++) {
          this[planType + 'SelectDisplay'].push(this[planType + 'Select'][j]);
          j++;
        }
      }
    }
  }

  private priceCalculator(price) {
    this.showCustomRecurrencePeriod = true;
    let totalPrice = 0;
    if (price > 0) {
      totalPrice = this.customPriceCalculator + price;
    } else {
      _.keys(this.tempCustomizePlanObj).forEach(key => {
        const pack = _.find(this.customPlansList, { 'id': this.tempCustomizePlanObj[key] });
        totalPrice = totalPrice + pack.productOfferingPrice;
      });
    }
    return totalPrice;
  }

  public isCustomPlan(item: planoffer) {
    return item.offerType === PLANTYPE.CUSTOMIZEPLANOFFER;
  }


  async loadPlans(preFillData: boolean) {
    const lang = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
    // todo market segment
    const offerType = this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMESFORVASEOFFERQUERY, StorageType.SESSION);
    // const customOfferType = [this.CustomizePlanOffer];
    const planAddOnData = await this.customerOnBoardService.getPlanAddonsDetails(lang, offerType, this.formMessageService.onboardingForm.value as customerOnboard).toPromise();
    const planAddOnWithDigitalAssets = await this.customerOnBoardService.getCMSDigitalAssets(planAddOnData, lang, offerType).toPromise();
    const plansAddOnDataAllItems = planAddOnData.map((item) => {
      let isItemInCMS = planAddOnWithDigitalAssets.filter(x => x.id === item.id);
      let CMSOffer: planoffer;
      if (isItemInCMS && isItemInCMS[0]) {
        CMSOffer = isItemInCMS[0];
      }
      else {
        CMSOffer = {
          "title": item.name || "",
          "summary": item.description || "",
          "coverImage": "assets/imgs/no-image-icon.png",
          "frontImage": "",
          "backImage": "",
          "id": item['id'] || "",
          "name": item['name'] || "",
          "description": item.description || "",

          "offerType": item['offerType'] || "",
          "productOfferingPrice": item['productOfferingPrice']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']['price']
            && item['productOfferingPrice']['0']['price']['amount']
            ? item['productOfferingPrice']['0']['price']['amount'] : 0,
            "priceType": item['productOfferingPrice']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']['priceType']
            ? item['productOfferingPrice']['0']['priceType'] : null,
          "productBuckets": item['productBuckets'] ?
            item['productBuckets'].map(item => {
              const productBucket: productBucket = this.customerOnBoardService.calculateDisplay(item);
              return productBucket;
            }) : null,
          periodTypes: item['productOfferingPrice']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']['priceType']
            ? item['productOfferingPrice']['0']['priceType'] : null,
          recurrencePeriod: item['productOfferingPrice']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']['recurrencePeriod']
            ? item['productOfferingPrice']['0']['recurrencePeriod'] : null,
          currency: item['productOfferingPrice']
            && item['productOfferingPrice']['0']
            && item['productOfferingPrice']['0']['price']
            && item['productOfferingPrice']['0']['price']['currency'] ?
            item['productOfferingPrice']['0']['price']['currency']
            : null
        }
      }
      return CMSOffer;
    });

    const planBaseStandardList = plansAddOnDataAllItems.filter(x => x.offerType !== PLANTYPE.CUSTOMIZEPLANOFFER && x.id !== this.preActivatedPlanId);
    const planCustomPlanList = plansAddOnDataAllItems.filter(x => x.offerType === PLANTYPE.CUSTOMIZEPLANOFFER);
    const preActivatedPlanList = plansAddOnDataAllItems.filter(x => x.id === this.preActivatedPlanId);
    const customPlanCMSList = planAddOnWithDigitalAssets.filter(x => x.id === PLANTYPE.CUSTOMIZEPLANOFFER);
    if (planCustomPlanList && planCustomPlanList[0]) {
      if (customPlanCMSList && customPlanCMSList[0]) {
        this.customMappedData.coverImage = customPlanCMSList[0].coverImage === undefined || customPlanCMSList[0].coverImage === '' ? 'assets/imgs/no-image-icon.png' : customPlanCMSList[0].coverImage;
        this.customMappedData.title = customPlanCMSList[0].title || '';
        this.customMappedData.summary = customPlanCMSList[0].summary || '';
      } else {
        this.customMappedData.coverImage = 'assets/imgs/no-image-icon.png';
        this.customMappedData.title = 'Custom Plan';
      }
      this.customMappedData.recurrencePeriod = planCustomPlanList[0].recurrencePeriod || null;
    }


    if (preActivatedPlanList && preActivatedPlanList.length) {
      this.preActivatedPlanOffer = preActivatedPlanList[0];
    }


    this.planList = [...planBaseStandardList];
    this.customMappedData.currency = this.planList[0].currency;

    let onlyProductBucketsOfCustomPlan = [];
    _.forEach(planCustomPlanList, (item) => {
      if(item && item.productBuckets){
        onlyProductBucketsOfCustomPlan = onlyProductBucketsOfCustomPlan.concat(item.productBuckets.map(x =>{
          x.id = item.id;
          return x;
        }));
      }
    });

    const uniqueProductBuckets = _.uniqWith(onlyProductBucketsOfCustomPlan, (a,b) => { return a.initialBalance === b.initialBalance && a.serviceName === b.serviceName});
    const groups = _.groupBy(uniqueProductBuckets, 'serviceName');
    this.dataLabel = groups.data && groups.data.length > 0 ? groups.data[0].name : 'Data';
    this.voiceLabel = groups.voice && groups.voice.length > 0 ? groups.voice[0].name : 'Voice';
    this.smsLabel = groups.sms && groups.sms.length > 0 ? groups.sms[0].name : 'SMS';
    this.customPlansList = planCustomPlanList;
    this.dataSelect = groups.data ? groups.data.map((item) => {
      return {
        value: item.id || '',
        label: item.forDisplay ? item.forDisplay.toUpperCase().indexOf('UNLIMITED') !== -1 ? '∞' : parseInt(item.forDisplay.toUpperCase().replace('DATA', '').replace('GB', '').trim()) : 0
      };
    }) : [];
    this.dataSelect = _.orderBy(this.dataSelect, ['label'], ['asc']);
    this.dataSelectDisplay = this.dataSelect.slice(0, 6);
    this.dataSelectArrow = this.dataSelect.length > 6 ? true : false;
    this.voiceSelect = groups.voice ? groups.voice.map((item) => {
      return {
        value: item.id || '',
        label: item.forDisplay ? item.forDisplay.toUpperCase().indexOf('UNLIMITED') !== -1 ? '∞' : parseInt(item.forDisplay.toUpperCase().replace('MIN', '').replace('MINS', '').replace('MINUTES', '').trim()) : 0
      };
    }) : [];
    this.voiceSelect = _.orderBy(this.voiceSelect, ['label'], ['asc']);
    this.voiceSelectDisplay = this.voiceSelect.slice(0, 6);
    this.voiceSelectArrow = this.voiceSelect.length > 6 ? true : false;
    this.smsSelect = groups.sms ? groups.sms.map((item) => {
      return {
        value: item.id || '',
        label: item.forDisplay ? item.forDisplay.toUpperCase().indexOf('UNLIMITED') !== -1 ? '∞' : parseInt(item.forDisplay.toUpperCase().replace('SMS', '')) : 0
      };
    }) : [];
    this.smsSelect = _.orderBy(this.smsSelect, ['label'], ['asc']);
    this.smsSelectDisplay = this.smsSelect.slice(0, 6);
    this.smsSelectArrow = this.smsSelect.length > 6 ? true : false;

    if(!this.cartId) {
      this.resetCustomDropDownValues();
    }
    else if(preFillData) {
      this.cartService.getCartDetails().subscribe(data => {
        this.prefillCustomDropDown(data);
        this.preselectBasePlan(data);
      });
    }
  }

  loadSortData() {
    const sortData = [
      { value: -1, label: this.translate.instant('Price(min-max)') },
      { value: 1, label: this.translate.instant('Price(max-min)') }
    ];
    this.sortByMinMax = [...sortData];
  }

  redirectTo(route) {
    this.router.navigate(route.split('/'));
  }

  public productSearchUpdatedValue(v: any) {
    this.productActivePage = 1;
  }

  changePage(event: any) {
    this.productActivePage = +event.target.text;
  }

  nextPage() {
    this.productActivePage += 1;
  }

  previousPage() {
    this.productActivePage -= 1;
  }

  getSelectedValue(val: number): boolean {
    this.order1 = val * (-1); // change order
    return false; // do not reload
  }

  isActive(item: planoffer) {
    return this.selectedBasePlan && this.selectedBasePlan.productOffering
      && this.selectedBasePlan.productOffering.id === item.id;
  }
  selectedStandardPlansId: productItem[];

  getRecurrencePeriod(item) {
    return item.recurrencePeriod ? ' for ' + item.recurrencePeriod.periodType : null
  }

  zeroCheck(item, isPlanUpdate) {
    if (this.selectedCustomdata === '' && this.selectedCustomvoice === '' && this.selectedCustomsms === '') {
      return true;
    }
    return false;
  }

  async addCustomPlanToCart(item: planoffer) {
    let cartDetails: cartDetails = null;
    const isPlanUpdate = this.cartId ? true : false;
    if (this.zeroCheck(item, isPlanUpdate)) {
      alertify.error(this.translate.instant('Selected plan should contain some value'));
      return false;
    }
    if (isPlanUpdate) {
      cartDetails = await this.cartService.getCartDetails().toPromise();
    }
    if (_.size(this.tempCustomizePlanObj) !== 0) {
      let cartResponse: any;
      const items = _.keys(this.tempCustomizePlanObj).map((key) => {
        return _.find(this.customPlansList, { 'id': this.tempCustomizePlanObj[key] });
      });
      cartResponse = await this.customerOnBoardService.addCustomPlanToCart(items, this.formMessageService.onboardingForm.value as customerOnboard, cartDetails).toPromise();
      //clear base plan selection
      this.selectedBasePlan = null;
      cartDetails = await this.cartService.getCartDetails().toPromise();
      this.prefillCustomDropDown(cartDetails);
      this.event.notifyCartUpdate(cartDetails);
      this.showCartUpdateMessage(isPlanUpdate);
    }
  }

  private prefillCustomDropDown(cartDetails: cartDetails) {

    this.selectedCustomPlans = cartDetails.cartList.filter(x => x.productOffering.offerType === PLANTYPE.CUSTOMIZEPLANOFFER);
    this.customPriceCalculator = 0;
    this.selectedCustomdata = '';
    this.selectedCustomsms = '';
    this.selectedCustomvoice = '';

    for (let i = 0; i < this.selectedCustomPlans.length; i++) {
      if (_.findIndex(this.dataSelect, ['value', this.selectedCustomPlans[i].productOffering.id]) > -1) {
        this.selectedCustomdata = this.selectedCustomPlans[i].productOffering.id;
        this.getSelectedCustomeValue('data', this.selectedCustomPlans[i].productOffering.id, this.selectedCustomPlans[i].itemPrice[0].price.amount, 'ts');
      }
      if (_.findIndex(this.smsSelect, ['value', this.selectedCustomPlans[i].productOffering.id]) > -1) {
        this.selectedCustomsms = this.selectedCustomPlans[i].productOffering.id;
        this.getSelectedCustomeValue('sms', this.selectedCustomPlans[i].productOffering.id, this.selectedCustomPlans[i].itemPrice[0].price.amount, 'ts');
      }
      if (_.findIndex(this.voiceSelect, ['value', this.selectedCustomPlans[i].productOffering.id]) > -1) {
        this.selectedCustomvoice = this.selectedCustomPlans[i].productOffering.id;
        this.getSelectedCustomeValue('voice', this.selectedCustomPlans[i].productOffering.id, this.selectedCustomPlans[i].itemPrice[0].price.amount, 'ts');
      }
    }

      //clear selection of tiles
    if (cartDetails && cartDetails.cartList && cartDetails.cartList.length === 0) {
      this.resetCustomDropDownValues();
    }
  }



  isCustomActive() {
    return this.selectedCustomPlans && this.selectedCustomPlans.length > 0
  }

  async addToCart(item: planoffer) {
    let cartDetails: cartDetails = null;
    // if cart exists plan will be updating
    const isPlanUpdate = this.cartId ? true : false;
    if (!this.isActive(item)) {
      if (isPlanUpdate) {
        cartDetails = await this.cartService.getCartDetails().toPromise();
      }
      const cartInfo = await this.customerOnBoardService.addToCart(item, this.formMessageService.onboardingForm.value as customerOnboard, cartDetails).toPromise();
      cartDetails = await this.cartService.getCartDetails().toPromise();
      this.resetCustomDropDownValues();
      this.showCartUpdateMessage(isPlanUpdate);
      this.event.notifyCartUpdate(cartDetails);
      this.preselectBasePlan(cartDetails);
    }
  }


  preselectBasePlan(cartDetails: cartDetails) {
    const basePlans = cartDetails.cartList.filter(x => (x.productOffering.offerType !== PLANTYPE.CUSTOMIZEPLANOFFER
      && x.productOffering.offerType !== CARTITEM.ADDON && x.action !== CARTACTION.ACTIVE));
    if (basePlans && basePlans[0]) {
      this.selectedBasePlan = basePlans[0];
    }
    else{
      this.selectedBasePlan = null;
    }

    //clear highlights
    if(cartDetails && cartDetails.cartList && cartDetails.cartList.length ===0){
      this.selectedBasePlan = null;
    }

  }

  private showCartUpdateMessage(isPlanUpdate) {
    isPlanUpdate ? alertify.success(this.translate.instant('Plan updated to cart')) :
      alertify.success(this.translate.instant('Added to cart'));
  }

  get cartId(): string {
    if(this.cartService.cartDetails && this.cartService.cartDetails.id){
      return this.cartService.cartDetails.id;
    }
    return null;
  }

  set cartId(id: string) {
    this.formMessageService.onboardingForm.controls.shoppingCartId.setValue(id);
  }

  ngOnDestroy() {
    if(this.abortJourney){
      this.abortJourney.unsubscribe();
    }
    if(this.saveJourney){
      this.saveJourney.unsubscribe();
    }
    if(this.languageChange){
      this.languageChange.unsubscribe();
    }
  }

  getTooltipData(productBucket) {
    this.tooltipData = '<ul class="list-type pl-3 my-1">';
    productBucket.forEach(element => {
      this.tooltipData += '<li>' + element.forDisplay + '</li>';
    });
    this.tooltipData += '</ul>';
    return this.tooltipData;
  }

}
