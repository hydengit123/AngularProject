import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY } from 'dxp-common';
import { ModalDirective } from 'ng-uikit-pro-standard';
import { Subscription } from 'rxjs';
import { PERSISTANCEKEY } from '../../../application-constants';
import { EventListenerService } from '../../event-listener.service';
import { AuthService } from '../../services/auth.service';
import { CartService } from '../../services/cart.service';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { CustomerSearchDataService } from '../../services/customer-search-data.service';
import { CustomerSearchService } from '../../services/customer-search.service';
import { PaymentGatewayService } from '../../services/payment-gateway.service';
import { loginValidator } from '../../shared/validators/LoginValidator';
import { FormMessageService } from '../services/form-message.service';




declare const alertify;

@Component({
  selector: 'app-save-cart-details',
  templateUrl: './save-cart-details.component.html',
  styleUrls: ['./save-cart-details.component.scss']
})
export class SaveCartDetailsComponent implements OnInit {
  saveCartForm: FormGroup;
  public activationDetails;
  submitted = false;
  enableOTP: Boolean;
  public saveCartData;
  public notificationValue: number = 0;
  public customerOnboardService: CustomerOnboardService;
  // public formMessageService: FormMessageService;
  public retainState: boolean;
  unsubscribeFirstName: Subscription;
  unsubscribeLastName: Subscription;
  unsubscribeIdentifier: Subscription;
  registerForm: FormGroup;
  phoneNumberLength: number;
  phoneNumberMaxLength: number;

  @Input() basicModal: ModalDirective;


  constructor(private formBuilder: FormBuilder,
    private persistenceService: PersistenceService,
    private translateService: TranslateService,
    private eventListenerService: EventListenerService,
    private paymentGatewayService: PaymentGatewayService,
    private customerSearchDataService: CustomerSearchDataService,
    private customerSearchService: CustomerSearchService,
    private authService: AuthService,
    private router: Router,
    public formMessageService: FormMessageService,
    private cartService: CartService) {


    this.registerForm = new FormGroup({
      username: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required])

    },
      [loginValidator(this.persistenceService)]
    );

  }


  ngOnInit() {
    this.saveCartForm = this.formMessageService.saveCartForm;
    this.activationDetails = this.formMessageService.activationDetails;
    this.saveCartForm.controls.optedForSelfcareRegistration.setValue(true);
    this.enableOTP = this.persistenceService.get(CMUICONFIGKEY.ENABLEOTP, StorageType.SESSION);
    this.phoneNumberLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION);
    this.phoneNumberMaxLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION);
    if (this.formMessageService && this.formMessageService.personalInformation && this.formMessageService.personalInformation.controls && this.formMessageService.personalInformation.controls.firstName && this.formMessageService.personalInformation.controls.firstName.value) {
      this.formMessageService.saveCartForm.controls.firstName.setValue(this.formMessageService.personalInformation.controls.firstName.value);
    }
    if (this.formMessageService && this.formMessageService.personalInformation && this.formMessageService.personalInformation.controls && this.formMessageService.personalInformation.controls.lastName && this.formMessageService.personalInformation.controls.lastName.value) {
      this.formMessageService.saveCartForm.controls.lastName.setValue(this.formMessageService.personalInformation.controls.lastName.value);
    }
    if (this.formMessageService && this.formMessageService.signUInfo && this.formMessageService.signUInfo.controls && this.formMessageService.signUInfo.controls.signUpEmail && this.formMessageService.signUInfo.controls.signUpEmail.value) {
      this.formMessageService.saveCartForm.controls.identifier.setValue(this.formMessageService.signUInfo.controls.signUpEmail.value);

    }

  }

  ngOnDestroy() {
    // if (this.unsubscribeFirstName) {
    //   this.unsubscribeFirstName.unsubscribe();
    // }
    // if (this.unsubscribeLastName) {
    //   this.unsubscribeLastName.unsubscribe();
    // }
    // if (this.unsubscribeIdentifier) {
    //   this.unsubscribeIdentifier.unsubscribe();
    // }
  }

  // convenience getter for easy access to form fields
  get formControl() {
    return this.saveCartForm.controls;
  }

  async onSubmit() {
    let email = this.saveCartForm.controls.identifier.value;
    let msisdn = this.activationDetails.controls.phoneNumber.value;
    const customerId = this.formMessageService.onboardingForm.controls.customerId.value;
    const userId = this.formMessageService.onboardingForm.controls.userId.value;
    const partyId = this.formMessageService.onboardingForm.controls.partyId.value;

    if (this.saveCartForm.invalid) {
      return;
    }

    const saveCartData = await this.customerOnboardService.saveCart(this.saveCartForm.value, msisdn, customerId, userId, partyId).toPromise();
    if (saveCartData.partyId && saveCartData.userProfileId && saveCartData.customerId) {
      this.formMessageService.onboardingForm.controls.partyId.setValue(saveCartData.partyId);
      this.formMessageService.onboardingForm.controls.userId.setValue(saveCartData.userProfileId);
      this.formMessageService.onboardingForm.controls.customerId.setValue(saveCartData.customerId);
    }
    const saveCartWithJourneySessionData = await this.customerOnboardService.createSaveCartJourneySessionInteraction(this.formMessageService.onboardingForm.value,
      this.cartService.cartDetails, null).toPromise();
      this.formMessageService.onboardingForm.controls.journeySessionId.setValue(saveCartWithJourneySessionData.id);
      alertify.success(this.translateService.instant('Saved Journey'));
    if(this.retainState){
      this.doLogin(this.saveCartForm.value.identifier, this.saveCartForm.value.credential, true);
    }
    if (!this.retainState) {
      this.formMessageService.resetServiceData();
      this.cartService.resetServiceData();
      this.router.navigate(['/public']);
    }
    this.eventListenerService.closeCustomerOnBoardPopup();
    
  }


  async save(username, customerIdparam, partyID) {
    this.formMessageService.onboardingForm.controls.partyId.setValue(partyID);
    this.formMessageService.onboardingForm.controls.userId.setValue(username);
    this.formMessageService.onboardingForm.controls.customerId.setValue(customerIdparam);

    const saveCartWithJourneySessionData = await this.customerOnboardService.createSaveCartJourneySessionInteraction(this.formMessageService.onboardingForm.value,
      this.cartService.cartDetails, null).toPromise();

    this.eventListenerService.closeCustomerOnBoardPopup();
    if (!this.retainState) {
      this.formMessageService.resetServiceData();
      this.cartService.resetServiceData();
      this.persistenceService.remove(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
      this.persistenceService.remove(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
      this.persistenceService.remove(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
      this.router.navigate(['/public']);
    }

  }


  onCancel() {
    this.formMessageService.onboardingForm.reset();
    this.router.navigate(['/public']);
  }


  doLogin(userName=null, password=null, isFromRegistration = null): void {
    if(!userName && !password){
      userName = this.registerForm.value.username;
      password = this.registerForm.value.password;
    }

    this.authService.login(userName, password)
      .subscribe(
        (res: any) => {
          this.persistenceService.set(PERSISTANCEKEY.PARTYID, res["partyId"], { type: StorageType.SESSION });
          this.persistenceService.set(PERSISTANCEKEY.ACCESSTOKEN, res["access_token"], { type: StorageType.SESSION });
          this.customerSearchDataService.setUserProfileData(res["partyId"])
            .subscribe((profiledata) => {
              this.persistenceService.set(PERSISTANCEKEY.CUSTOMERID, profiledata["customerId"], { type: StorageType.SESSION });
              if(!isFromRegistration){
              this.save(userName, profiledata.customerID, res["partyId"]);
              this.basicModal.hide();
              }
              this.eventListenerService.notifyLogin(true);
            })
        },
        (error) => {
          alertify.error(this.translateService.instant('Invalid Username/Password'));
        }
      )
  }

  onBlurValidation(fieldName) {

    loginValidator(this.persistenceService);
    let isError = false;
    const errors = this.registerForm.errors;
    const username = this.registerForm.controls.username.touched;
    if (errors && fieldName && !this.registerForm.controls[fieldName].value) {
      errors[fieldName + 'RequiredError'] = true;
      isError = true;
      // this.validationIniatiated = true;
    }
  }

}
