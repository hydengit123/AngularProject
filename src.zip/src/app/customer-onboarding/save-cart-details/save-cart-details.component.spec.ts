import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveCartDetailsComponent } from './save-cart-details.component';

describe('SaveCartDetailsComponent', () => {
  let component: SaveCartDetailsComponent;
  let fixture: ComponentFixture<SaveCartDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaveCartDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveCartDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
