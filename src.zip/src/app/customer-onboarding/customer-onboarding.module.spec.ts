import { CustomerOnboardingModule } from './customer-onboarding.module';

describe('CustomerOnboardingModule', () => {
  let customerOnboardingModule: CustomerOnboardingModule;

  beforeEach(() => {
    customerOnboardingModule = new CustomerOnboardingModule();
  });

  it('should create an instance', () => {
    expect(customerOnboardingModule).toBeTruthy();
  });
});
