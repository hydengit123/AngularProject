import { ModalFooterDirective } from './modal-footer.directive';

describe('ModalFooterDirective', () => {
  it('should create an instance', () => {
    const directive = new ModalFooterDirective(null);
    expect(directive).toBeTruthy();
  });
});
