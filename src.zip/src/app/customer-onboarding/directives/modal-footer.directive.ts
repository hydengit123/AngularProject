import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[modal-footer]'
})
export class ModalFooterDirective {

  constructor(public viewCOntainerRef:ViewContainerRef) { }

}
