import { ModalBodyDirective } from './modal-body.directive';

describe('ModalBodyDirective', () => {
  it('should create an instance', () => {
    const directive = new ModalBodyDirective(null);
    expect(directive).toBeTruthy();
  });
});
