import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

import { CustomerOnboardingComponent } from './customer-onboarding.component';
import { PlanListComponent } from './plan-list/plan-list.component';
import { ActivationDetailsComponent } from './activation-details/activation-details.component';
import { AdditionalServicesComponent } from './additional-services/additional-services.component';
import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { PaymentSuccessfulComponent } from './payment-successful/payment-successful.component';
import { SaveCartDetailsComponent } from './save-cart-details/save-cart-details.component';
import { CanActivateCustomerOnBoardRouteGuard } from '../guards/CanActivateCustomerOnBoardRouteGuard';
import { CanActivateRefreshRouteGuard } from '../guards/CanActivateRefreshRouteGuard';



const routes: Routes = [{
    path: '',
    component: CustomerOnboardingComponent,
    children: [{
      path: 'ActivationDetails', component: ActivationDetailsComponent, pathMatch: 'full',
      canActivate: [CanActivateCustomerOnBoardRouteGuard]
    }, {
      path: 'Plan', component: PlanListComponent, pathMatch: 'full', canActivate: [CanActivateRefreshRouteGuard]
    }, {
      path: 'AdditionalServices', component: AdditionalServicesComponent, pathMatch: 'full', canActivate: [CanActivateRefreshRouteGuard]
    }, {
      path: 'ContactDetails', component: ContactDetailsComponent, pathMatch: 'full', canActivate: [CanActivateRefreshRouteGuard]
    }, {
      path: 'AccountDetails', component: AccountDetailsComponent, pathMatch: 'full', canActivate: [CanActivateRefreshRouteGuard]
    }, {
      path: 'checkout', component: CheckoutComponent, pathMatch: 'full', canActivate: [CanActivateRefreshRouteGuard]
    }, {
      path: 'paymentsuccessful', component: PaymentSuccessfulComponent, canActivate: [CanActivateRefreshRouteGuard]
    },{
      path: '', redirectTo: 'ActivationDetails', pathMatch: 'full'
    },
    ]
}];

@NgModule({
imports: [RouterModule.forChild(routes)],
exports: [RouterModule]
})

export class CutomerOnboardingRouting {
}
