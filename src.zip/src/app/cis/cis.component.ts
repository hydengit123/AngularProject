import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY, PaymentRequestInfo } from 'dxp-common';
import { Subscription } from 'rxjs';
import { QuickRechargeFormDetails } from '../../app/interface/quick.recharge.details';
import { ANNONYMOUSUSER, LOCALIZATIONPERSISTANCEKEY, ONBOARDPERSISTANCEKEY, PERSISTANCEKEY, WEBCONTENTPERSISTANCEKEY } from '../../application-constants';
import { CisSettingsService } from '../cis-settings.service';
import { EventEnum } from '../enum/EventEnum';
import { EventListenerService } from '../event-listener.service';
import { IBanner } from '../interface/IBanner';
import { CustomizePlanOffer } from '../interface/product';
import { WebContent } from '../interface/web.content';
import { mockUsername } from '../mockData';
import { AuthService } from '../services/auth.service';
import { ChatbotService } from '../services/chatbot.service';
import { CMSContentService } from '../services/cms-content.service';
import { CustomerService } from '../services/customer.service';
import { ProductService } from '../services/product.service';
import { quickRechargeFormValidator } from './QuickRechargeValidate';


declare const jQuery: any;
declare const alertify;
declare let window: any;

@Component({
  selector: 'app-cis',
  templateUrl: './cis.component.html',
  styleUrls: ['./cis.component.scss'],
  providers: [ProductService, CMSContentService]
})
export class CisComponent implements OnInit, AfterViewInit {

  registerFormModel: FormGroup;
  forgotPFormModel: FormGroup;
  loginForm: FormGroup;
  confirmPasswordModal: FormControl = new FormControl('');
  isMsisdnEntered = false;

  /* Plan description */
  dataPlans = [];
  voicePlans = [];
  smsPlans = [];

  standardPlanOffer: CustomizePlanOffer;
  premiumPlanOffer: CustomizePlanOffer;

  useraddons: CustomizePlanOffer[] = [];
  availableAddons: CustomizePlanOffer[];
  inventory: string[] = [];

  selectedDataPlanIndex = 0;
  selectedVoicePlanIndex = 0;
  selectedSmsPlanIndex = 0;

  webContent: WebContent;
  cmsServiceSubscription: Subscription;

  planIndex = {};
  public bkimg;
  public bannerImg;
  public offerImg;
  public leftImg;
  public standardCollaterals: IBanner[];
  public pdfSrc;
  public pdfName;
  public languages = [];
  public phoneNumber
  public languageForm: FormGroup = new FormGroup({
    'language': new FormControl('en')
  });
  public quickRechargeForm: FormGroup;
  public userDetails: Array<any> = [];
  phoneNumberLength: Number = 0;
  phoneNumberMaxLength: Number = 0;
  quickRechargeSuccessMsgStatus: Boolean = false;
  quickRechargeSuccessMsg: String = '';
  rechargeLimit: any;
  messageBg: String = '';
  public quickRechargeFormDetails: QuickRechargeFormDetails = {
    partyId: '',
    customerId: '',
    firstName: '',
    lastName: '',
    email: ''
  };

  public paymentRequestInfo: PaymentRequestInfo = {
    key: '',
    hash: '',
    txnid: '',
    amount: 0,
    productinfo: '',
    firstname: '',
    lastname: '',
    email: '',
    phone: '',
    surl: '',
    furl: '',
    address1: '',
    address2: '',
    city: '',
    state: '',
    country: '',
    zipcode: '',
    salt: ''
  };


  constructor(private cisss: CisSettingsService,
    private persistenceService: PersistenceService,
    private router: Router,
    private customerService: CustomerService,
    private authService: AuthService,
    private fb: FormBuilder,
    private planService: ProductService,
    private cmsService: CMSContentService,
    private translateService: TranslateService,
    private event: EventListenerService,
    private chatbotService: ChatbotService) {

    this.loginForm = fb.group({
      loginName: ['9824222202', [Validators.required, Validators.pattern(new RegExp('[a-zA-Z0-9]'))]],
      password: ['Password', [Validators.required, Validators.minLength(4)]]
    });

    this.registerFormModel = fb.group({
      id: '',
      firstName: ['', [Validators.required, Validators.pattern(new RegExp('[a-zA-Z0-9]'))]],
      lastName: ['', [Validators.required, Validators.pattern(new RegExp('[a-zA-Z0-9]'))]],
      email: ['', [Validators.required, Validators.email, Validators.pattern(new RegExp('[a-zA-Z0-9]'))]],
      password: ['', [Validators.required, Validators.minLength(4)]],
      phoneModel: '',
      deviceOS: '',
      registrationId: '',
      userStatus: '1',
      msisdn: ['', [Validators.required, Validators.pattern(new RegExp('[a-zA-Z0-9]'))]],
      subscriberCategory: 'POSTPAID'
    });
    this.forgotPFormModel = this.fb.group({
      msisdn: ['', Validators.required],
      otp: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(4)]]
    });

    // this.quickRechargeForm = new FormGroup({
    //   msisdn: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
    //   quota: new FormControl('', [Validators.required, Validators.min(0)])
    // });

  }

  ngOnInit() {
    this.quickRechargeForm = new FormGroup({
      phoneNumber: new FormControl(),
      amount: new FormControl()
    },
      [quickRechargeFormValidator(this.persistenceService)]
    );
    this.genrateAccessToken();
    // this.loadChatbot();

    // const accessToken = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
    // if (accessToken) {
    //   this.router.navigate(['dashboard']);
    // }
    /* for plan info and custom info
     * login using dummy user and use token
     */
    // setTimeout(() => {
    //   this.loginDummyUser();
    // }, 1000);
    this.event.showPaymentSuccessMessageEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.showQuickRechageSuccessMessage && data.response) {
        this.quickRechargeSuccessMsgStatus = true;
        if (data.response && data.response.status === 'completed' || data.response && data.response.status === 'InProgress') {
          alertify.success(this.translateService.instant(data.response.statusReason.code));
          this.quickRechargeForm.reset();
        } else {
          alertify.error(this.translateService.instant(data.response.statusReason.code));
        }
        setTimeout(() => {
          this.quickRechargeSuccessMsgStatus = false;
        }, 5000);
      }
    });

    // when language is persisted
    const languagePersisted = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
    if (languagePersisted) {
      this.languageForm.patchValue({ language: languagePersisted });
    }

    // when language change
    // this.languageForm.valueChanges.subscribe((data) => {
    //   this.event.changeLanguage(data.language);
    // });

    // when CM data updated
    this.event.cmUIDataUpdateEvent.subscribe(data => {
      this.getCMUIInfo();
      const allLanguages = this.persistenceService.get(CMUICONFIGKEY.LANGUAGES, StorageType.SESSION);
      this.languages = allLanguages.map(item => {
        return { value: item.languageCode, label: this.translateService.instant(item.language) };
      });
    });

    //clear dummy token
    if (this.persistenceService.get(PERSISTANCEKEY.DUMMYTOKEN, StorageType.SESSION)) {
      this.persistenceService.remove(PERSISTANCEKEY.DUMMYTOKEN, StorageType.SESSION);
    }

    //on language update
    this.event.lanuageChangeEvent.subscribe(data => {
      if (data && data.eventType && data.eventType === EventEnum.languageUpdated) {
        this.updateWebContent();
      }
    });

    // load Banner, footer CMS image
    this.updateWebContent();

  }

  loadChatbot() {
    this.chatbotService.loadChatbot('');
    if (!!window.Avaamo) {
      this.chatbotService.loadChatbot('');
    } else {
      setTimeout(() => {
        this.loadChatbot();
      }, 1000);
    }
  }

  getCMUIInfo() {
    this.rechargeLimit = this.persistenceService.get(CMUICONFIGKEY.RECHARGE_LIMIT, StorageType.SESSION);
    this.phoneNumberLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION);
    this.phoneNumberMaxLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION);
  }

  genrateAccessToken() {
    this.authService.login(ANNONYMOUSUSER.USERNAME, ANNONYMOUSUSER.PASSWORD)
      .subscribe(
        (data: any) => {
          const res = data;
          this.persistenceService.set(PERSISTANCEKEY.DUMMYTOKEN, res["access_token"], { type: StorageType.SESSION });
        },
        (error) => {
        }
      )
  }

  updateWebContent() {
    const language = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
    // this.loadLanguage(language);
    this.cmsServiceSubscription = this.cmsService.getWebPageContent('selfcare', language).subscribe((data: any) => {
      this.persistenceService.set(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, data, { type: StorageType.SESSION });
      this.webContent = this.persistenceService.get(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, StorageType.SESSION);
      if (this.webContent) {
        if (this.webContent.footerImage) {
          this.bkimg = this.webContent.footerImage.url;
        }
        if (this.webContent.banner) {
          this.bannerImg = this.webContent.banner.url;
        }
        if (this.webContent.leftImage) {
          this.leftImg = this.webContent.leftImage.url;
        }
        if (this.webContent.offersBanner) {
          this.offerImg = this.webContent.offersBanner.url;
        }
      }
    },
      (error) => {
        if (error.status == 404) {
          alertify.error(this.translateService.instant('CMS server down'));
        } else if (error.error) {
          alertify.error(error.error.message);
        }
        else {
          alertify.error(error.message);
        }
      });
  }

  loadLanguage(language: string) {

    this.translateService.use(language).subscribe(
      (res) => {
        //check for RTL
      }
    );

  }


  ngAfterViewInit(): void {
    jQuery(document).ready(function () {
      // close collapsible menu when menu item click on responsive mode
      jQuery('#navb .nav-link').click(function () {
        if (window.innerWidth < 992) {
          jQuery('.navbar-toggler').trigger('click');
        }
      });

      // Select all links with hashes
      jQuery('.navbar a[href*="#"]')
        // Remove links that don't actually link to anything
        .not('[href="#"]')
        .not('[href="#0"]')
        .click(function (event) {
          event.preventDefault();
          // On-page links
          // Figure out element to scroll to
          let hasTarget = jQuery(this.hash);
          hasTarget = hasTarget.length ? hasTarget : jQuery('[name=' + this.hash.slice(1) + ']');
          // Does a scroll target exist?
          if (hasTarget.length) {
            // Only prevent default if animation is actually gonna happen
            event.preventDefault();
            jQuery('html, body').animate({
              scrollTop: hasTarget.offset().top
            }, 700, function () {
              // Callback after animation
              // Must change focus!
              const target = jQuery(hasTarget);
              target.focus();
              if (target.is(':focus')) { // Checking if the target was focused
                return false;
              } else {
                target.attr('tabindex', '-1'); // Adding tabindex for elements not focusable
                target.focus(); // Set focus again
              }
            });
          }

        });
    });
  }

  // loginDummyUser() {
  //   this.getDummyToken().then(() => {
  //     this.getAddons();
  //     this.getInventory();
  //     return Promise.all([
  //       this.planService.getCustomOffer(),
  //       this.planService.getPlanByType('Premium'),
  //       this.planService.getPlanByType('Standard')]);
  //   }).then(data => {
  //     const [customOffer, premium, standard] = data;
  //     this.dataPlans = customOffer.dataPlans;
  //     this.voicePlans = customOffer.voicePlans;
  //     this.smsPlans = customOffer.smsPlans;
  //     this.premiumPlanOffer = premium;
  //     this.standardPlanOffer = standard;
  //     this.persistenceService.set(ONBOARDPERSISTANCEKEY.CUSTOMOFFER, customOffer, { type: StorageType.SESSION });
  //     this.persistenceService.set(ONBOARDPERSISTANCEKEY.PREMIUM, premium, { type: StorageType.SESSION });
  //     this.persistenceService.set(ONBOARDPERSISTANCEKEY.STANDARD, standard, { type: StorageType.SESSION });
  //     this.removeDummyToken();
  //   }).catch(error => {
  //     this.removeDummyToken();
  //   });
  // }

  // async getDummyToken() {
  //   const res = await this.authService.login('9824000101', 'Password').toPromise();
  //   if (!this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION)) {
  //     this.persistenceService.set(PERSISTANCEKEY.ACCESSTOKEN, res.access_token, { type: StorageType.SESSION });
  //   } else {
  //     throw new Error('access-token set');
  //   }
  //   return res.access_token;
  // }

  removeDummyToken() {
    this.persistenceService.remove(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
  }


  doLogin(): void {
    const data = this.loginForm.value;
    this.authService.login(data.loginName, data.password)
      .subscribe(this.onLoginSuccess.bind(this));
  }

  registerUser() {
    if (this.registerFormModel.controls['password'].value !== this.confirmPasswordModal.value) {
      alertify.error(this.translateService.instant('password mismatch'));
      return false;
    }
    this.customerService.registerUser(this.registerFormModel.value)
      .subscribe((data) => {
        alertify.success(this.translateService.instant('User Registered Successfully'));
        this.registerFormModel.reset();
        this.confirmPasswordModal.reset();
        jQuery('#Register').modal('hide');
      }, error => {
        alertify.error(this.translateService.instant("Username and Password doesn't match"));
      });
  }

  onLoginSuccess(res: any): void {
    // jQuery('#loginForm').modal('hide');
    // const data = this.loginForm.value;
    // this.persistenceService.set(PERSISTANCEKEY.ACCESSTOKEN, res.access_token, {
    //   type: StorageType.SESSION
    // });
    // this.persistenceService.set(PERSISTANCEKEY.MSISDN, data.loginName, {
    //   type: StorageType.SESSION
    // });
    // this.getCustomerInfo();
    // this.persistenceService.set(PERSISTANCEKEY.USER, btoa(JSON.stringify(data)), { type: StorageType.SESSION });
    // setTimeout(() => {
    //   // this.router.navigate(['dashboard']);
    // }, 500);
  }

  getCustomerInfo() {
    const msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
    this.customerService.getCustomerInfo(msisdn)
      .subscribe(data => {
        this.persistenceService.set(PERSISTANCEKEY.USERNAME, data.firstName + ' ' + data.lastName, { type: StorageType.SESSION });
      }, error => {
        this.persistenceService.set(PERSISTANCEKEY.USERNAME, mockUsername, { type: StorageType.SESSION });
      });
  }

  getAddons() {
    if (!this.availableAddons) {
      this.availableAddons = this.persistenceService.get(ONBOARDPERSISTANCEKEY.USERADDON, StorageType.SESSION);
    }
    this.planService.getAddons()
      .subscribe((data: CustomizePlanOffer[]) => {
        if (Array.isArray(data) && data.length > 0) {
          this.availableAddons = data;
          this.persistenceService.set(ONBOARDPERSISTANCEKEY.USERADDON, this.availableAddons, { type: StorageType.SESSION });
        }
      }, error => {

      });
  }

  getInventory() {
    this.planService.getInventory().then(data => {
      this.inventory = data;
      this.persistenceService.set(ONBOARDPERSISTANCEKEY.INVENTORY, this.inventory, { type: StorageType.SESSION });
    }).catch(error => {
      alertify.error(this.translateService.instant('Error fetching inventory'));
    });
  }

  // showCollateralContent(collateral: IBanner) {
  //   jQuery('#CollateralModal').off("shown.bs.modal");
  //   jQuery('#CollateralModal').on("shown.bs.modal", (e)=>{
  //     this.pdfSrc = collateral.url;
  //     this.pdfName = collateral.id;
  //   });
  //   setTimeout(() => {
  //     jQuery('#CollateralModal').modal('show');
  //   }, 300);
  // }

  switchToRegister() {
    jQuery('#Register').modal('hide');
    setTimeout(() => {
      jQuery('#loginForm').modal('show');
    }, 300);
  }

  switchToForgot() {
    jQuery('#loginForm').modal('hide');
    setTimeout(() => {
      jQuery('#forgotPasswordForm').modal('show');
    }, 300);
  }

  getSumForCustom() {
    let total = 0;
    if (this.dataPlans.length > 0) {
      total = total + this.dataPlans[this.selectedDataPlanIndex].price;
    }
    if (this.voicePlans.length > 0) {
      total = total + this.voicePlans[this.selectedVoicePlanIndex].price;
    }
    if (this.smsPlans.length > 0) {
      total = total + this.smsPlans[this.selectedSmsPlanIndex].price;
    }
    this.persistenceService.set(ONBOARDPERSISTANCEKEY.CUSTOMPLANPRICE, total, { type: StorageType.SESSION });
    return total;
  }

  selectCustomPlan(type, index) {
    switch (type) {
      case 'sms':
        this.selectedSmsPlanIndex = index;
        break;
      case 'voice':
        this.selectedVoicePlanIndex = index;
        break;
      case 'data':
        this.selectedDataPlanIndex = index;
        break;
    }
    this.planIndex = {
      sms: this.selectedSmsPlanIndex,
      voice: this.selectedVoicePlanIndex,
      data: this.selectedDataPlanIndex
    };
    this.persistenceService.set(ONBOARDPERSISTANCEKEY.CUSTOMPLANINDEX, this.planIndex, { type: StorageType.SESSION });
  }

  // quickRecharge() {
  // const data = this.quickRechargeForm.value;
  // this.getDummyToken().then(() => {
  //   return this.customerService.recharge(data.msisdn, data.quota * 100);
  // }).then(() => {
  //   alertify.success(this.translateService.instant('Recharge successfull'));
  //   this.quickRechargeForm.reset();
  //   this.removeDummyToken();
  // }).catch(() => {
  //   this.removeDummyToken();
  //   alertify.error(this.translateService.instant('Please try again later'));
  // });
  // }

  openRoute(route) {
    this.router.navigate(route.split('/'));
  }

  setOnboardBar(type) {
    this.persistenceService.set(ONBOARDPERSISTANCEKEY.ENABLEREGISTER, false, { type: StorageType.SESSION });
    this.persistenceService.set(ONBOARDPERSISTANCEKEY.ENABLEDELIVERY, false, { type: StorageType.SESSION });
    this.persistenceService.set(ONBOARDPERSISTANCEKEY.ENABLEADDON, false, { type: StorageType.SESSION });
    this.persistenceService.set(ONBOARDPERSISTANCEKEY.ENABLECHECKOUT, false, { type: StorageType.SESSION });
    this.persistenceService.set(ONBOARDPERSISTANCEKEY.CURRENTPLAN, type, { type: StorageType.SESSION });
    this.persistenceService.set(ONBOARDPERSISTANCEKEY.SELECTEDDEVICE, {}, { type: StorageType.SESSION });
    this.persistenceService.set(ONBOARDPERSISTANCEKEY.SELECTEDADDONS, [], { type: StorageType.SESSION });
    this.persistenceService.set(ONBOARDPERSISTANCEKEY.REGISTERDATA, {}, { type: StorageType.SESSION });
  }

  activateSimRoute() {
    this.router.navigate(['/customerOnboard']);
  }

  quickRecharge(e) {
    if (this.quickRechargeForm.invalid) {
      return;
    }
  }

  doQuickRecharge() {
    let requestPayload = {};
    this.customerService.validateMSISDN(this.quickRechargeForm.value).subscribe((data) => {
      if (data[0].status.toLowerCase() == 'active') {
        this.customerService.customerSearchProfile(this.quickRechargeForm.value).subscribe((data) => {
          this.userDetails = data[0];
          const emailExist = this.userDetails['contactMedium'].filter(data => data.type === 'EmailContact');
          if (emailExist && emailExist.length > 0) {
            const email = emailExist[0].value[0].value;
            this.paymentRequestInfo.email = email;
          }
          this.paymentRequestInfo.firstname = this.userDetails['firstName'];
          this.paymentRequestInfo.lastname = this.userDetails['lastName'];
          this.paymentRequestInfo.phone = this.quickRechargeForm.value.phoneNumber;
          this.paymentRequestInfo.productinfo = 'Quick Recharge';
          const defaultCurrency = this.persistenceService.get(CMUICONFIGKEY.DEFAULTYCURRENCY, StorageType.SESSION);
          const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
          requestPayload = this.getQuickRechargeRequestPayload(channelName, defaultCurrency, this.paymentRequestInfo);
          let voucherPayload = this.getQuickRechargeVoucherPayload(channelName, defaultCurrency);
          if (this.userDetails['customerId']) {
            // this.event.showPaymentPopupDetails(this.paymentRequestInfo,
            //   {
            //     responseHandler: (BOLT) => {
            //       return this.customerService.paymentSuccessHandler(BOLT, this.paymentRequestInfo, this.userDetails['id'], this.userDetails['customerId'], requestPayload, EventEnum.showQuickRechageSuccessMessage);
            //     },
            //     catchException: (BOLT) => {
            //       return this.customerService.paymentFailureHandler(BOLT);
            //     }
            //   }
            // );
            this.event.accountRefill(requestPayload, voucherPayload, this.paymentRequestInfo, EventEnum.showQuickRechageSuccessMessage);
          }
        },
          error => {
            alertify.error(this.translateService.instant('MSISDN is not valid'));
          });
      } else {
        alertify.error(this.translateService.instant('MSISDN is Inactive'));
      }
    },
      error => {
        alertify.error(this.translateService.instant('MSISDN is not available'));
      });
  }

  buttonDisableCheck() {
    if (this.quickRechargeForm.status === 'PENDING' || this.quickRechargeForm.status === 'INVALID') {
      return true;
    } else {
      return false;
    }
  }

  getQuickRechargeRequestPayload(channelName, defaultCurrency, paymentRequest) {
    let requestPayload = {
      'userId': '',
      'partyId': this.userDetails['id'],
      'customerId': this.userDetails['customerId'],
      'journeyId': 'AccountRefill_ForOthers_Anon',
      'type': 'ServiceOrder',
      'status': 'InProgress',
      'channelName': channelName,
      'customerServiceOrder': {
        'state': 'InProgress'
      },
      'journeyData': {
        payment: paymentRequest
      },
      'coreData': {
        'refillAmount': '',
        'currency': defaultCurrency,
        'beneficiaryMsisdn': this.quickRechargeForm.value.phoneNumber,
        'summaryTextLabel': 'AccountRefillAnonSummary'
      }
    };
    return requestPayload;
  }

  getQuickRechargeVoucherPayload(channelName, defaultCurrency) {
    let voucherPayload = {
      'partyId': this.userDetails['id'],
      'customerId': this.userDetails['customerId'],
      'journeyId': 'VoucherTopup_Anon',
      'type': 'ServiceOrder',
      'status': 'InProgress',
      'channelName': channelName,
      'customerServiceOrder': {},
      'journeyData': {},
      'coreData': {
        'beneficiaryMsisdn': this.quickRechargeForm.value.phoneNumber,
        'currency': defaultCurrency,
        'summaryTextLabel': 'VoucherTopupAnonSummary',
        'voucherCode': ''
      }
    };
    return voucherPayload;
  }


}





