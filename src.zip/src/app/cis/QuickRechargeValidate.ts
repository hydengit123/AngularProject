import { FormGroup, ValidationErrors, ValidatorFn } from '@angular/forms';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY } from 'dxp-common';
import { REGEX } from '../../application-constants';

export function quickRechargeFormValidator(persistenceService: PersistenceService, sliderMaxValue?: Number, loggedInMsisdn?: Number): ValidatorFn {
    return (control: FormGroup): ValidationErrors | null => {
        const phoneNumber = control.get('phoneNumber');
        const amount = control.get('amount');
        const rechargeLimit = persistenceService.get(CMUICONFIGKEY.RECHARGE_LIMIT, StorageType.SESSION);
        const mobileNumberLength = parseInt(persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION)) || null;
        const mobileNumberMaxLength = parseInt(persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION)) || null;
        // const maxAdjustAmount = parseInt(persistenceService.get(CMUICONFIGKEY.MAXIMUMADJUSTMENTAMOUNT, StorageType.SESSION)) || null;
        let isError = false;
        let errors = {
            'phoneNumberRequiredError': false,
            'phoneNumberLengthError': false,
            'phoneNumberFormatError': false,
            'amountRequiredError': false,
            'amountFormatError': false,
            'maxLimitAmountError': false,
            'sliderMaxValueError': false,
            'loggedInMsisdnError': false,
            'smsValueFormatError': false,
        };

        const contactPhoneRegex = /^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$/g;
        const amountRegEx = /^\d*\.?\d+$/g;

        if (phoneNumber && !phoneNumber.value && phoneNumber.dirty) {
            errors.phoneNumberRequiredError = true;
            isError = true;
        }

        if (phoneNumber && phoneNumber.value && mobileNumberLength && (phoneNumber.value.length < mobileNumberLength || phoneNumber.value.length > mobileNumberMaxLength) && phoneNumber.value.match(REGEX.ONLYDIGIT)) {
            errors.phoneNumberLengthError = true;
            isError = true;
        }

        if (phoneNumber && phoneNumber.value && mobileNumberLength && (phoneNumber.value.length < mobileNumberLength || phoneNumber.value.length > mobileNumberMaxLength) && !phoneNumber.value.match(REGEX.ONLYDIGIT)) {
            errors.phoneNumberLengthError = false;
            isError = true;
        }

        if (phoneNumber && phoneNumber.value && !phoneNumber.value.match(REGEX.ONLYDIGIT)) {
            errors.phoneNumberFormatError = true;
            isError = true;
        }

        if (phoneNumber && phoneNumber.value && loggedInMsisdn && loggedInMsisdn == phoneNumber.value) {
            errors.loggedInMsisdnError = true;
            isError = true;
        }

        if ((phoneNumber && !phoneNumber.value)) {
            isError = true;
        }

        if (amount && !amount.value && amount.dirty) {
            errors.amountRequiredError = true;
            isError = true;
        }

        if (amount && amount.value && !amount.value.match(amountRegEx)) {
            errors.amountFormatError = true;
            isError = true;
        }

        if (amount && amount.value && sliderMaxValue && parseInt(amount.value) > sliderMaxValue) {
            errors.sliderMaxValueError = true;
            isError = true;
        }

        if (amount && amount.value && !sliderMaxValue && !loggedInMsisdn && rechargeLimit && parseInt(amount.value) > rechargeLimit) {
            errors.maxLimitAmountError = true;
            isError = true;
        }

        // if ((phoneNumber && !phoneNumber.value) || (amount && !amount.value)) {
        //     isError = true;
        // }

        if(amount && amount.value && !amount.value.match(REGEX.ONLYDIGIT) ){
            errors.smsValueFormatError = true;
            isError = true;
          }

        return isError ? errors : null;
    }
};