import { Pipe, PipeTransform } from '@angular/core';
import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CisSettingsService } from '../cis-settings.service';
import { AuthService } from '../services/auth.service';
import { CustomerService } from '../services/customer.service';
import { ProductService } from '../services/product.service';
import { CisComponent } from './cis.component';
import { Observable, ReplaySubject } from 'rxjs';
import { PERSISTANCEKEY, ONBOARDPERSISTANCEKEY } from '../../application-constants';
import { mockUsername } from '../mockData';
import { TranslateService } from '@ngx-translate/core';
import { CMSContentService } from '../services/cms-content.service';
declare const alertify;
declare const jQuery;

@Pipe({ name: 'translate' })
class MockTranslatePipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}

@Pipe({ name: 'valueFormatter' })
class MockValueFormatterPipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}

describe('CisComponent', () => {
  let component: CisComponent;
  let fixture: ComponentFixture<CisComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let routerSpy: jasmine.SpyObj<Router>;
  let customerServiceSpy: jasmine.SpyObj<CustomerService>;
  let productServiceSpy: jasmine.SpyObj<ProductService>;
  let authServiceSpy: jasmine.SpyObj<AuthService>;
  let cisSettingsServiceSpy: jasmine.SpyObj<CisSettingsService>;
  let translateServiceSpy: any;
  let cMSContentServiceSpy: any;

  beforeEach(async(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set', 'remove']);
    const ProductServiceSpy = jasmine.createSpyObj('ProductService', ['getCustomOffer', 'getPlanByType', 'getPlanByType', 'getAddons', 'getInventory']);
    const CustomerServiceSpy = jasmine.createSpyObj('CustomerService', ['registerUser', 'getCustomerInfo', 'recharge']);
    const RouterSpy = jasmine.createSpyObj('Router', ['navigate']);
    const AuthServiceSpy = jasmine.createSpyObj('AuthService', ['login']);
    const CisSettingsServiceSpy = jasmine.createSpyObj('CisSettingsService', [undefined]);

    translateServiceSpy = {

      instant: () => { 'message' },
    }


    cMSContentServiceSpy = {
      getWebPageContent: () => new ReplaySubject(1),
      getCollaterals: () => new ReplaySubject(1)
    }
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
      ],
      declarations: [
        CisComponent,
        MockValueFormatterPipe,
        MockTranslatePipe
      ],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy },
        { provide: Router, useValue: RouterSpy },
        { provide: AuthService, useValue: AuthServiceSpy },
        { provide: CisSettingsService, useValue: CisSettingsServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        FormBuilder
      ]
    }).overrideComponent(CisComponent, {
      set: {
        providers: [
          { provide: CustomerService, useValue: CustomerServiceSpy },
          { provide: ProductService, useValue: ProductServiceSpy },
          { provide: CMSContentService, useValue: cMSContentServiceSpy },
        ]
      }
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CisComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
    routerSpy = TestBed.get(Router);
    authServiceSpy = TestBed.get(AuthService);
    cisSettingsServiceSpy = TestBed.get(CisSettingsService);
    customerServiceSpy = fixture.debugElement.injector.get(CustomerService) as any;
    productServiceSpy = fixture.debugElement.injector.get(ProductService) as any;
    cMSContentServiceSpy = fixture.debugElement.injector.get(CMSContentService) as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit method should', () => {
    it('should route to dashoard path when access token is available and should call loginDummyUser after 1000 ms', fakeAsync(() => {
      persistenceServiceSpy.get.and.returnValue('AccessToken');
      fixture.detectChanges();
      tick(1000);
      expect(routerSpy.navigate).toHaveBeenCalledWith(['dashboard']);
    }));

    it('should not route to dashoard path when access token is unavailable and should call loginDummyUser after 1000 ms', fakeAsync(() => {
      persistenceServiceSpy.get.and.returnValue(undefined);
      fixture.detectChanges();
      tick(1000);
      expect(routerSpy.navigate).not.toHaveBeenCalledWith(['dashboard']);
    }));
  });

  describe('ngAfterViewInit method should', () => {
    it('', () => {
      fixture.detectChanges();
      const event = new MouseEvent('click', {
        view: window,
        bubbles: true,
        cancelable: true
      });
      const el = jQuery('.navbar a[href*="#"]').not('[href="#"]').not('[href="#0"]');
      el[0].dispatchEvent(event);
    });
  });

  describe('loginDummyUser method should', () => {
    it('should set dataPlans, voicePlans, smsPlans, premiumPlanOffer and standardPlanOffer. Should call removeDummyToken method ', fakeAsync(() => {
      spyOn(component, 'getAddons');
      spyOn(component, 'getInventory');
      spyOn(component, 'removeDummyToken');
      productServiceSpy.getCustomOffer.and.returnValue(Promise.resolve({ dataPlans: [1, 2], smsPlans: [3, 4], voicePlans: [5, 6] }));
      productServiceSpy.getPlanByType.and.returnValue(Promise.resolve({
        productId: 'CM_Combo_574', productName: 'Roaming data 10gb 1000mins 1000sms', productType: 'Combo', productGroup: 'Addon', productDescription: 'Description CM_Combo_574', productValidityDays: 5, productStatus: 'Active', quota: undefined, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
      }));



      tick();

      expect(persistenceServiceSpy.set).toHaveBeenCalledTimes(3);
      expect(component.getAddons).toHaveBeenCalled();
      expect(component.getInventory).toHaveBeenCalled();
      expect(component.removeDummyToken).toHaveBeenCalled();

      expect(component.dataPlans).toBeDefined();
      expect(component.voicePlans).toBeDefined();
      expect(component.premiumPlanOffer).toBeDefined();
      expect(component.standardPlanOffer).toBeDefined();
    }));

    it('should catch error from promise Should call removeDummyToken method ', fakeAsync(() => {
      spyOn(component, 'getAddons');
      spyOn(component, 'getInventory');
      spyOn(component, 'removeDummyToken');
      productServiceSpy.getCustomOffer.and.returnValue(Promise.resolve(undefined));
      productServiceSpy.getPlanByType.and.returnValue(Promise.resolve(undefined));


      tick();

      expect(component.getAddons).not.toHaveBeenCalled();
      expect(persistenceServiceSpy.set).not.toHaveBeenCalled();
      expect(component.getInventory).not.toHaveBeenCalled();
      expect(component.removeDummyToken).toHaveBeenCalled();
    }));
  });


  it('removeDummyToken method should remove tokken from persistence service', () => {
    component.removeDummyToken();

    expect(persistenceServiceSpy.remove).toHaveBeenCalledWith(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
  });

  it('doLogin method should call authService.login to login user and then call component.onLoginSuccess', () => {
    const name = 'mock_name';
    const password = 'mock_password';
    component.loginForm.setValue({ loginName: name, password: password });
    spyOn(component, 'onLoginSuccess');
    authServiceSpy.login.and.returnValue(Observable.of('Response'));

    component.doLogin();

    expect(authServiceSpy.login).toHaveBeenCalledWith(name, password);
    expect(component.onLoginSuccess).toHaveBeenCalled();
  });

  describe('registerUser method should', () => {
    it('return false when confirmPasswordModal password and registerFormModel password do not match', () => {
      component.registerFormModel.controls['password'].setValue('123456');
      component.confirmPasswordModal.setValue('4231');
      spyOn(alertify, 'error');

      expect(component.registerUser()).toBeFalsy();
      expect(customerServiceSpy.registerUser).not.toHaveBeenCalled();
      expect(alertify.error).toHaveBeenCalled();
    });

    it('call customerService.registerUser when confirmPasswordModal password and registerFormModel password match should call customerService.registerUser, alertify.success, registerFormModel.reset and confirmPasswordModal.reset when customerService.registerUser is successfull', () => {
      component.registerFormModel.controls['password'].setValue('123456');
      component.confirmPasswordModal.setValue('123456');
      spyOn(alertify, 'success');
      spyOn(component.registerFormModel, 'reset');
      spyOn(component.confirmPasswordModal, 'reset');
      spyOn(jQuery.fn, 'modal');
      customerServiceSpy.registerUser.and.returnValue(Observable.of('Response'));

      component.registerUser();

      expect(customerServiceSpy.registerUser).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalled();
      expect(jQuery.fn.modal).toHaveBeenCalledWith('hide');
      expect(component.registerFormModel.reset).toHaveBeenCalled();
      expect(component.confirmPasswordModal.reset).toHaveBeenCalled();
    });

    xit('catch error from customerService.registerUser', () => {
      component.registerFormModel.controls['password'].setValue('123456');
      component.confirmPasswordModal.setValue('123456');
      spyOn(alertify, 'error');
      spyOn(component.registerFormModel, 'reset');
      spyOn(component.confirmPasswordModal, 'reset');
      spyOn(jQuery.fn, 'modal');
      customerServiceSpy.registerUser.and.returnValue(Observable.throw({ 'error': { 'message': 'failed' } }));

      component.registerUser();

      expect(customerServiceSpy.registerUser).toHaveBeenCalled();
      expect(jQuery.fn.modal).not.toHaveBeenCalled();
      expect(component.registerFormModel.reset).not.toHaveBeenCalled();
      expect(component.confirmPasswordModal.reset).not.toHaveBeenCalled();
    });
  });


  it('onLoginSuccess method should set ACCESSTOKEN, MSISDN and USER on persistence service', fakeAsync(() => {
    spyOn(jQuery.fn, 'modal');
    spyOn(component, 'getCustomerInfo');
    component.loginForm.setValue({ loginName: '', password: '' });

    component.onLoginSuccess({ 'access_token': '' });
    tick(500);

    expect(jQuery.fn.modal).toHaveBeenCalledWith('hide');
    expect(persistenceServiceSpy.set).toHaveBeenCalledTimes(3);
    expect(component.getCustomerInfo).toHaveBeenCalled();
    expect(routerSpy.navigate).toHaveBeenCalled();
  }));

  describe('getCustomerInfo method should', () => {
    it('should set USERNAME on persistence service on success of customerService.getCustomerInfo', () => {
      const data = { firstName: 'FirstName', lastName: 'LastName' };
      persistenceServiceSpy.get.and.returnValue('123456');
      customerServiceSpy.getCustomerInfo.and.returnValue(Observable.of(data));

      component.getCustomerInfo();

      expect(persistenceServiceSpy.set).toHaveBeenCalledWith(PERSISTANCEKEY.USERNAME, data.firstName + ' ' + data.lastName, { type: StorageType.SESSION });
    });

    it('should set USERNAME on persistence service on failure of customerService.getCustomerInfo', () => {
      const data = { firstName: 'FirstName', lastName: 'LastName' };
      persistenceServiceSpy.get.and.returnValue('123456');
      customerServiceSpy.getCustomerInfo.and.returnValue(Observable.throw({ error: { message: 'error' } }));

      component.getCustomerInfo();

      expect(persistenceServiceSpy.set).toHaveBeenCalledWith(PERSISTANCEKEY.USERNAME, mockUsername, { type: StorageType.SESSION });
    });
  });

  describe('getAddons method should', () => {
    it('call planService.getAddons and should setset availableAddons and USERADDON on persistence service', () => {
      component.availableAddons = undefined;
      const data = [{
        productId: 'CM_Combo_574', productName: 'Roaming data 10gb 1000mins 1000sms', productType: 'Combo', productGroup: 'Addon', productDescription: 'Description CM_Combo_574', productValidityDays: 5, productStatus: 'Active', quota: undefined, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
      }];

      productServiceSpy.getAddons.and.returnValue(Observable.of(data));

      component.getAddons();

      expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.USERADDON, data, { type: StorageType.SESSION });
      expect(persistenceServiceSpy.get).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.USERADDON, StorageType.SESSION);
      expect(component.availableAddons).toBe(data);
    });

    it('call planService.getAddons and should not call persistenceservice.get when component.availableAddons are already present', () => {
      const data = [{
        productId: 'CM_Combo_574', productName: 'Roaming data 10gb 1000mins 1000sms', productType: 'Combo', productGroup: 'Addon', productDescription: 'Description CM_Combo_574', productValidityDays: 5, productStatus: 'Active', quota: undefined, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
      }];
      component.availableAddons = data;

      productServiceSpy.getAddons.and.returnValue(Observable.of(data));

      component.getAddons();

      expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.USERADDON, data, { type: StorageType.SESSION });
      expect(persistenceServiceSpy.get).not.toHaveBeenCalled();
    });
  });

  describe('getInventory method should', () => {
    it('call planService.getInventory and should set inventory on persistence service', fakeAsync(() => {
      expect(component.inventory).toEqual([]);
      productServiceSpy.getInventory.and.returnValue(Promise.resolve(['inventory_a', 'inventory_b', 'inventory_c']));

      component.getInventory();
      tick();

      expect(component.inventory.length).toBe(3);
    }));

    it('catch error from planService.getInventory', fakeAsync(() => {
      expect(component.inventory).toEqual([]);
      productServiceSpy.getInventory.and.returnValue(Promise.reject('Error fetching inventory'));
      spyOn(alertify, 'error');

      component.getInventory();
      tick();

      expect(alertify.error).toHaveBeenCalled();
      expect(component.inventory).toEqual([]);
    }));
  });

  it('switchToRegister method should hide Register modal and should show loginForm modal after 300ms', fakeAsync(() => {
    spyOn(jQuery.fn, 'modal');
    component.switchToRegister();
    expect(jQuery.fn.modal).toHaveBeenCalledWith('hide');
    tick(300);

    expect(jQuery.fn.modal).toHaveBeenCalledWith('show');
  }));

  it('switchToForgot method should hide loginForm modal and should show forgotPasswordForm modal after 300ms ', fakeAsync(() => {
    spyOn(jQuery.fn, 'modal');
    component.switchToForgot();
    expect(jQuery.fn.modal).toHaveBeenCalledWith('hide');
    tick(300);

    expect(jQuery.fn.modal).toHaveBeenCalledWith('show');
  }));

  it('getSumForCustom method should return total sum and should set CUSTOMPLANPRICE on persistemce service', () => {

    component.selectedDataPlanIndex = 0;
    component.dataPlans = [{ price: 3 }, { price: 4 }];
    component.voicePlans = [{ price: 1 }, { price: 4 }];
    component.smsPlans = [{ price: 6 }, { price: 8 }];

    const sum = component.getSumForCustom();

    expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.CUSTOMPLANPRICE, sum, { type: StorageType.SESSION })
    expect(sum).toBe(10);
  });

  describe('selectCustomPlan method should set component.selectedDataPlanIndex and component.planIndex', () => {
    it('when type is "sms"', () => {
      const index = 0;

      component.selectCustomPlan('sms', index);

      expect(component.selectedSmsPlanIndex).toBe(index);
      expect(component.planIndex).toEqual({
        sms: component.selectedSmsPlanIndex,
        voice: component.selectedVoicePlanIndex,
        data: component.selectedDataPlanIndex
      });
      expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.CUSTOMPLANINDEX, component.planIndex, { type: StorageType.SESSION });
    });

    it('when type is "voice"', () => {
      const index = 0;

      component.selectCustomPlan('voice', index);

      expect(component.selectedSmsPlanIndex).toBe(index);
      expect(component.planIndex).toEqual({
        sms: component.selectedSmsPlanIndex,
        voice: component.selectedVoicePlanIndex,
        data: component.selectedDataPlanIndex
      });
    });

    it('when type is "data"', () => {
      const index = 0;

      component.selectCustomPlan('data', index);

      expect(component.selectedSmsPlanIndex).toBe(index);
      expect(component.planIndex).toEqual({
        sms: component.selectedSmsPlanIndex,
        voice: component.selectedVoicePlanIndex,
        data: component.selectedDataPlanIndex
      });
    });
  });


  describe('quickRecharge method should', () => {
    it('call quickRechargeForm.reset and component.removeDummyToken method when getDummyToken and customerService.recharge methods are successfull', fakeAsync(() => {
      spyOn(alertify, 'success');
      spyOn(component, 'removeDummyToken');
      spyOn(component.quickRechargeForm, 'reset');
      component.quickRechargeForm.setValue({ msisdn: '123456', quota: 100 });
      customerServiceSpy.recharge.and.returnValue(Promise.resolve('response'));

      component.quickRecharge();
      tick();

      expect(component.removeDummyToken).toHaveBeenCalled();
      expect(customerServiceSpy.recharge).toHaveBeenCalled();
      expect(component.quickRechargeForm.reset).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalled();

    }));

    it('call component.removeDummyToken method when getDummyToken OR customerService.recharge method is unsuccessfull', fakeAsync(() => {
      spyOn(alertify, 'error');
      spyOn(component, 'removeDummyToken');
      spyOn(component.quickRechargeForm, 'reset');
      component.quickRechargeForm.setValue({ msisdn: '123456', quota: 100 });
      customerServiceSpy.recharge.and.returnValue(Promise.reject('error'));

      component.quickRecharge();
      tick();

      expect(component.removeDummyToken).toHaveBeenCalled();
      expect(customerServiceSpy.recharge).toHaveBeenCalled();
      expect(component.quickRechargeForm.reset).not.toHaveBeenCalled();
      expect(alertify.error).toHaveBeenCalled();
    }));
  });

  it('openRoute method should navigate to the route specified', () => {
    component.openRoute('home/new');

    expect(routerSpy.navigate).toHaveBeenCalledWith(['home', 'new']);
  });

  it('setOnboardBar method should set on persistence service', () => {
    const type = 'sms;'
    component.setOnboardBar(type);

    expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.ENABLEREGISTER, false, { type: StorageType.SESSION });
    expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.ENABLEDELIVERY, false, { type: StorageType.SESSION });
    expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.ENABLEADDON, false, { type: StorageType.SESSION });
    expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.ENABLECHECKOUT, false, { type: StorageType.SESSION });
    expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.CURRENTPLAN, type, { type: StorageType.SESSION });
    expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.SELECTEDDEVICE, {}, { type: StorageType.SESSION });
    expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.SELECTEDADDONS, [], { type: StorageType.SESSION });
    expect(persistenceServiceSpy.set).toHaveBeenCalledWith(ONBOARDPERSISTANCEKEY.REGISTERDATA, {}, { type: StorageType.SESSION });
  });

});
