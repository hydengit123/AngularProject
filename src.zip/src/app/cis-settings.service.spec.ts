import { HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';
import { CisSettingsService } from './cis-settings.service';

describe('CisSettingsService', () => {
  let httpClientSpy: jasmine.SpyObj<HttpClient>;
  let cisSettingsService: CisSettingsService;

  beforeEach(() => {
    const HttpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);

    TestBed.configureTestingModule({
      providers: [CisSettingsService,
        { provide: HttpClient, useValue: HttpClientSpy }]
    });
  });

  beforeEach(() => {
    httpClientSpy = TestBed.get(HttpClient);
    httpClientSpy.get.and.callFake(() => Observable.of('mock'));

    cisSettingsService = TestBed.get(CisSettingsService);
  });

  it('should be created', () => {
    expect(cisSettingsService).toBeTruthy();
    expect(cisSettingsService.config).toEqual('mock');
  });

  describe('getConfig', () => {
    it('should return config property', () => {
      cisSettingsService.config = 'mockConfig';
      const result = cisSettingsService.getConfig();
      expect(result).toEqual('mockConfig');
    });
  });
});
