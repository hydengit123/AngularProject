import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY, PaymentRequestInfo } from 'dxp-common';
import { ModalDirective } from 'ng-uikit-pro-standard';
import { CustomerService } from '../services/customer.service';
import { PaymentGatewayService } from './../services/payment-gateway.service';

declare const alertify;

@Component({
  selector: 'app-payment-popup',
  templateUrl: './payment-popup.component.html',
  styleUrls: ['./payment-popup.component.scss']
})
export class PaymentPopupComponent implements OnInit {
  @Input() paymentGateWayList: any;
  @Input() showPaymentList:boolean;
  public enablePayment: Boolean = true;
  public enablePayBtn: Boolean = false;
  defaultCurrency: String = '';
  maxAdjustAmount: Number;
  @ViewChild('basicModal') basicModal: ModalDirective;

  public paymentRequestInfo: PaymentRequestInfo = {
    key: '',
    hash: '',
    txnid: '',
    amount: 0,
    productinfo: '',
    firstname: '',
    lastname: '',
    email: '',
    phone: '',
    surl: '',
    furl: '',
    address1: '',
    address2: '',
    city: '',
    state: '',
    country: '',
    zipcode: '',
    salt: ''
  };

  public handler:any;

  constructor(private paymentGatewayService:PaymentGatewayService, private customerService: CustomerService,
    private translateService: TranslateService, private persistenceService: PersistenceService) { }

  ngOnInit() {
    this.defaultCurrency = this.persistenceService.get(CMUICONFIGKEY.DEFAULTYCURRENCY, StorageType.SESSION);
    const quickRechargeForm = this.customerService.getQuickRechargeFormDetails();
    const formResponseDetails = this.customerService.getQuickRechargeFormResponseDetails();
    
  }

  get selectedPayment():any{
    if(this.paymentGateWayList){
    const selectedPayments = this.paymentGateWayList.filter(item => item.checked == true);
    if(selectedPayments.length > 0){
      return selectedPayments[0];
    }
  }
    return null;
  }

  paymentGatewayRadioClicked(paymentGatewaySelected) {
    let list = this.paymentGateWayList.map( d => {
      d.value == paymentGatewaySelected.value? d.checked = !d.checked: d.checked = false;
      return d;
    });
    this.paymentGateWayList = [...list];
    this.showPaymentBtn();
  }
  showPaymentBtn(){
    if(this.selectedPayment && this.paymentRequestInfo.amount > 0){
      this.enablePayBtn = true;
    }
    else{
      this.enablePayBtn = false;
    }
  }

  doPayment(e) {
    this.basicModal.hide();
    const selectedPayments = this.paymentGateWayList.filter(item => item.checked === true);
    if (selectedPayments && selectedPayments[0] && selectedPayments[0].value) {
      const onboardData = this.paymentRequestInfo;
      const successURL = '/public';
      const failureURL = '/public';
      this.paymentGatewayService.launchPaymentBolt(this.paymentRequestInfo,
        selectedPayments[0].value,
        this.paymentRequestInfo.phone,
        'INR',
        successURL,
        failureURL,
        this.handler
        );
    } else {
      alertify.error(this.translateService.instant('Please Select Payment Option'));
    }

  }

}
