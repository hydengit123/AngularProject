import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../auth.guard';
import { CanActivateDashboardHomeRouteGuard } from '../guards/CanActivateDashboardHomeRouteGuard';
import { AddSubscriptionComponent } from './add-subscription/add-subscription.component';
import { ContinueJourneyComponent } from './continue-journey/continue-journey.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';
import { DashboardComponent } from './dashboard.component';
import { DfyComponent } from './dfy/dfy.component';
import { HomeComponent } from './home/home.component';
import { PlanComponent } from './plan/plan.component';
import { RoamingComponent } from './roaming/roaming.component';
import { SupportComponent } from './support/support.component';
import { UtcComponent } from './utc/utc.component';
import { WalletComponent } from './wallet/wallet.component';



const routes: Routes = [{
  path: '',
  component: DashboardComponent,
  canActivate: [AuthGuard],
  children: [{
    path: 'home', component: HomeComponent, canActivate:[CanActivateDashboardHomeRouteGuard]
  }, {
    path: 'customerProfile', component: CustomerProfileComponent
    }, {
    path: 'plan', component: PlanComponent
  }, {
    path: 'dfy', component: DfyComponent
  }, {
    path: 'utc', component: UtcComponent
  }, {
    path: 'support', component: SupportComponent
  }, {
    path: 'wallet', component: WalletComponent
  }, {
    path: 'roaming', component: RoamingComponent
  }, {
    path: 'subscription', component: AddSubscriptionComponent
  },
  {
    path: 'continueJourney', component: ContinueJourneyComponent
  }, {
    path: '', redirectTo: 'home', pathMatch: 'full',canActivate: [AuthGuard]
  }]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {
}
