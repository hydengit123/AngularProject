import { Component, ElementRef, EventEmitter, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService } from 'angular-persistence';
import * as _ from 'lodash';
import { Subscription } from 'rxjs';
import { EventListenerService } from '../../event-listener.service';
import { CustomerSearchDataService } from '../../services/customer-search-data.service';
import { CustomerSearchService } from '../../services/customer-search.service';

declare const alertify;
declare const $;
declare var jQuery: any;

@Component({
    selector: 'app-manage-addon',
    templateUrl: './manage-addon.component.html',
    styleUrls: ['./manage-addon.component.scss']
})
export class ManageAddonComponent implements OnInit, OnDestroy {

    msisdn;
    username;
    subscribedContract: any;
    sectionScroll: any;
    @Output() allAvailableAddonsLength = new EventEmitter<any>();
    @ViewChild('contract') contract: ElementRef;
    isExpandable = false;

    private msisdnChangeEvent: Subscription;

    constructor(
        public translateService: TranslateService,
        private customerSearchDataService: CustomerSearchDataService,
        private customerSearchService: CustomerSearchService,
        private events: EventListenerService,
        private persistenceService: PersistenceService,
        private router: Router
    ) {
    }

    ngOnInit() {
        this.msisdn = this.customerSearchService.getUserContracts()[0].msisdn;
        this.loadAllAddOns();
        this.msisdnChangeEvent = this.events.msisdnChangeEvent.subscribe((event) => {
            this.msisdn = event.msisdn;
            this.loadAllAddOns();
        });
        this.router.events.subscribe((evt) => {
            if (!(evt instanceof NavigationEnd)) {
              return;
            }
            this.doScroll();
            this.sectionScroll = null;
          });
    }
    openRoute(Page, Section) {
        // this.router.navigate(route.split('/'));
        this.sectionScroll = Section;
        this.router.navigate([Page], { fragment: Section });
    }

   doScroll() {
        if (!this.sectionScroll) {
            return;
        }
        try {
            const elements = document.getElementById(this.sectionScroll);
            elements.scrollIntoView();

        }
        finally {
            this.sectionScroll = null;
        }
    }
    private async loadAllAddOns() {
        try {
            const userContracts = this.customerSearchService.getUserContracts()
            this.subscribedContract = _.find(userContracts, { msisdn: this.msisdn });
            this.subscribedContract = this.subscribedContract.contract;
        } catch (error) {
        }
    }


    ngOnDestroy() {
        if(this.msisdnChangeEvent){
            this.msisdnChangeEvent.unsubscribe();
        }

    }



}
