import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageAddonComponent } from './manage-addon.component';

describe('ManageAddonComponent', () => {
  let component: ManageAddonComponent;
  let fixture: ComponentFixture<ManageAddonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageAddonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageAddonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
