import { Pipe, PipeTransform } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { PersistenceService } from 'angular-persistence';
import { Observable } from 'rxjs';
import { DataClientService } from '../../data-client.service';
import { EventListenerService } from '../../event-listener.service';
import { CustomerGroupService } from '../../services/customer-group.service';
import { CustomerService } from '../../services/customer.service';
import { ProductService } from '../../services/product.service';
import { CommonShareModalComponent } from './common-share-modal.component';
import { TranslateService } from '@ngx-translate/core';

declare const alertify;
const mockProducts = [{
  'productId': 'CM_Combo_574',
  'productName': 'Roaming data 10gb 1000mins 1000sms',
  'productType': 'Combo',
  'productGroup': 'Addon',
  'price': 2500,
  'paymentMode': 'AIR',
  'srcChannel': 'SELFCARE',
  'numberOfPendingRenewals': 0,
  'nextRenewalDate': '01-03-2019 14:30:00',
  'provisionedQuota': {
    'voice': {
      'unit': 60000,
      'unitType': '0'
    },
    'sms': {
      'unit': 1000,
      'unitType': '1'
    },
    'data': {
      'unit': 10737418240,
      'unitType': '6'
    }
  },
  'availableQuota': {
    'voice': {
      'unit': 60000,
      'unitType': '0'
    },
    'sms': {
      'unit': 1000,
      'unitType': '1'
    },
    'data': {
      'unit': 10737418240,
      'unitType': '6'
    }
  },
  'sharedQuota': {
    'voice': {
      'unit': 60000,
      'unitType': '0'
    },
    'sms': {
      'unit': 1000,
      'unitType': '1'
    },
    'data': {
      'unit': 10737418240,
      'unitType': '6'
    }
  },
  'activationDate': '30-01-2019 14:30:43',
  'expiryDate': '01-03-2019 14:30:00',
  'isRecurring': false
}];

@Pipe({ name: 'valueFormatter' })
class MockValueFormatterPipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}
@Pipe({ name: 'translate' })
class MockTranslatePipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}

describe('CommonShareModalComponent', () => {
  let component: CommonShareModalComponent;
  let fixture: ComponentFixture<CommonShareModalComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let productServiceSpy: jasmine.SpyObj<ProductService>;
  let customerServiceSpy: jasmine.SpyObj<CustomerService>;
  let eventListenerServiceSpy: jasmine.SpyObj<EventListenerService>;
  let customerGroupServiceSpy: jasmine.SpyObj<CustomerGroupService>;
  let dataClientServiceSpy: jasmine.SpyObj<DataClientService>;
  let translateServiceSpy: any;

  beforeEach(async(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set']);
    const ProductServiceSpy = jasmine.createSpyObj('ProductService', ['getRechargeOptions']);
    const CustomerServiceSpy = jasmine.createSpyObj('CustomerService', ['addQuota', 'shareQuota']);
    const EventListenerServiceSpy = jasmine.createSpyObj('EventListenerService', ['addData', 'addMinutes', 'addSMS']);
    const CustomerGroupServiceSpy = jasmine.createSpyObj('CustomerGroupService', ['getSharedAccount', 'removeSharedAccount']);
    const DataClientServiceSpy = jasmine.createSpyObj('DataClientService', [null]);
    translateServiceSpy = {
      instant: () => { },
    }

    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        ReactiveFormsModule
      ],
      declarations: [
        CommonShareModalComponent,
        MockValueFormatterPipe,
        MockTranslatePipe
      ],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy },
        { provide: EventListenerService, useValue: EventListenerServiceSpy },
        { provide: DataClientService, useValue: DataClientServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        FormBuilder
      ]
    }).overrideComponent(CommonShareModalComponent, {
      set: {
        providers: [
          { provide: ProductService, useValue: ProductServiceSpy },
          { provide: CustomerService, useValue: CustomerServiceSpy },
          { provide: CustomerGroupService, useValue: CustomerGroupServiceSpy }
        ]
      }
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonShareModalComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
    eventListenerServiceSpy = TestBed.get(EventListenerService);
    productServiceSpy = fixture.debugElement.injector.get(ProductService) as any;
    customerServiceSpy = fixture.debugElement.injector.get(CustomerService) as any;
    customerGroupServiceSpy = fixture.debugElement.injector.get(CustomerGroupService) as any;
    dataClientServiceSpy = fixture.debugElement.injector.get(DataClientService) as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call persistenceService.get and shareFormGroup and msisdn should be defined', () => {
    persistenceServiceSpy.get.and.returnValue('4622378109');

    component.ngOnInit();

    expect(persistenceServiceSpy.get).toHaveBeenCalled();
    expect(component.msisdn).toBe('4622378109');
    expect(component.shareFormGroup).toBeDefined();
  });

  describe('ngOnChanges method should', () => {
    it('set availableQuota, title and placeType and call getSharedAccount method when type = "data"', () => {
      persistenceServiceSpy.get.and.returnValue(mockProducts[0].availableQuota);
      component.type = 'data';
      spyOn(component, 'getSharedAccount');

      component.ngOnChanges(undefined);

      expect(component.title).toBe('Share Data');
      expect(component.placeType).toBe('00.0 GB ');
      expect(component.getSharedAccount).toHaveBeenCalled();
    });

    it('set availableQuota, title and placeType and call getSharedAccount method when type = "voice"', () => {
      persistenceServiceSpy.get.and.returnValue(mockProducts[0].availableQuota);
      component.type = 'voice';
      spyOn(component, 'getSharedAccount');

      component.ngOnChanges(undefined);

      expect(component.title).toBe('Share Minutes');
      expect(component.placeType).toBe('00.0 Min');
      expect(component.getSharedAccount).toHaveBeenCalled();
    });

    it('set availableQuota, title and placeType and call getSharedAccount method when type = "sms"', () => {
      persistenceServiceSpy.get.and.returnValue(mockProducts[0].availableQuota);
      component.type = 'sms';
      spyOn(component, 'getSharedAccount');

      component.ngOnChanges(undefined);

      expect(component.title).toBe('Share SMS');
      expect(component.placeType).toBe('0 SMS');
      expect(component.getSharedAccount).toHaveBeenCalled();
    });
  });

  describe('getSharedAccount method should', () => {
    it('set sharedUser when promise is resolved from customerGroupServiceSpy.getSharedAccount', () => {
      customerGroupServiceSpy.getSharedAccount.and.returnValue(Promise.resolve(mockProducts));

      component.getSharedAccount();

      expect(component.sharedUser).toBeDefined();
    });

    it('not set sharedUser and should catch error when promise is rejected from customerGroupServiceSpy.getSharedAccount', () => {
      customerGroupServiceSpy.getSharedAccount.and.returnValue(Promise.reject(new Error('error')));

      component.getSharedAccount();

      expect(component.sharedUser).toEqual([]);
    });
  });

  it('addsharedAccount method should set component.selectedno as msisdno passed to it', () => {
    expect(component.selectedno).toBe('');

    component.addsharedAccount('123456');

    expect(component.selectedno).toBe('123456');
  });

  describe('removeSharedAccount method should', () => {
    it('call component.getSharedAccount on success of customerGroupService.removeSharedAccount', () => {
      customerGroupServiceSpy.removeSharedAccount.and.returnValue(Observable.of(mockProducts));
      spyOn(component, 'getSharedAccount');
      spyOn(alertify, 'success');
      component.removeSharedAccount('123456');

      expect(component.getSharedAccount).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalled();
    });

    it('not call component.getSharedAccount on failure of customerGroupService.removeSharedAccount', () => {
      customerGroupServiceSpy.removeSharedAccount.and.returnValue(Observable.throw({ 'error': { 'message': 'failed' } }));
      spyOn(component, 'getSharedAccount');
      spyOn(alertify, 'error');

      component.removeSharedAccount('123456');

      expect(component.getSharedAccount).not.toHaveBeenCalled();
      expect(alertify.error).toHaveBeenCalled();
    });
  });

  describe('share method should', () => {
    it('call customerService.shareQuota and on success should further call getSharedAccount method when type = "data" ', () => {
      spyOn(alertify, 'success');
      spyOn(component, 'getSharedAccount');
      customerServiceSpy.shareQuota.and.returnValue(Observable.of(mockProducts[0].sharedQuota));
      component.type = 'data';

      component.share({ 'msisdn': '123456', 'buyOption': '' });

      expect(alertify.success).toHaveBeenCalled();
      expect(component.getSharedAccount).toHaveBeenCalled();
    });

    it('call customerService.shareQuota and on success should further call getSharedAccount method when type = "voice" ', () => {
      spyOn(alertify, 'success');
      spyOn(component, 'getSharedAccount');
      customerServiceSpy.shareQuota.and.returnValue(Observable.of(mockProducts[0].sharedQuota));
      component.type = 'voice';

      component.share({ 'msisdn': '123456', 'buyOption': '' });

      expect(alertify.success).toHaveBeenCalled();
      expect(component.getSharedAccount).toHaveBeenCalled();
    });

    it('call customerService.shareQuota and on success should further call getSharedAccount method when type = "sms" ', () => {
      spyOn(alertify, 'success');
      spyOn(component, 'getSharedAccount');
      customerServiceSpy.shareQuota.and.returnValue(Observable.of(mockProducts[0].sharedQuota));
      component.type = 'sms';

      component.share({ 'msisdn': '123456', 'buyOption': '' });

      expect(alertify.success).toHaveBeenCalled();
      expect(component.getSharedAccount).toHaveBeenCalled();
    });

    it('call customerService.shareQuota and on failure should further call alertify.error when type = "data" ', () => {
      spyOn(alertify, 'error');
      spyOn(component, 'getSharedAccount');
      customerServiceSpy.shareQuota.and.returnValue(Observable.throw({ 'error': { 'message': 'failed' } }));
      component.type = 'data';

      component.share({ 'msisdn': '123456', 'buyOption': '' });

      expect(alertify.error).toHaveBeenCalled();
      expect(component.getSharedAccount).not.toHaveBeenCalled();
    });
  });

});
