import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { Component } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { CustomerService } from '../../services/customer.service';
import { EventListenerService } from '../../event-listener.service';
import { UtilService } from '../../services/util.service';
import { PersistenceService } from 'angular-persistence';
import { DataClientService } from '../../data-client.service';
import { WalletComponent } from './wallet.component';
import { SubscriptionProduct } from '../../interface/subscription';
import AggregatedUnit = SubscriptionProduct.AggregatedUnit;
import { Observable } from 'rxjs';

@Component({ selector: 'app-payment-form', template: '' })
class MockPaymentFormComponent {

}
describe('WalletComponent', () => {
  let component: WalletComponent;
  let fixture: ComponentFixture<WalletComponent>;
  let productServiceSpy: jasmine.SpyObj<ProductService>;
  let customerServiceSpy: jasmine.SpyObj<CustomerService>;
  let utilServiceSpy: jasmine.SpyObj<UtilService>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let eventSpy: jasmine.SpyObj<EventListenerService>;
  let dataServiceSpy: jasmine.SpyObj<DataClientService>;

  beforeEach(async(() => {
    const ProductServiceSpy = jasmine.createSpyObj('ProductService', [''])
    const UtilServiceSpy = jasmine.createSpyObj('UtilService', ['']);
    const CustomerServiceSpy = jasmine.createSpyObj('CustomerService', ['getAggregatedSubscription']);
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set']);
    const EventSpy = jasmine.createSpyObj('EventListenerService', ['balanceEvent']);
    const DataServiceSpy = jasmine.createSpyObj('DataClientService', ['']);
    EventSpy['balanceEvent'] = { 'subscribe': (c) => { c(0) } };

    TestBed.configureTestingModule({
      declarations: [
        WalletComponent,
        MockPaymentFormComponent
      ],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy },
        { provide: EventListenerService, useValue: EventSpy },
        { provide: DataClientService, useValue: DataServiceSpy }
      ]
    })
      .overrideComponent(WalletComponent, {
        set: {
          providers: [
            { provide: ProductService, useValue: ProductServiceSpy },
            { provide: CustomerService, useValue: CustomerServiceSpy },
            { provide: UtilService, useValue: UtilServiceSpy }
          ]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WalletComponent);
    component = fixture.componentInstance;
    productServiceSpy = fixture.debugElement.injector.get(ProductService) as any;
    customerServiceSpy = fixture.debugElement.injector.get(CustomerService) as any;
    utilServiceSpy = fixture.debugElement.injector.get(UtilService) as any;
    persistenceServiceSpy = TestBed.get(PersistenceService);
    eventSpy = TestBed.get(EventListenerService);
    dataServiceSpy = TestBed.get(DataClientService)
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  describe('ngOnInit', () => {
    it('should call onResult,getAggregatedSubscription method,set the msisdn,username value ', () => {
      persistenceServiceSpy.get.and.callFake((params) => {
        if (params == 'username') {
          return 'mock'
        } else if (params == 'msisdn') {
          return '123'
        } else {
          return '400';
        }
      })
      spyOn(component, 'onResult');
      spyOn(component, 'getAggregatedSubscription')

      component.ngOnInit();

      expect(component.msisdn).toEqual('123');
      expect(component.username).toEqual('mock');
      expect(component.onResult).toHaveBeenCalledWith('400');
      expect(component.getAggregatedSubscription).toHaveBeenCalledWith('123');
      expect(component.balance).toEqual(0);
    });
  });

  describe('onResult', () => {
    it('should set the balance if mainBalance.unit is not undefined ', () => {
      const main = { mainBalance: { 'unit': 100 } };

      component.onResult(main);
      expect(component.balance).toEqual(1);
    });
    it('should not set the balance if mainBalance.unit is undefined ', () => {
      const main = { mainBalance: { 'unit': undefined } };

      component.onResult(main);
      expect(component.balance).toBeUndefined();
    });
  });

  describe('ngAfterViewInit', () => {
    it('should call getAggregatedSubscription', () => {
      component.msisdn = '1234';
      spyOn(component, 'getAggregatedSubscription')
      component.ngAfterViewInit();
      expect(component.getAggregatedSubscription).toHaveBeenCalledWith('1234');
    });
  });

  describe('getAggregatedSubscription', () => {
    it('should call customerservice.getAggregatedSubscription', fakeAsync(() => {

      spyOn(component, 'onResult');
      customerServiceSpy.getAggregatedSubscription.and.returnValue(Observable.of('success'));
      component.getAggregatedSubscription('1234');
      tick();
      expect(customerServiceSpy.getAggregatedSubscription).toHaveBeenCalledWith('1234');
      expect(component.onResult).toHaveBeenCalled();
    }));
  });
});
