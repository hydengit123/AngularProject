import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PersistenceService } from 'angular-persistence';
import { RoamingComponent } from './roaming.component';

describe('RoamingComponent', () => {
  let component: RoamingComponent;
  let fixture: ComponentFixture<RoamingComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;

  beforeEach(async(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set']);

    TestBed.configureTestingModule({
      declarations: [ RoamingComponent ],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoamingComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
  });

  it('should create', () => { 
    expect(component).toBeTruthy();
  });
});
