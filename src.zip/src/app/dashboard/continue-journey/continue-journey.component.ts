import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { PersistenceService, StorageType } from 'angular-persistence';
import { JOURNEYDATADETAILS } from '../../../application-constants';
import { CartService } from '../../services/cart.service';
import { CustomerSearchService } from '../../services/customer-search.service';
import { EventListenerService } from './../../event-listener.service';
import { CustomerOnboardService } from './../../services/customer-onboard.service';

@Component({
  selector: 'app-continue-journey',
  templateUrl: './continue-journey.component.html',
  styleUrls: ['./continue-journey.component.scss']
})
export class ContinueJourneyComponent implements OnInit {

  public journeySessionData: any;
  public dataLength: Number = 0;

  constructor(private customerOnboardService: CustomerOnboardService,
    private eventListenerService: EventListenerService,
    private persistenceService: PersistenceService,
    private router: Router,
    private customerSearchService: CustomerSearchService,
    private cartService: CartService) { }

  ngOnInit() {
    this.eventListenerService.fetchPendingJourney();
    let id = this.customerSearchService.getPendingId();

    this.journeySessionData = this.customerSearchService.getJourneyData()["data"];
    this.dataLength = this.customerSearchService.getJourneyData()["journeyLength"];
  }

  public deleteJourneySession(journeySessionId) {
    this.customerOnboardService.deleteJourneySessionData(journeySessionId).subscribe(data => {
      this.journeySessionData = this.journeySessionData.filter((item) => item.id !== journeySessionId);


      this.cartService.quantityMap = {};
      this.router.navigateByUrl('/customerOnboard');
    });
  }

  public async goToJourneySaved(journeyStep, journeySessionId) {
    let journeySessionData = this.journeySessionData.filter((item) => item.id === journeySessionId);
    this.persistenceService.set(JOURNEYDATADETAILS.CURRENTSTEP, journeyStep, { type: StorageType.SESSION });
    this.persistenceService.set(JOURNEYDATADETAILS.JOURNEYSESSIONID, journeySessionId, { type: StorageType.SESSION });
    this.persistenceService.set(JOURNEYDATADETAILS.JOURNEYDATA, journeySessionData[0].journeyData, { type: StorageType.SESSION });
    this.persistenceService.set(JOURNEYDATADETAILS.JOURNEYID, journeySessionData[0].journeyId, { type: StorageType.SESSION });
    this.persistenceService.set(JOURNEYDATADETAILS.JOURNEYSTATUS, journeySessionData[0].journeyStatus, { type: StorageType.SESSION });
    //this.eventListenerService.closeCustomerOnBoardPopup();
    this.router.navigateByUrl('/customerOnboard');


  }



}
