import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContinueJourneyComponent } from './continue-journey.component';

describe('ContinueJourneyComponent', () => {
  let component: ContinueJourneyComponent;
  let fixture: ComponentFixture<ContinueJourneyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContinueJourneyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContinueJourneyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
