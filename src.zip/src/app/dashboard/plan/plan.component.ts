import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CustomerInteractionRechargeOthers, PLANTYPE, CMUICONFIGKEY, PaymentRequestInfo } from 'dxp-common';
import { PERSISTANCEKEY } from '../../../application-constants';
import { EventEnum } from '../../enum/EventEnum';
import { EventListenerService } from '../../event-listener.service';
import { CustomizePlanOffer } from '../../interface/product';
import { QuickRechargeFormDetails } from '../../interface/quick.recharge.details';
import { Refillinfo } from '../../interface/Refillinfo';
import { SubscriptionProduct } from '../../interface/subscription';
import { CustomerGroupService } from '../../services/customer-group.service';
import { CustomerSearchService } from '../../services/customer-search.service';
import { CustomerService } from '../../services/customer.service';
import { PaymentGatewayService } from '../../services/payment-gateway.service';
import { ProductService } from '../../services/product.service';
import { RechargeTransferService } from '../../services/recharge-transfer.service';
import { UtilService } from '../../services/util.service';
import { rechargeMobileValidator, rechargeOthersValidator } from '../../shared/validators/rechargeOthers.validators';


import Product = SubscriptionProduct.Product;






declare const alertify;
declare const $;
declare var jQuery: any;
@Component({
  selector: 'app-plan',
  templateUrl: './plan.component.html',
  styleUrls: ['./plan.component.scss'],
  providers: [ProductService, UtilService, CustomerService, CustomerGroupService]
})
export class PlanComponent implements OnInit {

  FAFmsisdns: number[] = [];
  formGroup: FormGroup = new FormGroup({
    msisdn: new FormControl('', [Validators.required, Validators.min(1000000000), Validators.max(9999999999)])
  });
  showPayment = false;
  showPaymentPremium = false;
  showPaymentCustom = false;
  switchPlan = false;
  hideBuyOption = false;

  dataPlans = [];
  voicePlans = [];
  smsPlans = [];

  selectedDataPlanIndex = -1;
  selectedVoicePlanIndex = -1;
  selectedSmsPlanIndex = -1;

  availableAddons: CustomizePlanOffer[];
  msisdn;
  username;
  useraddons: CustomizePlanOffer[] = [];
  currentPlan: Product;
  currentPlanDetail: CustomizePlanOffer;
  planFeatures1: string[] = [];
  planFeatures2: string[] = [];

  standardPlan: CustomizePlanOffer;
  premiumPlan: CustomizePlanOffer;
  inventory: string[] = [];
  suspendSim;
  rechargeForm: FormGroup;
  public CommonProfile: any;
  public UserList: any;
  public mainBalanceValue: any;

  public msisdnNumber: string;
  public paymentProperty: any;
  public paymentRequest: any;
  public refillPayload: CustomerInteractionRechargeOthers;
  public paymentSuccess = false;
  public customerId: any;
  public userProfile: any;
  public userContractProfile: any;
  public refillInfo: Refillinfo;
  public orderIdMessage: any;
  public rechargeMessage: any;
  public transactionMessage: any;
  public rechargeFormSelf: boolean;
  public isNext: boolean;
  public rechargeMobileno: any;
  public rechargeAmount: any;
  public showRechargeSuccessMsg: any;
  public userDetails: Array<any> = [];
  public amountValidationMessage = { error: null, success: null };
  public mobileValidationMessage = { error: null, success: null };
  public quickRechargeFormDetails: QuickRechargeFormDetails = {
    partyId: '',
    customerId: '',
    firstName: '',
    lastName: '',
    email: ''
  };

  public paymentRequestInfo: PaymentRequestInfo = {
    key: '',
    hash: '',
    txnid: '',
    amount: 0,
    productinfo: '',
    firstname: '',
    lastname: '',
    email: '',
    phone: '',
    surl: '',
    furl: '',
    address1: '',
    address2: '',
    city: '',
    state: '',
    country: '',
    zipcode: '',
    salt: ''
  };
  public partyId: any;

  constructor(
    private persistenceService: PersistenceService,
    private utilService: UtilService,
    private customerService: CustomerService,
    private customerSearchService: CustomerSearchService,
    private customerGroupService: CustomerGroupService,
    public eventListenerService: EventListenerService,
    public paymentService: PaymentGatewayService,
    public rechargeTransferService: RechargeTransferService,
    public translateService: TranslateService,
    private planService: ProductService) {
    this.msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
    this.username = this.persistenceService.get(PERSISTANCEKEY.USERNAME, StorageType.SESSION);

    // this.rechargeForm = new FormGroup({
    //   msisdn: new FormControl('', Validators.required),
    //   quota: new FormControl('', Validators.required)
    // },
    this.rechargeForm = new FormGroup({
      phoneNumber: new FormControl('', Validators.required),
      amount: new FormControl('', Validators.required)
    });

    // [quickRechargeFormValidator(this.persistenceService)]);
  }

  ngOnInit() {
    //this.getFAF();
    //this.getCustomOffer();
    //this.getAddons();
    this.getCurrentPlan();
    //this.getPlanByType('Premium');
    //this.getPlanByType('Standard');
    //this.getSubscriptionDetail();
    //this.getInventory();
    this.CommonProfile = this.customerSearchService.getUserProfile();
    this.UserList = this.customerSearchService.getUserContracts();
    if (this.UserList && this.UserList[0]) {
      this.mainBalanceValue = this.UserList[0].contract.customerAccountAssignmentRules[0].customerAccount;
    }

    this.eventListenerService.showPaymentSuccessMessageEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.showPaymentSuccessMessage && data.response) {
        this.rechargeForm.reset();
        this.showRechargeSuccessMsg = true;
      }
    });

    this.partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
    this.customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
    const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';

    this.msisdnNumber = "9986430971",

      this.refillPayload = {
        userId: '',  // todo check with jayasri, is it optional
        partyId: this.partyId,
        customerId: this.customerId,
        journeyId: 'AccountRefill_ForOthers',
        type: 'ServiceOrder',
        status: 'InProgress',
        channelName: channelName,
        customerServiceOrder: {
          state: 'InProgress'
        },
        journeyData: {},
        coreData: {
          refillAmount: 30,
          currency: 'INR',  // todo check with jayasri,            
          donorCustomerName: 'Jayasri',
          beneficiaryMsisdn: '9638527413',
          summaryTextLabel: 'AccountRefillDonorSummary',
          donorMsisdn: '9638527412',
          donorEmail: 'jayasri.elango@wipro.com'

        }
      };



  }

  // public paymentResponseHandler(paymentRequest: PaymentRequestInfo) {
  //   let responseData = {};

  //   //if (onBoardData2) {
  //   responseData = {
  //       responseHandler: (BOLT) => {
  //           return this.requestpaymentSuccessHandler(BOLT, paymentRequest, customerInteractionRechargeOthers);
  //       }
  //       // ,
  //       // catchException: (BOLT) => {
  //       //     return this.requestpaymentFailureHandler(BOLT, onBoardData2);
  //       // }
  //   }
  //   //}
  //   return responseData;
  // }

  // private async requestpaymentSuccessHandler(BOLT, paymentRequest: PaymentRequestInfo, customerInteractionRechargeOthers) {
  //   if (BOLT.response && BOLT.response.txnStatus == "SUCCESS"
  //       && BOLT.response.txnid) {
  //       let paymentTransactionRequest = {
  //           resourceNumber: this.paymentService.paymentConfigSelected.resourceNumber,//MSISDN from customer journey
  //           payer: BOLT.response.payer || 'NA',//NA in old code
  //           merchantRefNum: this.paymentService.paymentConfigSelected.merchantRefNum,//merchantRefNum from create payment service
  //           paymentGwTransactionId: BOLT.response.txnid || BOLT.response.payuMoneyId || paymentRequest.txnid,
  //           status: BOLT.response.status,
  //           paymentToken: BOLT.response.paymentId || '',//empty in old code
  //           paymentMethod: BOLT.response.mode,
  //           expiryDate: BOLT.response.addedon || '',//empty in old code
  //           cardNumber: BOLT.response.cardnum || '' //cardnum from payumoney
  //       };
  //       const paymentInfo = await this.paymentService.updatePayment(paymentTransactionRequest).toPromise();

  //       if (paymentInfo && paymentInfo.message && paymentInfo.message === 'SUCCESS') {
  //           this.refillPayload.coreData.refillAmount = 30;

  //           const customerInteractionResponse = await this.rechargeTransferService.customerInteraction(customerInteractionRechargeOthers).toPromise();
  //           // this.orderIdMessage = this.translateService.instant("Your Order Id Message", {value: customerInteractionResponse.id});
  //           // this.rechargeMessage = this.translateService.instant("Your Mobile No Recharge Message", {x: this.userContractProfile.msisdn});
  //           // this.transactionMessage = this.translateService.instant("Your Transaction Id Message", {y: BOLT.response.txnid});
  //           if (customerInteractionResponse) {
  //               this.paymentSuccess = true;
  //               this.rechargeFormSelf = false;
  //               this.isNext = false;
  //               //this.redirectToSucessView(customerInteractionResponse);
  //               // this.eventListenerService.userProfileDashboardEvent.emit({eventType: EventEnum.refreshUserProfileDashboard});
  //           }
  //       }
  //       else {
  //           alertify.error(this.translateService.instant('Payment Failed'));
  //       }

  //   }
  //   else {
  //       alertify.error(this.translateService.instant(BOLT.response.txnMessage));
  //   }
  // }



  getCurrentPlan() {
    this.currentPlan = this.persistenceService.get(PERSISTANCEKEY.CURRENTPLAN, StorageType.SESSION);
    if (this.currentPlan && this.currentPlan.productGroup.toLowerCase() !== PLANTYPE.CUSTOM) {
      this.planFeatures1 = [];
      this.planFeatures2 = [];
      this.getProductByPlanId(this.currentPlan.productId);
    }
  }

  getProductByPlanId(productId) {
    this.planService.getProductByPlanId(productId)
      .subscribe((data: CustomizePlanOffer) => {
        this.currentPlanDetail = data;
        const features = data.productDescription.replace('\r\n', '').split('|').map(x => x.trim());
        const mid = Math.floor((features.length + 1) / 2);
        this.planFeatures1 = features.slice(0, mid);
        this.planFeatures2 = features.slice(mid);
      }, error => {
      });
  }

  getPlanByType(type) {
    this.planService.getPlanByType(type).then(data => {
      if (type.toLowerCase().trim() === PLANTYPE.STANDARD) {
        this.standardPlan = data;
      } else if (type.toLowerCase().trim() === PLANTYPE.PREMIUM) {
        this.premiumPlan = data;
      }
    }).catch(error => {
    });
  }


  showPlans() {
    if (!this.switchPlan) {
      this.switchPlan = true;
      this.showPayment = false;
      this.hideBuyOption = false;
    }
  }

  getFAF() {
    const msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
    this.customerGroupService.getFAF(msisdn)
      .subscribe((data) => {
        this.FAFmsisdns = data;
        if (this.FAFmsisdns.length > 5) {
          this.FAFmsisdns = this.FAFmsisdns.slice(0, 5);
        }
      }, error => {

      });
  }

  removeFAF(removeId) {
    const msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
    this.customerGroupService.removeFAF(msisdn, removeId)
      .subscribe((data) => {
        this.getFAF();
        alertify.success(`${removeId} has been removed`);
      }, error => {
        alertify.error('Error deleting FAF');
      });
  }

  addFAF() {
    if (this.FAFmsisdns.length >= 5) {
      return alertify.error('Cannot add more than 5 FAF');
    }
    const msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
    const addmsisdn = this.formGroup.controls[PERSISTANCEKEY.MSISDN].value.toString().trim();

    this.customerGroupService.addFAF(msisdn, addmsisdn)
      .subscribe((data) => {
        alertify.success('Added FAF');
        this.formGroup.patchValue({
          msisdn: '',
        });
        this.getFAF();
      }, error => {
        alertify.error('Error adding FAF');
      });
  }

  registerFAF() {
    const msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
    this.customerGroupService.registerFAF(msisdn)
      .subscribe((data) => {
      }, error => {
        alertify.error('Error adding FAF');
      });
  }

  getAddons() {
    let useraddon: CustomizePlanOffer[] = this.persistenceService.get(PERSISTANCEKEY.USERADDON, StorageType.SESSION);
    if (!Array.isArray(useraddon)) {
      useraddon = [];
    }
    this.useraddons = useraddon;
    this.planService.getAddons()
      .subscribe((data: CustomizePlanOffer[]) => {
        if (Array.isArray(data) && data.length > 0) {
          this.availableAddons = data.filter(x => {
            return this.useraddons.findIndex(u => x.productId === u.productId) < 0;
          });
        }
      }, error => {

      });
  }

  getCustomOffer() {
    this.planService
      .getCustomOffer()
      .then(data => {
        this.dataPlans = data.dataPlans;
        this.smsPlans = data.smsPlans;
        this.voicePlans = data.voicePlans;
      }).catch(error => {
        // alertify.error('Error fetching custom offer');
      });
  }

  selectCustomPlan(type, index) {
    switch (type) {
      case 'sms':
        if (this.selectedSmsPlanIndex !== index) {
          this.selectedSmsPlanIndex = index;
        } else {
          this.selectedSmsPlanIndex = -1;
        }
        break;
      case 'voice':
        if (this.selectedVoicePlanIndex !== index) {
          this.selectedVoicePlanIndex = index;
        } else {
          this.selectedVoicePlanIndex = -1;
        }
        break;
      case 'data':
        if (this.selectedDataPlanIndex !== index) {
          this.selectedDataPlanIndex = index;
        } else {
          this.selectedDataPlanIndex = -1;
        }
        break;
    }
  }

  getSumForCustom() {
    let total = 0;
    if (this.dataPlans.length > 0 && this.selectedDataPlanIndex > -1) {
      total = total + this.dataPlans[this.selectedDataPlanIndex].price;
    }
    if (this.voicePlans.length > 0 && this.selectedVoicePlanIndex > -1) {
      total = total + this.voicePlans[this.selectedVoicePlanIndex].price;
    }
    if (this.smsPlans.length > 0 && this.selectedSmsPlanIndex > -1) {
      total = total + this.smsPlans[this.selectedSmsPlanIndex].price;
    }
    return total;
  }

  public refill() {
//unused code very old code
    // this.customerService.customerSearchProfile(this.rechargeForm.value).subscribe((data) => {
    //   this.userDetails = data[0];
    //   const emailExist = this.userDetails['contactMedium'].filter(data => data.type === 'EmailContact');
    //   if (emailExist && emailExist.length > 0) {
    //     const email = emailExist[0].value[0].value;
    //     this.paymentRequestInfo.email = email;
    //   }
    //   this.paymentRequestInfo.firstname = this.userDetails['firstName'];
    //   this.paymentRequestInfo.lastname = this.userDetails['lastName'];
    //   this.paymentRequestInfo.amount = this.rechargeForm.value.amount;
    //   this.paymentRequestInfo.phone = this.rechargeForm.value.phoneNumber;
    //   this.paymentRequestInfo.productinfo = 'Quick Recharge';
    //   this.refillPayload.customerId = this.customerId; //this.userDetails['customerId'];
    //   this.refillPayload.partyId = this.partyId; //this.userDetails['id'];
    //   //construct customerinteraction object
    //   this.refillPayload.coreData.refillAmount = this.rechargeForm.value.amount;
    //   this.refillPayload.coreData.beneficiaryMsisdn = this.rechargeForm.value.phoneNumber;
    //   this.refillPayload.coreData.donorCustomerName = `${this.CommonProfile.firstName} ${this.CommonProfile.lastName}`;
    //   this.refillPayload.coreData.donorEmail = this.CommonProfile.email[0];
    //   if (this.UserList[0] && this.UserList[0].contract && this.UserList[0].contract.resources[0] && this.UserList[0].contract.resources[0].resourceNumber) {
    //     // this.refillPayload.coreData.donorEmail = this.UserList[0].contract.resources[0]
    //     this.refillPayload.coreData.donorMsisdn = this.UserList[0].contract.resources[0].resourceNumber;
    //   }

    //   if (this.userDetails['customerId']) {
    //     this.eventListenerService.showPaymentPopupDetails(this.paymentRequestInfo,
    //       {
    //         responseHandler: (BOLT) => {
    //           return this.rechargeTransferService.paymentSuccessHandler(BOLT, this.paymentRequestInfo, this.refillPayload, EventEnum.showPaymentSuccessMessage);
    //         },
    //         catchException: (BOLT) => {
    //           return this.customerService.paymentFailureHandler(BOLT);
    //         }
    //       }
    //     );
    //   }
    // },
    //   error => {
    //     alertify.error(this.translateService.instant('Customer profile is not available for this phone number'));
    //   });
  }








  confirmRemoveAddon(index) {

    const name = this.useraddons[index].productName;

    const productId = this.useraddons[index].productId;
    const params: any = {};

    params.msisdn = this.msisdn;

    params.productId = productId;

    params.buyOption = 'DACT';

    this.customerService.removeAddon(params)

      .subscribe((data) => {
        this.availableAddons.push(this.useraddons[index]);
        this.useraddons.splice(index, 1);
        alertify.success('Removed ' + name);
        this.persistenceService.set(PERSISTANCEKEY.USERADDON, this.useraddons, { type: StorageType.SESSION });
      }, error => {
        alertify.error('Error Removing ' + name);
      });

  }


  confirmAddAddon(index) {
    const name = this.availableAddons[index].productName;
    const productId = this.availableAddons[index].productId;
    const params: any = {};
    params.msisdn = this.msisdn;
    params.productId = productId;
    params.buyOption = 'NACT';
    this.customerService.addAddon(params)
      .subscribe((data) => {
        this.useraddons.push(this.availableAddons[index]);
        this.availableAddons.splice(index, 1);
        this.persistenceService.set(PERSISTANCEKEY.USERADDON, this.useraddons, { type: StorageType.SESSION });
        alertify.success('Added ' + name);
      }, error => {
        alertify.error(error.error.message);
      });
  }

  getInventory() {
    this.planService.getInventory().then(data => {
      this.inventory = data;
    }).catch(error => {
      // alertify.error('Error fetching inventory');
    });
  }

  simAdded() {
    alertify.success('SIM added successfully');
  }

  suspendSimAction() {
    if (this.suspendSim) {
      alertify.success('Sim suspended successfully');
    } else {
      alertify.error('Invalid msisdn');
    }
  }

  recharge() {
    const data = this.rechargeForm.value;
    this.customerService.recharge(data.msisdn, parseFloat(data.quota) * 100).then(data => {
      this.rechargeForm.reset();
      alertify.success('Recharge successful');
    }).catch(error => {
      alertify.error(error.error.message || error.message);
    });
  }
  confirmBuy(type) {
    this.switchPlan = true;
    this.showPayment = true;
    this.hideBuyOption = false;
    $('.container_header')[0].scrollIntoView(true);

  }

  confirmBuyPremium(type) {
    this.switchPlan = true;
    this.showPaymentPremium = true;
    this.hideBuyOption = false;
    $('.container_header')[0].scrollIntoView(true);
  }

  confirmBuyCustom(type) {
    this.switchPlan = true;
    this.showPaymentCustom = true;
    this.hideBuyOption = false;
    $('.container_header')[0].scrollIntoView(true);
  }

  confirmBuyPlan(type) {
    this.buyPlan(type);
    this.switchPlan = false;
    this.showPayment = false;
    this.showPaymentPremium = false;
    this.showPaymentCustom = false;
    jQuery('#buyPlan').modal('hide');
  }


  async buyPlan(type) {
    let productId = null;
    switch (type) {
      case 'standard':
        productId = this.standardPlan.productId;
        break;
      case 'premium':
        productId = this.premiumPlan.productId;
        break;
      case 'custom':
        break;
    }

    if (!productId && type.toString().toLowerCase() === PLANTYPE.CUSTOM) {
      if (this.selectedDataPlanIndex < 0) {
        this.selectedDataPlanIndex = 0;
      }
      if (this.selectedVoicePlanIndex < 0) {
        this.selectedVoicePlanIndex = 0;
      }
      if (this.selectedSmsPlanIndex < 0) {
        this.selectedSmsPlanIndex = 0;
      }
      /* append all the prodcutId */
      if (this.selectedDataPlanIndex >= 0) {
        productId = this.dataPlans[this.selectedDataPlanIndex].productId;
      }
      if (this.selectedVoicePlanIndex >= 0) {
        productId = productId + '^^' + this.voicePlans[this.selectedVoicePlanIndex].productId;
      }
      if (this.selectedSmsPlanIndex >= 0) {
        productId = productId + '^^' + this.smsPlans[this.selectedSmsPlanIndex].productId;
      }
    }
    if (!productId || productId === '' || (this.selectedDataPlanIndex === 0 && this.selectedVoicePlanIndex === 0 && this.selectedSmsPlanIndex === 0)) {
      this.selectedDataPlanIndex = -1;
      this.selectedDataPlanIndex = -1;
      this.selectedDataPlanIndex = -1;
      alertify.error('Please select any of data, sms and voice');
      return false;
    }

    const requestForBuy = productId.toString().split('^^').map(x => {
      return this.customerService.buyPlan(this.msisdn, x);
    });
    const requestForRemove = this.currentPlan.productId.toString().split('^^').map(x => {
      return this.customerService.removePlan(this.msisdn, x);
    });
    try {
      const responseForBuy = await Promise.all(requestForBuy);
      const responseForRemove = await Promise.all(requestForRemove);
      const subscriptionDetail = await this.customerService.subscriptionDetail(this.msisdn);
      const currentPlan = this.utilService.getCustomerPlanFromSubscription(subscriptionDetail.products);
      this.persistenceService.set(PERSISTANCEKEY.CURRENTPLAN, currentPlan, { type: StorageType.SESSION });
      alertify.success('Plan switched successfully');
      this.getCurrentPlan();
      this.getSubscriptionDetail();
      this.switchPlan = false;
      this.planFeatures1 = [];
      this.planFeatures2 = [];
    } catch (e) {
      alertify.error('Error buying  plan');
    }
  }

  goBack() {
    this.switchPlan = true;
    this.showPayment = false;
    this.showPaymentPremium = false;
    this.showPaymentCustom = false;
    this.hideBuyOption = false;
    jQuery('#buyPlan').modal('hide');
  }

  showSubscriptionPlans() {
    this.switchPlan = true;
    this.hideBuyOption = false;
  }

  getSubscriptionDetail() {
    const msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
    this.customerService.getSubscriptionDetail(msisdn)
      .subscribe((data: { msisdn: string, products: Product[] }) => {
        let currentPlan: Product = null;
        if (data.products) {
          currentPlan = this.utilService.getCustomerPlanFromSubscription(data.products);
          if (currentPlan) {
            if (currentPlan.productGroup === 'custom') {
              this.getCustomPlanFeature(currentPlan);
            }
          }
          this.persistenceService.set(PERSISTANCEKEY.CURRENTPLAN, currentPlan, { type: StorageType.SESSION });
          this.getCurrentPlan();
        }
      });
  }

  getCustomPlanFeature(currentPlan) {
    this.planFeatures1 = [];
    const currentCustomPlan = currentPlan;
    const customPlanFeatureArr = currentCustomPlan.productName.replace('_', ' ').replace('null^^', '').split('^^');
    this.planFeatures1 = customPlanFeatureArr;
  }

  public onBlurOfAmount(controlName) {
    const amountControl = this.rechargeForm.get(controlName);
    amountControl.setValidators(rechargeOthersValidator(this.persistenceService, this.translateService, this.amountValidationMessage));
    amountControl.updateValueAndValidity();
  }

  public onBlurOfMobile(controlName) {
    const mobileControl = this.rechargeForm.get(controlName);
    mobileControl.setValidators(rechargeMobileValidator(this.translateService, this.persistenceService, this.mobileValidationMessage));
    mobileControl.updateValueAndValidity();
  }
}
