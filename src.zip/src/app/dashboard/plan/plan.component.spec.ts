import { Component, Input, Pipe, PipeTransform } from '@angular/core';
import { async, ComponentFixture, fakeAsync, TestBed, tick, inject } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { PersistenceService } from 'angular-persistence';
import { Observable } from 'rxjs';
import { CustomizePlanOffer } from '../../interface/product';
import { CustomerGroupService } from '../../services/customer-group.service';
import { CustomerService } from '../../services/customer.service';
import { ProductService } from '../../services/product.service';
import { UtilService } from '../../services/util.service';
import { PlanComponent } from './plan.component';
import { SubscriptionProduct } from '../../interface/subscription';
import Product = SubscriptionProduct.Product;
import { By } from '@angular/platform-browser';
import { CustomOffer } from '../../interface/custom.offer';

declare const alertify;
declare var jQuery;

const mockSubscriptionDetail: any = {
  msisdn: '4622378109', products: [{
    'productId': 'CM_Combo_556',
    'productName': '50GB and Unlimited SMS and Voice Combo',
    'productType': 'Combo',
    'productGroup': 'Premium',
    'price': 2500,
    'paymentMode': 'AIR',
    'srcChannel': 'SELFCARE',
    'numberOfPendingRenewals': 9998,
    'nextRenewalDate': '01-03-2019 14:30:42',
    'provisionedQuota': {
      'voice': {
        'unit': -1,
        'unitType': '0'
      },
      'sms': {
        'unit': -1,
        'unitType': '1'
      },
      'data': {
        'unit': 53687091200,
        'unitType': '6'
      }
    },
    'availableQuota': {
      'voice': {
        'unit': -1,
        'unitType': '0'
      },
      'sms': {
        'unit': -1,
        'unitType': '1'
      },
      'data': {
        'unit': 53687091200,
        'unitType': '6'
      }
    },
    'activationDate': '30-01-2019 14:30:00',
    'expiryDate': '01-03-2019 14:30:42',
    'isRecurring': true
  },
  {
    'productId': 'CM_Combo_574',
    'productName': 'Roaming data 10gb 1000mins 1000sms',
    'productType': 'Combo',
    'productGroup': 'Addon',
    'price': 2500,
    'paymentMode': 'AIR',
    'srcChannel': 'SELFCARE',
    'numberOfPendingRenewals': 0,
    'nextRenewalDate': '01-03-2019 14:30:00',
    'provisionedQuota': {
      'voice': {
        'unit': 60000,
        'unitType': '0'
      },
      'sms': {
        'unit': 1000,
        'unitType': '1'
      },
      'data': {
        'unit': 10737418240,
        'unitType': '6'
      }
    },
    'availableQuota': {
      'voice': {
        'unit': 60000,
        'unitType': '0'
      },
      'sms': {
        'unit': 1000,
        'unitType': '1'
      },
      'data': {
        'unit': 10737418240,
        'unitType': '6'
      }
    },
    'activationDate': '30-01-2019 14:30:43',
    'expiryDate': '01-03-2019 14:30:00',
    'isRecurring': false
  }]
};

const mockCurrentPlan = {
  "productId": "CM_Combo_556",
  "productName": "50GB and Unlimited SMS and Voice Combo",
  "productType": "Combo",
  "productGroup": "custom",
  "price": 2500,
  "paymentMode": "AIR",
  "productDescription": 'Roaming data 10GB',
  "srcChannel": "SELFCARE",
  "numberOfPendingRenewals": 9998,
  "nextRenewalDate": "01-03-2019 14:30:42",
  "provisionedQuota": {
    "voice": {
      "unit": 1,
      "unitType": "0"
    },
    "sms": {
      "unit": 1,
      "unitType": "1"
    },
    "data": {
      "unit": 1,
      "unitType": "6"
    }
  },
  "availableQuota": {
    "voice": {
      "unit": 0,
      "unitType": "0"
    },
    "sms": {
      "unit": 0,
      "unitType": "1"
    },
    "data": {
      "unit": 0,
      "unitType": "6"
    }
  },
  "activationDate": "30-01-2019 14:30:00",
  "expiryDate": "01-03-2019 14:30:42",
  "isRecurring": true
}
const mockCurrentPlanData = {
  "productId": "CM_Combo_556",
  "productName": "50GB and Unlimited SMS and Voice Combo",
  "productType": "Combo",
  "productGroup": "AddOn",
  "price": 2500,
  "paymentMode": "AIR",
  "srcChannel": "SELFCARE",
  "numberOfPendingRenewals": 9998,
  "nextRenewalDate": "01-03-2019 14:30:42",
  "provisionedQuota": {
    "voice": {
      "unit": 1,
      "unitType": "0"
    },
    "sms": {
      "unit": 1,
      "unitType": "1"
    },
    "data": {
      "unit": 1,
      "unitType": "6"
    }
  },
  "availableQuota": {
    "voice": {
      "unit": 0,
      "unitType": "0"
    },
    "sms": {
      "unit": 0,
      "unitType": "1"
    },
    "data": {
      "unit": 0,
      "unitType": "6"
    }
  },
  "activationDate": "30-01-2019 14:30:00",
  "expiryDate": "01-03-2019 14:30:42",
  "isRecurring": true
}
@Component({ selector: 'app-payment-form', template: '' })
class MockPaymentFormComponent {
  @Input() cardType = 'Credit Card';
}

@Pipe({ name: 'valueFormatter' })
export class MockValueFormatterPipe implements PipeTransform {

  transform(value: any, args: string): any {
    value = parseFloat(value);
    return value;
  }
}
@Pipe({ name: 'dateDiff' })
export class MockDateDiffPipe implements PipeTransform {

  transform(value: any, args: string): any {
    if (!value) {
      return '';
    }
  }
}

describe('PlanComponent', () => {
  let component: PlanComponent;
  let fixture: ComponentFixture<PlanComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let utilServiceSpy: jasmine.SpyObj<UtilService>;
  let planServiceSpy: jasmine.SpyObj<ProductService>;
  let customerServiceSpy: jasmine.SpyObj<CustomerService>;
  let customerGroupServiceSpy: jasmine.SpyObj<CustomerGroupService>;
  let standardPlanStub: Partial<CustomizePlanOffer>;
  let premiumPlanStub: Partial<CustomizePlanOffer>;

  beforeEach(async(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set'])
    const UtilServiceSpy = jasmine.createSpyObj('UtilService', ['getCustomerPlanFromSubscription'])
    const PlanServiceSpy = jasmine.createSpyObj('ProductService', ['getProductByPlanId', 'getPlanByType', 'getAddons', 'getCustomOffer', 'getInventory'])
    const CustomerServiceSpy = jasmine.createSpyObj('CustomerService', ['removeAddon', 'addAddon', 'recharge', 'buyPlan', 'removePlan', 'getSubscriptionDetail', 'subscriptionDetail'])
    const CustomerGroupServiceSpy = jasmine.createSpyObj('CustomerGroupService', ['getFAF', 'removeFAF', 'addFAF', 'registerFAF'])

    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule],
      declarations: [
        PlanComponent,
        MockPaymentFormComponent,
        MockValueFormatterPipe,
        MockDateDiffPipe
      ],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy },

      ]
    })
      .overrideComponent(PlanComponent, {
        set: {
          providers: [
            { provide: ProductService, useValue: PlanServiceSpy },
            { provide: UtilService, useValue: UtilServiceSpy },
            { provide: CustomerService, useValue: CustomerServiceSpy },
            { provide: CustomerGroupService, useValue: CustomerGroupServiceSpy },
          ]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
    utilServiceSpy = fixture.debugElement.injector.get(UtilService) as any;
    planServiceSpy = fixture.debugElement.injector.get(ProductService) as any;
    customerServiceSpy = fixture.debugElement.injector.get(CustomerService) as any;
    customerGroupServiceSpy = fixture.debugElement.injector.get(CustomerGroupService) as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getFAF,getCustomOffer,getAddons,getCurrentPlan,getPlanByType,getSubscriptionDetail,getInventory methods from ngOnInit', () => {
    premiumPlanStub = {
      productName: 'Premium Plan'
    }
    standardPlanStub = {
      productName: 'Standard Plan'
    }
    spyOn(component, 'getFAF');
    spyOn(component, 'getCustomOffer');
    spyOn(component, 'getAddons');
    spyOn(component, 'getCurrentPlan');
    spyOn(component, 'getPlanByType')
      .and.callFake((Premium) => {
        return premiumPlanStub
      })
      .and.callFake((Standard) => {
        return premiumPlanStub
      })
    spyOn(component, 'getSubscriptionDetail');
    spyOn(component, 'getInventory');

    fixture.detectChanges();

    expect(component.getFAF).toHaveBeenCalled();
    expect(component.getCustomOffer).toHaveBeenCalled();
    expect(component.getAddons).toHaveBeenCalled();
    expect(component.getCurrentPlan).toHaveBeenCalled();
    expect(component.getPlanByType).toHaveBeenCalled();
    expect(component.getSubscriptionDetail).toHaveBeenCalled();
    expect(component.getInventory).toHaveBeenCalled();
  });

  describe('getFAF', function () {
    it('should call getFAF method of CustomerService and set the return data in to FAFmsisdns,if length of FAFmsisdns is greator than 5 slice upto length 5 ', fakeAsync(() => {

      persistenceServiceSpy.get.and.returnValue('1234567');
      customerGroupServiceSpy.getFAF.and.returnValue(Observable.of([1, 2, 3, 4, 5, 6, 7, 8]));
      component.getFAF();
      tick();
      expect(customerGroupServiceSpy.getFAF).toHaveBeenCalledWith('1234567');
      expect(component.FAFmsisdns.length).toEqual(5)
    }));

    it('should call getFAF method of CustomerService and set the return data in to FAFmsisdns,if length of FAFmsisdns is less than 5 dont slice the array ', fakeAsync(() => {

      persistenceServiceSpy.get.and.returnValue('1234567');
      customerGroupServiceSpy.getFAF.and.returnValue(Observable.of([1, 2, 3, 4]));

      component.getFAF();
      tick();
      expect(customerGroupServiceSpy.getFAF).toHaveBeenCalled();
      expect(component.FAFmsisdns).toEqual([1, 2, 3, 4])
      expect(component.FAFmsisdns.length).not.toEqual(5)
    }));
  });

  describe('getCustomOffer', function () {
    it('should call the planService and set the result into dataPlans,voicePlans and smsPlans', fakeAsync(() => {
      const mockPromisedData: CustomOffer =
      {
        dataPlans: [{ 'name': 'Data', 'price': 1, 'productId': 'a' }],
        voicePlans: [{ 'name': 'Voice', 'price': 2, 'productId': 'b' }],
        smsPlans: [{ 'name': 'SMS', 'price': 3, 'productId': 'c' }]
      };
      planServiceSpy.getCustomOffer.and.returnValue(Promise.resolve(mockPromisedData))
      component.getCustomOffer();

      tick();

      expect(planServiceSpy.getCustomOffer).toHaveBeenCalled();
      expect(component.dataPlans).toEqual(mockPromisedData.dataPlans);
      expect(component.voicePlans).toEqual(mockPromisedData.voicePlans);
      expect(component.smsPlans).toEqual(mockPromisedData.smsPlans);

    }));

    it('should call alertify.error when error is received from planService.getCustomOffer', fakeAsync(() => {

      planServiceSpy.getCustomOffer.and.returnValue(Promise.reject(new Error()))
      spyOn(alertify, 'error');
      component.getCustomOffer();

      tick();

      expect(planServiceSpy.getCustomOffer).toHaveBeenCalled();
      expect(alertify.error).toHaveBeenCalledWith('Error fetching custom offer');
    }));
  });
  describe('getAddOns', function () {
    it('should call planService.getAddons and set the filtered data into avaialableAddOns', fakeAsync(() => {
      const avaialableAddOns: Partial<CustomizePlanOffer>[] = [{ productId: '1', productName: 'A' }, { productId: '2', productName: 'B' }]
      planServiceSpy.getAddons.and.returnValue(Observable.of(avaialableAddOns));
      persistenceServiceSpy.get.and.returnValue([{ productId: '1', productName: 'A' }, { productId: '5', productName: 'BB' }]);
      component.getAddons();

      tick();

      expect(planServiceSpy.getAddons).toHaveBeenCalled();
      expect(component.availableAddons[0].productId).toBe('2')

    }));
    it('should call planService.getAddons and set useraddon to blank array if not geeting array as result from persistanceService', fakeAsync(() => {
      const avaialableAddOns: Partial<CustomizePlanOffer>[] = [{ productId: '1', productName: 'A' }, { productId: '2', productName: 'B' }]
      planServiceSpy.getAddons.and.returnValue(Observable.of(avaialableAddOns));
      persistenceServiceSpy.get.and.returnValue('1234');
      component.getAddons();

      tick();

      expect(planServiceSpy.getAddons).toHaveBeenCalled();
      expect(component.useraddons.length).toEqual(0);
      expect(component.availableAddons[0].productId).toBe('1')

    }));
    it('should throw the error when error is received from planService.getAddons', fakeAsync(() => {

      planServiceSpy.getAddons.and.returnValue(Observable.throw(new Error()));
      component.getAddons();
      tick();

      expect(planServiceSpy.getAddons).toHaveBeenCalled()
      expect(component.getAddons).toThrowError();
    }))
  });

  describe('getCurrentPlan', function () {
    it('should execute getCurrentPlan ', () => {
      const currentPlanData = JSON.parse(JSON.stringify(mockCurrentPlanData));

      persistenceServiceSpy.get.and.returnValue(currentPlanData);

      spyOn(component, 'getProductByPlanId').and.callFake(() => { });
      component.getCurrentPlan();
      expect(component.currentPlan).not.toBeNull();
      expect(component.currentPlan.productGroup).not.toEqual('custom');
      expect(component.planFeatures1.length).toEqual(0);
      expect(component.planFeatures2.length).toEqual(0);
      expect(component.getProductByPlanId).toHaveBeenCalledWith('CM_Combo_556');

    })

    it('should not call getProductByPlanId through getCurrentPlan method when currentPlan is empty ', () => {
      const CurrentPlan = JSON.parse(JSON.stringify(mockCurrentPlan));
      persistenceServiceSpy.get.and.returnValue(CurrentPlan);
      spyOn(component, 'getProductByPlanId').and.callFake(() => { });

      component.getCurrentPlan();

      expect(component.currentPlan.productGroup).toEqual('custom');
      expect(component.planFeatures1.length).toBe(0);
      expect(component.planFeatures2.length).toBe(0);
      expect(component.getProductByPlanId).not.toHaveBeenCalledWith('CM_Combo_556');
    })
  });

  describe('getCurrentPlan', function () {
    it('should call getPlanByType and set the standardPlan array when type is Standard ', fakeAsync(() => {
      let type = 'standard';
      const mockData: CustomizePlanOffer = JSON.parse(JSON.stringify(mockCurrentPlanData));
      planServiceSpy.getPlanByType.and.returnValue(Promise.resolve(mockData))

      component.getPlanByType(type);
      tick();

      expect(planServiceSpy.getPlanByType).toHaveBeenCalled();
      expect(component.standardPlan).toBe(mockData)
    }))
    it('should call getPlanByType and set the premiumPl/an array when type is Premium ', fakeAsync(() => {
      let type = 'premium';
      const mockData: CustomizePlanOffer = JSON.parse(JSON.stringify(mockCurrentPlanData));
      planServiceSpy.getPlanByType.and.returnValue(Promise.resolve(mockData))

      component.getPlanByType(type);
      tick();

      expect(planServiceSpy.getPlanByType).toHaveBeenCalled();
      expect(component.premiumPlan).toBe(mockData)
    }))
    it('should throw error when error is received from planService.getPlanByType ', fakeAsync(() => {
      let type = 'standard';
      planServiceSpy.getPlanByType.and.returnValue(Promise.reject(new Error()))
      spyOn(console, 'log')

      component.getPlanByType(type);
      tick();

      expect(planServiceSpy.getPlanByType).toHaveBeenCalled();
      expect(console.log).toHaveBeenCalled();
    }))
  });

  describe('subscriptionDetail', function () {
    it(`should call customerService.getSubscriptionDetail,persistenceService.get,utilService.getCustomerPlanFromSubscription
  when get result from customerService.getSubscriptionDetail and productGroup is custom`, fakeAsync(() => {
      const currentPlan: Product = JSON.parse(JSON.stringify(mockCurrentPlan));
      const subscriptionDetail = JSON.parse(JSON.stringify(mockSubscriptionDetail));
      persistenceServiceSpy.get.and.returnValue('123456');
      customerServiceSpy.getSubscriptionDetail.and.returnValue(Observable.of(subscriptionDetail));
      utilServiceSpy.getCustomerPlanFromSubscription.and.returnValue(currentPlan);
      spyOn(component, 'getCustomPlanFeature');
      spyOn(component, 'getCurrentPlan');

      component.getSubscriptionDetail();

      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(customerServiceSpy.getSubscriptionDetail).toHaveBeenCalledWith('123456');
      expect(utilServiceSpy.getCustomerPlanFromSubscription).toHaveBeenCalled();
      expect(component.getCustomPlanFeature).toHaveBeenCalledWith(currentPlan);
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
      expect(component.getCurrentPlan).toHaveBeenCalled();
    }));

    it(`get subscriptionDetail Method : should not call subscriptionDetail Method of customerService
  when return value is null from getSubscriptionDetail of customerService`, () => {
        const currentPlan: Product = JSON.parse(JSON.stringify(mockCurrentPlanData));
        persistenceServiceSpy.get.and.returnValue('123456');
        customerServiceSpy.getSubscriptionDetail.and.returnValue(Observable.of(''));
        utilServiceSpy.getCustomerPlanFromSubscription.and.returnValue(currentPlan);
        spyOn(component, 'getCustomPlanFeature');
        spyOn(component, 'getCurrentPlan');

        component.getSubscriptionDetail();

        expect(persistenceServiceSpy.get).toHaveBeenCalled();
        expect(customerServiceSpy.getSubscriptionDetail).toHaveBeenCalledWith('123456');
        expect(utilServiceSpy.getCustomerPlanFromSubscription).not.toHaveBeenCalled();

      });

    it(`get subscriptionDetail Method : should not call subscriptionDetail Method of customerService
      when return value is null from getSubscriptionDetail of customerService`, () => {
        const currentPlan: Product = JSON.parse(JSON.stringify(mockCurrentPlanData));
        const subscriptionDetail = JSON.parse(JSON.stringify(mockSubscriptionDetail));
        persistenceServiceSpy.get.and.returnValue('123456');
        customerServiceSpy.getSubscriptionDetail.and.returnValue(Observable.of(subscriptionDetail));
        utilServiceSpy.getCustomerPlanFromSubscription.and.returnValue(currentPlan);
        spyOn(component, 'getCustomPlanFeature');
        spyOn(component, 'getCurrentPlan');

        component.getSubscriptionDetail();

        expect(persistenceServiceSpy.get).toHaveBeenCalled();
        expect(customerServiceSpy.getSubscriptionDetail).toHaveBeenCalledWith('123456');
        expect(utilServiceSpy.getCustomerPlanFromSubscription).toHaveBeenCalled();
        expect(component.getCustomPlanFeature).not.toHaveBeenCalledWith(currentPlan);
        expect(persistenceServiceSpy.set).toHaveBeenCalled();
        expect(component.getCurrentPlan).toHaveBeenCalled();

      });
  });

  describe('getProductByPlanId', function () {
    it('should call planService.getProductByPlanId and set the currentPlanDetail,planFeatures1,planFeatures2', fakeAsync(() => {
      let productId = 'CM_Combo_556'
      const currentPlan: CustomizePlanOffer = JSON.parse(JSON.stringify(mockCurrentPlan));
      planServiceSpy.getProductByPlanId.and.returnValue(Observable.of(currentPlan))

      component.getProductByPlanId(productId);
      tick();

      expect(planServiceSpy.getProductByPlanId).toHaveBeenCalledWith(productId);
      expect(component.currentPlanDetail).toEqual(currentPlan);
      expect(component.planFeatures1.length).toBe(1);
      expect(component.planFeatures2.length).toBe(0);
    }));

    it('should throw error when error is received from planService.getProductByPlanId', fakeAsync(() => {
      let productId = 'CM_Combo_556'
      planServiceSpy.getProductByPlanId.and.returnValue(Observable.throw(new Error))
      spyOn(console, 'log')

      component.getProductByPlanId(productId);
      tick();

      expect(planServiceSpy.getProductByPlanId).toHaveBeenCalledWith(productId);
      expect(console.log).toHaveBeenCalled();
    }))
  });

  describe('showPlans', function () {
    it('should execute method showPlan, set the switch plan tobetruthy and set show payment , hideBuyOption to be falsy', () => {
      component.switchPlan = false;
      component.showPlans()

      expect(component.switchPlan).toBeTruthy();
      expect(component.showPayment).toBeFalsy();
      expect(component.hideBuyOption).toBeFalsy();
    })
    it('should execute method showPlan,  switch plan tobetruthy and set show payment , hideBuyOption tobetruthy', () => {
      component.switchPlan = true;
      component.showPayment = true;
      component.hideBuyOption = true;
      component.showPlans()

      expect(component.switchPlan).toBeTruthy();
      expect(component.showPayment).toBeTruthy();
      expect(component.hideBuyOption).toBeTruthy();
    })
  });

  describe('removeFAF', function () {
    it('should call customerGroupService.removeFAF,component.getFAF method and remove the FAF when getting result from customerService ', fakeAsync(() => {
      let removeId = 1;
      persistenceServiceSpy.get.and.returnValue('123456');
      spyOn(component, 'getFAF');
      spyOn(alertify, 'success');

      customerGroupServiceSpy.removeFAF.and.returnValue(Observable.of('1'));
      component.removeFAF(removeId);
      tick();

      expect(customerGroupServiceSpy.removeFAF).toHaveBeenCalledWith('123456', 1);
      expect(component.getFAF).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalledWith(`1 has been removed`);

    }))
    it('should call alertify.error when error is received from customerGroupService.removeFAF', fakeAsync(() => {
      let removeId = 1;
      persistenceServiceSpy.get.and.returnValue('123456');
      spyOn(component, 'getFAF');
      spyOn(alertify, 'error');

      customerGroupServiceSpy.removeFAF.and.returnValue(Observable.throw(new Error('error')));
      component.removeFAF(removeId);
      tick();

      expect(customerGroupServiceSpy.removeFAF).toHaveBeenCalledWith('123456', 1);
      expect(alertify.error).toHaveBeenCalledWith('Error deleting FAF');
    }))
  });
  describe('addFAF', function () {
    it('should call customerGroupService.addFAF,alertify.success,component.getFAF when get successful result from customerGroupService.addFAF', fakeAsync(() => {
      persistenceServiceSpy.get.and.returnValue('123456');
      spyOn(component, 'getFAF');
      spyOn(alertify, 'success');
      spyOn(component.formGroup,'patchValue')
      customerGroupServiceSpy.addFAF.and.returnValue(Observable.of('1'));

      component.addFAF();
      tick();

      expect(customerGroupServiceSpy.addFAF).toHaveBeenCalledWith('123456', '');
      expect(alertify.success).toHaveBeenCalledWith('Added FAF');
      expect(component.formGroup.patchValue).toHaveBeenCalledWith({msisdn : ''});
      expect(component.getFAF).toHaveBeenCalled();
    }));

    it('should call alertify.error if the length of FAFmsisdns array is greator than 5', fakeAsync(() => {
      component.FAFmsisdns = [1, 2, 3, 4, 5, 6];
      spyOn(alertify, 'error');

      component.addFAF();

      expect(alertify.error).toHaveBeenCalledWith('Cannot add more than 5 FAF');
    }))
    it('should call alertify.error when error is received from customerGroupService.addFAF', fakeAsync(() => {
      persistenceServiceSpy.get.and.returnValue('123456');

      spyOn(alertify, 'error');
      customerGroupServiceSpy.addFAF.and.returnValue(Observable.throw(new Error('error')));

      component.addFAF();
      tick();

      expect(customerGroupServiceSpy.addFAF).toHaveBeenCalledWith('123456', '');
      expect(alertify.error).toHaveBeenCalledWith('Error adding FAF');
    }))
  });
  describe('registerFAF', function () {
    it('should call alertify.error when error is received from customerGroupService.registerFAF', fakeAsync(() => {
      persistenceServiceSpy.get.and.returnValue('123456');
      spyOn(alertify, 'error');
      customerGroupServiceSpy.registerFAF.and.returnValue(Observable.throw(new Error('error')));

      component.registerFAF();
      tick();

      expect(customerGroupServiceSpy.registerFAF).toHaveBeenCalledWith('123456');
      expect(alertify.error).toHaveBeenCalledWith('Error adding FAF');
    }));
  });

  describe('selectCustomPlan', function () {

    it("should set selectedSmsPlanIndex to provided index when provided index not equal to component.selectedSmsPlanIndex ", () => {
      component.selectCustomPlan('sms', 1);
      expect(component.selectedSmsPlanIndex).toBe(1);
    });
    it("should set selectedSmsPlanIndex to -1 when provided index equal to component.selectedSmsPlanIndex", () => {
      component.selectCustomPlan('sms', -1);
      expect(component.selectedSmsPlanIndex).toBe(-1);
    });

    it("should set selectedVoicePlanIndex to provided index when provided index not equal to component.selectedVoicePlanIndex ", () => {
      component.selectCustomPlan('voice', 1);
      expect(component.selectedVoicePlanIndex).toBe(1);
    });
    it("should set selectedVoicePlanIndex to -1 when provided index equal to component.selectedVoicePlanIndex", () => {
      component.selectCustomPlan('voice', -1);
      expect(component.selectedVoicePlanIndex).toBe(-1);
    });

    it("should set selectedDataPlanIndex to provided index when provided index not equal to component.selectedDataPlanIndex  ", () => {
      component.selectCustomPlan('data', 1);
      expect(component.selectedDataPlanIndex).toBe(1);
    });
    it("should set selectedDataPlanIndex to -1 when provided index equal to component.selectedDataPlanIndex", () => {
      component.selectCustomPlan('data', -1);
      expect(component.selectedDataPlanIndex).toBe(-1);
    });
  });

  describe('getSumForCustom', function () {
    it('should set the result when dataplans.length > 1 and selectedDataPlanIndex > 0', () => {
      component.selectedDataPlanIndex = 0;
     component.dataPlans = [{ 'name': 'Data', 'price': 1, 'productId': 'a' }]
      let result = component.getSumForCustom();
      expect(result).toEqual(1);
    });
    it('should set the result when voicePlans.length > 1 and selectedVoicePlanIndex > 0', () => {
      component.selectedVoicePlanIndex = 0;
      component.voicePlans = [{ 'name': 'Voice', 'price': 2, 'productId': 'b' }]
      let result = component.getSumForCustom();
      expect(result).toEqual(2);
    });
    it('should set the result when smsPlans.length > 1 and selectedSmsPlanIndex > 0', () => {
      component.selectedSmsPlanIndex = 0;
      component.smsPlans = [{ 'name': 'SMS', 'price': 3, 'productId': 'c' }]
      let result = component.getSumForCustom();
      expect(result).toEqual(3);
    });
  });

  describe('confirmRemoveAddon method', () => {
    it('should call alertify.success and should remove product from addOns', fakeAsync(() => {
      component.msisdn = '123456';
      component.useraddons = JSON.parse(JSON.stringify(mockSubscriptionDetail.products));
      component.availableAddons = []
      customerServiceSpy.removeAddon.and.returnValue(Observable.of('Success'));
      persistenceServiceSpy.set.and.callFake(() => { });
      spyOn(alertify, 'success');

      component.confirmRemoveAddon(0);
      tick();

      expect(customerServiceSpy.removeAddon).toHaveBeenCalled();
      expect(component.availableAddons.length).toBe(1);
      expect(component.useraddons.length).toBe(1);
      expect(alertify.success).toHaveBeenCalledWith('Removed 50GB and Unlimited SMS and Voice Combo');
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
    }));

    it('should call alertify.error when error is received from customerService.removeAddon', fakeAsync(() => {
      component.msisdn = '123456';
      component.useraddons = JSON.parse(JSON.stringify(mockSubscriptionDetail.products));
      customerServiceSpy.removeAddon.and.returnValue(Observable.throw(new Error('Error')));
      spyOn(alertify, 'error');

      component.confirmRemoveAddon(0);
      tick();

      expect(alertify.error).toHaveBeenCalledWith('Error Removing 50GB and Unlimited SMS and Voice Combo');
    }));
  });

  describe('confirmAddAddon method', () => {
    it('should call alertify.success and should add product from availableAddons', fakeAsync(() => {
      component.msisdn = '123456';
      component.availableAddons = JSON.parse(JSON.stringify(mockSubscriptionDetail.products));
      component.useraddons = []
      customerServiceSpy.addAddon.and.returnValue(Observable.of('Success'));
      persistenceServiceSpy.set.and.callFake(() => { });
      spyOn(alertify, 'success');

      component.confirmAddAddon(0);
      tick();
      expect(customerServiceSpy.addAddon).toHaveBeenCalled();
      expect(component.useraddons.length).toBe(1);
      expect(component.availableAddons.length).toBe(1);
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalledWith('Added 50GB and Unlimited SMS and Voice Combo');
    }));

    it('should call alertify.error when error is received from customerService.removeAddon', fakeAsync(() => {
      component.msisdn = '123456';
      component.availableAddons = JSON.parse(JSON.stringify(mockSubscriptionDetail.products));
      customerServiceSpy.addAddon.and.returnValue(Observable.throw({ 'error': { 'message': 'NA' } }));
      spyOn(alertify, 'error');

      component.confirmAddAddon(0);
      tick();
      expect(alertify.error).toHaveBeenCalledWith('NA');
    }));
  });
  describe('simAdded method', () => {
    it('should call alertify.success', () => {

      spyOn(alertify, 'success');
      component.simAdded()

      expect(alertify.success).toHaveBeenCalledWith('SIM added successfully');
    });
  });

  describe('suspendSimAction method', () => {
    it('should call alertify.success if suspendSim is present', () => {
      component.suspendSim = true
      spyOn(alertify, 'success');
      component.suspendSimAction()
      expect(alertify.success).toHaveBeenCalledWith('Sim suspended successfully');
    });
    it('should call alertify.error if suspendSim is not present', () => {
      component.suspendSim = false
      spyOn(alertify, 'error');
      component.suspendSimAction()
      expect(alertify.error).toHaveBeenCalledWith('Invalid msisdn');
    });
  });

  describe('recharge method', () => {
    it('should call rechargeForm.reset and alertify.success when get the success result from customerService ,', fakeAsync(() => {
      customerServiceSpy.recharge.and.returnValue(Promise.resolve('success'))
      spyOn(alertify, 'success');
      spyOn(component.rechargeForm, 'reset');
      component.recharge()
      tick();

      expect(customerServiceSpy.recharge).toHaveBeenCalledWith('', NaN);
      expect(component.rechargeForm.reset).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalledWith('Recharge successful');
    }));
    it('should call alertify.error when get the error result from customerService', fakeAsync(() => {
      customerServiceSpy.recharge.and.returnValue(Promise.reject({ 'error': { 'message': 'NA' } }));
      spyOn(alertify, 'error');
      component.recharge();
      tick();
      expect(alertify.error).toHaveBeenCalledWith('NA');
    }));
  });

  describe('confirmBuy method', () => {
    it('should set hideBuyOption to tobeFalsy and showPayment,switchPlan toBetruthy', () => {
      component.confirmBuy('mockData')
      expect(component.switchPlan).toBeTruthy();
      expect(component.hideBuyOption).toBeFalsy();
      expect(component.showPayment).toBeTruthy();
    });
  });

  describe('confirmBuyPremium method', () => {
    it('should set hideBuyOption to tobefalsy and showPaymentPremium,switchPlan toBetruthy', () => {
      component.confirmBuyPremium('mockData')
      expect(component.switchPlan).toBeTruthy();
      expect(component.hideBuyOption).toBeFalsy();
      expect(component.showPaymentPremium).toBeTruthy();
    });
  });

  describe('confirmBuyCustom method', () => {
    it('should set hideBuyOption to false and switchPlan,showPaymentCustom toBetruthy', () => {
      component.confirmBuyCustom('mockData')
      expect(component.switchPlan).toBeTruthy();
      expect(component.hideBuyOption).toBeFalsy();
      expect(component.showPaymentCustom).toBeTruthy();
    });
  });

  describe('confirmBuyPlan method', () => {
    it('should call component.buyPlan and set switchPlan ,showPaymentCustom ,showPaymentPremium ', () => {

      spyOn(component, 'buyPlan');
      spyOn(jQuery.fn, 'modal');
      component.confirmBuyPlan('mockData');

      expect(component.buyPlan).toHaveBeenCalledWith('mockData');
      expect(component.switchPlan).toBeFalsy();
      expect(component.showPayment).toBeFalsy();
      expect(component.showPaymentCustom).toBeFalsy();
      expect(component.showPaymentPremium).toBeFalsy();
      expect(jQuery.fn.modal).toHaveBeenCalledWith('hide');
    });
  });

  describe('goBack method', () => {
    it('should set showPayment,showPaymentCustom ,showPaymentPremium,hideBuyOption to tobefalsy and switchPlan to tobetruthy', () => {

      component.goBack();

      expect(component.switchPlan).toBeTruthy();
      expect(component.showPayment).toBeFalsy();
      expect(component.showPaymentCustom).toBeFalsy();
      expect(component.showPaymentPremium).toBeFalsy();
      expect(component.hideBuyOption).toBeFalsy();
    });
  });

  describe('showSubscriptionPlans method', () => {
    it('should set switchPlan toBetruthy and hideBuyOption to tobefalsy', () => {

      component.showSubscriptionPlans();

      expect(component.switchPlan).toBeTruthy();
      expect(component.hideBuyOption).toBeFalsy();
    });
  });

  describe('getCustomPlanFeature method', () => {
    it('should set planFeatures1 Array', () => {
      let customPlan = { 'productName': 'mock' }
      component.getCustomPlanFeature(customPlan);
      expect(component.planFeatures1.length).toEqual(1);
    });
  });

  describe('buyPlan', function () {

    it("should set selectedDataPlanIndex,selectedSmsPlanIndex,selectedVoicePlanIndex to 0 when type is custom", () => {
      component.standardPlan = JSON.parse(JSON.stringify(mockCurrentPlan));
      component.premiumPlan = JSON.parse(JSON.stringify(mockCurrentPlan));
      let type = 'custom';
      component.selectedDataPlanIndex = -1;
      component.selectedSmsPlanIndex = -1;
      component.selectedVoicePlanIndex = -1;

      component.buyPlan(type);

      expect(type).toEqual('custom');
      expect(component.selectedDataPlanIndex).toEqual(0);
      expect(component.selectedSmsPlanIndex).toEqual(0);
      expect(component.selectedVoicePlanIndex).toEqual(0)
    })


    it(`should set selectedDataPlanIndex to -1 and throw error when productId is null
    and  selectedDataPlanIndex,selectedSmsPlanIndex,selectedVoicePlanIndex is equal to 0`, fakeAsync(() => {

      component.premiumPlan = JSON.parse(JSON.stringify(mockCurrentPlan));
      component.dataPlans = [{ 'name': 'Data', 'price': 1, 'productId': 'a' }]
      component.voicePlans = [{ 'name': 'Voice', 'price': 2, 'productId': 'b' }]
      component.smsPlans = [{ 'name': 'SMS', 'price': 3, 'productId': 'c' }]

      component.selectedDataPlanIndex = 0;
      component.selectedSmsPlanIndex = 0;
      component.selectedVoicePlanIndex = 0;
      spyOn(alertify, 'error')


      let result = component.buyPlan('premium');

      tick();

      expect(component.selectedDataPlanIndex).toEqual(-1);
      expect(alertify.error).toHaveBeenCalledWith('Please select any of data, sms and voice');
      result.then((res) => {
        expect(res).toBeFalsy();
      })
    }))

    it("should execute try block", fakeAsync(() => {
      let type = 'premium';
      component.msisdn = '4622378109';
      component.premiumPlan = JSON.parse(JSON.stringify(mockCurrentPlan));
      component.dataPlans = [{ 'name': 'Data', 'price': 1, 'productId': 'a' }]
      component.voicePlans = [{ 'name': 'Voice', 'price': 2, 'productId': 'b' }]
      component.smsPlans = [{ 'name': 'SMS', 'price': 3, 'productId': 'c' }]

      const subscriptionDetail = JSON.parse(JSON.stringify(mockSubscriptionDetail));
      const subscriptionDetailData = JSON.parse(JSON.stringify(mockSubscriptionDetail));
      component.currentPlan = subscriptionDetailData.products[0];

      customerServiceSpy.subscriptionDetail.and.returnValue(Promise.resolve(subscriptionDetail))
      utilServiceSpy.getCustomerPlanFromSubscription.and.returnValue(subscriptionDetail.products)

      spyOn(alertify, 'success');
      spyOn(component, 'getCurrentPlan');
      spyOn(component, "getSubscriptionDetail");
      component.buyPlan(type);

      tick();

      expect(persistenceServiceSpy.set).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalledWith('Plan switched successfully');
      expect(component.getCurrentPlan).toHaveBeenCalled();
      expect(component.getSubscriptionDetail).toHaveBeenCalled();
      expect(component.switchPlan).toBeFalsy();
      expect(component.planFeatures1.length).toEqual(0);
      expect(component.planFeatures2.length).toEqual(0);
    }));

    it("should execute catch block", fakeAsync(() => {
      let type = 'premium'
      component.premiumPlan = JSON.parse(JSON.stringify(mockCurrentPlan));
      component.dataPlans = [{ 'name': 'Data', 'price': 1, 'productId': 'a' }]
      component.voicePlans = [{ 'name': 'Voice', 'price': 2, 'productId': 'b' }]
      component.smsPlans = [{ 'name': 'SMS', 'price': 3, 'productId': 'c' }]

      component.selectedDataPlanIndex = 0;
      component.selectedSmsPlanIndex = 0;
      component.selectedVoicePlanIndex = 0;
      spyOn(alertify, 'error').and.returnValue('Error buying  plan');

      let result = component.buyPlan(type);
      tick();
      result.catch(e => {
        expect(alertify.error).toHaveBeenCalledWith('Error buying  plan');
      })
    }));



  });
});
