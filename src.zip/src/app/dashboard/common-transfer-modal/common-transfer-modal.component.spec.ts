import { Component, Input, Pipe, PipeTransform } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormsModule, NG_VALUE_ACCESSOR, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { PersistenceService } from 'angular-persistence';
import { Observable } from 'rxjs';
import { EventListenerService } from '../../event-listener.service';
import { CustomerService } from '../../services/customer.service';
import { ProductService } from '../../services/product.service';
import { CommonTransferModalComponent } from './common-transfer-modal.component';
import { TranslateService } from '@ngx-translate/core';
declare const alertify;

const mockProducts = [{
  'productId': 'CM_Combo_574',
  'productName': 'Roaming data 10gb 1000mins 1000sms',
  'productType': 'Combo',
  'productGroup': 'Addon',
  'price': 2500,
  'paymentMode': 'AIR',
  'srcChannel': 'SELFCARE',
  'numberOfPendingRenewals': 0,
  'nextRenewalDate': '01-03-2019 14:30:00',
  'provisionedQuota': {
    'voice': {
      'unit': 60000,
      'unitType': '0'
    },
    'sms': {
      'unit': 1000,
      'unitType': '1'
    },
    'data': {
      'unit': 10737418240,
      'unitType': '6'
    }
  },
  'availableQuota': {
    'voice': {
      'unit': 60000,
      'unitType': '0'
    },
    'sms': {
      'unit': 1000,
      'unitType': '1'
    },
    'data': {
      'unit': 10737418240,
      'unitType': '6'
    }
  },
  'sharedQuota': {
    'voice': {
      'unit': 60000,
      'unitType': '0'
    },
    'sms': {
      'unit': 1000,
      'unitType': '1'
    },
    'data': {
      'unit': 10737418240,
      'unitType': '6'
    }
  },
  'activationDate': '30-01-2019 14:30:43',
  'expiryDate': '01-03-2019 14:30:00',
  'isRecurring': false
}];

@Pipe({ name: 'valueFormatter' })
class MockValueFormatterPipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}
@Pipe({ name: 'translate' })
class MockTranslatePipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}

@Component({
  selector: 'nouislider',
  template: '',
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: MockNoUiSliderComponent, multi: true },
  ]
})
class MockNoUiSliderComponent {
  @Input() min = '';
  @Input() max = '';
  @Input() step = '';

  writeValue() { }
  registerOnChange() { }
  registerOnTouched() { }
}

describe('CommonTransferModalComponent', () => {
  let component: CommonTransferModalComponent;
  let fixture: ComponentFixture<CommonTransferModalComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let productServiceSpy: jasmine.SpyObj<ProductService>;
  let customerServiceSpy: jasmine.SpyObj<CustomerService>;
  let eventListenerServiceSpy: jasmine.SpyObj<EventListenerService>;
  let translateServiceSpy: any;

  beforeEach(async(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get']);
    const ProductServiceSpy = jasmine.createSpyObj('ProductService', ['getRechargeOptions']);
    const CustomerServiceSpy = jasmine.createSpyObj('CustomerService', ['transferItem']);
    const EventListenerServiceSpy = jasmine.createSpyObj('EventListenerService', ['customerDataChangesEvent', 'removeData', 'removeSms', 'removeMinutes']);
    EventListenerServiceSpy['customerDataChangesEvent'] = { 'subscribe': (c) => { c('data') } };
    translateServiceSpy = {
      instant: () => { },
    }

    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        ReactiveFormsModule
      ],
      declarations: [
        CommonTransferModalComponent,
        MockValueFormatterPipe,
        MockNoUiSliderComponent,
        MockTranslatePipe
      ],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy },
        { provide: EventListenerService, useValue: EventListenerServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        FormBuilder
      ]
    }).overrideComponent(CommonTransferModalComponent, {
      set: {
        providers: [
          { provide: ProductService, useValue: ProductServiceSpy },
          { provide: CustomerService, useValue: CustomerServiceSpy }
        ]
      }
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonTransferModalComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
    eventListenerServiceSpy = TestBed.get(EventListenerService);
    productServiceSpy = fixture.debugElement.injector.get(ProductService) as any;
    customerServiceSpy = fixture.debugElement.injector.get(CustomerService) as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit method should set customerObj and call getMinMaxValuesFormTransfer method', () => {
    expect(component.customerObj).toBeNull();
    spyOn(component, 'getMinMaxValuesFormTransfer');

    component.ngOnInit();

    expect(component.customerObj).toBeDefined();
    expect(component.getMinMaxValuesFormTransfer).toHaveBeenCalled();
  });

  describe('ngOnChanges method should', () => {
    it('initialize msisdn, bar and transfer. And should set transferUnit, srcAccountType, dstAccountType, title, productId and placeType. Should call getMinMaxValuesFormTransfer method when type = "data"', () => {
      spyOn(component, 'getMinMaxValuesFormTransfer');
      component.type = 'data';

      component.ngOnChanges(undefined);

      expect(component.getMinMaxValuesFormTransfer).toHaveBeenCalled();
      expect(component.msisdn).toBe('');
      expect(component.bar).toBe(0);
      expect(component.transfer).toBe('');

      expect(component.transferUnit).toBe('GB');
      expect(component.srcAccountType).toBe(6);
      expect(component.dstAccountType).toBe(6);
      expect(component.title).toBe('Transfer Data');
      expect(component.productId).toBe('CM_Data2Share_577');
      expect(component.placeType).toBe('00.0 GB ');
    });

    it('initialize msisdn, bar and transfer. And should set transferUnit, srcAccountType, dstAccountType, title, productId and placeType. Should call getMinMaxValuesFormTransfer method when type = "sms"', () => {
      spyOn(component, 'getMinMaxValuesFormTransfer');
      component.type = 'sms';

      component.ngOnChanges(undefined);

      expect(component.getMinMaxValuesFormTransfer).toHaveBeenCalled();
      expect(component.msisdn).toBe('');
      expect(component.bar).toBe(0);
      expect(component.transfer).toBe('');

      expect(component.transferUnit).toBe('');
      expect(component.srcAccountType).toBe(5);
      expect(component.dstAccountType).toBe(5);
      expect(component.title).toBe('Transfer SMS');
      expect(component.productId).toBe('CM_Data2Share_603');
      expect(component.placeType).toBe('SMS');
    });

    it('initialize msisdn, bar and transfer. And should set transferUnit, srcAccountType, dstAccountType, title, productId and placeType. Should call getMinMaxValuesFormTransfer method when type = "voice"', () => {
      spyOn(component, 'getMinMaxValuesFormTransfer');
      component.type = 'voice';

      component.ngOnChanges(undefined);

      expect(component.getMinMaxValuesFormTransfer).toHaveBeenCalled();
      expect(component.msisdn).toBe('');
      expect(component.bar).toBe(0);
      expect(component.transfer).toBe('');

      expect(component.transferUnit).toBe('Min');
      expect(component.srcAccountType).toBe(0);
      expect(component.dstAccountType).toBe(0);
      expect(component.title).toBe('Transfer Minutes');
      expect(component.productId).toBe('CM_Data2Share_601');
      expect(component.placeType).toBe('00.0 Min');
    });
  });

  describe('getMinMaxValuesFormTransfer method should', () => {
    it('not set availableQuota when type = null, component.customerObj = null and component.availableQuota = null', () => {
      component.customerObj = null;
      component.type = null;
      persistenceServiceSpy.get.and.returnValue(null);

      component.getMinMaxValuesFormTransfer();

      expect(component.availableQuota).toBe(null);
    });

    // ****************************Data*******************************

    it('set maxCreditBalance = 50, when type = "data" and availableQuota.data < 107373108658176', () => {
      const obj = { data: 53687091200, sms: -1, voice: -1 };
      component.customerObj = JSON.parse(JSON.stringify(obj));
      component.type = 'data';
      persistenceServiceSpy.get.and.returnValue(JSON.parse(JSON.stringify(mockProducts[0].availableQuota)));

      component.getMinMaxValuesFormTransfer();

      expect(component.availableQuota.data).toEqual(obj.data);
      expect(component.availableQuota.voice).toEqual(obj.voice);
      expect(component.availableQuota.sms).toEqual(obj.sms);
      expect(component.maxCreditBalance).toBe(50);
    });

    it('set maxCreditBalance = 100 when type = "data", availableQuota.data = -1', () => {
      const obj = { data: -1, sms: -1, voice: -1 };
      component.customerObj = JSON.parse(JSON.stringify(obj));
      component.type = 'data';
      persistenceServiceSpy.get.and.returnValue(JSON.parse(JSON.stringify(mockProducts[0].availableQuota)));

      component.getMinMaxValuesFormTransfer();

      expect(component.maxCreditBalance).toBe(100);
    });

    it('set maxCreditBalance = 100 when type = "data", availableQuota.data > 107373108658176', () => {
      const obj = { data: 107373108658177, sms: -1, voice: -1 };
      component.customerObj = JSON.parse(JSON.stringify(obj));
      component.type = 'data';
      persistenceServiceSpy.get.and.returnValue(JSON.parse(JSON.stringify(mockProducts[0].availableQuota)));

      component.getMinMaxValuesFormTransfer();

      expect(component.maxCreditBalance).toBe(100);
    });

    // ***********************************sms*************************************

    it('set maxCreditBalance = component.customerObj.sms, when type = "sms" and availableQuota.sms < 99999', () => {
      const obj = { data: 123456, sms: 99998, voice: -1 };
      component.customerObj = JSON.parse(JSON.stringify(obj));
      component.type = 'sms';
      persistenceServiceSpy.get.and.returnValue(JSON.parse(JSON.stringify(mockProducts[0].availableQuota)));

      component.getMinMaxValuesFormTransfer();

      expect(component.availableQuota.data).toEqual(obj.data);
      expect(component.availableQuota.voice).toEqual(obj.voice);
      expect(component.availableQuota.sms).toEqual(obj.sms);
      expect(component.maxCreditBalance).toBe(component.customerObj.sms);
    });

    it('set maxCreditBalance = 100 when type = "sms", availableQuota.sms = -1', () => {
      const obj = { data: -1, sms: -1, voice: -1 };
      component.customerObj = JSON.parse(JSON.stringify(obj));
      component.type = 'sms';
      persistenceServiceSpy.get.and.returnValue(JSON.parse(JSON.stringify(mockProducts[0].availableQuota)));

      component.getMinMaxValuesFormTransfer();

      expect(component.maxCreditBalance).toBe(100);
    });

    it('set maxCreditBalance = 100 when type = "sms", availableQuota.sms > 99999', () => {
      const obj = { data: 123456, sms: 100000, voice: -1 };
      component.customerObj = JSON.parse(JSON.stringify(obj));
      component.type = 'sms';
      persistenceServiceSpy.get.and.returnValue(JSON.parse(JSON.stringify(mockProducts[0].availableQuota)));

      component.getMinMaxValuesFormTransfer();

      expect(component.maxCreditBalance).toBe(100);
    });

    // ******************************voice******************************
    it('set maxCreditBalance = component.customerObj.voice, when type = "voice" and availableQuota.voice < 5999940', () => {
      const obj = { data: 123456, sms: 99998, voice: 5999939 };
      component.customerObj = JSON.parse(JSON.stringify(obj));
      component.type = 'voice';
      persistenceServiceSpy.get.and.returnValue(JSON.parse(JSON.stringify(mockProducts[0].availableQuota)));

      component.getMinMaxValuesFormTransfer();

      expect(component.availableQuota.data).toEqual(obj.data);
      expect(component.availableQuota.sms).toEqual(obj.sms);
      expect(component.availableQuota.voice).toEqual(obj.voice);
      expect(component.maxCreditBalance).toBe(component.customerObj.voice / 60);
    });

    it('set maxCreditBalance = 100 when type = "voice", availableQuota.voice = -1', () => {
      const obj = { data: -1, sms: -1, voice: -1 };
      component.customerObj = JSON.parse(JSON.stringify(obj));
      component.type = 'voice';
      persistenceServiceSpy.get.and.returnValue(JSON.parse(JSON.stringify(mockProducts[0].availableQuota)));

      component.getMinMaxValuesFormTransfer();

      expect(component.maxCreditBalance).toBe(100);
    });

    it('set maxCreditBalance = 100 when type = "voice", availableQuota.voice > 5999940', () => {
      const obj = { data: 123456, sms: 100000, voice: 5999941 };
      component.customerObj = JSON.parse(JSON.stringify(obj));
      component.type = 'voice';
      persistenceServiceSpy.get.and.returnValue(JSON.parse(JSON.stringify(mockProducts[0].availableQuota)));

      component.getMinMaxValuesFormTransfer();

      expect(component.maxCreditBalance).toBe(100);
    });

  });

  describe('transferItem method should', () => {
    it('call component.transferQuota, component.getMinMaxValuesFormTransfer, component.resetModal and alertify.success when customerServiceSpy.transferItem is successful. type = data', () => {
      const params = { benmsisdn: 123456, dstAccountType: 6, msisdn: '4622378109', srcAccountType: 6, transfer: 102400, buyOption: 'ME2U', productId: undefined };
      persistenceServiceSpy.get.and.returnValue('4622378109');
      customerServiceSpy.transferItem.and.callFake((para) => {
        expect(para).toEqual(params);
        return Observable.of('success');
      });
      spyOn(alertify, 'success');
      spyOn(component, 'transferQuota');
      spyOn(component, 'getMinMaxValuesFormTransfer');
      spyOn(component, 'resetModal');
      component.srcAccountType = 6;
      component.dstAccountType = 6;
      component.type = 'data';


      component.transferItem(123456, 100);

      expect(customerServiceSpy.transferItem).toHaveBeenCalled();
      expect(component.transferQuota).toHaveBeenCalledWith(102400);
      expect(component.getMinMaxValuesFormTransfer).toHaveBeenCalled();
      expect(component.resetModal).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalled();
    });

    it('call component.transferQuota, component.getMinMaxValuesFormTransfer, component.resetModal and alertify.success when customerServiceSpy.transferItem is successful. type = sms', () => {
      const params = { benmsisdn: 123456, dstAccountType: 6, msisdn: '4622378109', srcAccountType: 6, transfer: 150, buyOption: 'ME2U', productId: undefined };
      persistenceServiceSpy.get.and.returnValue('4622378109');
      customerServiceSpy.transferItem.and.callFake((para) => {
        expect(para).toEqual(params);
        return Observable.of('success');
      });
      spyOn(alertify, 'success');
      spyOn(component, 'transferQuota');
      spyOn(component, 'getMinMaxValuesFormTransfer');
      spyOn(component, 'resetModal');
      component.srcAccountType = 6;
      component.dstAccountType = 6;
      component.type = 'sms';


      component.transferItem(123456, 100);

      expect(customerServiceSpy.transferItem).toHaveBeenCalled();
      expect(component.transferQuota).toHaveBeenCalledWith(150);
      expect(component.getMinMaxValuesFormTransfer).toHaveBeenCalled();
      expect(component.resetModal).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalled();
    });

    it('call component.transferQuota, component.getMinMaxValuesFormTransfer, component.resetModal and alertify.success when customerServiceSpy.transferItem is successful. type = voice', () => {
      const params = { benmsisdn: 123456, dstAccountType: 6, msisdn: '4622378109', srcAccountType: 6, transfer: 6000, buyOption: 'ME2U', productId: undefined };
      persistenceServiceSpy.get.and.returnValue('4622378109');
      customerServiceSpy.transferItem.and.callFake((para) => {
        expect(para).toEqual(params);
        return Observable.of('success');
      });
      spyOn(alertify, 'success');
      spyOn(component, 'transferQuota');
      spyOn(component, 'getMinMaxValuesFormTransfer');
      spyOn(component, 'resetModal');
      component.srcAccountType = 6;
      component.dstAccountType = 6;
      component.type = 'voice';


      component.transferItem(123456, 100);

      expect(customerServiceSpy.transferItem).toHaveBeenCalled();
      expect(component.transferQuota).toHaveBeenCalledWith(6000);
      expect(component.getMinMaxValuesFormTransfer).toHaveBeenCalled();
      expect(component.resetModal).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalled();
    });

    it('call component.transferQuota, component.resetModal, alertify.error and not call component.getMinMaxValuesFormTransfer when customerServiceSpy.transferItem is unsuccessful', () => {
      persistenceServiceSpy.get.and.returnValue('4622378109');
      customerServiceSpy.transferItem.and.returnValue(Observable.throw({ 'error': { 'message': 'failed' } }));
      spyOn(alertify, 'error');
      spyOn(component, 'transferQuota');
      spyOn(component, 'getMinMaxValuesFormTransfer');
      spyOn(component, 'resetModal');
      component.srcAccountType = 6;
      component.dstAccountType = 6;
      component.type = 'data';

      const params = { benmsisdn: 123456, dstAccountType: 6, msisdn: '4622378109', srcAccountType: 6, transfer: 100 };

      component.transferItem(123456, 100);

      expect(customerServiceSpy.transferItem).toHaveBeenCalled();
      expect(component.transferQuota).toHaveBeenCalledWith(params.transfer * 1024);
      expect(component.getMinMaxValuesFormTransfer).not.toHaveBeenCalled();
      expect(component.resetModal).toHaveBeenCalled();
      expect(alertify.error).toHaveBeenCalled();
    });
  });

  describe('transferQuota method should', () => {
    it('event.removeData method when type = data', () => {
      component.type = 'data';

      component.transferQuota(10);

      expect(eventListenerServiceSpy.removeData).toHaveBeenCalledWith(10 * 1024 * 1024);
    });

    it('event.removeSms method when type = sms', () => {
      component.type = 'sms';

      component.transferQuota(10);

      expect(eventListenerServiceSpy.removeSms).toHaveBeenCalledWith(10);
    });

    it('event.removeMinutes method when type = voice', () => {
      component.type = 'voice';

      component.transferQuota(10);

      expect(eventListenerServiceSpy.removeMinutes).toHaveBeenCalledWith(10);
    });
  });

  describe('onChange method', () => {
    it('should set transfer and bar', () => {
      component.onChange(10);

      expect(component.transfer).toBe(10 as any);
      expect(component.bar).toBe(10);
    });

    it('not should set transfer and bar', () => {
      component.onChange(null);

      expect(component.transfer).toBe('');
      expect(component.bar).toBe(0);
    });
  });

  it('resetModal method should reset msisdn, bar and transfer', () => {
    component.resetModal();

    expect(component.msisdn).toBe('');
    expect(component.bar).toBe(0);
    expect(component.transfer).toBe('');
  });

});
