import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, Input } from '@angular/core'
import { PersistenceService } from 'angular-persistence';
import { UtcComponent } from './utc.component';


class MockCommonUsagetrafficComponent {
  @Input() type;
}
describe('UtcComponent', () => {
  let component: UtcComponent;
  let fixture: ComponentFixture<UtcComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;

  beforeEach(async(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set']);

    TestBed.configureTestingModule({
      declarations: [
        UtcComponent,
        MockCommonUsagetrafficComponent
      ],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UtcComponent);
    persistenceServiceSpy = TestBed.get(PersistenceService);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
