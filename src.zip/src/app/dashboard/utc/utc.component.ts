import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY, Configuration, ConsumptionDataCallbacks } from 'dxp-common';
import { Subscription } from 'rxjs';
import { EventListenerService } from '../../../app/event-listener.service';
import { CustomerSearchDataService } from '../../services/customer-search-data.service';
import { CustomerSearchService } from '../../services/customer-search.service';

@Component({
    selector: 'app-utc',
    templateUrl: './utc.component.html',
    styleUrls: ['./utc.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class UtcComponent implements OnInit {
    activeTab = 0;

    subscribedContract: any;

    changeMsisdnEventSubscription: Subscription;

    // this default configuration for consumption
    consumptionConfiguration: Configuration = {
        constants: {
            lastRecharge: 'last_recharge',
            currentCycle: 'current_cycle',
            custom: 'custom',
            mainBalance: 'mainBalance'
        },
        daysRange: [
            { value: 1, label: 'Yesterday' },
            { value: 3, label: 'Last 3 days' },
            { value: 7, label: 'Last 7 days' },
            { value: 'last_recharge', label: 'Since Last Recharge' },
            { value: 'current_cycle', label: 'Current recurrence Cycle' },
            { value: 'custom', label: 'Select Period' },
        ],
        products: [
            { value: 'mainBalance', label: 'Credit Balance' }
        ],
        csvFileName: 'consumption.csv',
        dateFormat: 'YYYY-MM-DD',
        dateTimeFormat: 'YYYY-MM-DD hh:mm:ss',
        pagination: {
            maxPaginationSize: 5,
            pageSize: 20
        },
        maxDateRange: 182
    };

    public consumptionDataCallBacks: ConsumptionDataCallbacks = {
        fetchRecords: (values) => {
            return this.customerSearchDataService.getConsumption(values);
        },
        fetchLastRechargeDate: (msisdn) => {
            return this.customerSearchDataService.getLastRechargeFromMsisdn(msisdn);
        }
    }

    constructor(private persistenceService: PersistenceService,
        private customerSearchService: CustomerSearchService,
        private customerSearchDataService: CustomerSearchDataService,
        private eventListenerService: EventListenerService,
        private translateService: TranslateService
    ) {

    }

    // This function will override the default value from cmui configuration
    private populateConsumptionConfiguration() {
        this.consumptionConfiguration.constants = this.persistenceService.get(CMUICONFIGKEY.CONSUMPTION_CONSTANTS, StorageType.SESSION);
        this.consumptionConfiguration.daysRange = this.persistenceService.get(CMUICONFIGKEY.CONSUMPTION_DAYS_RANGE, StorageType.SESSION)
            .map(item => {
                return { value: item.daysValue, label: this.translateService.instant(item.daysName) };
            });
        this.consumptionConfiguration.products = this.persistenceService.get(CMUICONFIGKEY.CONSUMPTION_STATIC_PRODUCTS, StorageType.SESSION)
            .map(item => {
                return { value: item.value, label: this.translateService.instant(item.label) };
            });
        this.consumptionConfiguration.csvFileName = this.persistenceService.get(CMUICONFIGKEY.CONSUMPTION_CSV_FILE_NAME, StorageType.SESSION);
        this.consumptionConfiguration.dateFormat = this.persistenceService.get(CMUICONFIGKEY.DATEFORMAT, StorageType.SESSION);
        this.consumptionConfiguration.dateTimeFormat = this.persistenceService.get(CMUICONFIGKEY.DATE_TIME_FORMAT, StorageType.SESSION);
        this.consumptionConfiguration.pagination = this.persistenceService.get(CMUICONFIGKEY.PAGINATION, StorageType.SESSION);
        this.consumptionConfiguration.maxDateRange = this.persistenceService.get(CMUICONFIGKEY.MAX_DATE_RANGE, StorageType.SESSION);
    }


    ngOnInit() {
        this.populateConsumptionConfiguration();
        this.changeMsisdnEventSubscription = this.eventListenerService.msisdnChangeEvent.subscribe((event) => {
            this.getCustomerContract(event.msisdn);
        });
        this.eventListenerService.fetchPendingJourney();
    }

    private getCustomerContract(msisdn: string) {
        const currentContract = this.customerSearchService.getCurrentContract();
        this.subscribedContract = currentContract.contract;
    }

}
