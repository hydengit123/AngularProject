import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-success-message',
  templateUrl: './success-message.component.html',
  styleUrls: ['./success-message.component.scss']
})
export class SuccessMessageComponent implements OnInit {

  public id:string;
  public showId:boolean;
  public showFooterAction:boolean;
  public message:string;
  public orderLabel:string;

  constructor(private translate:TranslateService) { }

  ngOnInit() {
    this.orderLabel = this.translate.instant("yourOrderIdIs",{id:this.id});
  }

}
