import { Component, Input, Pipe, PipeTransform } from '@angular/core';
import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { PersistenceService } from 'angular-persistence';
import { SubscriptionProduct } from '../../interface/subscription';
import { CustomerGroupService } from '../../services/customer-group.service';
import { CustomerService } from '../../services/customer.service';
import { ProductService } from '../../services/product.service';
import { CommonUsagetrafficComponent } from './common-usagetraffic.component';
import { TranslateService } from '@ngx-translate/core';
import Product = SubscriptionProduct.Product;

@Component({
  selector: 'canvas',
  template: '',
  providers: []
})
class MockCanvasComponent {
  @Input() datasets = [];
  @Input() labels = ['Jan', 'Feb', 'Mar', 'Apr', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  @Input() options = undefined;
  @Input() legend = true;
  @Input() chartType = 'bar'
  @Input() colors = [];
}

@Pipe({ name: 'valueFormatter' })
class MockValueFormatterPipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}

@Pipe({ name: 'dateDiff' })
class MockDateDiffPipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}

describe('CommonUsagetrafficComponent', () => {
  let component: CommonUsagetrafficComponent;
  let fixture: ComponentFixture<CommonUsagetrafficComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let productServiceSpy: jasmine.SpyObj<ProductService>;
  let customerServiceSpy: jasmine.SpyObj<CustomerService>;
  let customerGroupServiceSpy: jasmine.SpyObj<CustomerGroupService>;
  let translateServiceSpy: any;

  beforeEach(async(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get']);
    const ProductServiceSpy = jasmine.createSpyObj('ProductService', ['getRechargeOptions']);
    const CustomerServiceSpy = jasmine.createSpyObj('CustomerService', ['transferItem', 'getRechargeHistory', 'getTransferHistory', 'subscriptionDetail']);
    const CustomerGroupServiceSpy = jasmine.createSpyObj('CustomerGroupService', ['getSharedAccount', 'removeSharedAccount']);
    translateServiceSpy = {
      instant: () => { },
    }

    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        ReactiveFormsModule
      ],
      declarations: [
        CommonUsagetrafficComponent,
        MockCanvasComponent,
        MockValueFormatterPipe,
        MockDateDiffPipe
      ],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy },
        FormBuilder
      ]
    }).overrideComponent(CommonUsagetrafficComponent, {
      set: {
        providers: [
          { provide: ProductService, useValue: ProductServiceSpy },
          { provide: CustomerService, useValue: CustomerServiceSpy },
          { provide: TranslateService, useValue: translateServiceSpy },
          { provide: CustomerGroupService, useValue: CustomerGroupServiceSpy }
        ]
      }
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonUsagetrafficComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
    productServiceSpy = fixture.debugElement.injector.get(ProductService) as any;
    customerServiceSpy = fixture.debugElement.injector.get(CustomerService) as any;
    customerGroupServiceSpy = fixture.debugElement.injector.get(CustomerGroupService) as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    expect(component.colors.length).toBe(11);
  });

  describe('ngOnInit method should', () => {
    it('set currentTitle = "Data Usage". Should call getTransferHistory, getShared, getAdded, generateData and getCurrentPlan. Should not call getRechargeHistory when type = 0 ', () => {
      persistenceServiceSpy.get.and.returnValue('4622378109');
      component.type = 0;
      spyOn(component, 'getTransferHistory');
      spyOn(component, 'getShared');
      spyOn(component, 'getAdded');
      spyOn(component, 'generateData');
      spyOn(component, 'getCurrentPlan');
      spyOn(component, 'getRechargeHistory');

      component.ngOnInit();

      expect(component.currentTitle).toBe('Data Usage');
      expect(component.getTransferHistory).toHaveBeenCalled();
      expect(component.getShared).toHaveBeenCalled();
      expect(component.getAdded).toHaveBeenCalled();
      expect(component.generateData).toHaveBeenCalled();
      expect(component.getCurrentPlan).toHaveBeenCalled();
      expect(component.getRechargeHistory).not.toHaveBeenCalled();
    });

    it('set currentTitle = "Credit History". Should call getTransferHistory, getRechargeHistory, generateData and getCurrentPlan. Should not call getShared, getAdded when type = 3 ', () => {
      persistenceServiceSpy.get.and.returnValue('4622378109');
      component.type = 3;
      spyOn(component, 'getTransferHistory');
      spyOn(component, 'getShared');
      spyOn(component, 'getAdded');
      spyOn(component, 'generateData');
      spyOn(component, 'getCurrentPlan');
      spyOn(component, 'getRechargeHistory');

      component.ngOnInit();

      expect(component.currentTitle).toBe('Credit History');
      expect(component.getTransferHistory).toHaveBeenCalled();
      expect(component.getRechargeHistory).toHaveBeenCalled();
      expect(component.getShared).not.toHaveBeenCalled();
      expect(component.getAdded).not.toHaveBeenCalled();
      expect(component.generateData).toHaveBeenCalled();
      expect(component.getCurrentPlan).toHaveBeenCalled();
    });
  });

  it('generateData method should set component.barChartData', () => {
    expect(component.barChartData.length).toBe(0);

    component.generateData();

    expect(component.barChartData.length).toBe(1);
    expect(component.barChartData[0].data.length).toBe(11);
  });

  describe('getRechargeHistory method should', () => {
    it('change balanceTxnDate to "YYYY-MM-DD h:mm:ss" 24 hour format and should sort credit items to show recent items first', fakeAsync(() => {
      persistenceServiceSpy.get.and.returnValue('4622378109');
      const creditHistory = [{
        "msisdn": '4622378109',
        "balanceTxnDate": '06-02-2019 14:20:10.738',
        "balanceTxnType": 'add',
        "quota": {
          "credit": 1000
        }
      }, {
        "msisdn": '4622378109',
        "balanceTxnDate": '06-02-2019 14:20:18.874',
        "balanceTxnType": 'add',
        "quota": {
          "credit": 5000
        }
      }
      ];

      customerServiceSpy.getRechargeHistory.and.returnValue(Promise.resolve(creditHistory));

      component.getRechargeHistory();

      tick();

      expect(component.added[0].balanceTxnDate).toBe('06-02-2019 2:20:18');
      expect(component.added[1].balanceTxnDate).toBe('06-02-2019 2:20:10');

    }));

    it('catch error and component.added.length should be zero when promise is rejected from customerServiceSpy.getRechargeHistory', fakeAsync(() => {
      persistenceServiceSpy.get.and.returnValue('4622378109');
      customerServiceSpy.getRechargeHistory.and.returnValue(Promise.reject(new Error('err')));

      component.getRechargeHistory();

      tick();

      expect(component.added.length).toBe(0);

    }));
  });

  describe('getTransferHistory method should', () => {
    it('should sort items in descending order on the basis of transferDate and filter on the basis of type', fakeAsync(() => {
      const transferHistoryData = [{
        "msisdn": '4622378109',
        "benmsisdn": '9824222202',
        "transferDate": '06-02-2019 09:19:42',
        "transferQuota": {
          "data": '9902'
        },
        "expiryDate": '01-03-2019 09:00:42'
      }, {
        "msisdn": '4622378109',
        "benmsisdn": '9824222202',
        "transferDate": '06-02-2019 09:19:52',
        "transferQuota": {
          "voice": '1198'
        },
        "expiryDate": '01-03-2019 09:00:42'
      }, {
        "msisdn": '4622378109',
        "benmsisdn": '9824222202',
        "transferDate": '06-02-2019 09:20:00',
        "transferQuota": {
          "sms": '38'
        },
        "expiryDate": '01-03-2019 09:00:42'
      },
      {
        "msisdn": '4622378109',
        "benmsisdn": '9824222202',
        "transferDate": '06-02-2019 09:19:59',
        "transferQuota": {
          "data": '9902'
        },
        "expiryDate": '01-03-2019 09:00:42'
      }
      ];
      persistenceServiceSpy.get.and.returnValue('4622378109');
      component.type = 0;
      customerServiceSpy.getTransferHistory.and.returnValue(Promise.resolve(transferHistoryData));

      component.getTransferHistory();
      tick();

      expect(component.transfer.length).toBe(2);
      expect(component.transfer[1].transferDate).toBe('06-02-2019 9:19:42')
      expect(component.transfer[1].transferQuota).toEqual({ data: '9902' });
      expect(component.transfer[0].transferQuota).toEqual({ data: '9902' });
    }));

    it('should catch error when promise is rejected', fakeAsync(() => {
      persistenceServiceSpy.get.and.returnValue('4622378109');
      component.type = 0;
      customerServiceSpy.getTransferHistory.and.returnValue(Promise.reject(new Error('err')));

      component.getTransferHistory();
      tick();

      expect(component.transfer.length).toBe(0);

    }));
  });

  describe('getAdded method should', () => {
    it('filter product which are of type component.productType and show them in descending order on hte basis of expiryDate', fakeAsync(() => {
      const data = {
        "msisdn": '4622378109',
        "products": [{
          "productId": 'CM_Combo_556',
          "productName": '50GB and Unlimited SMS and Voice Combo',
          "productType": 'Combo',
          "productGroup": 'Premium',
          "price": 2500,
          "paymentMode": 'AIR',
          "srcChannel": 'SELFCARE',
          "numberOfPendingRenewals": 9998,
          "nextRenewalDate": '01-03-2019 14:30:42',
          "provisionedQuota": { "voice": { "unit": -1, "unitType": '0' }, "sms": { "unit": -1, "unitType": '1' }, "data": { "unit": 53687091200, "unitType": '6' } },
          "availableQuota": { "voice": { "unit": -1, "unitType": '0' }, "sms": { "unit": -1, "unitType": '1' }, "data": { "unit": 150678274048, "unitType": '6' } },
          "activationDate": '30-01-2019 14:30:00',
          "expiryDate": '01-03-2019 14:30:42', "isRecurring": true
        },
        {
          "productId": 'CM_Combo_574',
          "productName": 'Roaming data 10gb 1000mins 1000sms',
          "productType": 'Combo',
          "productGroup": 'Addon',
          "price": 2500,
          "paymentMode": 'AIR',
          "srcChannel": 'SELFCARE',
          "numberOfPendingRenewals": 0,
          "nextRenewalDate": '01-03-2019 14:30:00',
          "provisionedQuota": { "voice": { "unit": 60000, "unitType": '0' }, "sms": { "unit": 1000, "unitType": '1' }, "data": { "unit": 10737418240, "unitType": "6" } },
          "availableQuota": { "voice": { "unit": 60000, "unitType": '0' }, "sms": { "unit": 1000, "unitType": '1' }, "data": { "unit": 10737418240, "unitType": "6" } },
          "activationDate": '30-01-2019 14:30:43',
          "expiryDate": '01-03-2019 14:30:00',
          "isRecurring": false
        },
        { "productId": 'CM_Voice_597', "productName": "100 Mins Voice Recharge", "productType": "Voice", "productGroup": "Recharge", "price": 800, "paymentMode": "AIR", "srcChannel": "SELFCARE", "numberOfPendingRenewals": 0, "nextRenewalDate": "08-03-2019 15:29:00", "provisionedQuota": { "voice": { "unit": 6000, "unitType": "0" }, "sms": { "unit": 0, "unitType": "1" }, "data": { "unit": 0, "unitType": "6" } }, "availableQuota": { "voice": { "unit": 100004801, "unitType": "0" } }, "activationDate": "06-02-2019 15:29:09", "expiryDate": "08-03-2019 15:29:00", "isRecurring": false }]
      }

      persistenceServiceSpy.get.and.returnValue('4622378109');
      component.type = 1;
      customerServiceSpy.subscriptionDetail.and.returnValue(Promise.resolve(data));

      component.getAdded();
      tick();

      expect(component.added.length).toBe(1);
      expect(component.added[0].productType).toEqual('Voice');
    }));

    it('catch error from customerServiceSpy.subscriptionDetail and component.added.length should be 0', fakeAsync(() => {
      persistenceServiceSpy.get.and.returnValue('4622378109');
      component.type = 1;
      customerServiceSpy.subscriptionDetail.and.returnValue(Promise.reject(new Error('error')));

      component.getAdded();
      tick();

      expect(component.added.length).toBe(0);
    }));
  });

  describe('getShared method should', () => {
    it('set component.shared by filtering data from customerGroupServiceSpy.getSharedAccount according to component.type. should sort in the basis of expiryDate and change expiryDate to YYYY-MM-DD h:mm:ss format', fakeAsync(() => {
      const data = [
        { "msisdn": "9824222202", "sharedQuota": { "data": 6144 }, "addedDate": "2019-02-06 15:52:38.163", "expiryDate": "2019-02-10 15:52:38.163" }, { "msisdn": "9824222202", "sharedQuota": { "voice": 6144 }, "addedDate": "2019-02-04 14:22:21.111", "expiryDate": "2019-02-11 15:52:38.163" },
        { "msisdn": "9824222202", "sharedQuota": { "data": 6144 }, "addedDate": "2019-02-05 14:11:11.111" }
      ];
      customerGroupServiceSpy.getSharedAccount.and.returnValue(Promise.resolve(data));
      persistenceServiceSpy.get.and.returnValue('4622378109');
      component.type = 0;

      component.getShared();
      tick();

      expect(component.shared.length).toBe(2);
      expect(component.shared[0].addedDate).toBe('2019-02-06 15:52:38.163');
      expect(component.shared[1].addedDate).toBe('2019-02-05 14:11:11.111');
      expect(component.shared[0].expiryDate).toBe('06-02-2019 3:52:38');
      expect(component.shared[1].expiryDate).toBe('05-02-2019 2:11:11');
    }));

    it('catch error from customerGroupServiceSpy.getSharedAccount', fakeAsync(() => {
      customerGroupServiceSpy.getSharedAccount.and.returnValue(Promise.reject(new Error('error')));
      persistenceServiceSpy.get.and.returnValue('4622378109');
      component.type = 0;

      component.getShared();
      tick();

      expect(component.shared.length).toBe(0);
    }));
  });

  describe('getTypesString method should', () => {
    it('return "data" when type is 0', () => {
      expect(component.getTypesString(0)).toBe('data');
    });

    it('return "voice" when type is 1', () => {
      expect(component.getTypesString(1)).toBe('voice');
    });

    it('return "sms" when type is 2', () => {
      expect(component.getTypesString(2)).toBe('sms');
    });

    it('return "credit" when type is 2', () => {
      expect(component.getTypesString(3)).toBe('credit');
    });
  });

  it('chartClicked method should log', () => {
    spyOn(console, 'log');

    component.chartClicked('event');

    expect(console.log).toHaveBeenCalledWith('event');
  });

  it('chartHovered method should log', () => {
    spyOn(console, 'log');

    component.chartHovered('event');

    expect(console.log).toHaveBeenCalledWith('event');
  });
});
