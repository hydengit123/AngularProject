import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { PersistenceService } from 'angular-persistence';
import { EventListenerService } from '../../event-listener.service';
import { CustomerService } from '../../services/customer.service';
import { ProductService } from '../../services/product.service';
import { CommonAddModalComponent } from './common-add-modal.component';
import { Pipe, PipeTransform, Component } from '@angular/core';
import { Observable } from 'rxjs';
import { mockaddDataAddOnSet, mockDataSMSAddOn, mockDataVoiceAddOn } from '../../mockData';
import { TranslateService } from '@ngx-translate/core';

declare var jQuery: any;
declare const alertify;

const mockProducts = [{
  'productId': 'CM_Combo_574',
  'productName': 'Roaming data 10gb 1000mins 1000sms',
  'productType': 'Combo',
  'productGroup': 'Addon',
  'price': 2500,
  'paymentMode': 'AIR',
  'srcChannel': 'SELFCARE',
  'numberOfPendingRenewals': 0,
  'nextRenewalDate': '01-03-2019 14:30:00',
  'provisionedQuota': {
    'voice': {
      'unit': 60000,
      'unitType': '0'
    },
    'sms': {
      'unit': 1000,
      'unitType': '1'
    },
    'data': {
      'unit': 10737418240,
      'unitType': '6'
    }
  },
  'availableQuota': {
    'voice': {
      'unit': 60000,
      'unitType': '0'
    },
    'sms': {
      'unit': 1000,
      'unitType': '1'
    },
    'data': {
      'unit': 10737418240,
      'unitType': '6'
    }
  },
  'activationDate': '30-01-2019 14:30:43',
  'expiryDate': '01-03-2019 14:30:00',
  'isRecurring': false
}];

@Pipe({ name: 'valueFormatter' })
class MockValueFormatterPipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}

@Component({ selector: 'app-payment-form', template: '' })
class MockPaymentFormComponent { }

describe('CommonAddModalComponent', () => {
  let component: CommonAddModalComponent;
  let fixture: ComponentFixture<CommonAddModalComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let productServiceSpy: jasmine.SpyObj<ProductService>;
  let customerServiceSpy: jasmine.SpyObj<CustomerService>;
  let eventListenerServiceSpy: jasmine.SpyObj<EventListenerService>;
  let translateServiceSpy: any;

  beforeEach(async(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set']);
    const ProductServiceSpy = jasmine.createSpyObj('ProductService', ['getRechargeOptions']);
    const CustomerServiceSpy = jasmine.createSpyObj('CustomerService', ['addQuota']);
    const EventListenerServiceSpy = jasmine.createSpyObj('EventListenerService', ['addData', 'addMinutes', 'addSMS']);
    translateServiceSpy = {
      instant: () => { },
    }

    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        ReactiveFormsModule
      ],
      declarations: [
        CommonAddModalComponent,
        MockValueFormatterPipe,
        MockPaymentFormComponent
      ],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy },
        { provide: EventListenerService, useValue: EventListenerServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        FormBuilder
      ]
    }).overrideComponent(CommonAddModalComponent, {
      set: {
        providers: [
          { provide: ProductService, useValue: ProductServiceSpy },
          { provide: CustomerService, useValue: CustomerServiceSpy }
        ]
      }
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonAddModalComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
    eventListenerServiceSpy = TestBed.get(EventListenerService);
    productServiceSpy = fixture.debugElement.injector.get(ProductService) as any;
    customerServiceSpy = fixture.debugElement.injector.get(CustomerService) as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call component.getDataAddOns with type provided type as DATA and set title to "Add Data"', () => {
    persistenceServiceSpy.get.and.returnValue('4622378109');
    spyOn(component, 'getDataAddOns');
    component.type = 'data';

    component.ngOnChanges(undefined);

    expect(component.getDataAddOns).toHaveBeenCalledWith('DATA');
    expect(component.title).toBe('Add Data');
  });

  it('should call component.getDataAddOns with type provided type as SMS and set title to "Add SMS"', () => {
    persistenceServiceSpy.get.and.returnValue('4622378109');
    spyOn(component, 'getDataAddOns');
    component.type = 'sms';

    component.ngOnChanges(undefined);

    expect(component.getDataAddOns).toHaveBeenCalledWith('SMS');
    expect(component.title).toBe('Add SMS');
    expect(component.activeDataSet).toBe(0);
    expect(component.isNext).toBeFalsy();
    expect(component.addOnsDataSets).toEqual([]);
  });

  it('should call component.getDataAddOns with type as VOICE and set title to "Add Minutes"', () => {
    persistenceServiceSpy.get.and.returnValue('4622378109');
    spyOn(component, 'getDataAddOns');
    component.type = 'voice';

    component.ngOnChanges(undefined);

    expect(component.getDataAddOns).toHaveBeenCalledWith('VOICE');
    expect(component.title).toBe('Add Minutes');
    expect(component.activeDataSet).toBe(0);
    expect(component.isNext).toBeFalsy();
    expect(component.addOnsDataSets).toEqual([]);
  });

  // Unable to fire event
  xit('ngAfterViewInit should listen to event for addData and set isNext to false', fakeAsync(() => {
    component.isNext = true;
    component.addOnsDataSets = JSON.parse(JSON.stringify(mockProducts));
    component.ngAfterViewInit();
    jQuery('#addData').trigger('hidden.bs.modal');
    tick();
    expect(component.isNext).toBeFalsy();
  }));

  describe('getDataAddOns method', () => {
    it('should set addOnsDataSets value to the data returned from productServiceSpy.getRechargeOptions', () => {
      productServiceSpy.getRechargeOptions.and.returnValue(Observable.of(JSON.parse(JSON.stringify(mockProducts))));

      component.getDataAddOns('DATA');

      expect(component.addOnsDataSets.length).toBe(1);
    });

    it('should set addOnsDataSets value to mockData when no data is returned from productServiceSpy.getRechargeOptions and type is "data"', () => {
      productServiceSpy.getRechargeOptions.and.returnValue(Observable.of([]));
      component.type = 'data';

      component.getDataAddOns('DATA');

      expect(component.addOnsDataSets.length).toBe(mockaddDataAddOnSet.length);
    });

    it('should set addOnsDataSets value to mockData when no data is returned from productServiceSpy.getRechargeOptions and type is "sms"', () => {
      productServiceSpy.getRechargeOptions.and.returnValue(Observable.of([]));
      component.type = 'sms';

      component.getDataAddOns('SMS');

      expect(component.addOnsDataSets.length).toBe(mockDataSMSAddOn.length);
    });

    it('should set addOnsDataSets value to mockData when no data is returned from productServiceSpy.getRechargeOptions and type is "voice"', () => {
      productServiceSpy.getRechargeOptions.and.returnValue(Observable.of([]));
      component.type = 'voice';

      component.getDataAddOns('VOICE');

      expect(component.addOnsDataSets.length).toBe(mockDataVoiceAddOn.length);
    });

    it('should call productServiceSpy.getRechargeOptions and catch error thrown', () => {
      productServiceSpy.getRechargeOptions.and.returnValue(Observable.throw(Observable.throw(new Error('Error'))));
      spyOn(console, 'log');

      component.getDataAddOns('DATA');

      expect(console.log).toHaveBeenCalled();
    });
  });

  describe('setActive method', () => {
    it('should set activeDataSetData equal to unit from addOnsDataSets "data" units of product at index i', () => {
      const index = 0;
      component.addOnsDataSets = JSON.parse(JSON.stringify(mockaddDataAddOnSet));
      component.type = 'data';
      const beforeCall: boolean = component.addOnsDataSets[index].isSelected;

      component.setActive(0);

      const afterCall: boolean = component.addOnsDataSets[index].isSelected;

      expect(beforeCall).toEqual(!afterCall);
      expect(component.activeDataSetData).toEqual(mockaddDataAddOnSet[index].quota.data.unit);
      expect(component.activeDataSet).toEqual(mockaddDataAddOnSet[index].price);
    });

    it('should set activeDataSetData equal to unit from addOnsDataSets "voice" units of product at index i', () => {
      component.addOnsDataSets = JSON.parse(JSON.stringify(mockDataVoiceAddOn));
      component.type = 'voice';

      component.setActive(0);

      expect(component.activeDataSetData).toEqual(mockDataVoiceAddOn[0].quota.voice.unit);
    });

    it('should set activeDataSetData equal to unit from addOnsDataSets "sms" units of product at index i', () => {
      component.addOnsDataSets = JSON.parse(JSON.stringify(mockDataSMSAddOn));
      component.type = 'sms';

      component.setActive(0);

      expect(component.activeDataSetData).toEqual(mockDataSMSAddOn[0].quota.sms.unit);
    });
  });

  describe('addData method', () => {
    it('should call eventListenerServiceSpy.addData when type component.type is data', () => {
      component.addOnsDataSets = JSON.parse(JSON.stringify(mockaddDataAddOnSet));
      component.addOnsDataSets[0].isSelected = true;
      component.type = 'data';
      component.msisdn = '4622378109';
      customerServiceSpy.addQuota.and.returnValue(Observable.of('Response'));
      spyOn(alertify, 'success');

      component.addData();

      expect(eventListenerServiceSpy.addData).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalled();
    });

    it('should call eventListenerServiceSpy.addMinutes when type component.type is voice', () => {
      component.addOnsDataSets = JSON.parse(JSON.stringify(mockaddDataAddOnSet));
      component.addOnsDataSets[0].isSelected = true;
      component.type = 'voice';
      component.msisdn = '4622378109';
      customerServiceSpy.addQuota.and.returnValue(Observable.of('Response'));
      spyOn(alertify, 'success');

      component.addData();

      expect(eventListenerServiceSpy.addMinutes).toHaveBeenCalled();
    });

    it('should call eventListenerServiceSpy.addMinutes when type component.type is sms', () => {
      component.addOnsDataSets = JSON.parse(JSON.stringify(mockaddDataAddOnSet));
      component.addOnsDataSets[0].isSelected = true;
      component.type = 'sms';
      component.msisdn = '4622378109';
      customerServiceSpy.addQuota.and.returnValue(Observable.of('Response'));
      spyOn(alertify, 'success');

      component.addData();

      expect(eventListenerServiceSpy.addSMS).toHaveBeenCalled();
    });

    it('should catch error when thrown from customerServiceSpy.addQuota', () => {
      component.addOnsDataSets = JSON.parse(JSON.stringify(mockaddDataAddOnSet));
      component.addOnsDataSets[0].isSelected = true;
      component.type = 'sms';
      component.msisdn = '4622378109';
      customerServiceSpy.addQuota.and.returnValue(Observable.throw(new Error('Error')));
      spyOn(alertify, 'error');

      component.addData();

      expect(alertify.error).toHaveBeenCalled();
    });
  });
});
