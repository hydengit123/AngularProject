export interface IDashboardProfileUpdate {
    refreshDashBoardView: () => void;
}