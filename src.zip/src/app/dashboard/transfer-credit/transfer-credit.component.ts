import { getCurrencySymbol } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { PERSISTANCEKEY } from '../../../application-constants';
import { quickRechargeFormValidator } from '../../cis/QuickRechargeValidate';
import { EventEnum } from '../../enum/EventEnum';
import { EventListenerService } from '../../event-listener.service';
import { TransferCreditPayload } from './../../interface/transfer-credit-payload';
import { CustomerService } from './../../services/customer.service';
import { CMUICONFIGKEY } from 'dxp-common';

declare const alertify;

@Component({
  selector: 'app-transfer-credit',
  templateUrl: './transfer-credit.component.html',
  styleUrls: ['./transfer-credit.component.scss']
})
export class TransferCreditComponent implements OnInit {

  range: any = 0;
  public sliderValue: any = 0;
  public sliderInputValue: any = 0;
  public phoneNumberLength: any;
  public phoneNumberMaxLength: any;
  public transferCreditForm: FormGroup;
  public requestPayload: TransferCreditPayload;
  public itemDetails: any;
  private sliderMaxValue: any;
  public successMsgShow: Boolean = false;
  private orderId: String = '';
  public currencyVal: String;
  public currencySymbol: String;
  public successMessage: String = '';
  public amount = 0;

  constructor(public persistenceService: PersistenceService, private customerService: CustomerService,
    private eventListenerService: EventListenerService,
    private translateService: TranslateService) {
  }

  ngOnInit() {
    this.phoneNumberLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION);
    this.phoneNumberMaxLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION);
    this.currencyVal = this.persistenceService.get(CMUICONFIGKEY.DEFAULTYCURRENCY, StorageType.SESSION);
    const loggedInMsisdn = this.persistenceService.get(PERSISTANCEKEY.REGISTEREMAILMSISDN, StorageType.SESSION);
    const transferLimit = this.persistenceService.get(CMUICONFIGKEY.MONETARY_TRANSFER_LIMIT, StorageType.SESSION);
    if (parseFloat(this.itemDetails.mainBalance) > parseFloat(transferLimit)) {
      this.sliderMaxValue = transferLimit;
    } else {
      this.sliderMaxValue = this.itemDetails.mainBalance;
    }
    this.currencySymbol = getCurrencySymbol(this.itemDetails.currency, 'narrow');
    this.transferCreditForm = new FormGroup({
      phoneNumber: new FormControl(),
      amount: new FormControl(),
    },
      [quickRechargeFormValidator(this.persistenceService, this.sliderMaxValue, loggedInMsisdn)]
    );
    this.transferCreditForm.controls.amount.valueChanges.subscribe(data => {
      if (data === '') {
        this.amount = 0;
        this.sliderValue = '0';
      } else {
        this.sliderValue = data;
      }
    });
  }

  changeSlider(value: number) {
    this.sliderValue = value;
    this.transferCreditForm.controls.amount.setValue(this.sliderValue);
  }

  doTransfer() {
    this.customerService.customerSearchProfile(this.transferCreditForm.value).subscribe((data) => {
      this.requestPayload.coreData.beneficiaryMsisdn = this.transferCreditForm.controls.phoneNumber.value.toString();
      this.requestPayload.coreData.transferQuantity = this.transferCreditForm.controls.amount.value.toString();
      this.requestPayload.coreData.summaryTextLabel = 'AccountTransferDonorSummary';
      this.customerService.customerInteractionForRecharge(this.requestPayload).subscribe(data => {
        if (data && data.statusReason) {
          this.orderId = data.id;
          this.successMessage = this.translateService.instant(data.statusReason.code);
          this.successMsgShow = true;
          this.eventListenerService.dashboardEvent.emit({ eventType: EventEnum.dashboardRefresh });
        }
      });
    },
    error => {
      alertify.error(this.translateService.instant('Customer profile is not available for this phone number'));
    });
  }

  disableCheck() {
    if (!this.transferCreditForm.controls.phoneNumber.value || !this.transferCreditForm.controls.amount.value || this.transferCreditForm.invalid || this.transferCreditForm.controls.amount.value == 0) {
      return true;
    } else {
      return false;
    }
  }

  makeNewTransfer() {
    const newValue: Number = this.sliderMaxValue - this.sliderValue;
    this.sliderMaxValue = newValue;
    this.transferCreditForm.reset();
    this.sliderValue = 0;
    this.amount = 0;
    this.successMsgShow = false;
  }

  changeInputSlider(value: number) {
    this.sliderInputValue = value;
  }


}
