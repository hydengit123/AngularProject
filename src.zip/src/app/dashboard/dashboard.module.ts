import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { DxpCommonModule, DxpPipeModule, ShareConsumerModule } from 'dxp-common';
import { MDBBootstrapModulesPro } from 'ng-uikit-pro-standard';
import { ChartsModule } from 'ng2-charts';
import { NouisliderModule } from 'ng2-nouislider';
import { AuthInterceptorService } from '../auth-interceptor.service';
import { CommonNavigationFormModule } from '../custom-component/common-navigation-form.module';
import { CustomPipeModule } from '../custom-pipe/custom-pipe.module';
import { CanActivateDashboardHomeRouteGuard } from '../guards/CanActivateDashboardHomeRouteGuard';
import { SharedModuleModule } from '../shared-module/shared-module.module';
import { AddSubscriptionComponent } from './add-subscription/add-subscription.component';
import { CommonAddModalComponent } from './common-add-modal/common-add-modal.component';
import { CommonShareModalComponent } from './common-share-modal/common-share-modal.component';
import { CommonTransferModalComponent } from './common-transfer-modal/common-transfer-modal.component';
import { CommonUsagetrafficComponent } from './common-usagetraffic/common-usagetraffic.component';
import { ContinueJourneyComponent } from './continue-journey/continue-journey.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { DfyComponent } from './dfy/dfy.component';
import { HistoryComponent } from './history/history.component';
import { DxpProductBundleComponent } from './home/dxp-product-bundle/dxp-product-bundle.component';
import { HomeComponent } from './home/home.component';
import { ManageAddonComponent } from './manage-addon/manage-addon.component';
import { PlanComponent } from './plan/plan.component';
import { PopupModalComponent } from './popup-modal/popup-modal.component';
import { RoamingComponent } from './roaming/roaming.component';
import { SuccessMessageComponent } from './success-message/success-message.component';
import { SupportComponent } from './support/support.component';
import { TopProfileComponent } from './top-profile/top-profile.component';
import { TransferBucketComponent } from './transfer-bucket/transfer-bucket.component';
import { TransferCreditComponent } from './transfer-credit/transfer-credit.component';
import { UtcComponent } from './utc/utc.component';
import { WalletComponent } from './wallet/wallet.component';



@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MDBBootstrapModulesPro,
    CustomPipeModule,
    DxpPipeModule,
    NouisliderModule,
    ChartsModule,
    SharedModuleModule,
    TranslateModule,
    CommonNavigationFormModule,
    NgbModule,
    DxpCommonModule,
    ShareConsumerModule
  ],
  declarations: [
    ContinueJourneyComponent,
    DashboardComponent,
    HomeComponent,
    PlanComponent,
    DfyComponent,
    UtcComponent,
    CustomerProfileComponent,
    SupportComponent,
    CommonAddModalComponent,
    CommonShareModalComponent,
    CommonTransferModalComponent,
    WalletComponent,
    RoamingComponent,
    CommonUsagetrafficComponent,
    ManageAddonComponent,
    AddSubscriptionComponent,
    PopupModalComponent,
    SuccessMessageComponent,
    HistoryComponent,
    TransferCreditComponent,
    TopProfileComponent,
    TransferBucketComponent,
    DxpProductBundleComponent
  ],
  entryComponents: [
    TransferCreditComponent,
    SuccessMessageComponent,
    TransferBucketComponent],
    providers:[
      {
        provide: HTTP_INTERCEPTORS,
        useClass: AuthInterceptorService,
        multi: true
      },
      CanActivateDashboardHomeRouteGuard
    ]
})
export class DashboardModule {
}
