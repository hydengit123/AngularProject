import { AfterViewInit, Component, ElementRef, HostListener, OnInit, ViewChild, OnDestroy, DoCheck } from '@angular/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { Router, ActivatedRoute } from '@angular/router';
import { EventListenerService } from '../event-listener.service';
import { DataClientService } from '../data-client.service';
import { mockUsername, NotificationMsg } from '../mockData';
import { EventEnum } from '../enum/EventEnum';
import { AuthService } from '../services/auth.service';
import { CustomerService } from '../services/customer.service';
import { PERSISTANCEKEY, WEBCONTENTPERSISTANCEKEY, LOCALIZATIONPERSISTANCEKEY, CHATBOT } from '../../application-constants';
import { ProductService } from '../services/product.service';
import * as crypto from 'crypto-js';
import { WebContent } from '../interface/web.content';
import { TranslateService } from '@ngx-translate/core';
import { CustomerSearchService } from '../services/customer-search.service';
import { UserContractModel } from 'dxp-common';
import { CustomerOnboardService } from '../services/customer-onboard.service';
import { CustomerSearchDataService } from '../services/customer-search-data.service';
import { AddSubscriptionService } from '../services/add-subscription.service';
import UserProfile from '../modals/ProfileModal';
import { UtilService } from '../services/util.service';
import { IDashboardProfileUpdate } from './interface/dashboard-profile-update';
import { Subscription } from 'rxjs';
import { CartService } from '../services/cart.service';
import { DfyComponent } from './dfy/dfy.component';
import { UtcComponent } from './utc/utc.component';
import { HomeComponent } from './home/home.component';
import { PlanComponent } from './plan/plan.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';

declare var $: any;

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
    providers: [CustomerService]
})

export class DashboardComponent implements OnInit, AfterViewInit, OnDestroy, DoCheck {
    journeySessionData: any;
    pendingJourney: any;
    webContent: WebContent;
    isRTL = false;
    childComp: any;
    showCommonProfile = false;
    showMsisdnDropDown = true;
    enableSorting = false;
    enableSearching = false;
    public bkimg;
    private loadedComponentForProfileUpdate: IDashboardProfileUpdate;
    private dashboardRefreshSubscription: Subscription;
    private msisdnChangeEvent: Subscription;
    public footerFlag: any;

    constructor(
        private persistenceService: PersistenceService,
        private router: Router,
        private route: ActivatedRoute,
        private listener: EventListenerService,
        private authservice: AuthService,
        private customerService: CustomerService,
        private dataService: DataClientService,
        private translate: TranslateService,
        private cartService: CartService,
        private customerSearchService: CustomerSearchService,
        private productService: ProductService,
        private customerSearchDataService: CustomerSearchDataService,
        private customerOnboardService: CustomerOnboardService,
        private addSubscriptionService: AddSubscriptionService,
        private utilService: UtilService,
        private eventListerService: EventListenerService) {

        this.msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
        this.notificationMsg = NotificationMsg;
        this.getNotificationCount();

        this.webContent = this.persistenceService.get(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, StorageType.SESSION);
        if (this.webContent && this.webContent.footerLightImage) {
            this.bkimg = this.webContent.footerLightImage.url;
        }

    }

    // open and close notificationBox
    msisdn = null;
    notificationMsg = [];
    notificationCount = 0;
    showNotification = false;
    personalisedOffer: any;
    allProducts: any;
    personalisedOfferData = [];
    AvaamoChatBot: any;
    Avaamo: any;
    chatBox: any;
    accessToken: string;
    currentContract = null;


    @ViewChild('btnBell') btnBell: ElementRef;

    @HostListener('document:click', ['$event.target']) onDocumentClick(targetElement) {
        if (this.btnBell && this.btnBell.nativeElement.contains(targetElement)) {
            this.showNotification = !this.showNotification;
        } else {
            this.showNotification = false;
        }
    }

    ngOnInit() {
        this.listener.redirectDashboardEvent.subscribe(data => {
            if (data && data.eventType === EventEnum.dashboardRedirect) {
                this.pendingJourney = this.customerSearchService.getpendingJourneyStatus();
                this.setCurrent();
            }
        });

        this.dashboardRefreshSubscription = this.listener.dashboardEvent.subscribe(eventPayload => {
            if (eventPayload && eventPayload.eventType === EventEnum.dashboardRefresh) {
                setTimeout(() => {
                    this.setCurrent(true);
                }, 3000);
            }
        });

        this.pendingJourney = this.customerSearchService.getpendingJourneyStatus();
        //this.setCurrent();

    }

    private setCurrent(refreshProfileOfChildComponent: boolean = false) {
        const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
        this.customerSearchDataService.setUserProfileData(partyId)
            .subscribe((profiledata) => {

                const profile = new UserProfile(profiledata, this.persistenceService);
                if (profile && profile.language) {
                    this.eventListerService.changeLanguage(profile.language);
                }
                this.customerSearchService.setUserProfile(profile);
                const CustomerID = profile.customerId;

                this.customerSearchDataService.getContract(CustomerID)
                    .subscribe((contractResponse) => {
                        let activeStatusProfile = [];
                        const contractDetails = contractResponse;
                        this.customerSearchService.setpendingJourneyStatus(false);
                        if (contractDetails.length > 0) {
                            activeStatusProfile = contractDetails.filter((item) => item.status.toLowerCase() === 'active');
                        }
                        if (contractDetails.length === 0) {
                            this.getJourneySessionDetails(CustomerID, profile, contractResponse, false);
                        } else if (contractDetails.length > 0 && activeStatusProfile.length === 0) {
                            this.getJourneySessionDetails(CustomerID, profile, contractResponse, true);
                        } else {
                            this.getDashboardData(profile, contractResponse);
                        }
                        if (refreshProfileOfChildComponent) {
                            if (this.loadedComponentForProfileUpdate) {
                                this.loadedComponentForProfileUpdate.refreshDashBoardView();
                            }
                        }
                    }
                    );

            });
    }

    private getJourneySessionDetails(customerId, profile, contractResponse, contractExist: Boolean) {
        this.footerFlag = false;
        this.customerSearchDataService.getJourneySessionData(customerId).subscribe(journeydata => {
            this.journeySessionData = journeydata;
            this.customerSearchService.setPendingId(customerId);
            this.customerSearchService.setJourneyData(journeydata, journeydata.length);
            if (this.journeySessionData && this.journeySessionData.length > 0) {
                this.customerSearchService.setpendingJourneyStatus(true);
                this.listener.notifyPendingJourneyStatus(true);
                this.addSubscriptionService.setSubscriptionStatus(false);
                if (this.router.url.indexOf('/subscription') !== -1) {
                    this.router.navigate(['dashboard/subscription']);
                } else if (this.router.url.indexOf('/support') !== -1) {
                    this.router.navigate(['dashboard/support']);
                } else {
                    this.router.navigate(['dashboard/home']);
                }

            }
        }, (err) => {
            if (contractExist) {
                this.getDashboardData(profile, contractResponse);
            } else {
                // call link subscription
                this.customerSearchService.setpendingJourneyStatus(false);
                this.addSubscriptionService.setSubscriptionStatus(true);
                if (err.error.code === '2002') {
                    if (this.router.url.indexOf('/subscription') !== -1) {
                        this.router.navigate(['dashboard/subscription']);
                    } else if (this.router.url.indexOf('/support') !== -1) {
                        this.router.navigate(['dashboard/support']);
                    } else {
                        this.router.navigate(['customerOnboard']);
                    }
                } else {
                    this.router.navigate(['dashboard/home']);
                }
            }
        });
    }

    private getDashboardData(profile, contractResponse) {
        this.footerFlag = true;
        // const userProfileData = profiledata;
        const constracs = contractResponse;
        // const profile = new UserProfile(userProfileData);
        this.customerSearchService.setUserProfile(profile);
        const userContracts = constracs.map(contract => {
            return new UserContractModel(contract);
        });
        this.customerSearchService.setUserContracts(userContracts);
        this.customerSearchService.setpendingJourneyStatus(false);
        this.addSubscriptionService.setSubscriptionStatus(false);
        this.userChange();
        if (this.router.url.endsWith('dashboard')) {
            this.router.navigate(['dashboard/home']);
        }

    }

    private userChange() {
        this.customerSearchService.setCurrentContract(this.customerSearchService.getUserContracts()[0]);
        this.msisdnChangeEvent = this.listener.msisdnChangeEvent.subscribe((event) => {
            const msisdn = event.msisdn;
            const contracts = this.customerSearchService.getUserContracts();
            for (let i = 0; i < contracts.length; i++) {
                if (contracts[i].msisdn === msisdn) {
                    this.currentContract = contracts[i];
                    this.customerSearchService.setCurrentContract(this.currentContract);
                    break;
                }
            }
        });
    }

    ngAfterViewInit() {
        $('.box-1').click(function (e) {
            if (window.innerWidth <= 991) {
                $('.navbar-toggler').trigger('click');
            }
        });
    }

    logout() {
        this.authservice.logout()
            .subscribe(data => {
            }, error => {
            });
        this.persistenceService.removeAll(StorageType.SESSION);
        // Fetch CM UI config
        this.utilService.getCMUIDetails().subscribe(data => {
            this.listener.updateCMUIData(data);
        });
        window.location.reload();
        // this.router.navigate(['public']);
    }

    openRoute(route) {
        this.router.navigate(route.split('/'));
    }

    getCustomerInfo() {
        const msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
        this.customerService.getCustomerInfo(msisdn)
            .subscribe(data => {
                this.persistenceService.set(PERSISTANCEKEY.USERNAME, data.firstName + ' ' + data.lastName, { type: StorageType.SESSION });
            }, error => {
                this.persistenceService.set(PERSISTANCEKEY.USERNAME, mockUsername, { type: StorageType.SESSION });
            });
    }

    setAsRead(index) {
        this.notificationMsg[index].read = true;
        this.getNotificationCount();
    }

    getNotificationCount() {
        let count = 0;
        this.notificationMsg.forEach(x => {
            if (!x.read) {
                count++;
            }
        });
        this.notificationCount = count;
    }

    getPersonalisedOffers() {
        let url: any;
        this.productService.getInsightURL().subscribe(response => {
            // url = response.url + 'topoffers/' + '9831022210';
            url = response.url + 'topoffers/' + this.msisdn;
            // url = response.url + this.msisdn;
            this.productService.getPersonalisedOffers(url).
                subscribe(data => {
                    this.personalisedOffer = data;
                    for (let i = 0; i < this.personalisedOffer.length; i++) {
                        for (let j = 0; j < this.allProducts.length; j++) {
                            if ((this.allProducts[j]['productId']).indexOf(this.personalisedOffer[i]['productOfferID']) > -1) {
                                this.personalisedOfferData.push(this.allProducts[j]);
                            }
                        }
                    }
                    this.persistenceService.set(PERSISTANCEKEY.PERSONALISEDDEALS, this.personalisedOfferData, { type: StorageType.SESSION });
                }, error => {
                });
        });
    }

    getAllProducts() {
        this.productService.getAllProducts().
            subscribe(data => {
                this.allProducts = data;
                this.getPersonalisedOffers();
            }, error => {
            });
    }

    ngOnDestroy() {
        if (this.dashboardRefreshSubscription) {
            this.dashboardRefreshSubscription.unsubscribe();
        }
    }

    ngDoCheck() {
        const componentsWithProfile = [HomeComponent.name, CustomerProfileComponent.name, DfyComponent.name, UtcComponent.name];
        if (this.childComp) {
            this.showCommonProfile = componentsWithProfile.indexOf(this.childComp.constructor.name) === -1 ? false : true;
        }
    }

    activatedComponentInstance(componentRef: IDashboardProfileUpdate) {
        if (componentRef && componentRef.refreshDashBoardView) {
            this.loadedComponentForProfileUpdate = componentRef;
        }
        this.childComp = componentRef;
        this.showMsisdnDropDown = componentRef.constructor.name === PlanComponent.name || componentRef.constructor.name === CustomerProfileComponent.name ? false : true;
        this.enableSorting = componentRef.constructor.name === DfyComponent.name ? true : false;
        this.enableSearching = componentRef.constructor.name === DfyComponent.name ? true : false;
    }
}
