import { Component, OnInit, OnDestroy, ViewChild, ViewChildren, ElementRef, Directive, AfterViewInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { PersistenceService, StorageType } from "angular-persistence";
import { Observable, Subject } from 'rxjs';
import { Router } from '@angular/router'; 
import { TranslateService } from '@ngx-translate/core';
import { PERSISTANCEKEY } from '../../../application-constants';
import { AddSubscriptionService } from './../../services/add-subscription.service';
import { addSubscriptionValidator } from './../../shared/validator/AddSubscriptionValidate';
import { EventListenerService } from '../../event-listener.service';
import { CMUICONFIGKEY } from "dxp-common";

declare const alertify;
@Component({
  selector: 'app-add-subscription',
  templateUrl: './add-subscription.component.html',
  styleUrls: ['./add-subscription.component.scss']
})
export class AddSubscriptionComponent implements OnInit {

  @ViewChild('mobilenumber') private elementRef: ElementRef;
  mobileNumberLength: number;
  mobileNumberMaxLength: number;
  verficationCodeShow: Boolean = false;
  partyId: String = '';
  formShow: Boolean = true;
  successMessageShow: Boolean = false;
  subscribedPartyId: String = "";
  subscribedCustomerId: String = "";
  public subscriptionForm: FormGroup = new FormGroup({
    mobileNumber: new FormControl(),
    verficationCode: new FormControl()
  },
    [addSubscriptionValidator(this.persistenceService)]
  );

  constructor(private persistenceService: PersistenceService,
    private addSubscriptionService: AddSubscriptionService,
    private translateService: TranslateService,
    private router: Router,
    private eventListenerService: EventListenerService) { }

  ngOnInit() {
    this.eventListenerService.showSubscriptionMenu(true);
    this.mobileNumberLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION);
    this.mobileNumberMaxLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION);
    this.partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
  }

  subscriptionFormSubmit(e) {
    if (this.subscriptionForm.invalid) {
      return;
    }
  }

  continueButtonClick() {
    this.addSubscriptionService.getMobileNumberStatus(this.subscriptionForm.value).subscribe(data => {
      if (data && data.statusCode === '1041') {
        this.subscribedPartyId = data.details.partyId;
        this.subscribedCustomerId = data.details.customerId;
        this.sendVerificationCode(this.partyId);
        this.verficationCodeShow = true;
      } else {
        this.verficationCodeShow = false;
        alertify.error(this.translateService.instant("This mobile number is not activated yet"));
        // alertify.error("This mobile number is not activated yet");
      }
    }, error => {
      this.verficationCodeShow = false;
      alertify.error(this.translateService.instant("This mobile number is not activated yet"));
      // alertify.error("This mobile number is not activated yet");
    }
    );
  }

  ngAfterViewInit() {
    if (this.elementRef && this.elementRef.nativeElement) {
      this.elementRef.nativeElement.focus();
    }
  }

  disableStatusCheck() {
    if (this.subscriptionForm.status == "PENDING" || this.subscriptionForm.status == "INVALID") {
      return true;
    } else {
      return false;
    }
  }

  sendVerificationCode(partyId) {
    this.addSubscriptionService.sendVerificationCodeToMobile(partyId, this.subscriptionForm.value).subscribe(data => {
      const response = data;
    });
  }

  checkVerificationCodeValid(partyId) {
    this.addSubscriptionService.validateVerificationCode(partyId, this.subscriptionForm.value).subscribe(data => {
      this.formShow = false;
      this.successMessageShow = true;
      this.addSubscriptionService.setSubscribedCustomerId(this.subscribedCustomerId);
      this.addSubscriptionService.setSubscribedMSISDN(this.subscriptionForm.controls.mobileNumber.value);
      this.persistenceService.set(PERSISTANCEKEY.ACCESSTOKEN, data.access_token, { type: StorageType.SESSION });
      this.persistenceService.set(PERSISTANCEKEY.PARTYID, this.subscribedPartyId, { type: StorageType.SESSION });
      this.persistenceService.set(PERSISTANCEKEY.MSISDN, this.subscriptionForm.controls.mobileNumber.value, { type: StorageType.SESSION });
    }, error => {
      this.successMessageShow = false;
      if(error.error && error.error.code === "1038"){
        alertify.error(this.translateService.instant(error.error.code.toString()));
      } else {
        alertify.error(this.translateService.instant("Invalid Verification Code"));
      }
    });
  }

  buttonStatusCheck() {
    if (this.subscriptionForm.controls.verficationCode.value == "") {
      return true;
    } else {
      return false;
    }
  }

  goToDashboard() {
    // this.router.navigate(['dashboard']);
    this.addSubscriptionService.setSubscriptionStatus(false);
    this.eventListenerService.showSubscriptionMenu(false);
    this.eventListenerService.goToDashboard();
  }

}
