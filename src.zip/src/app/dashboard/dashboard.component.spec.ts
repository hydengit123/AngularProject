import { Pipe, PipeTransform, Directive, NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { Router } from '@angular/router';
import { PersistenceService } from 'angular-persistence';
import { DataClientService } from '../data-client.service';
import { EventListenerService } from '../event-listener.service';
import { AuthService } from '../services/auth.service';
import { CustomerService } from '../services/customer.service';
import { ProductService } from '../services/product.service';
import { DashboardComponent } from './dashboard.component';
import { Observable, ReplaySubject } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { testBedModule } from '../test-bed-module-mock';

declare const $;

@Pipe({ name: 'getLocalTime' })
class MockGetLocalTimePipe implements PipeTransform {
  transform(value: number): number {
    // Do stuff here
    return value;
  }
}

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let authServiceSpy: jasmine.SpyObj<AuthService>;
  let productServiceSpy: jasmine.SpyObj<ProductService>;
  let customerServiceSpy: jasmine.SpyObj<CustomerService>;
  let eventListenerServiceSpy: jasmine.SpyObj<EventListenerService>;
  let dataClientServiceSpy: jasmine.SpyObj<DataClientService>;
  // let routerStub: any;
  let routerSpy: jasmine.SpyObj<Router>;

  beforeEach(async(() => {
    const EventListenerServiceSpy = jasmine.createSpyObj('EventListenerService', ['profileEvent']);
    EventListenerServiceSpy['profileEvent'] = { 'subscribe': (c) => c(4) };

    const testBedModules = testBedModule().testBedModules;
    const spies = testBedModule().spies;
    TestBed.configureTestingModule({
      imports: [ ...testBedModules.imports],
      declarations: [
        DashboardComponent, ...testBedModules.declarations
      ],
      providers: [ ...testBedModules.providers ],
      schemas: [NO_ERRORS_SCHEMA]
    }).overrideComponent(DashboardComponent, {
      set: {
        providers: [
          { provide: CustomerService, useValue: spies.CustomerServiceSpy }
         ]
      }
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
    authServiceSpy = TestBed.get(AuthService);
    eventListenerServiceSpy = TestBed.get(EventListenerService);
    routerSpy = TestBed.get(Router);
    productServiceSpy = TestBed.get(ProductService) as any;
    dataClientServiceSpy = TestBed.get(DataClientService) as any;
    customerServiceSpy = fixture.debugElement.injector.get(CustomerService) as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('ngOnInit method should call getAllProducts and identifyuser', () => {
    spyOn(component, 'getAllProducts');
    spyOn(component, 'identifyuser');

    component.ngOnInit();

    expect(component.getAllProducts).toHaveBeenCalled();
    expect(component.identifyuser).toHaveBeenCalled();
  });

  xit('ngAfterViewInit method should', fakeAsync(() => {
    spyOn($.fn, 'click');
    spyOn($.fn, 'trigger');

    component.ngAfterViewInit();
    $('.box-1').trigger('click');
    tick();

    expect($.fn.trigger).toHaveBeenCalled();
  }));

  xdescribe('logout method should', () => {
    it('call persistenceService.removeAll method', () => {
      spyOn(window.location, 'reload');
      authServiceSpy.logout.and.returnValue(Observable.of('SUCCESS'));

      component.logout();

      expect(persistenceServiceSpy.removeAll).toHaveBeenCalled();
      expect(routerSpy.navigate).toHaveBeenCalled();
      expect(window.location.reload).toHaveBeenCalled();
    });

    it('call persistenceService.removeAll method and catch error from authService.logout', () => {
      spyOn(window.location, 'reload');
      authServiceSpy.logout.and.returnValue(Observable.throw(new Error('err')));
      spyOn(console, 'log');

      component.logout();

      expect(persistenceServiceSpy.removeAll).toHaveBeenCalled();
      expect(routerSpy.navigate).toHaveBeenCalled();
      expect(console.log).toHaveBeenCalled();
      expect(window.location.reload).toHaveBeenCalled();
    });
  });

  it('openRoute method should call router.navigate method', () => {
    component.openRoute('home/new');

    expect(routerSpy.navigate).toHaveBeenCalledWith(['home', 'new']);
  });

  describe('getCustomerInfo method should', () => {
    it('call persistenceServiceSpy.set method when customer data has been received succssfully', () => {
      persistenceServiceSpy.get.and.returnValue('4622378109');
      customerServiceSpy.getCustomerInfo.and.returnValue(Observable.of({ firstName: 'John', lastName: 'Smith' }));

      component.getCustomerInfo();

      expect(persistenceServiceSpy.set).toHaveBeenCalled();
    });

    it('call persistenceServiceSpy.set method when customer data has not been received', () => {
      persistenceServiceSpy.get.and.returnValue('4622378109');
      customerServiceSpy.getCustomerInfo.and.returnValue(Observable.throw(new Error('Error')));

      component.getCustomerInfo();

      expect(persistenceServiceSpy.set).toHaveBeenCalled();
    });
  });

  it('setAsRead method should set read property as true in notificationMsg object and should call getNotificationCount method', () => {
    spyOn(component, 'getNotificationCount');
    component.notificationMsg = [{ read: false }];

    component.setAsRead(0);

    expect(component.notificationMsg[0].read).toBeTruthy();
    expect(component.getNotificationCount).toHaveBeenCalled();
  });

  it('getNotificationCount method should set notificationCount as the count of unread notifcation messages', () => {
    component.notificationMsg = [{ read: true }, { read: true }, { read: true }, { read: false }, { read: false }];

    component.notificationCount = 0;
    component.getNotificationCount();

    expect(component.notificationCount).toBe(2);
  });

  describe('getPersonalisedOffers method should', () => {
    it(' push personlaised offers to personalisedOfferData', () => {
      const allProducts = [{
        'productId': 'CM_Data_628',
        'productName': 'MAINRESET',
        'productType': 'Data',
        'productGroup': 'MAINRESET',
        'productDescription': 'MAINRESET',
        'productValidityDays': 30,
        'price': 0,
        'productStatus': 'ACTIVE',
        'issharedaccount': false,
        'isSplit': false,
        'isRecurring': false,
        'BuyForOther': false,
        'quota': {},
        'productCreationDate': '08-10-2018 15:01:33'
      },
      {
        'productId': 'CM_Data_579',
        'productName': 'optIN_buy',
        'productType': 'Data',
        'productGroup': 'OptinProduct',
        'productDescription': 'Optin ',
        'productValidityDays': 3,
        'price': 0,
        'productStatus': 'ACTIVE',
        'issharedaccount': false,
        'isSplit': false,
        'isRecurring': true,
        'recurringTimes': 3,
        'recurringValue': 72,
        'recurringUnit': 'Hours',
        'BuyForOther': false,
        'quota': {
          'voice': {
            'unit': 0,
            'unitType': '0'
          },
          'sms': {
            'unit': 0,
            'unitType': '1'
          },
          'data': {
            'unit': 10737418240,
            'unitType': '6'
          }
        },
        'productCreationDate': '06-07-2018 10:25:02'
      },
      {
        'productId': 'CM_SMS_559',
        'productName': 'SMS_0',
        'productType': 'SMS',
        'productGroup': 'CustomizePlanOffer',
        'productDescription': '',
        'productValidityDays': 30,
        'price': 0,
        'productStatus': 'ACTIVE',
        'issharedaccount': false,
        'isSplit': false,
        'isRecurring': true,
        'recurringTimes': 9999,
        'recurringValue': 30,
        'recurringUnit': 'Days',
        'BuyForOther': false,
        'quota': {
          'voice': {
            'unit': 0,
            'unitType': '0'
          },
          'sms': {
            'unit': 0,
            'unitType': '1'
          },
          'data': {
            'unit': 0,
            'unitType': '6'
          }
        },
        'productCreationDate': '07-06-2018 16:03:33'
      },
      {
        'productId': 'CM_Voice_558',
        'productName': 'voice_0',
        'productType': 'Voice',
        'productGroup': 'CustomizePlanOffer',
        'productDescription': 'Voice 0',
        'productValidityDays': 30,
        'price': 0,
        'productStatus': 'ACTIVE',
        'issharedaccount': false,
        'isSplit': false,
        'isRecurring': true,
        'recurringTimes': 9999,
        'recurringValue': 30,
        'recurringUnit': 'Days',
        'BuyForOther': false,
        'quota': {
          'voice': {
            'unit': 0,
            'unitType': '0'
          },
          'sms': {
            'unit': 0,
            'unitType': '1'
          },
          'data': {
            'unit': 0,
            'unitType': '6'
          }
        },
        'productCreationDate': '07-06-2018 15:57:43'
      }];
      const personalisedOffers = [{
        'productId': 'CM_Data_628',
        'productName': 'MAINRESET',
        'productType': 'Data',
        'productGroup': 'MAINRESET',
        'productDescription': 'MAINRESET',
        'productValidityDays': 30,
        'price': 0,
        'productStatus': 'ACTIVE',
        'issharedaccount': false,
        'isSplit': false,
        'isRecurring': false,
        'BuyForOther': false,
        'quota': {},
        'productCreationDate': '08-10-2018 15:01:33',
        'productOfferID': 'CM_Data_628'
      },
      {
        'productId': 'CM_Data_579',
        'productName': 'optIN_buy',
        'productType': 'Data',
        'productGroup': 'OptinProduct',
        'productDescription': 'Optin ',
        'productValidityDays': 3,
        'price': 0,
        'productStatus': 'ACTIVE',
        'issharedaccount': false,
        'isSplit': false,
        'isRecurring': true,
        'recurringTimes': 3,
        'recurringValue': 72,
        'recurringUnit': 'Hours',
        'BuyForOther': false,
        'quota': {
          'voice': {
            'unit': 0,
            'unitType': '0'
          },
          'sms': {
            'unit': 0,
            'unitType': '1'
          },
          'data': {
            'unit': 10737418240,
            'unitType': '6'
          }
        },
        'productCreationDate': '06-07-2018 10:25:02',
        'productOfferID': 'CM_Data_579'
      }];
      const insightUrl = {
        url: 'http://insightsapi.curie006.seli.gic.ericsson.se/dxp-ci-insight-api/insights/v1/'
      };
      component.msisdn = 4622378109;
      component.allProducts = allProducts;
      productServiceSpy.getInsightURL.and.returnValue(Observable.of(insightUrl));
      productServiceSpy.getPersonalisedOffers.and.returnValue(Observable.of(personalisedOffers));

      component.getPersonalisedOffers();

      expect(component.personalisedOfferData.length).toBe(2);
    });

    it('catch error from productService.getPersonalisedOffers', () => {
      const insightUrl = {
        url: 'http://insightsapi.curie006.seli.gic.ericsson.se/dxp-ci-insight-api/insights/v1/'
      };
      component.msisdn = 4622378109;
      component.allProducts = [];
      productServiceSpy.getInsightURL.and.returnValue(Observable.of(insightUrl));
      productServiceSpy.getPersonalisedOffers.and.returnValue(Observable.throw(new Error()));
      spyOn(console, 'log');

      component.getPersonalisedOffers();

      expect(console.log).toHaveBeenCalled();
    });
  });

  describe('getAllProducts method should', () => {
    it('set all products and call getPersonalisedOffers methods', () => {
      const allProducts = [{
        'productId': 'CM_Data_628',
        'productName': 'MAINRESET',
        'productType': 'Data',
        'productGroup': 'MAINRESET',
        'productDescription': 'MAINRESET',
        'productValidityDays': 30,
        'price': 0,
        'productStatus': 'ACTIVE',
        'issharedaccount': false,
        'isSplit': false,
        'isRecurring': false,
        'BuyForOther': false,
        'quota': {},
        'productCreationDate': '08-10-2018 15:01:33',
        'productOfferID': 'CM_Data_628'
      },
      {
        'productId': 'CM_Data_579',
        'productName': 'optIN_buy',
        'productType': 'Data',
        'productGroup': 'OptinProduct',
        'productDescription': 'Optin ',
        'productValidityDays': 3,
        'price': 0,
        'productStatus': 'ACTIVE',
        'issharedaccount': false,
        'isSplit': false,
        'isRecurring': true,
        'recurringTimes': 3,
        'recurringValue': 72,
        'recurringUnit': 'Hours',
        'BuyForOther': false,
        'quota': {
          'voice': {
            'unit': 0,
            'unitType': '0'
          },
          'sms': {
            'unit': 0,
            'unitType': '1'
          },
          'data': {
            'unit': 10737418240,
            'unitType': '6'
          }
        },
        'productCreationDate': '06-07-2018 10:25:02',
        'productOfferID': 'CM_Data_579'
      }];
      productServiceSpy.getAllProducts.and.returnValue(Observable.of(allProducts));
      spyOn(component, 'getPersonalisedOffers');

      component.getAllProducts();

      expect(component.getPersonalisedOffers).toHaveBeenCalled();
      expect(component.allProducts.length).toBe(2);
    });

    it('catch error from productService.getAllProducts', () => {
      productServiceSpy.getAllProducts.and.returnValue(Observable.throw(new Error('error')));
      spyOn(console, 'log');

      component.getAllProducts();

      expect(console.log).toHaveBeenCalled();
    });
  });

  it('loadChatbot method should define AvaamoChatBot', () => {
    expect(component.AvaamoChatBot).toBeUndefined();

    component.loadChatbot(12344);

    expect(component.AvaamoChatBot).toBeDefined();
  });

  it('identifyuser method should', () => {
    const accesstoken = 'TestToken';
    persistenceServiceSpy.get.and.returnValue(accesstoken);
    component.msisdn = 4622378109;
    spyOn(component, 'loadChatbot');

    component.identifyuser();

    expect(component.loadChatbot).toHaveBeenCalled();
  });
});
