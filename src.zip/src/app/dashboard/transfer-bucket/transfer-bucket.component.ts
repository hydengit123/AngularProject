import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { DataFormatterPipe, CMUICONFIGKEY } from 'dxp-common';
import { PERSISTANCEKEY, SHAREDCONSUMER } from '../../../application-constants';
import { quickRechargeFormValidator } from '../../cis/QuickRechargeValidate';
import { EventEnum } from '../../enum/EventEnum';
import { EventListenerService } from '../../event-listener.service';
import { TransferBucketPayload } from './../../interface/transfer-bucket-payload';
import { CustomerService } from './../../services/customer.service';

declare const alertify;

@Component({
  selector: 'app-transfer-bucket',
  templateUrl: './transfer-bucket.component.html',
  styleUrls: ['./transfer-bucket.component.scss']
})
export class TransferBucketComponent implements OnInit {
  public bucketItemDetails: any;
  public requestPayload: TransferBucketPayload;
  private range: any = 0;
  private sliderValue: any = 0;
  private phoneNumberLength: any;
  private phoneNumberMaxLength: any;
  private transferBucketForm: FormGroup;
  private sliderMaxValue: any;
  private dataType: String;
  public successMsgShow: Boolean = false;
  private orderId: String = '';
  public successMessage: String = '';
  public amountLabel: String = '';
  public amount = 0;
  public dataLimit: any;
  public voiceLimit: any;
  public smsLimit: any;
  private dataFormatterPipe: DataFormatterPipe = new DataFormatterPipe(this.translateService);

  constructor(private customerService: CustomerService,
    private persistenceService: PersistenceService,
    private eventListenerService: EventListenerService,
    private translateService: TranslateService) { }

  ngOnInit() {
    this.phoneNumberLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION);
    this.phoneNumberMaxLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION);
    this.amountLabel = this.translateService.instant(this.bucketItemDetails.bucketType.toLowerCase());
    const loggedInMsisdn = this.persistenceService.get(PERSISTANCEKEY.REGISTEREMAILMSISDN, StorageType.SESSION);
    this.dataLimit = this.persistenceService.get(CMUICONFIGKEY.XFER_DATA_LIMIT, StorageType.SESSION);
    this.voiceLimit = this.persistenceService.get(CMUICONFIGKEY.XFER_VOICE_LIMIT, StorageType.SESSION);
    this.smsLimit = this.persistenceService.get(CMUICONFIGKEY.XFER_SMS_LIMIT, StorageType.SESSION);
    const dataValue = this.dataFormatterPipe.transform(this.bucketItemDetails.currentBalance, this.bucketItemDetails.unit);
    const unitValue = dataValue.split(' ')[0];
    this.dataType = dataValue.split(' ')[1];
    if (this.bucketItemDetails.bucketType.toLowerCase() === SHAREDCONSUMER.DATA) {
      if (this.bucketItemDetails.currentBalance > this.dataLimit) {
        const data = this.dataFormatterPipe.transform(this.dataLimit, this.bucketItemDetails.unit);
        this.sliderMaxValue = data.split(' ')[0];
        this.dataType = data.split(' ')[1];
      } else {
        this.sliderMaxValue = unitValue;
      }
    } else if (this.bucketItemDetails.bucketType.toLowerCase() === SHAREDCONSUMER.VOICE) {
      if (this.bucketItemDetails.currentBalance > this.voiceLimit) {
        const voice = this.dataFormatterPipe.transform(this.voiceLimit, this.bucketItemDetails.unit);
        this.sliderMaxValue = voice.split(' ')[0];
        this.dataType = voice.split(' ')[1];
      } else {
        this.sliderMaxValue = unitValue;
      }
    } else if (this.bucketItemDetails.bucketType.toLowerCase() === SHAREDCONSUMER.SMS) {
      if (this.bucketItemDetails.currentBalance > this.smsLimit) {
        this.sliderMaxValue = this.smsLimit;
      } else {
        this.sliderMaxValue = unitValue;
      }
    }
    this.transferBucketForm = new FormGroup({
      phoneNumber: new FormControl(),
      amount: new FormControl(),
    },
      [quickRechargeFormValidator(this.persistenceService, this.sliderMaxValue, loggedInMsisdn)]
    );
    this.transferBucketForm.controls.amount.valueChanges.subscribe(data => {
      if (data === '') {
        this.amount = 0;
        this.sliderValue = '0';
      } else {
        this.sliderValue = data;
        this.amount = data;
      }
    });
  }

  changeSlider(value: number) {
    this.sliderValue = value;
    this.amount = value;
    this.transferBucketForm.controls.amount.setValue(this.sliderValue);
  }

  doTransfer() {
    this.customerService.customerSearchProfile(this.transferBucketForm.value).subscribe((data) => {
      // const dataValue = this.dataReformatterPipe.transform(this.sliderValue, this.dataType);
      const dataValue = this.dataReformatter(this.sliderValue, this.bucketItemDetails.unit);
      this.requestPayload.coreData.beneficiaryMsisdn = this.transferBucketForm.controls.phoneNumber.value.toString();
      this.requestPayload.coreData.transferQuantity = dataValue;
      this.customerService.customerInteractionForRecharge(this.requestPayload).subscribe(data => {
        if (data && data.statusReason) {
          this.orderId = data.id;
          this.successMessage = this.translateService.instant(data.statusReason.code);
          this.successMsgShow = true;
          this.eventListenerService.dashboardEvent.emit({ eventType: EventEnum.dashboardRefresh });
        }
      });
    },
    error => {
      alertify.error(this.translateService.instant('Customer profile is not available for this phone number'));
    });
  }

  disableCheck() {
    if (!this.transferBucketForm.controls.phoneNumber.value || !this.transferBucketForm.controls.amount.value || this.transferBucketForm.invalid || this.transferBucketForm.controls.amount.value == 0) {
      return true;
    } else {
      return false;
    }
  }

  dataReformatter(value, unit) {
    value = parseFloat(value);
    if (value && unit) {
      if (unit.toLowerCase() === SHAREDCONSUMER.DATAUNIT || unit.toLowerCase() === SHAREDCONSUMER.DATAUNITS) {
        value = this.reConvertData(value, this.dataType);
        return value;
      } else if (unit.toLowerCase() === SHAREDCONSUMER.VOICEUNIT || unit.toLowerCase() === SHAREDCONSUMER.VOICEUNITS) {
        value = this.reConvertVoice(value, this.dataType);
        return value;
      } else {
        return value.toString();
      }
    }
  }

  reConvertData(value, unit: String) {
    if (value && unit === 'GB') {
      value = parseInt((value * 1024 * 1024 * 1024).toString(), 10);
    } else if (value && unit === 'MB') {
      value = parseFloat((value * 1024 * 1024).toString()).toFixed(2);
    } else if (value && unit === 'KB') {
      value = parseFloat((value * 1024).toString()).toFixed(2);
    } else {
      value = '0';
    }
    return value.toString();
  }

  reConvertVoice(value, unit: String, onlyValueConversion?: boolean) {
    const convertedUnit = unit;
    if (unit === 'Min') {
      value = parseFloat((value * 60).toString()).toFixed(2).split('.')[0];
      return value.toString();
    } else {
      return value.toString();
    }
  }

  makeNewTransfer() {
    const amountBaseValue = this.dataReformatter(this.amount, this.bucketItemDetails.unit);
    const updatedUserValue = this.bucketItemDetails.currentBalance - amountBaseValue;
    this.setSliderMaxValue(updatedUserValue);
    this.transferBucketForm.reset();
    this.sliderValue = 0;
    this.amount = 0;
    this.successMsgShow = false;
  }

  setSliderMaxValue(updatedUserValue) {
    if (this.bucketItemDetails.bucketType.toLowerCase() === SHAREDCONSUMER.DATA) {
      if (updatedUserValue > this.dataLimit) {
        const data = this.dataFormatterPipe.transform(this.dataLimit, this.bucketItemDetails.unit);
        this.sliderMaxValue = data.split(' ')[0];
      } else {
        const newValue: Number = this.sliderMaxValue - this.sliderValue;
        this.sliderMaxValue = newValue;
      }
    } else if (this.bucketItemDetails.bucketType.toLowerCase() === SHAREDCONSUMER.VOICE) {
      if (updatedUserValue > this.voiceLimit) {
        const voice = this.dataFormatterPipe.transform(this.voiceLimit, this.bucketItemDetails.unit);
        this.sliderMaxValue = voice.split(' ')[0];
      } else {
        const newValue: Number = this.sliderMaxValue - this.sliderValue;
        this.sliderMaxValue = newValue;
      }
    } else if (this.bucketItemDetails.bucketType.toLowerCase() === SHAREDCONSUMER.SMS) {
      if (updatedUserValue > this.smsLimit) {
        this.sliderMaxValue = this.smsLimit;
      } else {
        const newValue: Number = this.sliderMaxValue - this.sliderValue;
        this.sliderMaxValue = newValue;
      }
    }
  }


}
