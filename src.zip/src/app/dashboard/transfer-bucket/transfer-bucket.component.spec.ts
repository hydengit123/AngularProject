import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferBucketComponent } from './transfer-bucket.component';

describe('TransferBucketComponent', () => {
  let component: TransferBucketComponent;
  let fixture: ComponentFixture<TransferBucketComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransferBucketComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferBucketComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
