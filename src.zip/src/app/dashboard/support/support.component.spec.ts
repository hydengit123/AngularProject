import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { PersistenceService } from 'angular-persistence';
import { SupportComponent } from './support.component';
import * as GoogleMapsLoader from 'google-maps';
import { Pipe, PipeTransform } from '@angular/core';
declare const $;

@Pipe({ name: 'translate' })
class MockTranslatePipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}

describe('SupportComponent', () => {
  let component: SupportComponent;
  let fixture: ComponentFixture<SupportComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;

  beforeEach(async(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set']);

    TestBed.configureTestingModule({
      declarations: [SupportComponent, MockTranslatePipe],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SupportComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngAfterViewInit', () => {
    it('should call $.collapse Method', () => {
      spyOn($.fn, 'collapse');

      component.ngAfterViewInit();

      expect($.fn.collapse).toHaveBeenCalled();
    });
  });

  describe('loadGoogleMap', () => {
    it('should call GoogleMapsLoader.load Method', () => {
      const spyMethod = spyOn(component, 'onGoogleMapLoad');
      spyOn(GoogleMapsLoader, 'load')
      component.loadGoogleMap();

      expect(GoogleMapsLoader.load).toHaveBeenCalledWith(spyMethod);

    });
  });

  describe('selectTab', () => {
    it('should set property activeTab, locateDisplay,call the loadGoogleMap method in setTimeout if value of tab is Find a Store ,', fakeAsync(() => {
      spyOn(component, 'loadGoogleMap');

      component.selectTab('Find a Store');
      tick(1000);
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        expect(component.loadGoogleMap).toHaveBeenCalled();
      })
      expect(component.activeTab).toEqual('Find a Store');
      expect(component.locateDisplay).toBeTruthy();
    }));
    it('should set property activeTab, locateDisplay,call the loadGoogleMap method in setTimeout if value of tab is Network Coverage', fakeAsync(() => {
      spyOn(component, 'loadGoogleMap');

      component.selectTab('Network Coverage');
      tick(1000);
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        expect(component.loadGoogleMap).toHaveBeenCalled();
      })
      expect(component.activeTab).toEqual('Network Coverage');
      expect(component.locateDisplay).toBeTruthy();
    }));
    it('should set property activeTab, locateDisplay,call the collapse method in setTimeout if value of tab is FAQ', fakeAsync(() => {
      spyOn($.fn, 'collapse');

      component.selectTab('FAQ');
      tick(100);
      fixture.detectChanges();

      fixture.whenStable().then(() => {
        expect($.fn.collapse).toHaveBeenCalled();
      })
      expect(component.activeTab).toEqual('FAQ');
      expect(component.locateDisplay).toBeTruthy();
    }));
  });

  describe('locateMinimize', () => {
    it('should toggle the property locateDisplay and  call animate method if it is false,', () => {
      component.locateDisplay = true;
      spyOn($.fn, 'animate');

      component.locateMinimize();

      expect(component.locateDisplay).toBeFalsy();
      expect($.fn.animate).toHaveBeenCalled();
    });
    it('should toggle the property locateDisplay and  call animate method if it is true,', () => {
      component.locateDisplay = false;
      spyOn($.fn, 'animate');

      component.locateMinimize();

      expect(component.locateDisplay).toBeTruthy();
      expect($.fn.animate).toHaveBeenCalled();
    });
  });

  describe('searchMinimize', () => {
    it('should toggle the property searchDisplay and  call animate method if it is false,', () => {
      component.searchDisplay = true;
      spyOn($.fn, 'animate');

      component.searchMinimize();

      expect(component.searchDisplay).toBeFalsy();
      expect($.fn.animate).toHaveBeenCalled();
    });
    it('should toggle the property searchDisplay and  call animate method if it is true,', () => {
      component.searchDisplay = false;
      spyOn($.fn, 'animate');

      component.searchMinimize();

      expect(component.searchDisplay).toBeTruthy();
      expect($.fn.animate).toHaveBeenCalled();
    });
  });
});
