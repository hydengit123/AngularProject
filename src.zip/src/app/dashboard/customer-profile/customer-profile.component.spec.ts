import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PersistenceService } from 'angular-persistence';
import { CustomerProfileComponent } from './customer-profile.component';
import { testBedModule } from '../../../test-bed-module-mock';


describe('CustomerProfileComponent', () => {
    let component: CustomerProfileComponent;
    let fixture: ComponentFixture<CustomerProfileComponent>;
    let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>
    const testBedModules = testBedModule().testBedModules;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [...testBedModules.imports],
            declarations: [CustomerProfileComponent, ...testBedModules.declarations],
            providers: [
                ...testBedModules.providers
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(CustomerProfileComponent);
        component = fixture.componentInstance;
        persistenceServiceSpy = TestBed.get(PersistenceService);
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
