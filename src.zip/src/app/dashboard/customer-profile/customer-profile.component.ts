import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { EventListenerService } from '../../../app/event-listener.service';
import { CustomerSearchService } from '../../services/customer-search.service';
import { CustomerSearchDataService } from '../../services/customer-search-data.service';
import { Subscription } from 'rxjs';
import * as _ from 'lodash';
import { PERSISTANCEKEY } from '../../../application-constants';
import { TranslateService } from '@ngx-translate/core';
import { Configuration, UserContractModel, OrderHistoryDataCallbacks, CustomerOrderConfiguration, CustomerContractsCallBacks } from 'dxp-common';
import { Router, NavigationStart, NavigationEnd } from '@angular/router';
import { CMUICONFIGKEY } from 'dxp-common';


@Component({
    selector: 'app-customer-profile',
    templateUrl: './customer-profile.component.html',
    styleUrls: ['./customer-profile.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class CustomerProfileComponent implements OnInit {
    sectionScroll;

    changeMsisdnEventSubscription: Subscription;

    commonProfile: any = {};
    selectedUserContractModel: UserContractModel;
    userContracts: UserContractModel[];

    msisdn:string;
    private customerId;


    profileConfiguration: CustomerOrderConfiguration = {
        daysRange: [],
        dateFormat: 'YYYY-MM-DD',
        dateTimeFormat: 'YYYY-MM-DD hh:mm:ss',
        pagination: {
            maxPaginationSize: 5,
            pageSize: 20
        },
        maxDateRange: 182,
        transferedProductTypes: ['MEU']
    };


    orderHistoryCallBacks: OrderHistoryDataCallbacks = {
        fetchRecords: (dates: any) => {
            return this.customerSearchDataService.searchCustomerInteractionInDateRange(this.customerId, dates);
        },
        fetchRecentRecords: () => {
            const numberOfOrderToShow = this.persistenceService.get(CMUICONFIGKEY.NO_OF_ORDER_TO_SHOW_IN_DASHBOARD, StorageType.SESSION);
            return this.customerSearchDataService.searchCustomerInteractionRecentFirst(this.customerId, numberOfOrderToShow);
        },
        fetchCMSData: (productIDs: Array<string>) => {
            const lang = this.translateService.currentLang;
            return this.customerSearchDataService.getProductDetailsFromCMS(lang, productIDs);
        }
    };

    customerContractCallbacks: CustomerContractsCallBacks = {
        getContracts: (getExpiredProducts: boolean) => {
            const customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
            return this.customerSearchDataService.getContract(customerId, getExpiredProducts);
        }
    };

    private populateConsumptionConfiguration() {
        this.profileConfiguration.daysRange = this.persistenceService.get(CMUICONFIGKEY.NOTIFICATIONDAYS, StorageType.SESSION)
            .map(item => {
                return { value: item.daysValue, label: this.translateService.instant(item.daysName) };
            });
        this.profileConfiguration.dateFormat = this.persistenceService.get(CMUICONFIGKEY.DATEFORMAT, StorageType.SESSION);
        this.profileConfiguration.dateTimeFormat = this.persistenceService.get(CMUICONFIGKEY.DATE_TIME_FORMAT, StorageType.SESSION);
        this.profileConfiguration.pagination = this.persistenceService.get(CMUICONFIGKEY.PAGINATION, StorageType.SESSION);
        this.profileConfiguration.maxDateRange = this.persistenceService.get(CMUICONFIGKEY.MAX_DATE_RANGE, StorageType.SESSION);
        this.profileConfiguration.transferedProductTypes = this.persistenceService.get(CMUICONFIGKEY.TRANSFERABLE_BASE_PLAN, StorageType.SESSION);
    }



    constructor(private eventListenerService: EventListenerService,
        private customerSearchDataService: CustomerSearchDataService,
        private customerSearchService: CustomerSearchService,
        private persistenceService: PersistenceService,
        private translateService: TranslateService,
        private router: Router
    ) { }

    commonProfileLoad() {
        // this.commonProfile = profile;
        this.commonProfile = this.customerSearchService.getUserProfile();
    }

    userContractLoad(userContracts: UserContractModel[]) {
        this.userContracts = userContracts;
    }

    onContractModelSelectedFromContractList(contractModel: UserContractModel) {
        this.selectedUserContractModel = contractModel;
    }


    ngOnInit() {
        this.msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
        this.customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
        this.populateConsumptionConfiguration();
        this.userContracts = this.customerSearchService.getUserContracts();
        this.commonProfileLoad();
        this.router.events.subscribe((evt) => {
            if (evt instanceof NavigationStart) {
                if (evt.url && evt.url.indexOf('#') !== -1) {
                    this.sectionScroll = evt.url.split('#')[1];
                }
            }
            if (!(evt instanceof NavigationEnd)) {
              return;
            }
            this.doScroll();
            this.sectionScroll = null;
          });
          this.eventListenerService.fetchPendingJourney();
    }

    doScroll() {

        if (!this.sectionScroll) {
          return;
        }
        try {
          const elements = document.getElementById(this.sectionScroll);
          elements.scrollIntoView();
        }
        finally {
          this.sectionScroll = null;
        }
      }


}
