import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { Component, Pipe, PipeTransform } from '@angular/core';
import { DfyComponent } from './dfy.component';
import { ProductService } from '../../services/product.service';
import { PersistenceService } from 'angular-persistence';
import { CustomerService } from '../../services/customer.service';
import { CustomizePlanOffer } from '../../interface/product';
import { of, Observable } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';

declare const alertify;
declare var jQuery: any;

const mockCurrentPlan = {
  "productId": 'CM_Combo_556',
  "productName": '50GB and Unlimited SMS and Voice Combo',
  "productType": 'Combo',
  "productGroup": 'custom',
  "price": 2500,
  "paymentMode": 'AIR',
  "productDescription": 'Roaming data 10GB',
  "srcChannel": 'SELFCARE',
  "numberOfPendingRenewals": 9998,
  "nextRenewalDate": '01-03-2019 14:30:42',
  "provisionedQuota": {
    "voice": {
      "unit": 1,
      "unitType": '0'
    },
    "sms": {
      "unit": 1,
      "unitType": '1'
    },
    "data": {
      "unit": 1,
      "unitType": '6'
    }
  },
  "availableQuota": {
    "voice": {
      "unit": 0,
      "unitType": '0'
    },
    "sms": {
      "unit": 0,
      "unitType": '1'
    },
    "data": {
      "unit": 0,
      "unitType": '6'
    }
  },
  "activationDate": '30-01-2019 14:30:00',
  "expiryDate": '01-03-2019 14:30:42',
  "isRecurring": true
}

@Component({ selector: 'app-payment-form', template: '' })
class MockPaymentFormComponent {

}

@Pipe({ name: 'valueFormatter' })
export class MockValueFormatterPipe implements PipeTransform {

  transform(value: any, args: string): any {
    value = parseFloat(value);
    return value;
  }
}

describe('DfyComponent', () => {
  let component: DfyComponent;
  let fixture: ComponentFixture<DfyComponent>;
  let productServiceSpy: jasmine.SpyObj<ProductService>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let customerServiceSpy: jasmine.SpyObj<CustomerService>;
  let translateServiceSpy: any;

  beforeEach(async(() => {
    const ProductServiceSpy = jasmine.createSpyObj('ProductService', ['getUpcomingOffers'])
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set']);
    const CustomerServiceSpy = jasmine.createSpyObj('CustomerService', ['addQuota']);
    translateServiceSpy = {
      instant: () => { },
    }

    TestBed.configureTestingModule({
      declarations: [
        DfyComponent,
        MockPaymentFormComponent,
        MockValueFormatterPipe
      ],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy },
        { provide: TranslateService, useValue: translateServiceSpy },
        { provide: CustomerService, useValue: CustomerServiceSpy }
      ]
    })
      .overrideComponent(DfyComponent, {
        set: {
          providers: [
            { provide: ProductService, useValue: ProductServiceSpy }
          ]
        }
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DfyComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
    customerServiceSpy = TestBed.get(CustomerService);
    productServiceSpy = fixture.debugElement.injector.get(ProductService) as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnInit', () => {
    it('should call getUpcomingOffers method,set the result personalisedOfferData array ', () => {
      persistenceServiceSpy.get.and.returnValue([1, 2, 3]);
      spyOn(component, 'getUpcomingOffers')

      component.ngOnInit();

      expect(component.getUpcomingOffers).toHaveBeenCalled();
      expect(component.personalisedOfferData).toEqual([1, 2, 3])
    });
  });

  describe('getUpcomingOffers', () => {
    it('should call productService.getUpcomingOffers , set the result in products array ', fakeAsync(() => {

      const mockData: CustomizePlanOffer[] = JSON.parse(JSON.stringify(mockCurrentPlan));
      productServiceSpy.getUpcomingOffers.and.returnValue(Promise.resolve(mockData))

      component.getUpcomingOffers();
      tick();

      expect(productServiceSpy.getUpcomingOffers).toHaveBeenCalled();
      expect(component.products).toEqual(mockData);
    }));

    it('should throw error when error is received from productServiceSpy.getUpcomingOffers ', fakeAsync(() => {
      productServiceSpy.getUpcomingOffers.and.returnValue(Promise.reject(new Error()))
      spyOn(alertify, 'error')

      component.getUpcomingOffers();
      tick();

      expect(productServiceSpy.getUpcomingOffers).toHaveBeenCalled();
      expect(alertify.error).toHaveBeenCalled();
    }));
  });

  describe('buyDeal', () => {
    it('should call customerService.addQuota,jQuery.modal method,On successful result from addQuota callalertify.success ', fakeAsync(() => {

      customerServiceSpy.addQuota.and.returnValue(of('Success'));
      spyOn(alertify, 'success');
      spyOn(jQuery.fn, 'modal');
      component.buyDeal('CM_Combo_556');
      tick();

      expect(alertify.success).toHaveBeenCalled();
      expect(jQuery.fn.modal).toHaveBeenCalled();
    }));

    it('should throw error when error is received from productServiceSpy.getUpcomingOffers ', fakeAsync(() => {
      customerServiceSpy.addQuota.and.returnValue(Observable.throw(new Error()));
      spyOn(alertify, 'error');

      component.buyDeal('CM_Combo_556');
      tick();

      expect(alertify.error).toHaveBeenCalled();
    }));
  });

  describe('cancelDeal', () => {
    it('should call jQuery.modal Method', () => {
      spyOn(jQuery.fn, 'modal');

      component.cancelDeal();

      expect(jQuery.fn.modal).toHaveBeenCalled();
    })
  })
});
