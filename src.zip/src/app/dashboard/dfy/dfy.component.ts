import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { Subscription } from 'rxjs';
import { cartDetails, CARTITEM, CMUICONFIGKEY, planoffer, productBucket } from 'dxp-common';
import { LOCALIZATIONPERSISTANCEKEY, WEBCONTENTPERSISTANCEKEY } from '../../../application-constants';
import { EventEnum } from '../../enum/EventEnum';
import { EventListenerService } from '../../event-listener.service';
import { WebContent } from '../../interface/web.content';
import { CartService } from '../../services/cart.service';
import { CustomerSearchService } from '../../services/customer-search.service';
import { DealsForYouService } from '../../services/dfy.service';
import { ProductService } from '../../services/product.service';


declare const alertify;
declare var jQuery: any;


@Component({
    selector: 'app-dfy',
    templateUrl: './dfy.component.html',
    styleUrls: ['./dfy.component.scss'],
    encapsulation: ViewEncapsulation.None,
    providers: [ProductService]
})
export class DfyComponent implements OnInit, OnDestroy {

    order1: number;
    contractActive = true; // checks if contract is active
    showrecommendation = false; // check if to show recommendations or not
    currentSelection = null; // selected addon/deal
    searchKey = '';
    recommendationList: any = []; // raw recommendations
    slidesRecommend: any[]; // recommendations coverted to 2d array
    slides: any = [[]]; // deals coverted to 2d array

    languageChange: Subscription;
    webContent: WebContent;
    bottomRightImageURL: string;
    public currentContract: any;
    public userProfile: any;
    public planList: any;

    // public planList2:any;
    public tempPlanList: any;
    // sortByMinMax: Array<any>;

    // public offerType:any;
    public offerList: any = [];



    public sortByMinMax;
    public serviceNames;
    private selectedAddOns;
    quantityMap: any = {};


    constructor(private router: Router,
        private persistenceService: PersistenceService,
        private translate: TranslateService,
        private event: EventListenerService,
        private dealsForYouService: DealsForYouService,
        private customerSearchService: CustomerSearchService,
        private cartService: CartService) {
        this.serviceNames = this.dealsForYouService.productBucketArray;
    }

    createQuantityMap(products) {
        this.cartService.createQuantityMap();
    }

    getQuantity(name) {
        return this.cartService.getQuantity(name);
    }

    ngOnDestroy() {
        this.languageChange.unsubscribe();
        if (this.cartService.cartDetails && this.cartService.cartDetails.cartList.length === 0) {
            this.dealsForYouService.deleteJourneySessionData(this.dealsForYouService.journeySessionId).subscribe(result => {
                this.event.fetchPendingJourney();
            }, error => {
                console.log('Journey Data Not Deleted');
            });
          } else if (this.cartService.cartDetails && this.cartService.cartDetails.id) {
            this.cartService.cartDetails = null;
            this.event.notifyCartUpdate(this.cartService.cartDetails);
        }
    }

    ngOnInit() {
        this.cartService.cartDetails = null;
        this.event.notifyCartUpdate(this.cartService.cartDetails);
        this.cartService.quantityMap = {};

        this.planList = [];

        // this.productMaxVisibleItems = this.persistenceService.get(CMUICONFIGKEY.NUMBEROFADDONSPERPAGE, StorageType.SESSION);
        this.webContent = this.persistenceService.get(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, StorageType.SESSION);
        if (this.webContent && this.webContent.bottomRightImage) {
            this.bottomRightImageURL = this.webContent.bottomRightImage.url;
        }

        // on language update
        this.languageChange = this.event.lanuageChangeEvent.subscribe(data => {
            if (data && data.isUserSelected && data.eventType && data.eventType === EventEnum.languageUpdated) {
                this.loadPlans();
                this.loadSortData();
            }
        });

        this.event.dfySearchChangeEvent.subscribe(data => {
            if (data && data.eventType && data.eventType === EventEnum.dfySearchChange) {
                this.searchKey = data.searchStr;
            }
        });

        this.event.dfySortChangeEvent.subscribe(data => {
            if (data && data.eventType && data.eventType === EventEnum.dfySortChange) {
                this.renderSearch(data.sortStr);
            }
        });

        this.event.notifyCartUpdateEvent.subscribe((data) => {
            if (data && data.eventType) {
                if (data.eventType === EventEnum.notifyCartUpdated) {
                    if (data.cartDetails) {
                        this.prefillAddOnFromCart(data.cartDetails);
                    }
                }
            }
        });

        this.currentContract = this.customerSearchService.getCurrentContract();
        this.userProfile = this.customerSearchService.getUserProfile();
        this.loadPlans();
        this.loadSortData();


    }

    chunk(arr, chunkSize) {
        const R = [];
        for (let i = 0, len = arr.length; i < len; i += chunkSize) {
            R.push(arr.slice(i, i + chunkSize));
        }
        return R;
    }

    async addToCart(productItem) {
        let createSaveCart = true;
       // this.notificationCount++;
        if (this.cartService.cartDetails && this.cartService.cartDetails.id) {
          createSaveCart = false;
        }
        const contractDetails = this.customerSearchService.getCurrentContract();
        const userProfile = this.customerSearchService.getUserProfile();
        const cartInfo = await this.dealsForYouService.addToCart(productItem, contractDetails, userProfile).toPromise();
        const cartDetails: cartDetails = await this.cartService.getCartDetails().toPromise();
        const saveCart = await this.dealsForYouService.createSaveCartJourney(contractDetails, cartDetails, userProfile, null, createSaveCart).toPromise();
        alertify.success(this.translate.instant('Added to cart'));
        this.event.notifyCartUpdate(cartDetails);
    }

    renderSearch(event) {
        let resultArray = [];
        let list = this.slides;

        for (let i = 0; i < list.length; i++) {
            for (let j = 0; j < list[i].length; j++) {
                resultArray.push(list[i][j]);
            }
        }

        let temp = resultArray.sort((a, b) => {
            return ((a.productOfferingPrice) < (b.productOfferingPrice)) ? (1 * event) : (-1 * event);
        });
        this.slides = this.chunk(temp, 4);
///sort simialr offer

        if (this.slidesRecommend && this.slidesRecommend.length != 0) {
            let resultArrayrecommend = [];
            let listrecommend = this.slidesRecommend;

            for (let i = 0; i < listrecommend.length; i++) {
                for (let j = 0; j < listrecommend[i].length; j++) {
                    resultArrayrecommend.push(listrecommend[i][j]);
                }
            }

            let temprecommend = resultArrayrecommend.sort((a, b) => {
                return ((a.productOfferingPrice) < (b.productOfferingPrice)) ? (1 * event) : (-1 * event);
            });
            this.slidesRecommend = this.chunk(temprecommend, 4);

        }
    }
    async loadPlans() {

        const lang = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
        let addOns = this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMES_FORADDONQUERY, StorageType.SESSION);

        const planData = await this.dealsForYouService.getPlanAddonsDetails(lang, addOns, this.userProfile).toPromise();
        const planWithDigitalData = await this.dealsForYouService.getCMSDigitalAssets(planData, lang, addOns).toPromise();

        try {
            this.offerList = await this.dealsForYouService.loadPromotedOffers().toPromise();
        } catch (error) {
            // alertify.error('No Recommended Offers');
        }


        const plansAddOnDataAllItems = planData.map((item) => {
            let isItemInCMS = planWithDigitalData.filter(x => x.id === item.id);
            let CMSOffer: planoffer;
            if (isItemInCMS && isItemInCMS[0]) {
                CMSOffer = isItemInCMS[0];
            }
            else {
                CMSOffer = {
                    "deal": false,
                    "title": item.name || "",
                    "summary": item.description || "",
                    "coverImage": "assets/imgs/no-image-icon.png",
                    "frontImage": "",
                    "backImage": "",
                    "id": item['id'] || "",
                    "name": item['name'] || "",
                    "description": item.description || "",

                    "offerType": item['offerType'] || "",

                    "productOfferingPrice": item['productOfferingPrice']
                    && item['productOfferingPrice']['0']
                    && item['productOfferingPrice']['0']['price']
                    && item['productOfferingPrice']['0']['price']['amount']
                    ? item['productOfferingPrice']['0']['price']['amount'] : 0,
                    "priceType": item['productOfferingPrice']
                    && item['productOfferingPrice']['0']
                    && item['productOfferingPrice']['0']['priceType']
                    ? item['productOfferingPrice']['0']['priceType'] : null,
                    "productBuckets": item['productBuckets'] ?
                        item['productBuckets'].map(item => {
                            const productBucket: productBucket = this.dealsForYouService.calculateDisplay(item);
                            return productBucket;
                        }) : null,

                        periodTypes: item['productOfferingPrice']
                        && item['productOfferingPrice']['0']
                        && item['productOfferingPrice']['0']['recurrencePeriod']
                        && item['productOfferingPrice']['0']['recurrencePeriod']['periodType']
                        ? item['productOfferingPrice']['0']['recurrencePeriod']['periodType'] : null,
                    recurrencePeriod: item['productOfferingPrice']
                        && item['productOfferingPrice']['0']
                        && item['productOfferingPrice']['0']['recurrencePeriod']
                        ? item['productOfferingPrice']['0']['recurrencePeriod'] : null,
                    currency: item['productOfferingPrice']
                        && item['productOfferingPrice']['0']
                        && item['productOfferingPrice']['0']['price']
                        && item['productOfferingPrice']['0']['price']['currency'] ?
                        item['productOfferingPrice']['0']['price']['currency']
                        : null
                }
            }
            return CMSOffer;
        });
        this.planList = [...plansAddOnDataAllItems];

        this.planList.forEach(plan => {
            if (this.offerList.indexOf(plan.id) != -1) {
                plan["deal"] = true;
            }
        });

        this.planList.sort((x, y) => {
            if (x.deal < y.deal) {
                return 1;
            }
            if (x.deal > y.deal) {
                return -1;
            }
            return 0;
        });
        this.slides = this.chunk(this.planList, 4);
    }


    async showrecommendations(card, showrecommendation) {
        this.currentSelection = card.name;

        this.recommendationList = [];
        let recommendationListIds = [];
        try {
            recommendationListIds = await this.dealsForYouService.loadRecommendedOffers(card.id).toPromise();

            for (let i = 0; i < recommendationListIds.length; i++) {
                let addon = this.planList.filter((plan) => {
                    return plan.id == recommendationListIds[i].productOfferID;
                });
                if (addon.length != 0) {
                    this.recommendationList.push(addon[0]);
                }


            }
            if (this.recommendationList.length != 0) {
                this.slidesRecommend = this.chunk(this.recommendationList, 4);
                this.showrecommendation = showrecommendation;
            } else {
                this.showrecommendation = false;
            }
        } catch (error) {
            this.showrecommendation = false;
            // alertify.error('No Similar Offers');
        }
    }

    loadSortData() {
        const sortData = [
            { value: -1, label: this.translate.instant('Price(min-max)') },
            { value: 1, label: this.translate.instant('Price(max-min)') }
        ];
        this.sortByMinMax = [...sortData];
    }

    redirectTo(route) {
        this.router.navigate(route.split('/'));
    }


    public searchProductText: string = "";




    selectedValue = -1;


    private prefillAddOnFromCart(cartDetails: cartDetails) {
        this.selectedAddOns = cartDetails.cartList.filter(x => x.productOffering.offerType === CARTITEM.ADDON);
        this.quantityMap = {};
        this.createQuantityMap(cartDetails.cartList);
        
    }

    
}

