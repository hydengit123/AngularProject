import { Component, Input, Pipe, PipeTransform } from '@angular/core';
import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormBuilder, FormsModule, NG_VALUE_ACCESSOR, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService } from 'angular-persistence';
import * as moment from 'moment';
import { Observable } from 'rxjs';
import { EventListenerService } from '../../event-listener.service';
import { CustomizePlanOffer } from '../../interface/product';
import { mockDataAvailable, mockDataProvisoned, mockSMSAvailable, mockSMSProvisoned, mockVoiceAvailable, mockVoiceProvisoned } from '../../mockData';
import { CustomerService } from '../../services/customer.service';
import { ProductService } from '../../services/product.service';
import { UtilService } from '../../services/util.service';
import { HomeComponent } from './home.component';
declare const alertify;
declare var jQuery: any;

const mockSubscriptionDetail: any = {
  msisdn: '4622378109', products: [{
    'productId': 'CM_Combo_556',
    'productName': '50GB and Unlimited SMS and Voice Combo',
    'productType': 'Combo',
    'productGroup': 'Premium',
    'price': 2500,
    'paymentMode': 'AIR',
    'srcChannel': 'SELFCARE',
    'numberOfPendingRenewals': 9998,
    'nextRenewalDate': '01-03-2019 14:30:42',
    'provisionedQuota': {
      'voice': {
        'unit': -1,
        'unitType': '0'
      },
      'sms': {
        'unit': -1,
        'unitType': '1'
      },
      'data': {
        'unit': 53687091200,
        'unitType': '6'
      }
    },
    'availableQuota': {
      'voice': {
        'unit': -1,
        'unitType': '0'
      },
      'sms': {
        'unit': -1,
        'unitType': '1'
      },
      'data': {
        'unit': 53687091200,
        'unitType': '6'
      }
    },
    'activationDate': '30-01-2019 14:30:00',
    'expiryDate': '01-03-2019 14:30:42',
    'isRecurring': true
  },
  {
    'productId': 'CM_Combo_574',
    'productName': 'Roaming data 10gb 1000mins 1000sms',
    'productType': 'Combo',
    'productGroup': 'Addon',
    'price': 2500,
    'paymentMode': 'AIR',
    'srcChannel': 'SELFCARE',
    'numberOfPendingRenewals': 0,
    'nextRenewalDate': '01-03-2019 14:30:00',
    'provisionedQuota': {
      'voice': {
        'unit': 60000,
        'unitType': '0'
      },
      'sms': {
        'unit': 1000,
        'unitType': '1'
      },
      'data': {
        'unit': 10737418240,
        'unitType': '6'
      }
    },
    'availableQuota': {
      'voice': {
        'unit': 60000,
        'unitType': '0'
      },
      'sms': {
        'unit': 1000,
        'unitType': '1'
      },
      'data': {
        'unit': 10737418240,
        'unitType': '6'
      }
    },
    'activationDate': '30-01-2019 14:30:43',
    'expiryDate': '01-03-2019 14:30:00',
    'isRecurring': false
  }]
};

const mockCurrentPlan = {
  "productId": "CM_Combo_556",
  "productName": "50GB and Unlimited SMS and Voice Combo",
  "productType": "Combo",
  "productGroup": "Premium",
  "price": 2500,
  "paymentMode": "AIR",
  "srcChannel": "SELFCARE",
  "numberOfPendingRenewals": 9998,
  "nextRenewalDate": "01-03-2019 14:30:42",
  "provisionedQuota": {
    "voice": {
      "unit": 1,
      "unitType": "0"
    },
    "sms": {
      "unit": 1,
      "unitType": "1"
    },
    "data": {
      "unit": 1,
      "unitType": "6"
    }
  },
  "availableQuota": {
    "voice": {
      "unit": 0,
      "unitType": "0"
    },
    "sms": {
      "unit": 0,
      "unitType": "1"
    },
    "data": {
      "unit": 0,
      "unitType": "6"
    }
  },
  "activationDate": "30-01-2019 14:30:00",
  "expiryDate": "01-03-2019 14:30:42",
  "isRecurring": true
}

@Pipe({ name: 'valueFormatter' })
class MockValueFormatterPipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}
@Pipe({ name: 'translate' })
class MockTranslatePipe implements PipeTransform {
  transform(value: number): number {
    return value;
  }
}

@Component({ selector: 'app-water-glass', template: '' })
class MockWaterGlassComponent {
  @Input() provisioned = 0;
  @Input() available = 0;
  @Input() colorscheme;
}

@Component({ selector: 'app-payment-form', template: '' })
class MockPaymentFormComponent {
  @Input() cardType = '';
}

@Component({
  selector: 'nouislider',
  template: '',
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: MockNoUiSliderComponent, multi: true },
  ]
})
class MockNoUiSliderComponent {
  @Input() min = '';
  @Input() max = '';
  @Input() step = '';

  writeValue() { }
  registerOnChange() { }
  registerOnTouched() { }
}

@Component({ selector: 'app-common-add-modal', template: '' })
class MockAppCommonAddModalComponent {
  @Input() type = '';
}

@Component({ selector: 'app-common-share-modal', template: '' })
class MockAppCommonShareModalComponent {
  @Input() type = '';
}

@Component({ selector: 'app-common-transfer-modal', template: '' })
class MockAppCommonShareTransferComponent {
  @Input() type = '';
}

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let productServiceSpy: jasmine.SpyObj<ProductService>;
  let utilServiceSpy: jasmine.SpyObj<UtilService>;
  let customerServiceSpy: jasmine.SpyObj<CustomerService>;
  let eventListenerServiceSpy: jasmine.SpyObj<EventListenerService>;
  let translateServiceSpy: any;

  beforeEach(async(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set']);
    const ProductServiceSpy = jasmine.createSpyObj('ProductService', ['getUpcomingOffers']);
    const UtilServiceSpy = jasmine.createSpyObj('UtilService', ['getCustomerPlanFromSubscription']);
    const CustomerServiceSpy = jasmine.createSpyObj('CustomerService', ['getAggregatedSubscription', 'getSubscriptionDetail', 'recharge', 'transferCreditBalance', 'removeAddon']);
    const EventListenerServiceSpy = jasmine.createSpyObj('EventListenerService', ['customerDataChanges', 'addToMainBalance', 'removeFromMainBalance']);
    EventListenerServiceSpy['balanceEvent'] = { 'subscribe': (c) => { c('data') } };
    translateServiceSpy = {
      instant: () => { },
    }

    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        ReactiveFormsModule
      ],
      declarations: [
        HomeComponent,
        MockValueFormatterPipe,
        MockWaterGlassComponent,
        MockPaymentFormComponent,
        MockNoUiSliderComponent,
        MockAppCommonAddModalComponent,
        MockAppCommonShareModalComponent,
        MockAppCommonShareTransferComponent,
        MockTranslatePipe
      ],
      providers: [
        { provide: PersistenceService, useValue: PersistenceServiceSpy },
        { provide: EventListenerService, useValue: EventListenerServiceSpy },
        FormBuilder
      ]
    }).overrideComponent(HomeComponent, {
      set: {
        providers: [
          { provide: UtilService, useValue: UtilServiceSpy },
          { provide: ProductService, useValue: ProductServiceSpy },
          { provide: TranslateService, useValue: translateServiceSpy },
          { provide: CustomerService, useValue: CustomerServiceSpy }
        ]
      }
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    persistenceServiceSpy = TestBed.get(PersistenceService);
    eventListenerServiceSpy = TestBed.get(EventListenerService);
    productServiceSpy = fixture.debugElement.injector.get(ProductService) as any;
    utilServiceSpy = fixture.debugElement.injector.get(UtilService) as any;
    customerServiceSpy = fixture.debugElement.injector.get(CustomerService) as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call onResult1 and getAggregatedSubscription methods from ngOnInit when MSISDN is present', () => {
    persistenceServiceSpy.get.and.returnValue([1, 2]);
    customerServiceSpy.getAggregatedSubscription.and.returnValue(Observable.of({ mainBalance: { 'unit': 1, 'expiryDate': '01/01/2019' } }));
    spyOn(component, 'onResult1').and.callFake(() => { });
    spyOn(component, 'getAggregatedSubscription').and.callFake(() => { });
    spyOn(component, 'getSubscriptionDetail').and.callFake(() => { });
    spyOn(component, 'initChart').and.callFake(() => { });
    spyOn(component, 'getUpcomingOffers').and.callFake(() => { });

    fixture.detectChanges();

    expect(component.onResult1).toHaveBeenCalled();
    expect(component.getAggregatedSubscription).toHaveBeenCalled();
    expect(component.getSubscriptionDetail).toHaveBeenCalled();
    expect(component.initChart).toHaveBeenCalled();
    expect(component.getUpcomingOffers).toHaveBeenCalled();
  })

  it('should not call onResult1 method from ngOnInit when MSISDN is not present', () => {
    persistenceServiceSpy.get.and.returnValue(undefined);
    customerServiceSpy.getAggregatedSubscription.and.returnValue(Observable.of({ mainBalance: { 'unit': 1, 'expiryDate': '01/01/2019' } }));
    spyOn(component, 'onResult1').and.callFake(() => { });
    spyOn(component, 'getAggregatedSubscription').and.callFake(() => { });
    spyOn(component, 'getSubscriptionDetail').and.callFake(() => { });
    spyOn(component, 'initChart').and.callFake(() => { });
    spyOn(component, 'getUpcomingOffers').and.callFake(() => { });

    fixture.detectChanges();

    expect(component.onResult1).not.toHaveBeenCalled();
    expect(component.getAggregatedSubscription).toHaveBeenCalled();
    expect(component.getSubscriptionDetail).toHaveBeenCalled();
    expect(component.initChart).toHaveBeenCalled();
    expect(component.getUpcomingOffers).toHaveBeenCalled();
  })

  it('onResult1 method should set main balance to persistance service when not present already and should reset bar, transfer and mainBalance', () => {
    persistenceServiceSpy.get.and.returnValue(undefined);

    component.onResult1({ mainBalance: { 'unit': 1, 'expiryDate': '31/01/2019' } });

    expect(persistenceServiceSpy.set).toHaveBeenCalled();
    expect(component.maxCreditBalance).toEqual(0.01);
    expect(component.bar).toEqual(0);
    expect(component.transfer).toEqual('');
    expect(component.mainBalance).toEqual({ 'unit': 0 });
  });


  it('getAggregatedSubscription should call customerService.getAggregatedSubscription method and then call onResult method', () => {
    customerServiceSpy.getAggregatedSubscription.and.callFake(() => {
      return Observable.of({ mainBalance: { 'unit': 1, 'expiryDate': '31/01/2019' } })
    });
    spyOn(component, 'onResult');

    component.getAggregatedSubscription('123456');

    expect(customerServiceSpy.getAggregatedSubscription).toHaveBeenCalled();
    expect(component.onResult).toHaveBeenCalled();
  });

  it('getAggregatedSubscription should call customerService.getAggregatedSubscription method and then call onError method', () => {
    customerServiceSpy.getAggregatedSubscription.and.callFake(() => {
      return Observable.throw(new Error());
    });
    spyOn(component, 'onError');

    component.getAggregatedSubscription('123456');

    expect(customerServiceSpy.getAggregatedSubscription).toHaveBeenCalled();
    expect(component.onError).toHaveBeenCalled();
  });

  describe('getSubscriptionDetail method', () => {
    it('should call customerService.getSubscriptionDetail method for provided msisdn, should call setAvailableQuota method with arguments(0, 0, 0), should call setProvisionedQuota method with units according to current plan, should filter expired products', () => {
      const currentPlan = JSON.parse(JSON.stringify(mockCurrentPlan));
      const subscriptionDetail = JSON.parse(JSON.stringify(mockSubscriptionDetail));
      persistenceServiceSpy.get.and.returnValue('123456');
      customerServiceSpy.getSubscriptionDetail.and.returnValue(Observable.of(subscriptionDetail));
      utilServiceSpy.getCustomerPlanFromSubscription.and.returnValue(currentPlan);
      spyOn(component, 'setAvailableQuota');
      spyOn(component, 'setProvisionedQuota');
      spyOn(component, 'getOtherPurchases');

      component.getSubscriptionDetail();

      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(utilServiceSpy.getCustomerPlanFromSubscription).toHaveBeenCalled();
      expect(component.setAvailableQuota).toHaveBeenCalledWith(0, 0, 0);
      expect(component.setProvisionedQuota).toHaveBeenCalledWith(1, 1, 1);
      // expect(component.addOns.length).toBe(1);
      // expect(component.addOns[0].productId).toBe('CM_Combo_574');
      expect(component.getOtherPurchases).toHaveBeenCalled();
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
    });

    it('should call setAvailableQuota method with arguments according to current plan and should call setProvisionedQuota method with units (-1, -1, -1)', () => {
      const currentPlan = JSON.parse(JSON.stringify(mockCurrentPlan));
      const subscriptionDetail = JSON.parse(JSON.stringify(mockSubscriptionDetail));
      currentPlan.provisionedQuota = null;
      currentPlan.availableQuota.voice.unit = 11;
      currentPlan.availableQuota.sms.unit = 22;
      currentPlan.availableQuota.data.unit = 33;
      persistenceServiceSpy.get.and.returnValue('123456');
      customerServiceSpy.getSubscriptionDetail.and.returnValue(Observable.of(subscriptionDetail));
      utilServiceSpy.getCustomerPlanFromSubscription.and.returnValue(currentPlan);
      spyOn(component, 'setAvailableQuota');
      spyOn(component, 'setProvisionedQuota');
      spyOn(component, 'getOtherPurchases');

      component.getSubscriptionDetail();

      expect(component.setAvailableQuota).toHaveBeenCalledWith(33, 11, 22);
      expect(component.setProvisionedQuota).toHaveBeenCalledWith(-1, -1, -1);
    });

    it('should call setAvailableQuota method with arguments (-1, -1, -1) when available quota according to current plan is null', () => {
      const currentPlan = JSON.parse(JSON.stringify(mockCurrentPlan));
      const subscriptionDetail = JSON.parse(JSON.stringify(mockSubscriptionDetail));
      currentPlan.provisionedQuota = null;
      currentPlan.availableQuota = null;
      persistenceServiceSpy.get.and.returnValue('123456');
      customerServiceSpy.getSubscriptionDetail.and.returnValue(Observable.of(subscriptionDetail));
      utilServiceSpy.getCustomerPlanFromSubscription.and.returnValue(currentPlan);
      spyOn(component, 'setAvailableQuota');
      spyOn(component, 'setProvisionedQuota');
      spyOn(component, 'getOtherPurchases');

      component.getSubscriptionDetail();

      expect(component.setAvailableQuota).toHaveBeenCalledWith(-1, -1, -1);
    });

    it('should call setAvailableQuota and setProvisionedQuota methods when current plan is not defined', () => {
      const subscriptionDetail = JSON.parse(JSON.stringify(mockSubscriptionDetail));
      persistenceServiceSpy.get.and.returnValue('123456');
      customerServiceSpy.getSubscriptionDetail.and.returnValue(Observable.of(subscriptionDetail));
      utilServiceSpy.getCustomerPlanFromSubscription.and.returnValue(null);
      spyOn(component, 'setAvailableQuota');
      spyOn(component, 'setProvisionedQuota');
      spyOn(component, 'getOtherPurchases');

      component.getSubscriptionDetail();

      expect(component.setAvailableQuota).toHaveBeenCalledWith(mockDataAvailable, mockVoiceAvailable, mockSMSAvailable);
      expect(component.setProvisionedQuota).toHaveBeenCalledWith(mockDataProvisoned, mockVoiceProvisoned, mockSMSProvisoned);
    });

    it('should call setAvailableQuota and setProvisionedQuota methods when customerService.getSubscriptionDetail throws an Error', () => {
      persistenceServiceSpy.get.and.returnValue('123456');
      customerServiceSpy.getSubscriptionDetail.and.returnValue(Observable.throw(new Error()));
      utilServiceSpy.getCustomerPlanFromSubscription.and.returnValue(null);
      spyOn(component, 'setAvailableQuota');
      spyOn(component, 'setProvisionedQuota');
      spyOn(component, 'getOtherPurchases');

      component.getSubscriptionDetail();

      expect(component.setAvailableQuota).toHaveBeenCalledWith(mockDataAvailable, mockVoiceAvailable, mockSMSAvailable);
      expect(component.setProvisionedQuota).toHaveBeenCalledWith(mockDataProvisoned, mockVoiceProvisoned, mockSMSProvisoned);
    });

  });

  describe('setAvailableQuota method', () => {
    it('should set data, voice and sms quantities on component and should not set availableQuota on persistance service when already available there', () => {
      const availableQuota = {
        'voice': {
          'unit': -1,
          'unitType': '0'
        },
        'sms': {
          'unit': -1,
          'unitType': '1'
        },
        'data': {
          'unit': 53687091200,
          'unitType': '6'
        }
      };
      const data = 2;
      const voice = 3;
      const sms = 4;
      persistenceServiceSpy.get.and.returnValue(availableQuota);
      eventListenerServiceSpy.customerDataChanges.and.callFake(() => { });

      component.setAvailableQuota(data, voice, sms);

      expect(component.data).toEqual(2);
      expect(component.voice).toEqual(3);
      expect(component.sms).toEqual(4);
      expect(persistenceServiceSpy.set).not.toHaveBeenCalled();
      expect(eventListenerServiceSpy.customerDataChanges).toHaveBeenCalledWith(data, voice, sms);
    });

    it('should set data, voice and sms quantities on component and should set availableQuota on persistance service when not available already there', () => {
      const data = 2;
      const voice = 3;
      const sms = 4;
      persistenceServiceSpy.get.and.returnValue(null);
      eventListenerServiceSpy.customerDataChanges.and.callFake(() => { });

      component.setAvailableQuota(data, voice, sms);

      expect(component.data).toEqual(2);
      expect(component.voice).toEqual(3);
      expect(component.sms).toEqual(4);
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
    });
  });

  describe('setProvisionedQuota method', () => {
    it('should set data, voice and sms quantities on component and should not set provisionedQuota on persistance service when available already  there', () => {
      const provisionedQuota = {
        'voice': {
          'unit': -1,
          'unitType': '0'
        },
        'sms': {
          'unit': -1,
          'unitType': '1'
        },
        'data': {
          'unit': 53687091200,
          'unitType': '6'
        }
      };
      const data = 2;
      const voice = 3;
      const sms = 4;
      persistenceServiceSpy.get.and.returnValue(provisionedQuota);

      component.setAvailableQuota(data, voice, sms);

      expect(component.data).toEqual(2);
      expect(component.voice).toEqual(3);
      expect(component.sms).toEqual(4);
      expect(persistenceServiceSpy.set).not.toHaveBeenCalled();
    });

    it('should set data, voice and sms quantities on component and should set provisionedQuota on persistance service when not available already  there', () => {
      const data = 2;
      const voice = 3;
      const sms = 4;
      persistenceServiceSpy.get.and.returnValue(null);
      eventListenerServiceSpy.customerDataChanges.and.callFake(() => { });

      component.setAvailableQuota(data, voice, sms);

      expect(component.data).toEqual(2);
      expect(component.voice).toEqual(3);
      expect(component.sms).toEqual(4);
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
    });
  });

  it('getOtherPurchases method should set upcommingOffer which are not available in prductGrouplist and should set it on persistamce service', () => {
    const products = JSON.parse(JSON.stringify(mockSubscriptionDetail.products));
    products[0].productGroup = 'NewPremium';

    component.getOtherPurchases(products);

    expect(persistenceServiceSpy.set).toHaveBeenCalled();
    expect(component.upcommingOffer.length).toBe(1);
  });

  it('initChart method should call generateRandomArray and then createGraphSet', () => {
    spyOn(component, 'createGraphSet');
    spyOn(component, 'generateRandomArray');
    component.username = 'Test_User';

    component.initChart();

    expect(component.createGraphSet).toHaveBeenCalled();
    expect(component.generateRandomArray).toHaveBeenCalled()
  });

  it('createGraphSet method should create chart', () => {
    expect(component.chart).toBeUndefined();

    const labels: string[] = [];
    let currentDate = new Date();
    for (let i = 0; i < 6; i++) {
      const label = moment(currentDate).format('DD-MM-YY');
      labels.push(label);
      currentDate = new Date(new Date().setDate(currentDate.getDate() - 1));
    }
    labels.reverse();

    component.createGraphSet(component.canvasRef1.nativeElement, labels, [], 'rgba(0,199,154,0.8)', 'Data(GB)');

    expect(component.chart).toBeDefined();
  });

  it('generateRandomArray should generate random array with length specified as limit', () => {
    const data: number[] = component.generateRandomArray(4);
    expect(data.length).toEqual(4);
  });

  it('getUpcomingOffers call success method when data is returned from product service', fakeAsync(() => {
    const customOffer: CustomizePlanOffer[] = [{ productId: '1', productName: 'AA', productType: 'New', productGroup: 'group', productDescription: 'Description', productValidityDays: 30, productStatus: 'Status', quota: undefined, price: 1, issharedaccount: false, isSplit: false, isRecurring: false, BuyForOther: false, isSelected: true }];
    productServiceSpy.getUpcomingOffers.and.returnValue(Promise.resolve(customOffer));

    component.getUpcomingOffers();
    tick();
    expect(productServiceSpy.getUpcomingOffers).toHaveBeenCalled();
  }));

  it('getUpcomingOffers call error method when promise is rejected', fakeAsync(() => {

    productServiceSpy.getUpcomingOffers.and.returnValue(Promise.reject(new Error('falied!')));
    spyOn(console, 'log');

    component.getUpcomingOffers();
    tick();

    expect(productServiceSpy.getUpcomingOffers).toHaveBeenCalled();
    expect(console.log).toHaveBeenCalled();
  }));

  it('tabSelectionHandler method should set tabSelection as selected', () => {
    expect(component.tabSelection).toBe('addOn');

    component.tabSelectionHandler('otherPurchases');

    expect(component.tabSelection).toBe('otherPurchases');

    component.tabSelectionHandler('addOn');

    expect(component.tabSelection).toBe('addOn');
  });

  it('onResult method should set main balance to persistance service when not present already and should reset bar and transfer', () => {
    persistenceServiceSpy.get.and.returnValue(undefined);

    component.onResult({ mainBalance: { 'unit': 1, 'expiryDate': '31/01/2019' } });

    expect(persistenceServiceSpy.set).toHaveBeenCalled();
    expect(component.maxCreditBalance).toEqual(0.01);
    expect(component.bar).toEqual(0);
    expect(component.transfer).toEqual('');
    expect(component.mainBalance).toEqual({ 'unit': 1, 'expiryDate': '31/01/2019' });
  });

  it('onError method should call onResult method', () => {
    spyOn(component, 'onResult');

    component.onError('Error');

    expect(component.onResult).toHaveBeenCalled();
  });

  it('makePlanboxActive method should set values of isDataPlanboxSelected, isMinutesPlanboxSelected and isSmsPlanboxSelected', () => {
    component.makePlanboxActive('DATA');

    expect(component.isDataPlanboxSelected).toBeTruthy();
    expect(component.isMinutesPlanboxSelected).toBeFalsy();
    expect(component.isSmsPlanboxSelected).toBeFalsy();

    component.makePlanboxActive('MINUTES');

    expect(component.isDataPlanboxSelected).toBeFalsy();
    expect(component.isMinutesPlanboxSelected).toBeTruthy();
    expect(component.isSmsPlanboxSelected).toBeFalsy();

    component.makePlanboxActive('SMS');

    expect(component.isDataPlanboxSelected).toBeFalsy();
    expect(component.isMinutesPlanboxSelected).toBeFalsy();
    expect(component.isSmsPlanboxSelected).toBeTruthy();
  });

  it('selectAddOn method should set selectedAddOn as passed to it', () => {
    const data = { isSelected: false };
    component['selectedAddOn'] = {
      isSelected: true
    }
    component.selectAddOn(data);

    expect(component.selectedAddOn).toEqual(data);
    expect(component.selectedAddOn.isSelected).toBeTruthy()
  });

  it('setActive method should set activeDataSet as passed to it', () => {
    component.setActive(1);
    expect(component.activeDataSet).toEqual(1);

    component.setActive(2);
    expect(component.activeDataSet).toEqual(2);
  });

  describe('addCreditBalance method', () => {
    it(' should call eventListenerService.addToMainBalance and set activeDataSet to be 0', fakeAsync(() => {
      customerServiceSpy.recharge.and.returnValue(Promise.resolve('Mock String'));
      spyOn(alertify, 'success');
      eventListenerServiceSpy.addToMainBalance.and.callFake(() => { });

      component.addCreditBalance();
      tick();
      expect(alertify.success).toHaveBeenCalled();
      expect(eventListenerServiceSpy.addToMainBalance).toHaveBeenCalledWith(0);
      expect(component.activeDataSet).toEqual(0);
    }));

    it('should catch error from customerServiceSpy.recharge when promise is rejected', fakeAsync(() => {
      customerServiceSpy.recharge.and.returnValue(Promise.reject('Error'));
      spyOn(alertify, 'error');

      component.addCreditBalance();
      tick();

      expect(alertify.error).toHaveBeenCalled();
    }));
  });

  describe('transferCreditBalance method', () => {
    it('should call alertify.success when promise is resolved at customerServiceSpy.transferCreditBalance', () => {
      component.benmsisdn = 20;
      component.msisdn = 30;
      component.transfer = 10;
      customerServiceSpy.transferCreditBalance.and.returnValue(Observable.of('Credited Balalnce'));
      spyOn(alertify, 'success');
      eventListenerServiceSpy.removeFromMainBalance.and.callFake(() => { });
      spyOn(jQuery.fn, 'modal');

      component.transferCreditBalance();

      expect(alertify.success).toHaveBeenCalled();
      expect(eventListenerServiceSpy.removeFromMainBalance).toHaveBeenCalledWith(1000);
      expect(jQuery.fn.modal).toHaveBeenCalled();

    });

    it('should call alertify.error when promise is rejected from customerServiceSpy.transferCreditBalance', () => {
      component.benmsisdn = 20;
      component.msisdn = 30;
      component.transfer = 10;
      customerServiceSpy.transferCreditBalance.and.returnValue(Observable.throw(new Error('Error')));
      spyOn(alertify, 'error');
      eventListenerServiceSpy.removeFromMainBalance.and.callFake(() => { });
      spyOn(jQuery.fn, "modal");

      component.transferCreditBalance();

      expect(alertify.error).toHaveBeenCalled();
      expect(eventListenerServiceSpy.removeFromMainBalance).toHaveBeenCalledWith(1000);
      expect(jQuery.fn.modal).toHaveBeenCalled();
    });
  });

  describe('confirmRemoveAddon method', () => {
    it('should call alertify.success and should remove product from addOns', () => {
      component.msisdn = '123456';
      component.addOns = JSON.parse(JSON.stringify(mockSubscriptionDetail.products));
      customerServiceSpy.removeAddon.and.returnValue(Observable.of('Success'));
      persistenceServiceSpy.set.and.callFake(() => { });
      spyOn(alertify, 'success');

      component.confirmRemoveAddon(0);

      expect(component.addOns.length).toBe(1);
      expect(alertify.success).toHaveBeenCalled();
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
    });

    it('should call alertify.error when error is received from customerService.removeAddon', () => {
      component.msisdn = '123456';
      component.addOns = JSON.parse(JSON.stringify(mockSubscriptionDetail.products));
      customerServiceSpy.removeAddon.and.returnValue(Observable.throw(new Error('Error')));
      spyOn(alertify, 'error');

      component.confirmRemoveAddon(0);

      expect(alertify.error).toHaveBeenCalled();
    });
  });

  describe('confirmRemoveDeals method', () => {
    it('should remove product from upcommingOffer and set upcommingOffer to persistanceService when removeAddon is successfull', () => {
      component.msisdn = '123456';
      component.upcommingOffer = JSON.parse(JSON.stringify(mockSubscriptionDetail.products));
      customerServiceSpy.removeAddon.and.returnValue(Observable.of('Success'));
      persistenceServiceSpy.set.and.callFake(() => { });
      spyOn(alertify, 'success');

      component.confirmRemoveDeals(0);

      expect(component.upcommingOffer.length).toBe(1);
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
      expect(alertify.success).toHaveBeenCalled();
    });

    it('should call alertify.error when error is received from customerService.removeAddon', () => {
      component.msisdn = '1234567';
      component.upcommingOffer = JSON.parse(JSON.stringify(mockSubscriptionDetail.products));
      customerServiceSpy.removeAddon.and.returnValue(Observable.throw(new Error('Error')));
      spyOn(alertify, 'error');

      component.confirmRemoveDeals(0);

      expect(component.upcommingOffer.length).toBe(2);
      expect(alertify.error).toHaveBeenCalled();
    });
  });

  it('onChange method should set bar and transfer to value passed to onChange method is not undefined', () => {
    component.onChange(2);

    expect(component.transfer).toEqual(2);
    expect(component.bar).toEqual(2);
  });

  it('onChange method should not alter value of bar and transfer when value passed to onChange method is undefined', () => {
    component.transfer = 2;
    component.bar = 2;

    component.onChange(undefined);

    expect(component.transfer).toEqual(2);
    expect(component.bar).toEqual(2);
  });
});

