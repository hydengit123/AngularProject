import { getCurrencySymbol } from '@angular/common';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { Chart } from 'chart.js';
import { CMUICONFIGKEY, DataFormatterPipe, PaymentRequestInfo, PLANTYPE, productBucketCard, ProductBucketShared, SHAREDBUCKETTYPE, UserContractModel } from 'dxp-common';
import * as _ from 'lodash';
import { Subscription } from 'rxjs';
import { JOURNEYIDS, LOCALIZATIONPERSISTANCEKEY, PERSISTANCEKEY, PRODUCTGROUP, WEBCONTENTPERSISTANCEKEY } from '../../../application-constants';
import { EventEnum } from '../../enum/EventEnum';
import { EventListenerService } from '../../event-listener.service';
import { ICustomerStory } from '../../interface/customer.story';
import { CustomizePlanOffer } from '../../interface/product';
import { SubscriptionProduct } from '../../interface/subscription';
import { WebContent } from '../../interface/web.content';
import { mockDataAvailable, mockDataProvisoned, mockSMSAvailable, mockSMSProvisoned, mockVoiceAvailable, mockVoiceProvisoned } from '../../mockData';
import { CartService } from '../../services/cart.service';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { CustomerSearchDataService } from '../../services/customer-search-data.service';
import { CustomerSearchService } from '../../services/customer-search.service';
import { CustomerService } from '../../services/customer.service';
import { PaymentGatewayService } from '../../services/payment-gateway.service';
import { ProductService } from '../../services/product.service';
import { UtilService } from '../../services/util.service';
import { DateHelper } from '../../shared/helper/date.helper';
import { IDashboardProfileUpdate } from '../interface/dashboard-profile-update';
import { ManageAddonComponent } from '../manage-addon/manage-addon.component';
import { RechargeOthersPayload } from './../../interface/recharge.others.payload';
import { TransferBucketPayload } from './../../interface/transfer-bucket-payload';
import { TransferCreditPayload } from './../../interface/transfer-credit-payload';
import { rechargeNumberValidator, rechargeValidator, rechargeWithVoucherCodeValidator } from './../../shared/validators/recharge.validators';

import Product = SubscriptionProduct.Product;
import AggregatedUnit = SubscriptionProduct.AggregatedUnit;

declare const alertify;
declare var jQuery: any;

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
    providers: [ProductService, UtilService, CustomerService],
    encapsulation: ViewEncapsulation.None
})
export class HomeComponent implements OnInit, AfterViewInit, IDashboardProfileUpdate {
    allCarouselItems: any;

    readonly showLimit = 3;
    sectionScroll;
    consumerEventSubscription: Subscription;
    sharedConsumerDetails: any;
    contractID: String = '';
    tooltipData: String = '';
    balanceDate: string;
    optionsSelect: Array<{ value?: string, label?: string, selected?: boolean }>;
    userProfile = null;
    currentUser = null;
    ContractList: UserContractModel[] = null;
    messageBg: String = '';
    public paymentRequestInfo: PaymentRequestInfo = {
        key: '',
        hash: '',
        txnid: '',
        amount: 0,
        productinfo: '',
        firstname: '',
        lastname: '',
        email: '',
        phone: '',
        surl: '',
        furl: '',
        address1: '',
        address2: '',
        city: '',
        state: '',
        country: '',
        zipcode: '',
        salt: ''
    };
    refillList: any[];
    timeSortAsc = true;
    currencySymbolRefill: any;

    contractDetails: any;
    profile: any;

    // this chart Canvas will be removed canvasRef1
    @ViewChild('chartCanvas1') canvasRef1: ElementRef;
    @ViewChild('chartCanvas2') canvasRef2: ElementRef;
    @ViewChild('chartCanvas3') canvasRef3: ElementRef;
    @ViewChild('clickcomp') clickcomp: ManageAddonComponent;
    chart: any = {};
    tabSelection = 'addOn';
    addOns: Product[] = [];
    selectedAddOn: any;

    customerStoryList: ICustomerStory[] = [];
    customerOrderList: ICustomerStory[] = [];

    selectedValue: any = 1;

    isDataPlanboxSelected: boolean;
    isMinutesPlanboxSelected: boolean;
    isSmsPlanboxSelected: boolean;

    isNext = false;

    private dataFormatterPipe: DataFormatterPipe = new DataFormatterPipe(this.translateService);

    mainBalance: AggregatedUnit;
    data: any = null;
    voice: any = null;
    sms: any = null;

    mainBalanceValue: any;
    dataValue: any = null;
    voiceValue: any = null;
    smsValue: any = null;



    currentAddForm;
    currentTransferForm;
    currentShareForm;
    currentUserName: any;

    msisdn = null;
    username;
    addDataAdons = [];
    bannerDeal = [];


    provisionedData;
    provisionedVoice;
    provisionedSms;

    activeDataSet = 0;

    creditTransferForm: FormGroup;
    mixCreditBalance = 0;
    maxCreditBalance = 50;
    transfer;
    bar = 0;
    benmsisdn;
    currentContract = null;

    selectedQuota = 'DATA';

    upcommingOffer: CustomizePlanOffer[] = [];

    bottomRightImageURL: string;
    webContent: WebContent;
    public productDetails: any;
    private prodBuckets: any;
    public produBuckets = [];
    public customerPlanName;
    public customerPlanPrice;
    public customerPlanCurrency;
    public customerPlanRecurrence;
    private dashboardEventSubscription: Subscription;
    public rechargeOthersForm: FormGroup;
    public showFields: Boolean = false;
    userDetails: any;
    private rechargeForOthersPayload: RechargeOthersPayload;
    rechargeOtherSuccessMsgStatus: Boolean = false;
    rechargeOtherSuccessMsg: String = '';
    public amountValidationMessage = { error: null, success: null };
    public voucherCodeValidationMessage = { error: null, success: null };
    public phoneNoValidationMessage = { error: null, success: null };
    optionsSelect_recentOrders = [
        { value: 1, label: 'Customer' },
        { value: 2, label: 'Contract' }
    ];
    slides: any = [[]];
    selectedValue_recentOrders = 1;

    public currencySymbol: any;


    private msisdnChangeEvent: Subscription;
    public initialProductBucketBalance: any;
    public currentProductBucketBalance: any;
    public renewalDate: any;
    public currentDate: any;
    public assignedDate: any;
    public differenceDate: any;
    public customproductDetails: any;
    public customerContractDetails: any;
    public combinedProductBuckets: any = [];
    public productDDetails: any = [];
    public basePlanData: any = [];
    public planRenewalDate: any;
    public paymentGateWayList: any;
    constructor(private persistenceService: PersistenceService,
        private router: Router, private event: EventListenerService,
        private customerService: CustomerService,
        private fb: FormBuilder,
        private planservice: ProductService,
        private customerSearchService: CustomerSearchService,
        private utilService: UtilService, private translateService: TranslateService,
        private customerSearchDataService: CustomerSearchDataService,
        private eventListenerService: EventListenerService,
        private customerOnBoardService: CustomerOnboardService,
        private cartService: CartService,
        private paymentGatewayService: PaymentGatewayService
    ) {

        this.creditTransferForm = this.fb.group({
            msisdn: ['', Validators.required],
            benmsisdn: ['', Validators.required],
            transfer: [0, Validators.required],
            srcAccountType: '1',
            dstAccountType: '1',
            buyOption: 'ME2U',
            productId: 'CM_Time2Share_575',
        });

        this.webContent = this.persistenceService.get(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, StorageType.SESSION);
        if (this.webContent && this.webContent.bottomRightImage) {
            this.bottomRightImageURL = this.webContent.bottomRightImage.url;
        }
    }
    public contractCustomerID;

    ngOnInit() {
        this.eventListenerService.fetchPendingJourney();
        this.rechargeOthersForm = new FormGroup({
            phoneNumber: new FormControl(),
            voucherCode: new FormControl(),
            amount: new FormControl()
        });

        this.rechargeOthersForm.controls.amount.valueChanges.subscribe(data => {
            if (this.rechargeOthersForm.controls.amount.value) {
                this.rechargeOthersForm.controls.voucherCode.setValue('');
            }
        });
        this.rechargeOthersForm.controls.voucherCode.valueChanges.subscribe(data => {
            if (this.rechargeOthersForm.controls.voucherCode.value) {
                this.rechargeOthersForm.controls.amount.setValue('');
            }
        });
        if (this.cartService.cartDetails && this.cartService.cartDetails.id) {
            // this.cartService.clearCart();
            // this.cartService.cartDetails = null;
            this.cartService.cartDetails = null;
            this.event.notifyCartUpdate(this.cartService.cartDetails);
        }
        this.msisdnChangeEvent = this.event.msisdnChangeEvent.subscribe((event) => {
            const msisdn = event.msisdn;
            const contracts = this.customerSearchService.getUserContracts();

            for (let i = 0; i < contracts.length; i++) {
                if (contracts[i].msisdn === msisdn) {
                    this.currentContract = contracts[i];
                    this.customerSearchService.setCurrentContract(this.currentContract);
                    break;
                }
            }


            this.profileUpdate();



        });

        this.event.showPaymentSuccessMessageEvent.subscribe(data => {
            if (data && data.eventType === EventEnum.showRechargeOtherSuccessMessage && data.response) {
                this.showFields = false;
                this.rechargeOtherSuccessMsgStatus = true;
                if (data && data.response && data.response.status === 'completed' || data && data.response && data.response.status === 'InProgress' || data.status === 'completed' || data.status === 'InProgress') {
                    alertify.success(this.translateService.instant(data.response.statusReason.code));
                } else {
                    alertify.error(this.translateService.instant(data.response.statusReason.code));
                }
                this.eventListenerService.dashboardEvent.emit({ eventType: EventEnum.dashboardRefresh });
                this.rechargeOthersForm.reset();
                setTimeout(() => {
                    this.rechargeOtherSuccessMsgStatus = false;
                }, 5000);
            }
        });

        this.event.lanuageChangeEvent.subscribe(data => {
            if (data && data.eventType && data.eventType === EventEnum.languageUpdated) {
                const language = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
                this.loadLanguage(language);
            }
        });

        const language = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
        this.loadLanguage(language);



        this.userProfile = this.customerSearchService.getUserProfile();
        if (this.customerSearchService.getCurrentContract() == null && this.customerSearchService.getUserContracts() !== null) {
            this.customerSearchService.setCurrentContract(this.customerSearchService.getUserContracts()[0]);
        }

        this.profileUpdate();

        const defaultCurrency = this.persistenceService.get(CMUICONFIGKEY.DEFAULTYCURRENCY, StorageType.SESSION);
        this.currencySymbolRefill = getCurrencySymbol(defaultCurrency, 'narrow');
        this.router.events.subscribe((evt) => {
            if (!(evt instanceof NavigationEnd)) {
                return;
            }
            this.doScroll();
            this.sectionScroll = null;
        });

    }

    private updateSlides(collection: any) {
        this.allCarouselItems = collection;
    }

    public whenExpandClicked(e: any) {
        let carouselItems;
        if (this.allCarouselItems && this.allCarouselItems.length > 0) {
            carouselItems = this.allCarouselItems.map((productBundle) => {
                if (productBundle !== e.product) {
                    productBundle.isCollapsed = true;

                }
                return productBundle;
            });
            this.updateSlides(carouselItems);
        }
    }

    private profileUpdate() {
        this.setCustomerProfileOnPage();
        this.onOverviewProfileLoad();
        this.loadCustomerContract();
    }

    public refreshDashBoardView(): void {
        this.profileUpdate();
    }

    loadLanguage(language: string) {
        this.translateService.use(language).subscribe(
            (res) => {
                // check for RTL
            }
        );
    }



    private loadCustomerContract() {
        this.basePlanData = [];
        this.combinedProductBuckets = [];

        const customerContractDetails = this.customerSearchService.getUserContracts();

        const basePlanTypes = this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMESFORVASEOFFERQUERY, StorageType.SESSION);
        const transferPlanTypes = this.persistenceService.get(CMUICONFIGKEY.TRANSFERABLE_BASE_PLAN, StorageType.SESSION);
        const lang = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);

        if (customerContractDetails && this.currentContract.contract) {


            this.contractID = this.currentContract.contract.id;
            if (this.currentContract.contract && this.currentContract.contract.products) {
                this.productDetails = this.currentContract.contract.products.filter(x => x.type.toLowerCase() !== PLANTYPE.ADDON.toLowerCase());

                this.basePlanData = this.customerSearchService.getCurrentContractBasePlan(basePlanTypes);

                this.produBuckets = this.customerSearchService.getProductBucketCards(basePlanTypes, transferPlanTypes, 'bucketType');
                if (this.produBuckets) {
                    this.allCarouselItems = this.customerSearchService.productBundleAddToCarousel(this.produBuckets, ['currentBalance', 'initialBalance'], 'bucketType');
                }
            }
        }


        if (this.currentContract.contract) {
            this.renewalDate = new Date(this.currentContract.contract.customerAccountAssignmentRules[0].customerAccount.lifeCycleState.transitionDate);
        }
        if (this.renewalDate) {
            this.currentDate = new Date();

            const dt1 = new Date();
            const dt2 = new Date(this.renewalDate);
            this.planRenewalDate = dt2.getFullYear() + '-' + ('0' + (dt2.getMonth() + 1)).slice(-2) + '-' + ('0' + dt2.getDate()).slice(-2);
            this.differenceDate = Math.floor((Date.UTC(dt2.getFullYear(), (dt2.getMonth() + 1), dt2.getDate()) - Date.UTC(dt1.getFullYear(), (dt1.getMonth() + 1), dt1.getDate())) / (1000 * 60 * 60 * 24));
        }

        this.consumerDetails();

    }
    sharedImage(card: productBucketCard) {
        if (card && card.sharedBucketType && card.sharedBucketType === SHAREDBUCKETTYPE.SHAREDCONSUMER) {
            return null;
        } else if (card && card.sharedBucketType && card.sharedBucketType === SHAREDBUCKETTYPE.SHAREDPROVIDER) {
            return 'assets/imgs/home/Path 635.svg';
        } else if (card && !card.sharedBucketType) {
            return 'assets/imgs/home/Group 1244.svg';
        }
    }
    cardImage(card: productBucketCard) {
        if (card && card.bucketType && card.bucketType === 'VOICE') {
            return 'assets/imgs/home/phone-call-button.svg';
        } else if (card && card.bucketType && card.bucketType === 'SMS') {
            return 'assets/imgs/home/sms.svg';
        } else if (card && card.bucketType && card.bucketType === 'DATA') {
            return 'assets/imgs/home/Wi-Fi.svg';
        }
    }

    consumedImage(card: productBucketCard) {
        if (card && card.sharedBucketType && card.sharedBucketType === SHAREDBUCKETTYPE.SHAREDCONSUMER) {
            return 'assets/imgs/home/Group 850.svg';
        }
        if (card && card.sharedBucketType && card.sharedBucketType === SHAREDBUCKETTYPE.SHAREDPROVIDER) {
            return 'assets/imgs/home/Group 1415.svg';
        }
    }


    chunk(arr, chunkSize) {
        let R = [];
        for (let i = 0, len = arr.length; i < len; i += chunkSize) {
            R.push(arr.slice(i, i + chunkSize));
        }
        return R;
    }

    private raiseProfileIsLoadedEvent() {
        setTimeout(() => {
            this.getSelectedValue(this.msisdn);
        });
    }

    private setCustomerProfileOnPage() {
        this.ContractList = this.customerSearchService.getUserContracts();//all contracts
        this.currentContract = this.customerSearchService.getCurrentContract();//current contract default 0

        if (this.currentContract) {
            this.MsisdnDropdownInitialisation();//initialise msisdn dropdown
            this.InitialiseBalanceDateAndName();//initialise balance name and date

            if ((this.currentContract == null) || (this.userProfile == null)) {
                this.router.navigate(['login']);
            }

        }
    }

    InitialiseBalanceDateAndName() {
        this.mainBalanceValue = this.currentContract.contract.customerAccountAssignmentRules[0].customerAccount;
        this.currencySymbol = getCurrencySymbol(this.mainBalanceValue.currency, "narrow");
        var dateObj = new Date(this.mainBalanceValue.lifeCycleState.transitionDate);
        this.balanceDate = (dateObj.getUTCDate()) + "-" + (dateObj.getUTCMonth() + 1) + "-" + (dateObj.getUTCFullYear());
        this.currentUserName = `${this.userProfile.firstName}  ${this.userProfile.lastName}`;
    }

    MsisdnDropdownInitialisation() {
        this.optionsSelect = [];
        this.ContractList.forEach(contract => {
            this.optionsSelect.push({ value: contract.msisdn, label: contract.msisdn, selected: true });
        });
        this.selectedValue = this.currentContract.msisdn;
        this.msisdn = this.currentContract.msisdn;
    }


    ngAfterViewInit(): void {

        jQuery('#creditTranser').on('hidden.bs.modal', (e) => {
            this.benmsisdn = '';
            this.bar = 0;
            this.transfer = '';
        });
    }

    tabSelectionHandler(tab) {
        this.tabSelection = tab;
    }

    private onOverviewProfileLoad() {
        this.loadStories(this.customerSearchService.getUserProfile().customerId);
        this.loadOrders(this.customerSearchService.getUserProfile().customerId);
    }

    async loadStories(customerId) {
        let closedStories, draftStories, storiesObj = [];
        closedStories = await this.findQuery(customerId, '!draft');
        closedStories.map(a => {
            a.statusType = 'closed';
            a.createDate = DateHelper.getDateTime(a.createDate);
        });
        draftStories = await this.findQuery(customerId, 'draft');
        draftStories.map(a => {
            a.statusType = 'draft';
            a.createDate = DateHelper.getDateTime(a.createDate);
        });
        storiesObj = closedStories.concat(draftStories);
        this.setStoriesData(storiesObj);
    }

    async loadOrders(customerId: string) {
        let orderList = [];
        orderList = await this.findQuery(customerId, 'PurchaseOrder,ServiceOrder');
        orderList.map(a => {
            a.statusType = 'closed';
            a.createDate = DateHelper.getDateTime(a.createDate);
        });
        this.customerOrderList = orderList.slice(0, 3);
        orderList = _.sortBy(orderList, 'createDate').reverse();
        let refillList: any[];
        refillList = orderList.filter(x => x.journeyId && JOURNEYIDS.REFILL.indexOf(x.journeyId) !== -1);
        refillList = refillList.slice(0, 4);
        refillList.map(x => {
            if (x.coreData) {
                if (x.coreData.refillAmount) {
                    x.coreData.refillAmount = parseFloat(x.coreData.refillAmount).toFixed(2);
                } else if (x.coreData.transactionAmount) {
                    x.coreData.transactionAmount = parseFloat(x.coreData.transactionAmount).toFixed(2);
                }
            }
            return x;
        });
        this.refillList = refillList;
    }

    findQuery(customerId: string, sourceType: string) {
        try {

            return this.customerSearchDataService.searchCustomerInteraction(customerId, sourceType).toPromise().catch(err => {
                return [];
            });

        } catch (error) {
            return [];
        }
    }

    changeSortDirection(list: string) {
        this.timeSortAsc = !this.timeSortAsc;
        this[list].reverse();
    }

    setStoriesData(storiesObj) {
        this.customerStoryList = storiesObj;
    }

    getSelectedValue(val) {
        this.event.msisdnChange(val);
    }

    getSelectedValue_recentOrders(val) {
    }

    ngOnDestroy() {

        if (this.msisdnChangeEvent) {
            this.msisdnChangeEvent.unsubscribe();
        }
        if (this.consumerEventSubscription) {
            this.consumerEventSubscription.unsubscribe();
        }
        if (this.dashboardEventSubscription) {
            this.dashboardEventSubscription.unsubscribe();
        }
    }

    getAggregatedSubscription(msisdn): void {
        this.customerService.getAggregatedSubscription(msisdn)
            .subscribe(this.onResult.bind(this), this.onError.bind(this));
    }

    onResult(res: { mainBalance: AggregatedUnit }): void {
        const mainBalance = this.persistenceService.get(PERSISTANCEKEY.MAINBALANCE, StorageType.SESSION);
        if (!mainBalance) {
            this.persistenceService.set(PERSISTANCEKEY.MAINBALANCE, res, { type: StorageType.SESSION });
        }
        this.mainBalance = res.mainBalance;
        if (typeof this.mainBalance.unit !== 'undefined') {
            this.maxCreditBalance = this.mainBalance.unit / 100;
            if (this.maxCreditBalance === 0) {
                this.maxCreditBalance = 0.1;
            }
        }
        this.bar = 0;
        this.transfer = '';
    }

    onResult1(res: { mainBalance: AggregatedUnit }): void {
        const mainBalance = this.persistenceService.get(PERSISTANCEKEY.MAINBALANCE, StorageType.SESSION);
        if (!mainBalance) {
            this.persistenceService.set(PERSISTANCEKEY.MAINBALANCE, res, { type: StorageType.SESSION });
        }
        this.mainBalance = res.mainBalance;
        if (typeof this.mainBalance.unit !== 'undefined') {
            this.maxCreditBalance = this.mainBalance.unit / 100;
            if (this.maxCreditBalance === 0) {
                this.maxCreditBalance = 0.1;
            }
        }
        this.bar = 0;
        this.transfer = '';
        this.mainBalance = { 'unit': 0 };
    }

    onError(res: any): void {
        this.onResult({
            mainBalance: { unit: 5000, expiryDate: new Date().toDateString() }
        });
    }

    getSubscriptionDetail() {
        const msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
        this.customerService.getSubscriptionDetail(msisdn)
            .subscribe((data: { msisdn: string, products: Product[] }) => {
                let currentPlan: Product = null;
                if (data.products) {
                    currentPlan = this.utilService.getCustomerPlanFromSubscription(data.products);
                    if (currentPlan) {
                        if (currentPlan.availableQuota) {
                            let dataUnit, voiceUnit, smsUnit;
                            if ((currentPlan.availableQuota.data && currentPlan.availableQuota.data.unit === 0) || currentPlan.availableQuota.data == null) {
                                dataUnit = 0;
                            } else {
                                dataUnit = currentPlan.availableQuota.data && currentPlan.availableQuota.data.unit ? currentPlan.availableQuota.data.unit : -1;
                            }
                            if ((currentPlan.availableQuota.voice && currentPlan.availableQuota.voice.unit === 0) || currentPlan.availableQuota.voice == null) {
                                voiceUnit = 0;
                            } else {
                                voiceUnit = currentPlan.availableQuota.voice && currentPlan.availableQuota.voice.unit ? currentPlan.availableQuota.voice.unit : -1;
                            }
                            if ((currentPlan.availableQuota.sms && currentPlan.availableQuota.sms.unit === 0) || currentPlan.availableQuota.sms == null) {
                                smsUnit = 0;
                            } else {
                                smsUnit = currentPlan.availableQuota.sms && currentPlan.availableQuota.sms.unit ? currentPlan.availableQuota.sms.unit : -1;
                            }

                            this.setAvailableQuota(dataUnit, voiceUnit, smsUnit);
                        } else {
                            this.setAvailableQuota(-1, -1, -1);
                        }
                        if (currentPlan.provisionedQuota) {

                            this.setProvisionedQuota(currentPlan.provisionedQuota.data && currentPlan.provisionedQuota.data.unit ? currentPlan.provisionedQuota.data.unit : 0, currentPlan.provisionedQuota.voice && currentPlan.provisionedQuota.voice.unit ? currentPlan.provisionedQuota.voice.unit : 0, currentPlan.provisionedQuota.sms && currentPlan.provisionedQuota.sms.unit ? currentPlan.provisionedQuota.sms.unit : 0);
                        } else {
                            this.setProvisionedQuota(-1, -1, -1);
                        }
                    } else {

                        this.setAvailableQuota(mockDataAvailable, mockVoiceAvailable, mockSMSAvailable);
                        this.setProvisionedQuota(mockDataProvisoned, mockVoiceProvisoned, mockSMSProvisoned);
                    }
                    this.addOns = data.products.filter((x: Product) => {
                        let expDateString: string = x.expiryDate.split(' ')[0];
                        expDateString = expDateString.split('-').reverse().join('-');
                        const expDate = new Date(expDateString);
                        const currentDate = new Date(new Date().setHours(0, 0, 0, 0));

                        if (x.productGroup) {
                            return x.productGroup.toString().toLowerCase() === PRODUCTGROUP.ADDON && expDate.getTime() > currentDate.getTime();
                        }
                    });

                    this.getOtherPurchases(data.products);
                    this.persistenceService.set(PERSISTANCEKEY.CURRENTPLAN, currentPlan, { type: StorageType.SESSION });
                    this.persistenceService.set(PERSISTANCEKEY.USERADDON, this.addOns, { type: StorageType.SESSION });
                }
            }, error => {
                this.setAvailableQuota(mockDataAvailable, mockVoiceAvailable, mockSMSAvailable);
                this.setProvisionedQuota(mockDataProvisoned, mockVoiceProvisoned, mockSMSProvisoned);
            });
    }

    setProvisionedQuota(data, voice, sms) {
        this.provisionedData = data;

        this.provisionedVoice = voice;

        this.provisionedSms = sms;


        const provisionedQuota = this.persistenceService.get(PERSISTANCEKEY.PROVISIONEDQUOTA, StorageType.SESSION);
        if (!provisionedQuota) {
            this.persistenceService.set(PERSISTANCEKEY.PROVISIONEDQUOTA, {
                data: data,
                voice: voice,
                sms: sms
            }, { type: StorageType.SESSION });
        }

    }

    setAvailableQuota(data, voice, sms) {
        this.data = data;

        this.voice = voice;

        this.sms = sms;

        this.event.customerDataChanges(data, voice, sms);

        const availableQuota = this.persistenceService.get(PERSISTANCEKEY.PROVISIONEDQUOTA, StorageType.SESSION);
        if (!availableQuota) {
            this.persistenceService.set(PERSISTANCEKEY.AVAILABLEQUOTA, {
                data: data,
                voice: voice,
                sms: sms
            }, { type: StorageType.SESSION });
        }


    }

    makePlanboxActive(planboxType: string): void {
        this.selectedQuota = planboxType;
        if (planboxType === 'DATA') {
            this.isDataPlanboxSelected = true;
            this.isMinutesPlanboxSelected = false;
            this.isSmsPlanboxSelected = false;
        } else if (planboxType === 'MINUTES') {
            this.isDataPlanboxSelected = false;
            this.isMinutesPlanboxSelected = true;
            this.isSmsPlanboxSelected = false;
        } else if (planboxType === 'SMS') {
            this.isDataPlanboxSelected = false;
            this.isMinutesPlanboxSelected = false;
            this.isSmsPlanboxSelected = true;
        }
    }


    selectAddOn(addOne: any): void {
        addOne.isSelected = true;
        this.selectedAddOn.isSelected = false;
        this.selectedAddOn = addOne;
    }

    //   initChart(): void {
    //     const labels: string[] = [];
    //     let currentDate = new Date();
    //     for (let i = 0; i < 6; i++) {
    //       const label = moment(currentDate).format('DD-MM-YY');
    //       labels.push(label);
    //       currentDate = new Date(new Date().setDate(currentDate.getDate() - 1));
    //     }
    //     labels.reverse();

    //     let dataSet1 = this.generateRandomArray(6, 100);
    //     this.createGraphSet(this.canvasRef1.nativeElement, labels, dataSet1, 'rgba(0,199,154,0.8)', 'Data(GB)');
    //   }

    createGraphSet(ref, labels, dataset, rgba, label = '') {
        const colorArray = [];
        for (let i = 0; i < labels.length; i++) {
            colorArray.push(rgba);
        }
        this.chart = new Chart(ref, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: label,
                    data: dataset,
                    backgroundColor: ['rgba(0, 0, 0, 0)'],
                    borderColor: colorArray,
                    borderWidth: 1
                }]
            },
            options: {

                scales: {
                    yAxes: [{
                        ticks: {
                            display: true
                        }
                    }]
                },
                legend: {
                    display: false
                }
            }
        });
    }

    setActive(val) {
        this.activeDataSet = val;
    }

    generateRandomArray(limit, limiter = 100): number[] {
        const data = [];
        for (let i = 0; i < limit; i++) {
            const rand = Math.floor(Math.random() * limiter);
            data.push(rand);
        }
        return data;
    }


    addCreditBalance() {
        this.customerService.recharge(this.msisdn, this.activeDataSet * 100).then(data => {
            alertify.success(this.translateService.instant('Credit added successfully'));
            this.event.addToMainBalance(this.activeDataSet * 100);
            this.activeDataSet = 0;
        }).catch(error => {
            alertify.error(this.translateService.instant('Error adding creit balance'));
        });
    }

    transferCreditBalance() {
        jQuery('#creditTranser').modal('hide');
        const params: any = this.creditTransferForm.value;
        params.benmsisdn = this.benmsisdn.toString();
        params.msisdn = this.msisdn.toString();
        params.transfer = (this.transfer * 100).toString(10);
        this.customerService.transferCreditBalance(params)
            .subscribe((data) => {
                alertify.success(this.translateService.instant('Transferred Successfully'));
                this.event.removeFromMainBalance(this.transfer * 100);
            }, error => {
                this.event.removeFromMainBalance(this.transfer * 100);
                alertify.error(this.translateService.instant('Transfer Unsuccessfull'));
            }, () => {

            });
    }

    confirmRemoveAddon(index) {
        const name = this.addOns[index].productName;
        const productId = this.addOns[index].productId;
        const params: any = {};
        params.msisdn = this.msisdn;
        params.productId = productId;
        params.buyOption = 'DACT';
        this.customerService.removeAddon(params)
            .subscribe((data) => {
                this.addOns.splice(index, 1);
                this.persistenceService.set(PERSISTANCEKEY.USERADDON, this.addOns, { type: StorageType.SESSION });
                alertify.success(this.translateService.instant('Removed ') + name);
            }, error => {
                alertify.error(this.translateService.instant('Error Removing ') + name);
            });
    }

    confirmRemoveDeals(index) {
        const name = this.upcommingOffer[index].productName;
        const productId = this.upcommingOffer[index].productId;
        const params: any = {};
        params.msisdn = this.msisdn;
        params.productId = productId;
        params.buyOption = 'DACT';


        this.customerService.removeAddon(params)
            .subscribe((data) => {
                this.upcommingOffer.splice(index, 1);
                this.persistenceService.set(PERSISTANCEKEY.USERDEALS, this.upcommingOffer, { type: StorageType.SESSION });
                alertify.success(this.translateService.instant('Removed ') + name);

            }, error => {
                alertify.error(this.translateService.instant('Error Removing ') + name);
            });
    }

    onChange(event) {
        if (typeof event !== 'undefined' && event) {
            this.transfer = event;
            this.bar = event;
        }

    }

    getUpcomingOffers() {
        this.planservice.getUpcomingOffers()
            .then((data: CustomizePlanOffer[]) => {
                this.bannerDeal = [];
                this.bannerDeal = data;

            }).catch((error) => {
            });
    }

    getOtherPurchases(data) {

        this.upcommingOffer = data.filter((x: Product) => {
            if (x.productGroup) {
                let _pg = x.productGroup.toString().toLowerCase();
                let _pgList = ['premium', 'standard', 'customizeplanoffer', 'addon', 'recharge'];
                return ((_pgList.indexOf(_pg) == -1));
            }

        });

        this.persistenceService.set(PERSISTANCEKEY.USERDEALS, this.upcommingOffer, { type: StorageType.SESSION });
    }

    public shareWithConsumer(productBucketCard: productBucketCard) {
        if (productBucketCard && productBucketCard.isSharable) {
            const prodBucketShared: ProductBucketShared = {
                id: productBucketCard.id,
                name: productBucketCard.name,
                bucketType: productBucketCard.bucketType,
                sharedBucketType: productBucketCard.sharedBucketType,
                currentBalance: productBucketCard.currentBalance,
                initialBalance: productBucketCard.initialBalance,
                unit: productBucketCard.unit,
                validUntil: productBucketCard.validUntil,
                maxSharedQuota: productBucketCard.maxSharedQuota,
                providerMSISDN: this.msisdn
            };
            this.eventListenerService.showUpdateConsumersInPopup(prodBucketShared, this.userProfile, this.ContractList, this.basePlanData[0].id);
        }
    }

    public refill(itemDetails) {
        const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
        const customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
        const currency = this.persistenceService.get(CMUICONFIGKEY.DEFAULTYCURRENCY, StorageType.SESSION);
        const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        let refillPayload = {
            'userId': '',
            'partyId': partyId,
            'customerId': customerId,
            'journeyId': 'AccountRefill',
            'type': 'ServiceOrder',
            'status': 'InProgress',
            'channelName': channelName,
            'customerServiceOrder': { 'state': 'InProgress' },
            'journeyData': {},
            'coreData': {
                'refillAmount': '',
                'currency': currency,
                'customerAccountId': itemDetails.id,
                'summaryTextLabel': 'AccountRefillSummary'
            }
        };

        let voucherPayload = {
            'partyId': partyId,
            'customerId': customerId,
            'journeyId': 'VoucherTopup_Self',
            'type': 'ServiceOrder',
            'status': 'InProgress',
            'channelName': channelName,
            'customerServiceOrder': {},
            'journeyData': {},
            'coreData': {
                'msisdn': itemDetails.id,
                'currency': currency,
                'summaryTextLabel': 'VoucherTopupSelfSummary',
                'voucherCode': ''
            }
        };
        // const emailExist = this.userDetails['contactMedium'].filter(data => data.type === 'EmailContact');
        // if (emailExist && emailExist.length > 0) {
        //   const email = emailExist[0].value[0].value;
        //   this.paymentRequestInfo.email = email;
        // }
        this.paymentRequestInfo.email = this.userProfile.email[0];
        this.paymentRequestInfo.firstname = this.userProfile.firstName;
        this.paymentRequestInfo.lastname = this.userProfile.lastName;
        // this.paymentRequestInfo.amount = this.quickRechargeForm.value.amount;
        this.paymentRequestInfo.phone = itemDetails.id;
        this.paymentRequestInfo.productinfo = 'Recharge';
        this.eventListenerService.accountRefill(refillPayload, voucherPayload, this.paymentRequestInfo, EventEnum.refillPopup);
        // this.eventListenerService.refillPopup(this.mainBalanceValue, this.userProfile, this.ContractList, true, false, this.paymentRequest);
    }

    public transfercredit(itemDetails) {
        const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
        const customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
        const currency = this.persistenceService.get(CMUICONFIGKEY.DEFAULTYCURRENCY, StorageType.SESSION);
        const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        const requestPayload: TransferCreditPayload = {
            'partyId': partyId,
            'customerId': customerId,
            'journeyId': 'AccountTransfer',
            'type': 'ServiceOrder',
            'status': 'InProgress',
            'channelName': channelName,
            'customerServiceOrder': {
                'state': 'InProgress'
            },
            'journeyData': {},
            'coreData': {
                'beneficiaryMsisdn': '',
                'currency': currency,
                'summaryTextLabel': '',
                'transferQuantity': '',
                'customerAccountId': itemDetails.id,
            }
        };
        this.eventListenerService.transferCreditPopup(itemDetails, requestPayload);
    }

    consumerDetails() {
        const userProfileDetails = this.customerSearchService.getUserProfile();
        this.customerSearchDataService.getSharedConsumerData(userProfileDetails.customerId, this.contractID).subscribe((data) => {
            this.sharedConsumerDetails = data;
        });
    }

    getTooltipData($event, items) {
        this.tooltipData = "";
        if (items.sharedBucketType == "SHARED_PROVIDER") {
            let sharedToDetails = "";
            if (this.sharedConsumerDetails) {
                this.sharedConsumerDetails.forEach(element => {
                    const itemSharedConsumerDetails = element['consumerBuckets'].filter((data) => data.name == items.name);
                    if (itemSharedConsumerDetails && itemSharedConsumerDetails.length > 0) {
                        sharedToDetails += element['consumerResource'] + ': ';
                        itemSharedConsumerDetails.forEach(data => {
                            const dataInfo = this.dataFormatterPipe.transform(data.bucketValue, data.unitOfMeasure);
                            sharedToDetails += dataInfo + '\n';
                        });
                    }
                });
            }
            if (sharedToDetails) {
                this.tooltipData = this.translateService.instant("Shared to \n");
                this.tooltipData += sharedToDetails;
            }
        } else {
            let sharedByDetails = "";
            const sharedConsumerDetails = this.produBuckets.filter(data => data.sharedBucketType == items.sharedBucketType);
            const itemSharedConsumerDetails = sharedConsumerDetails.filter((data) => data.name == items.name);
            if (itemSharedConsumerDetails) {
                itemSharedConsumerDetails.forEach(element => {
                    const dataInfo = this.dataFormatterPipe.transform(element.initialBalance, element.unit);
                    sharedByDetails += element.providerMSISDN + ': ' + dataInfo + '\n';
                });
                if (sharedByDetails) {
                    this.tooltipData = this.translateService.instant("Shared by \n");
                    this.tooltipData += sharedByDetails;
                }
            }
        }
        // =================****=====   Donot remove this below commented code May be used later =======******===================
        // const userProfileDetails = this.customerSearchService.getUserProfile();
        // const consumerDetails: any = await this.customerSearchDataService.getConsumerData(userProfileDetails.customerId, this.contractID, items).toPromise();
        // this.customerSearchDataService.getConsumerData(this.contractCustomerID, this.contractID, items).subscribe((data) => {
        //   const x = data;
        // });


        // if(consumerDetails && consumerDetails.length > 0 && consumerDetails[0]) {
        //   const consumerData = consumerDetails[0];
        //   consumerData.forEach(data => {
        //     const gb = this.dataFormatterPipe.transform(data["consumerBuckets"].bucketValue, data["consumerBuckets"].bytes, true);
        //   });
        // }
        // this.tooltipData = "Shared to 9876543211: 10GB 9876543212: 20GB";

        return this.tooltipData.trim();
    }

    public transferBucketWithCustomer(itemDetails: productBucketCard) {
        if (itemDetails.isTransferrable) {
            const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
            const customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
            const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
            const transferPlan = this.persistenceService.get(CMUICONFIGKEY.TRANSFERABLE_BASE_PLAN, StorageType.SESSION);

            const requestPayload: TransferBucketPayload = {
                partyId: partyId,
                customerId: customerId,
                journeyId: 'ProductBucketTransfer',
                type: 'ServiceOrder',
                status: 'InProgress',
                channelName: channelName,
                customerServiceOrder: {
                    state: 'InProgress'
                },
                journeyData: {},
                coreData: {
                    beneficiaryMsisdn: '',
                    bucketId: itemDetails.id,
                    bucketType: itemDetails.bucketType,
                    contractId: this.contractID,
                    productId: itemDetails.productId,
                    quantityUnit: itemDetails.unit,
                    summaryTextLabel: 'BucketTransferDonorSummary',
                    transferQuantity: '',
                    msisdn: this.msisdn,
                    srcProductInstanceId: itemDetails.productInstanceId
                }
            };
            this.eventListenerService.transferBucketPopup(itemDetails, requestPayload);
        }
    }

    showOtherFields() {
        const phoneNumberControl = this.rechargeOthersForm.controls.phoneNumber;
        if (phoneNumberControl) {
            phoneNumberControl.setValidators(rechargeNumberValidator(this.persistenceService, this.translateService, this.phoneNoValidationMessage));
        }
        phoneNumberControl.updateValueAndValidity();
        this.customerService.customerSearchProfile(this.rechargeOthersForm.value).subscribe((data) => {
            this.userDetails = data[0];
            this.showFields = true;
        },
            error => {
                if (!this.phoneNoValidationMessage.error) {
                    this.showFields = false;
                    alertify.error(this.translateService.instant('MSISDN is not valid'));
                }
            });
        if (this.phoneNoValidationMessage.error) {
            this.showFields = false;
        } else {
            this.showFields = true;
        }
    }

    topRechargeButtonStatus() {
        if (this.rechargeOthersForm.controls.phoneNumber && !this.rechargeOthersForm.value.phoneNumber) {
            return true;
        } else {
            return false;
        }
    }

    downRechargeButtonStatus() {
        if ((!this.rechargeOthersForm.value.amount && !this.rechargeOthersForm.value.voucherCode) || this.rechargeOthersForm.status === 'PENDING' || this.rechargeOthersForm.status === 'INVALID') {
            return true;
        } else {
            return false;
        }
    }

    async doRecharge() {
        if (this.rechargeOthersForm.value.voucherCode) {
            let requestPayload = {};
            const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
            const customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
            const currency = this.persistenceService.get(CMUICONFIGKEY.DEFAULTYCURRENCY, StorageType.SESSION);
            const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
            requestPayload = {
                'partyId': partyId,
                'customerId': customerId,
                'journeyId': 'VoucherTopup_Others',
                'type': 'ServiceOrder',
                'status': 'InProgress',
                'channelName': channelName,
                'customerServiceOrder': {},
                'journeyData': {},
                'coreData': {
                    'beneficiaryMsisdn': this.rechargeOthersForm.value.phoneNumber,
                    'currency': currency,
                    'summaryTextLabel': 'VoucherTopupOthersDonorSummary',
                    'voucherCode': this.rechargeOthersForm.value.voucherCode,
                    'donorMsisdn': this.msisdn
                }
            };
            this.customerService.customerInteractionForRecharge(requestPayload).subscribe((data) => {
                if (data) {
                    this.showFields = false;
                    this.rechargeOtherSuccessMsgStatus = true;
                    if (data.status && data.statusReason === 'completed' || data.status && data.statusReason === 'InProgress' || data.status === 'completed' || data.status === 'InProgress') {
                        alertify.success(this.translateService.instant(data.statusReason.code));
                    } else {
                        alertify.error(this.translateService.instant(data.statusReason.code));
                    }
                    this.eventListenerService.dashboardEvent.emit({ eventType: EventEnum.dashboardRefresh });
                    this.rechargeOthersForm.reset();
                    setTimeout(() => {
                        this.rechargeOtherSuccessMsgStatus = false;
                    }, 5000);
                }
            });
        } else {
            this.customerService.validateMSISDN(this.rechargeOthersForm.value).subscribe((data) => {
                if (data[0].status.toLowerCase() == 'active') {
                    this.customerService.customerSearchProfile(this.rechargeOthersForm.value).subscribe((data) => {
                        this.userDetails = data[0];
                        let email = '';
                        const emailExist = this.userDetails['contactMedium'].filter(data => data.type === 'EmailContact');
                        if (emailExist && emailExist.length > 0) {
                            email = emailExist[0].value[0].value;
                            this.paymentRequestInfo.email = email;
                        }
                        this.paymentRequestInfo.firstname = this.userDetails['firstName'];
                        this.paymentRequestInfo.lastname = this.userDetails['lastName'];
                        this.paymentRequestInfo.amount = this.rechargeOthersForm.value.amount;
                        this.paymentRequestInfo.phone = this.rechargeOthersForm.value.phoneNumber;
                        this.paymentRequestInfo.productinfo = 'Recharge for Others';
                        if (this.userDetails['customerId']) {
                            this.paymentGatewayService.paymentGatewayList().subscribe((data) => {
                                this.paymentGateWayList = data;
                                const showPaymentList = this.paymentGateWayList && this.paymentGateWayList.length && this.paymentGateWayList.length > 1;
                                if (showPaymentList) {
                                    this.event.showPaymentPopupDetails(this.paymentRequestInfo,
                                        this.paymentGateWayList,
                                        showPaymentList,
                                        {
                                            responseHandler: (BOLT) => {
                                                this.rechargeForOthersPayload = this.getRechargeForOthersPayload(this.paymentRequestInfo.email);
                                                return this.customerService.paymentSuccessHandler(BOLT, this.paymentRequestInfo, this.userDetails['id'], this.userDetails['customerId'], this.rechargeForOthersPayload, EventEnum.showRechargeOtherSuccessMessage);
                                            },
                                            catchException: (BOLT) => {
                                                return this.customerService.paymentFailureHandler(BOLT);
                                            }
                                        }
                                    );
                                }
                                else {
                                    this.doPayment();
                                }
                            });
                        }
                    },
                        error => {
                            alertify.error(this.translateService.instant('MSISDN is not valid'));
                        });
                } else {
                    alertify.error(this.translateService.instant('MSISDN is not active'));
                }
            },
                error => {
                    alertify.error(this.translateService.instant('MSISDN is not available'));
                });

        }
    }

    doPayment() {

        const selectedPayments = this.paymentGateWayList.filter(item => item.checked === true);
        if (selectedPayments && selectedPayments[0] && selectedPayments[0].value) {
            const onboardData = this.paymentRequestInfo;
            const successURL = '/public';
            const failureURL = '/public';
            this.paymentGatewayService.launchPaymentBolt(this.paymentRequestInfo,
                selectedPayments[0].value,
                this.paymentRequestInfo.phone,
                'INR',
                successURL,
                failureURL,
                {
                    responseHandler: (BOLT) => {
                        this.rechargeForOthersPayload = this.getRechargeForOthersPayload(this.paymentRequestInfo.email);
                        return this.customerService.paymentSuccessHandler(BOLT, this.paymentRequestInfo, this.userDetails['id'], this.userDetails['customerId'], this.rechargeForOthersPayload, EventEnum.showRechargeOtherSuccessMessage);
                    },
                    catchException: (BOLT) => {
                        return this.customerService.paymentFailureHandler(BOLT);
                    }
                }
            );
        } else {
            alertify.error(this.translateService.instant('Please Select Payment Option'));
        }

    }

    getRechargeForOthersPayload(email) {
        // let payload = {};
        const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
        const customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
        const currency = this.persistenceService.get(CMUICONFIGKEY.DEFAULTYCURRENCY, StorageType.SESSION);
        const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        const payload = {
            userId: '',  // todo check with jayasri, is it optional
            partyId: partyId,
            customerId: customerId,
            journeyId: 'AccountRefill_ForOthers',
            type: 'ServiceOrder',
            status: 'InProgress',
            channelName: channelName,
            customerServiceOrder: {
                state: 'InProgress'
            },
            journeyData: {},
            coreData: {
                refillAmount: this.rechargeOthersForm.value.amount,
                currency: currency,
                donorCustomerName: '',
                beneficiaryMsisdn: this.rechargeOthersForm.value.phoneNumber,
                summaryTextLabel: 'AccountRefillDonorSummary',
                donorMsisdn: this.msisdn,
                donorEmail: email
            }
        };
        return payload;
    }

    public onBlurOfAmount() {
        const amountControl = this.rechargeOthersForm.controls.amount;
        const voucherCodeControl = this.rechargeOthersForm.controls.voucherCode;
        if (amountControl) {
            amountControl.setValidators(rechargeValidator(this.persistenceService, this.translateService, this.amountValidationMessage));
        }
        if (voucherCodeControl) {
            voucherCodeControl.setValidators(rechargeWithVoucherCodeValidator(this.translateService, this.persistenceService, this.voucherCodeValidationMessage));
        }
        amountControl.updateValueAndValidity();
        voucherCodeControl.updateValueAndValidity();
    }

    openRouteSection(Page, Section) {
        //this.router.navigate([Page], {fragment: Section});
        this.clickcomp.openRoute(Page, Section);
    }
    doScroll() {

        if (!this.sectionScroll) {
            return;
        }
        try {
            const elements = document.getElementById(this.sectionScroll);

            elements.scrollIntoView();

        }
        finally {
            this.sectionScroll = null;
        }
    }
}
