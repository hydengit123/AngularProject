import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DxpProductBundleComponent } from './dxp-product-bundle.component';

describe('DxpProductBundleComponent', () => {
  let component: DxpProductBundleComponent;
  let fixture: ComponentFixture<DxpProductBundleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DxpProductBundleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DxpProductBundleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
