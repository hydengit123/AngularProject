import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { DataFormatterPipe } from 'dxp-common';
import { CustomerSearchDataService } from '../../../services/customer-search-data.service';
import { CustomerSearchService } from '../../../services/customer-search.service';
@Component({
  selector: 'dxp-product-bundle',
  templateUrl: './dxp-product-bundle.component.html',
  styleUrls: ['./dxp-product-bundle.component.scss']
})
export class DxpProductBundleComponent implements OnInit {
  isDataPlanboxSelected: boolean;
  @Input() product: any;
  @Input() otherItem: any;
  @Input() expandable:boolean;
  @Input() tooltipData:any;
  @Input() sharedConsumerDetails: any;
  @Output() onExpandIconClick:EventEmitter<any> = new EventEmitter();
  @Output() onTransferClick:EventEmitter<any> = new EventEmitter();
  @Output() onShareClick:EventEmitter<any> = new EventEmitter();
  @Output() onTooltipClick:EventEmitter<any> = new EventEmitter();
  public expandOrCollapseLabel:string="Expand";
  public voiceImg: any;
  public dataImg: any;
  public smsImg: any;
  public bgColor:any;
  public colorScheme: any;
  private dataFormatterPipe: DataFormatterPipe;
  public expriyDateElement = false;

  constructor(private translateService:TranslateService, 
    private customerSearchService: CustomerSearchService,
    private customerSearchDataService: CustomerSearchDataService) {
      this.dataFormatterPipe = new DataFormatterPipe(this.translateService);
  }



  ngOnInit() {
    if(this.product && this.product.expandable){
      if(this.product.isCollapsed){
        // this.expandOrCollapseLabel = this.translateService.instant("moreavail", {more:`${this.dataFormatterPipe.transform(this.product.currentBalanceMore, this.product.unit)}`});
        this.expandOrCollapseLabel = `${this.dataFormatterPipe.transform(this.product.currentBalanceMore, this.product.unit)} more available`;
      }
      else{
        this.expandOrCollapseLabel = this.translateService.instant("Show Less");
      }
    }


    if(this.product.bucketType ){
    if(this.product.bucketType.toLowerCase() === "data" && this.product.isBasePlanBucket)
    {
      if(this.product.bucketType.toLowerCase() === "data"){
        this.bgColor = "#34B07F";
      }
        this.colorScheme = 'g';
    }
    else if(this.product.bucketType.toLowerCase() === "voice" )
    {
        this.bgColor = "#F2C618";
      if(this.product.bucketType.toLowerCase() === "voice"&& this.product.isBasePlanBucket)
      {
        this.colorScheme = 'y';
      }
    }
    else if(this.product.bucketType.toLowerCase() === "sms")
    {
        this.bgColor = "#DC2D37";
      if(this.product.bucketType.toLowerCase() === "sms" && this.product.isBasePlanBucket)
      {
        this.colorScheme = 'r';
      }
    }
  }
  }



  public moreProducts(e:any){
    this.product.isCollapsed = !this.product.isCollapsed;
    this.onExpandIconClick.emit({product: this.product});
  }



  public transferBuckets(productItem){
    this.onTransferClick.emit(productItem);
  }

  public shareBuckets(productItem){
    this.onShareClick.emit(productItem);
  }

  public getTooltipData($event, otherItem) {
    console.log($event);
    console.log(this.product);
    this.tooltipData = "";
    if (otherItem.sharedBucketType == "SHARED_PROVIDER") {
      let sharedToDetails = "";
      if (this.sharedConsumerDetails) {
          this.sharedConsumerDetails.forEach(element => {
              const itemSharedConsumerDetails = element['consumerBuckets'].filter((data) => data.name === otherItem.name);
              if (itemSharedConsumerDetails && itemSharedConsumerDetails.length > 0) {
                  sharedToDetails += element['consumerResource'] + ': ';
                  itemSharedConsumerDetails.forEach(data => {
                      const dataInfo = this.dataFormatterPipe.transform(data.bucketValue, data.unitOfMeasure);
                      sharedToDetails += dataInfo + '\n';
                  });
              }
          });
      }
      if (sharedToDetails) {
          this.tooltipData = this.translateService.instant("Shared to \n");
          this.tooltipData += sharedToDetails;
      }
  }  else {
        let sharedByDetails = "";
                const dataInfo = this.dataFormatterPipe.transform(otherItem.initialBalance, otherItem.unit);
                sharedByDetails += otherItem.providerMSISDN + ': ' + dataInfo + '\n';

            if (sharedByDetails) {
                this.tooltipData = this.translateService.instant("Shared by \n");
                this.tooltipData += sharedByDetails;
            }
    }

    return this.tooltipData.trim();
}

  public cardImage(otherItem) {
    if (otherItem && otherItem.bucketType && otherItem.bucketType == "VOICE") {
      this.voiceImg = "assets/imgs/home/phone-call-button.svg"
      return this.voiceImg;
    }
    else if (otherItem && otherItem.bucketType && otherItem.bucketType == "SMS") {
      return "assets/imgs/home/sms.svg";
    }
    else if (otherItem && otherItem.bucketType && otherItem.bucketType == "DATA") {
      return "assets/imgs/home/Wi-Fi.svg";
    }
  }

  public consumedImage(otherItem) {
    if (otherItem.isSharable === true) {
      return "assets/imgs/home/Group 1415.svg";
    }
   else if(otherItem.isSharable === false && otherItem.providerMSISDN) {
      return "assets/imgs/home/Group 850.svg";
    }
  }


}
