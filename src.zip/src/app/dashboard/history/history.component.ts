import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY } from 'dxp-common';
import * as _ from 'lodash';
import { IMyOptions } from 'ng-uikit-pro-standard';
import { Subscription } from 'rxjs';
import { CustomDecodeText } from '../../custom-pipe/CustomDecodeText.pipe';
import { EventListenerService } from '../../event-listener.service';
import { NotificationService } from '../../services/notification.service';
import { Notification } from '../../shared/model/notification';

declare const alertify;

@Component({
    selector: 'app-history',
    templateUrl: './history.component.html',
    styleUrls: ['./history.component.scss'],
    providers: [NotificationService, DatePipe]
})
export class HistoryComponent implements OnInit, OnDestroy {

    notificationForm: FormGroup;

    private toDate: Date;
    private fromDate: Date;
    public notifyShowHide: boolean;
    public errorNoRecord: boolean;
    public mymodel = '';
    public toDateMessage = { error: null, success: null };
    public fromDateMessage = { error: null, success: null };
    optionsHistory: {
        days?: Array<any>,
        channel?: Array<{ value?: string, label?: string, selected?: boolean }>
    };
    notificationSubscription: Subscription;
    daysSubscription: Subscription;


    preValue = {
        channel: '',
        days: '',
        fromDate: '',
        toDate: ''
    };

    public customDecodeText: CustomDecodeText = new CustomDecodeText();
    public notificationResponseData: Notification;
    public datePickerOptions: IMyOptions = {
        dateFormat: 'yyyy-mm-dd',
        disableSince: this.getDOBDateDisableUntil()
    };

    res: any;
    public fromDtPlaceholder: string;
    public toDtPlaceholder: string;


    constructor(
        private persistenceService: PersistenceService,
        private translateService: TranslateService,
        private eventListenerService: EventListenerService,
        private notificationService: NotificationService,
        private datePipe: DatePipe,
        private event: EventListenerService) {
        this.optionsHistory = {};
    }

    ngOnInit() {
        const notificationChanels = this.persistenceService.get(CMUICONFIGKEY.NOTIFICATIONCHANNELS, StorageType.SESSION);
        const notificationDays = this.persistenceService.get(CMUICONFIGKEY.NOTIFICATIONDAYS, StorageType.SESSION);
        this.fromDtPlaceholder = this.translateService.instant('From date');
        this.toDtPlaceholder = this.translateService.instant('To date');
        this.notificationForm = new FormGroup({
            channel: new FormControl('ALL', [Validators.required]),
            days: new FormControl('7', [Validators.required]),
            fromDate: new FormControl('', [Validators.required]),
            toDate: new FormControl('', [Validators.required])
        });

        this.calculateDate(this.notificationForm.get('days').value);

        this.optionsHistory.channel = notificationChanels.map((item) => {
            return { value: item.toUpperCase(), label: this.translateService.instant(item) };
        });

        this.optionsHistory.days = notificationDays.map(item => {
            return { value: item.daysValue, label: this.translateService.instant(item.daysName) };
        });

        this.notificationSubscription = this.notificationForm.valueChanges.subscribe((value) => {
            if (this.preValue.channel !== value.channel || this.preValue.fromDate !== value.fromDate || this.preValue.toDate !== value.toDate) {
                this.getNotificationData(value);
            }
        });

        this.daysSubscription = this.notificationForm.get('days').valueChanges.subscribe((value) => {
            if (value === 'Select Period') {
                this.notificationForm.get('toDate').setValue('');
                this.notificationForm.get('fromDate').setValue('');
            } else {
                this.calculateDate(value);
            }
        });
        this.getNotificationData(this.notificationForm.value);
    }
    searchText(searchText) {
        if (this.notificationResponseData) {
            const notificationFilteredData = this.customDecodeText.transform(this.notificationResponseData, 'deliveredMessage', searchText);
            this.notificationGroupedData(notificationFilteredData);
        }
    }
    calculateDate(value) {
        if (value !== 'Select Period') {
            this.toDate = new Date();
            this.fromDate = new Date();
            this.fromDate.setDate(this.fromDate.getDate() - value);
            const toDate = this.datePipe.transform(this.toDate, 'yyyy-MM-dd');
            const fromDate = this.datePipe.transform(this.fromDate, 'yyyy-MM-dd');
            this.notificationForm.get('toDate').setValue(toDate);
            this.notificationForm.get('fromDate').setValue(fromDate);
        }
    }

    getNotificationData(notificationFormData) {
        if (this.notificationForm.status === 'VALID') {

            if (this.notificationForm.get('fromDate').value && this.notificationForm.get('toDate').value && this.notificationForm.get('fromDate').value > this.notificationForm.get('toDate').value) {
                this.notifyShowHide = false;
                this.errorNoRecord = false;
                return false;
            }

            if (notificationFormData.days !== 'Select Period') {
                this.notifyShowHide = true;
            }
            this.errorNoRecord = false;
            this.preValue = Object.assign({}, notificationFormData);

            this.notificationService.getNotification(notificationFormData).subscribe(data => {
                if (data.length > 0) {
                    this.notifyShowHide = true;
                    this.errorNoRecord = false;
                    this.notificationResponseData = data.filter((item) => item.deliveredMessage !== '');
                    this.notificationGroupedData(this.notificationResponseData);

                } else {
                    this.notifyShowHide = false;
                    this.errorNoRecord = true;
                    // alertify.error(this.translateService.instant('No Record Found!'));
                }
            },
                (error) => {

                });
        }
    }
    sortDateTime(data) {
        return data.sort((a, b) => {
            if (new Date(a['lastModifiedDate']) < new Date(b['lastModifiedDate'])) {
                return -1;
            } else if (new Date(a['lastModifiedDate']) > new Date(b['lastModifiedDate'])) {
                return 1;
            } else {
                if (a['time'] <= b['time']) {
                    return -1;
                } else if (a['time'] > b['time']) {
                    return 1;
                }
            }
        });
    }
    private notificationGroupedData(data) {

        let sortedData = this.sortDateTime(data);
        const groupedDate = _.groupBy(sortedData, 'lastModifiedDate');

        const afterMapDate = [];
        _.mapKeys(groupedDate, (val, key) => {
            afterMapDate.push({ lastModifiedDate: key, messages: val });
        });
        this.res = afterMapDate;
    }

    private getDOBDateDisableUntil() {
        const dateObj = new Date();
        dateObj.setDate(dateObj.getDate());
        const dateOptions = { year: 'numeric', month: 'numeric', day: 'numeric' };
        const month = parseInt(dateObj.toLocaleDateString(undefined, dateOptions).split('/')[0]);
        const day = parseInt(dateObj.toLocaleDateString(undefined, dateOptions).split('/')[1]);
        const year = dateObj.getFullYear();
        return { year: year, month: month, day: day + 1 };
    }
    ngOnDestroy() {
        this.daysSubscription.unsubscribe();
        this.notificationSubscription.unsubscribe();
    }

    private isDateExceeded(curMessageObj, otherMessageObj,  message) {
        if (this.notificationForm.get('fromDate').value && this.notificationForm.get('toDate').value && this.notificationForm.get('fromDate').value > this.notificationForm.get('toDate').value) {
            curMessageObj.error = message;
        } else if (this.notificationForm.get('fromDate').value && this.notificationForm.get('toDate').value && this.notificationForm.get('fromDate').value <= this.notificationForm.get('toDate').value) {
            curMessageObj.error = null;
            otherMessageObj.error = null;
        }  else {
            curMessageObj.error = null;
        }
    }

    private isFutureDate(model, messageObj) {
        if (new Date(model.value) > new Date()) {
            messageObj.error = 'Dont use future date';
        }
    }

    public onChangeOfFromDatePicker(model) {
        if (!model.valid) {
            this.fromDateMessage.error = 'Date format is incorrect';
            this.isFutureDate(model, this.fromDateMessage);
        } else {
            this.isDateExceeded(this.fromDateMessage, this.toDateMessage, 'From-date should be less than To-date');
        }
    }
    public onChangeOfToDatePicker(model) {
        if (!model.valid) {
            this.toDateMessage.error = 'Date format is incorrect';
            this.isFutureDate(model, this.toDateMessage);
        } else {
            this.isDateExceeded(this.toDateMessage, this.fromDateMessage, 'To-date should be greater than From-date');
        }
    }
    public onBlurOfFromDatePicker(model) {
        if (model.reason === 2) {
            if (!model.value) {
                this.fromDateMessage.error = 'Date is required';
             }
    }
}
    public onBlurOfToDatePicker(model) {
        if (model.reason === 2) {
            if (!model.value) {
                this.toDateMessage.error = 'Date is required';
        }
    }
}
}
