import { HttpClient } from '@angular/common/http';
import { Component, ComponentFactoryResolver, Input, OnDestroy, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { ProductBucketShared, UpdateConsumerFormComponent, UserContractModel, UserProfile, CMUICONFIGKEY } from 'dxp-common';
import { ModalDirective } from 'ng-uikit-pro-standard';
import { Subscription } from 'rxjs';
import { REGEX } from '../../../application-constants';
import { EventEnum } from '../../enum/EventEnum';
import { EventListenerService } from '../../event-listener.service';
import { ShareWithConsumerService } from '../../services/share-with-consumer.service';
import { SuccessMessageComponent } from '../success-message/success-message.component';
import { TransferCreditComponent } from '../transfer-credit/transfer-credit.component';
import { TransferBucketComponent } from './../transfer-bucket/transfer-bucket.component';

@Component({
  selector: 'app-popup-modal',
  templateUrl: './popup-modal.component.html',
  styleUrls: ['./popup-modal.component.scss']
})
export class PopupModalComponent implements OnInit, OnDestroy {

  public title: string;
  public popUpSize: Boolean = true;
  @ViewChild('modalBody', { read: ViewContainerRef }) modalBody: ViewContainerRef;
  @ViewChild('modalFooter', { read: ViewContainerRef }) modalFooter: ViewContainerRef;
  @Input() modalBodyComponent: any;
  @ViewChild('basicModal') basicModal: ModalDirective;

  private consumerEventSubscription: Subscription;
  private closeEventSubscription: Subscription;
  private transferCreditEventSubsciption: Subscription;
  private transferBucketEventSubsciption: Subscription;

  constructor(private componentFactoryResolver: ComponentFactoryResolver,
    private httpClient: HttpClient,
    private eventService: EventListenerService,
    private translateService: TranslateService,
    private persistenceService: PersistenceService) { }

  onClose(e) {

  }


  ngOnInit() {


    this.consumerEventSubscription = this.eventService.consumersEvent.subscribe(d => {
      if (d && d.eventType === EventEnum.showAllConsumersInPopup) {
        this.showAllConsumersInPopup();
      }
      if (d && d.eventType === EventEnum.showUpdateConsumersInPopup) {
        if (d.userProfile && d.userContractProfile && d.productBucketShared && d.productId)
          this.showUpdateConsumersInPopup(d.productBucketShared, d.userProfile, d.userContractProfile, d.productId);
      }
      if (d && d.eventType === EventEnum.showSuccessAfterSharedBucketUpdateInPopup) {
        if (d.id && d.message && d.title) {
          this.showSuccessAfterSharedBucketUpdateInPopup(d.id, d.title, d.message, d.showId)
        }
      }

    });

    //closing popup modal
    this.closeEventSubscription = this.eventService.closeDashBoardPopupEvent.subscribe(d => {
      this.basicModal.hide();
    });


    this.transferCreditEventSubsciption = this.eventService.transferCreditPopupEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.transferCreditPopup && data.item && data.requestPayload) {
        this.transferCreditPopup(data.item, data.requestPayload);
      }
    });

    this.transferBucketEventSubsciption = this.eventService.transferBucketEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.transferBucket && data.item && data.requestPayload) {
        this.transferBucketPopup(data.item, data.requestPayload);
      }
    });

  }


  transferCreditPopup(itemDetails, requestPayload) {
    this.popUpSize = false;
    this.title = this.translateService.instant('Transfer Credit');
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(TransferCreditComponent);
    const viewContainerRef = this.modalBody;
    viewContainerRef.clear();
    const componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.itemDetails = itemDetails;
    componentRef.instance.requestPayload = requestPayload;
    this.basicModal.show();
  }

  showAllConsumersInPopup() {
    this.popUpSize = false;
    //set title
    // this.title = this.translateService.instant("Shared With");

    // let componentFactory = this.componentFactoryResolver.resolveComponentFactory(SharedConsumerListComponent);

    // let viewContainerRef = this.modalBody;
    // viewContainerRef.clear();

    // let componentRef = viewContainerRef.createComponent(componentFactory);
    // this.basicModal.show();

  }

  showUpdateConsumersInPopup(productBucketShared: ProductBucketShared, userProfile: UserProfile, userContractProfile: UserContractModel[], productId: string) {
    this.popUpSize = false;
    //set title
    this.title = this.translateService.instant("Share");

    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(UpdateConsumerFormComponent);

    let viewContainerRef = this.modalBody;
    viewContainerRef.clear();

    let componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.showFooterAction = true;
    componentRef.instance.customerId = userProfile.customerId;
    componentRef.instance.userProfile = userProfile;
    componentRef.instance.userContractProfile = userContractProfile[0];
    componentRef.instance.productBucketShared = productBucketShared;
    componentRef.instance.productId = productId;
    componentRef.instance.shareWithConsumerService = new ShareWithConsumerService(this.httpClient, this.persistenceService);
    componentRef.instance.event = this.eventService;
    componentRef.instance.refreshConsumerListEventEnum = EventEnum.refreshConsumerList;
    componentRef.instance.floatNumberRegex = REGEX.FLOATNUMBER;
    componentRef.instance.zeroExcludedNumberRegex = REGEX.ZEROEXCLUDEDNUMBER;
    componentRef.instance.onlyDigitRegex = REGEX.ONLYDIGIT;
    componentRef.instance.phoneNumberLength = parseInt(this.persistenceService.get(
      CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION
    )) || null;
    componentRef.instance.phoneNumberMaxLength = parseInt(this.persistenceService.get(
      CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION
    )) || null;
    this.basicModal.show();

  }

  showSuccessAfterSharedBucketUpdateInPopup(id: string, title: string, message: string, showId: boolean) {
    this.popUpSize = false;
    //set title
    this.title = this.translateService.instant(title);

    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(SuccessMessageComponent);

    let viewContainerRef = this.modalBody;
    viewContainerRef.clear();

    let componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.showFooterAction = true;
    componentRef.instance.id = id;
    componentRef.instance.message = message;
    componentRef.instance.showId = showId;
    this.basicModal.show();

  }

  ngOnDestroy() {
    if (this.consumerEventSubscription) {
      this.consumerEventSubscription.unsubscribe();
    }
    if (this.closeEventSubscription) {
      this.closeEventSubscription.unsubscribe();
    }
    if (this.transferBucketEventSubsciption) {
      this.transferBucketEventSubsciption.unsubscribe();
    }
    if (this.transferCreditEventSubsciption) {
      this.transferCreditEventSubsciption.unsubscribe();
    }

  }

  transferBucketPopup(itemDetails, requestPayload) {
    this.popUpSize = false;
    this.title = this.translateService.instant('Transfer') + ' ' + itemDetails.name;
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(TransferBucketComponent);
    const viewContainerRef = this.modalBody;
    viewContainerRef.clear();
    const componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.bucketItemDetails = itemDetails;
    componentRef.instance.requestPayload = requestPayload;
    this.basicModal.show();
  }


}
