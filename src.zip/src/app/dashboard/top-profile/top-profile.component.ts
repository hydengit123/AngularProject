import { Component, OnInit, Output, Input, ViewEncapsulation } from '@angular/core';
import { PERSISTANCEKEY } from '../../../application-constants';
import { CustomerSearchService } from '../../services/customer-search.service';
import { UserContractModel } from 'dxp-common';
import { PersistenceService, StorageType } from 'angular-persistence';
import { EventEmitter } from '@angular/core';
import { EventListenerService } from '../../event-listener.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
    selector: 'app-top-profile',
    templateUrl: './top-profile.component.html',
    styleUrls: ['./top-profile.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class TopProfileComponent implements OnInit {

    currentUserName: any;
    optionsSelect: Array<{ value?: string, label?: string, selected?: boolean }> = [];
    selectedValue;
    sortByMinMax:any;
    sortValue;
    commonProfile: any;
    msisdn;
    username;
    userList: UserContractModel[] = null;
    contractStatus = 'Active';

    @Input() enableSorting = null;
    @Input() enableSearching = null;
    @Input() enableMsisdnList = null;
    @Output() msisdnChangedEvent = new EventEmitter();

    constructor(
        private persistenceService: PersistenceService,
        private customerSearchService: CustomerSearchService,
        private event: EventListenerService,
        private translate : TranslateService
    ) {
        this.msisdn = this.persistenceService.get(PERSISTANCEKEY.MSISDN, StorageType.SESSION);
        this.username = this.persistenceService.get(PERSISTANCEKEY.USERNAME, StorageType.SESSION);
    }

    ngOnInit() {
        if (this.customerSearchService.getCurrentContract()==null) {
            this.customerSearchService.setCurrentContract(this.customerSearchService.getUserContracts()[0]);
          }
          this.loadSortData();
        this.setProfile();
    }

    loadSortData() {
        const sortData = [
          { value: -1, label: this.translate.instant('Price(min-max)') },
          { value: 1, label: this.translate.instant('Price(max-min)') }
        ];
        this.sortByMinMax = [...sortData];
      }

    getSelectedValue(event) {
        // event will have msisdn
        this.msisdn = event;
        this.persistenceService.set(PERSISTANCEKEY.MSISDN, this.msisdn, { type: StorageType.SESSION });

        this.event.msisdnChange(event);
        const contracts = this.customerSearchService.getUserContracts();
        for (let i = 0; i < contracts.length; i++) {
            if (contracts[i].msisdn === event) {
                this.contractStatus = contracts[i].status;
                this.customerSearchService.setCurrentContract(contracts[i]);
                break;
            }
        }
        this.msisdnChangedEvent.emit(event);
    }

    searchText(event) {
        this.event.dfySearchValChanged(event);
    }

    getSortingValue(event){
        this.event.dfySortValChanged(event);
    }

    private setProfile() {
        this.commonProfile = this.customerSearchService.getUserProfile();
        this.userList = this.customerSearchService.getUserContracts();

        this.userList.forEach(contractModel => {
            this.optionsSelect.push({ value: contractModel.msisdn, label: contractModel.msisdn, selected: true });
        });
        if (this.customerSearchService.getCurrentContract() == null) {
            this.msisdn = this.selectedValue = this.userList[0].msisdn;
        } else {
            this.msisdn = this.selectedValue = this.customerSearchService.getCurrentContract().msisdn;
        }
        this.getSelectedValue(this.msisdn);
        this.currentUserName = `${this.commonProfile.firstName.toUpperCase()}  ${this.commonProfile.lastName.toUpperCase()}`;
    }
}
