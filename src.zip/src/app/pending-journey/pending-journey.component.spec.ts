import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingJourneyComponent } from './pending-journey.component';

describe('PendingJourneyComponent', () => {
  let component: PendingJourneyComponent;
  let fixture: ComponentFixture<PendingJourneyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingJourneyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingJourneyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
