import { Component, OnInit, Input } from '@angular/core';
import { PERSISTANCEKEY, JOURNEYDATADETAILS } from '../../application-constants';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { EventListenerService } from '../event-listener.service';
import { CustomerSearchDataService } from '../services/customer-search-data.service';
import { Router } from '@angular/router';
import { CartService } from '../services/cart.service';
import { DealsForYouService } from '../services/dfy.service';

declare const alertify;

@Component({
  selector: 'app-pending-journey',
  templateUrl: './pending-journey.component.html',
  styleUrls: ['./pending-journey.component.scss']
})
export class PendingJourneyComponent implements OnInit {

  public journeySessionData = null;
  @Input() type = null;

  constructor(
    private translateService: TranslateService, private persistenceService: PersistenceService,
    private event: EventListenerService, private customerSearchDataService: CustomerSearchDataService,
    private router: Router, private cartService: CartService, private dealsForYouService: DealsForYouService
  ) { }

  ngOnInit() {
    this.loadpendingjourneys();
  }

  loadpendingjourneys() {
    let customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);

    if (this.type == 'addon') {
      this.getAddonJourney(customerId).subscribe((journeydata) => {
        this.journeySessionData = journeydata;
      }, error => {
      });
    }

    if (this.type == 'all') {
      this.customerSearchDataService.getJourneySessionData(customerId).subscribe(journeydata => {
        this.journeySessionData = journeydata;
      }, error => {
      });
    }

  }

  deleteJourneySession(journeyId) {
    let customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);

    this.dealsForYouService.deleteJourneySessionData(journeyId).subscribe(result => {
      this.event.notifyPendingJourneyCount();
      this.getAddonJourney(customerId).subscribe((journeydata) => {
        this.journeySessionData = journeydata;

      }, error => {
        this.event.closePendingJourneyPopUp();
        alertify.success(this.translateService.instant('Journey has been deleted'));
        if(this.journeySessionData && this.journeySessionData[0].journeyType=="ONBOARDING"){
          this.router.navigateByUrl('/customerOnboard');
        }        
      });
    });

  }

  getAddonJourney(customerId) {
    return this.cartService.getAddonJourneySessionData(customerId, 'BuyAddon');
  }

  private async goToJourneySaved(journeyStep, journeySessionId, checkJourney) {
    if (checkJourney && this.router.url.indexOf('/dfy') == -1) {
      this.router.navigate(['dashboard/dfy']);
    }else{
      this.router.navigateByUrl('/customerOnboard');
    }
      let journeySessionData = this.journeySessionData.filter((item) => item.id === journeySessionId);
      this.persistenceService.set(JOURNEYDATADETAILS.CURRENTSTEP, journeyStep, { type: StorageType.SESSION });
      this.persistenceService.set(JOURNEYDATADETAILS.JOURNEYSESSIONID, journeySessionId, { type: StorageType.SESSION });
      this.persistenceService.set(JOURNEYDATADETAILS.JOURNEYDATA, journeySessionData[0].journeyData, { type: StorageType.SESSION });
      this.persistenceService.set(JOURNEYDATADETAILS.JOURNEYID, journeySessionData[0].journeyId, { type: StorageType.SESSION });
      this.persistenceService.set(JOURNEYDATADETAILS.JOURNEYSTATUS, journeySessionData[0].journeyStatus, { type: StorageType.SESSION });
      this.dealsForYouService.journeySessionId = journeySessionId;
      this.event.closePendingJourneyPopUp();
      if (journeySessionData && journeySessionData[0]
        && journeySessionData[0].journeyData) {
        if (journeySessionData[0].journeyData.shoppingCartId) {
          const cartDetails = await this.cartService.getCartDetails(journeySessionData[0].journeyData.shoppingCartId).toPromise();
          this.event.notifyCartUpdate(cartDetails);
        }
        this.event.updateStepperInfo(journeyStep);
      }
    

  }

}
