import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { ModalDirective } from 'ng-uikit-pro-standard';
import { Subscription } from 'rxjs';
import { LOCALIZATIONPERSISTANCEKEY, PERSISTANCEKEY, WEBCONTENTPERSISTANCEKEY } from '../../application-constants';
import { EventListenerService } from '../event-listener.service';
import { WebContent } from '../interface/web.content';
import { AuthService } from '../services/auth.service';
import { CMSContentService } from '../services/cms-content.service';
import { RegisterService } from '../services/register.service';
import { registerValidator } from '../shared/validators/RegisterValidate';
import { CMUICONFIGKEY } from 'dxp-common';


declare const alertify;

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
  providers: [CMSContentService, RegisterService]
})
export class RegisterComponent implements OnInit {

  @ViewChild('username') private elementRef: ElementRef;
  @Input() basicModal: ModalDirective;

  registerForm: FormGroup;
  phoneNumberLength: number;
  phoneNumberMaxLength: number;
  validationIniatiated = true;
  testRef: any;
  isOtpGenerated: boolean = false;
  otpToVerify: number = 0;
  showEmailMsisdn: string;

  webContent: WebContent;
  cmsServiceSubscription: Subscription;
  public userStatus: any = false;
  public userIdentity:any;

  public leftImg;

  constructor(
    private persistenceService: PersistenceService,
    private router: Router,
    private authService: AuthService,
    private fb: FormBuilder,
    private cmsService: CMSContentService,
    private translateService: TranslateService,
    public registerService: RegisterService,
    private event: EventListenerService) {

    this.registerForm = new FormGroup({
      username: new FormControl('', [Validators.required]),
      user_otp: new FormControl(),
      password: new FormControl(),
      confirm_password: new FormControl(),
      otp_verify: new FormControl(this.otpToVerify)
    },
      [registerValidator(this.persistenceService)]
    );

  }

  ngOnInit() {
    this.updateWebContent();
  }

  updateWebContent() {
    const language = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
    this.phoneNumberLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION);
    this.phoneNumberMaxLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION);
    this.testRef = this.registerForm.errors;
    this.cmsServiceSubscription = this.cmsService.getWebPageContent('selfcare', language).subscribe((data: any) => {
      this.persistenceService.set(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, data, { type: StorageType.SESSION });
      this.webContent = this.persistenceService.get(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, StorageType.SESSION);
      if (this.webContent) {
        if (this.webContent.leftImage) {
          this.leftImg = this.webContent.leftImage.url;
        }
      }
    },
      (error) => {
        if (error.status == 404) {
          alertify.error(this.translateService.instant('CMS server down'));
        } else if (error.error) {
          alertify.error(error.error.message);
        }
        else {
          alertify.error(error.message);
        }
      });
  }

  doRegister() {
    if (this.isOtpGenerated) {
      this.updateUserInfo();
    } else {
      this.registerUserInfo();
    }
  }
  private registerUserInfo() {

    this.registerService.emailCheck(this.registerForm.controls['username'].value).subscribe(data => {
      this.showEmailMsisdn = data.identities[0].identityType;
      this.userIdentity = data.identities[0].identifier;
      this.authService.setUserIdentity(this.userIdentity);
      this.registerForm.controls['username'].setErrors({ 'emailAlreadyExists': true });      
      this.isOtpGenerated = false;

      if(data.identities[0].status && data.identities[0].status.toLowerCase() === 'active'){
        this.userStatus = true;
      }else if(data.identities[0].status && data.identities[0].status.toLowerCase() === 'init'){
        this.userStatus = false;
      }

    },
      error => {
        if (error.status === 404) {
          this.isOtpGenerated = true;
          this.otpToVerify = 1234;
          this.registerForm.controls.otp_verify.setValue(this.otpToVerify);

          this.registerForm = new FormGroup({
            username: new FormControl(this.registerForm.controls.username.value),
            user_otp: new FormControl('', [Validators.required]),
            password: new FormControl('', [Validators.required]),
            confirm_password: new FormControl('', [Validators.required]),
            otp_verify: new FormControl(this.otpToVerify)
          },
            [registerValidator(this.persistenceService)]
          );

          this.registerService.userRegister(this.registerForm.value).subscribe((data) => {
            alertify.success(this.translateService.instant('User Registered Successfully'));
            this.persistenceService.set(PERSISTANCEKEY.REGISTEREMAILMSISDN, this.registerForm.controls['username'].value, { type: StorageType.SESSION });
            this.elementRef.nativeElement.focus();
          });
        } else {
          this.isOtpGenerated = false;
          alertify.error(this.translateService.instant('Something Went Wrong'));
        }
      });
  }
  private updateUserInfo() {

    this.registerService.userLoginCheck(this.registerForm.value).subscribe((data) => {
      let res = data;
      this.persistenceService.set(PERSISTANCEKEY.ACCESSTOKEN, res["access_token"], { type: StorageType.SESSION });
      this.persistenceService.set(PERSISTANCEKEY.PARTYID, res["partyId"], { type: StorageType.SESSION });
      setTimeout(() => {
        this.doReset();
      }, 1000);
    },
      (error) => {
        if (error.status === 401) {
          this.registerForm.controls['user_otp'].setErrors({ 'user_otpInvalidError': true });
        }
      });
  }

  redirectToLogin(){
    this.event.showLoginPopupDetails(true);
  }

  doReset() {
    let userObject = {
      "username": btoa(this.registerForm.controls['username'].value),
      "currentPassword": btoa(this.registerForm.controls['user_otp'].value),
      "newPassword": btoa(this.registerForm.controls['password'].value)
    };
    this.authService.resetPassword(userObject)
      .subscribe(
        (data: any) => {
          alertify.success(this.translateService.instant('Password changed successfully'));
          this.basicModal.hide();
          this.router.navigate(['dashboard']);
        },
        (error) => {
          alertify.error(this.translateService.instant('Password not changed'));
        }
      )
  }

  onBlurValidation(fieldName) {
    registerValidator(this.persistenceService);
    let isError = false;
    const errors = this.registerForm.errors;
    const username = this.registerForm.controls.username.touched;
    if (errors && fieldName && !this.registerForm.controls[fieldName].value) {
      errors[fieldName + 'RequiredError'] = true;
      isError = true;
      this.validationIniatiated = true;
    }
  }

  get formValidate() {
    return this.registerForm;
  }

  ngAfterViewInit() {
    if (this.elementRef && this.elementRef.nativeElement) {
      this.elementRef.nativeElement.focus();
    }
  }

  resendOtp() {
    this.registerService.otpResent(this.registerForm.controls['username'].value).subscribe((data) => {

    });
  }
}
