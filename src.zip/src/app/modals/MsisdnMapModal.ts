import UserProfile from "./ProfileModal";

export default  class MsisdnMapModal{

    voice:any;
    sms:any;
    data:any;
    addOns=[];
    PlanName:string='';
    PlanDescription:string='';
    msisdn:Number;
    // profile:UserProfile;

    constructor(msisdn){
        this.msisdn=msisdn;
        this.voice=null;
        this.sms=null
        this.data=null;
        // this.profile= null;
    }

    // setProfile(profile){
    //     this.profile=new UserProfile(profile);
    // }

    public setVoice(voice){
        this.voice=voice;
    }

    public  setSms(sms){
        this.sms=sms;
    }

    public setData(data){
        this.data=data;
    }

    public pushAddon(addon){
        this.addOns.push(addon);
    }

    public setPlanDetails(plan){
        this.PlanDescription = plan.PlanDescription;
        this.PlanName = plan.PlanName;
    }
}