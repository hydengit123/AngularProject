import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY } from 'dxp-common';
import { environment } from '../../environments/environment';

export default class UserProfile {

    firstName: string = '';
    lastName: string = '';
    dateOfBirth: any = '';
    country: string = '';
    gender: string = '';
    nationality: string = '';
    language: string = '';

    email: any = [];
    phone: any = [];
    address: any = [];

    contactMedium: any = []

    identities: any = [];
    identityDocumentType: any = [];
    customerId: string = '';
    status: string = "";
    photo: string = '';
    anniversaryDate: any;
    maritalStatus: string;
    customerSegment: string;
    placeOfBirth: string;
    communicationAddressType: string;
    communicationEmailType: string;
    shippingAddressType: string;
    shippingEmailType: string;
    communicationAddress: any[];
    communicationEmail: any[];
    shippingAddress: any[];
    shippingEmail: any[];

    constructor(profile,
        private persistenceService: PersistenceService) {

        this.firstName = profile.firstName || '';
        this.lastName = profile.lastName || '';
        this.dateOfBirth = profile.dateOfBirth || '';
        this.country = profile.country || '';
        this.gender = profile.gender || '';
        this.nationality = profile.nationality || '';
        this.language = profile.language || '';
        this.status = profile.status || '';
        this.customerId = profile.customerId || '';
        this.anniversaryDate = profile.anniversaryDate || '';
        this.maritalStatus = profile.maritalStatus || '';
        if (profile.customerSegment && profile.customerSegment.length > 0) {
            this.customerSegment = profile.customerSegment[0].segmentId || '';
        }

        this.placeOfBirth = profile.placeOfBirth || '';
        this.communicationAddressType = this.persistenceService.get(CMUICONFIGKEY.COMMUNICATION_ADDRESS, StorageType.SESSION);
        this.communicationEmailType = this.persistenceService.get(CMUICONFIGKEY.COMMUNICATION_EMAIL, StorageType.SESSION);
        this.shippingAddressType = this.persistenceService.get(CMUICONFIGKEY.SHIPPING_ADDRESS, StorageType.SESSION);
        this.shippingEmailType = this.persistenceService.get(CMUICONFIGKEY.SHIPPING_EMAIL, StorageType.SESSION);
        this.identityDocumentType = this.persistenceService.get(CMUICONFIGKEY.IDENTITYDOCTYPE, StorageType.SESSION);
        if (profile.photo) {
            this.photo = (environment.urls.cmsUrl + profile.photo) || '';
        } else {
            this.photo = 'assets/imgs/Group 157@2x.png' || '';
        }

        if (profile.contactMedium || profile.contactMediumAssociations) {
            this.setContact(profile.contactMedium, profile.contactMediumAssociations);
        }

        if (profile.identities) {
            this.setIdentities(profile.identities);
        }


    }

    setItemVal(contactMedium, loopItem) {
        for (const contact of contactMedium) {
            if (contact.type === this[loopItem + 'Type']) {
                for (const val of contact.value) {
                    this[loopItem].push(val.value);
                }
            }
        }
    }

    setContact(contactMedium, contactMediumAssociations) {
        const loopArr = ['communicationAddress', 'shippingAddress', 'communicationEmail', 'shippingEmail'];
        for (const loopItem of loopArr) {
            this[loopItem] = [];
            if (contactMediumAssociations) {
                for (const association of contactMediumAssociations) {
                    if (association.contactRole === this[loopItem + 'Type']) {
                        for (const val of association.contactMedium.contactMediumValue) {
                            this[loopItem].push(val.value);
                        }
                    }
                }
                if (this[loopItem] && this[loopItem].length === 0) {
                    this.setItemVal(contactMedium, loopItem);
                }
            } else {
                this.setItemVal(contactMedium, loopItem);
            }
        }

        for (const contact of contactMedium) {
            if (contact.type === 'EmailContact') {
                for (const value of contact.value) {
                    this.email.push(value.value);
                }
            }
            if (contact.type === 'PhoneContact') {
                for (const value of contact.value) {
                    this.phone.push(value.value);
                }
            }
            if (contact.type === 'PostalContact') {
                for (const value of contact.value) {
                    this.address.push(value.value);
                }
            }
        }
    }

    setIdentities(identies) {
        for (const identity of identies) {
            if (this.identityDocumentType) {
                for (let docs = 0; docs < this.identityDocumentType.length; docs++) {
                    if (identity.type === this.identityDocumentType[docs].identityDocumentCode) {
                        this.identities.push(this.identityDocumentType[docs].identityDocumentName + '/' + identity.value);
                    }
                }
            }
        }
    }

}
