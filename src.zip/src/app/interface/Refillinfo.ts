export interface Refillinfo {
    userId: string,
    partyId: string,
    customerId: string,
    journeyId: string,
    type: string,
    status: string,
    channelName: string,
    // customerServiceOrder: { "state":"InProgress" },
    journeyData: {},
    coreData: rechargeamount[]
}

export interface rechargeamount {
    refillAmount: number,
    currency: string,
    customerAccountId: number,
    summaryTextLabel: string
}