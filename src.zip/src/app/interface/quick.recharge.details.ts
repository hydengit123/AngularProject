
export interface QuickRechargeFormDetails {
    partyId: string;
    customerId: string;
    firstName: string;
    lastName: string;
    email: string;
}