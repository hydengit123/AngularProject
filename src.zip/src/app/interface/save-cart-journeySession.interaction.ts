import { productItemSelected, activationDetails, contactDetails } from "dxp-common";

export interface saveCartJourneySessionInteraction{

    userId: string,
    customerId: number,
    partyId: string,
    journeyStatus: string,
    journeyType: string,
    currentStep: number,
    journeyId: string,
    channelName: string,
        journeyData: {
            activationDetails:activationDetails,
      
            plan:productItemSelected[],
         
            addons:productItemSelected[],

            contactDetails:contactDetails,
}
}