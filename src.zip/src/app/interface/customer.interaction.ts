import { PaymentTransactionRequest, productItemSelected, activationDetails, contactDetails, customerIdentities, customerPurchaseOrder } from "dxp-common";

export interface customerInteraction {

        summary: string,

        journeyData: {

                activationDetails: activationDetails,

                plan: productItemSelected[],

                addons: productItemSelected[],

                contactDetails: contactDetails,

                payment: PaymentTransactionRequest,

                customerStatus: string,

                contractId: string,

                contractStatus: string,

                shoppingCartId: string,

                customerId: string,

                partyId: string,

                journeySessionId: string,

                userId: string,

                "pre-activatedBaseOffer": {

                        id: string

                }

        },

        customerId: string,

        partyId: string,

        journeySessionId: string,

        userId: string,

        journeyId: string,


        journeyStatus: string,
        journeyType: string,

        currentStep: number,

        status: string,

        type: string,

        channelName: string,

        externalId: string,

        customerPurchaseOrder: customerPurchaseOrder,

        customerIdentities: customerIdentities
}