import {IBanner} from './IBanner';

export interface WebContent{
    banner: IBanner,
    leftImage: IBanner,
    offersBanner: IBanner,
    bottomRightImage: IBanner,
    footerImage: IBanner,
    footerLightImage: IBanner,
}