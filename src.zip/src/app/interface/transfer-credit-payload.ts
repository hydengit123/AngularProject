export interface TransferCreditPayload {
    'partyId': String;
    'customerId': String;
    'journeyId': String;
    'type': String;
    'status': String;
    'channelName': String;
    'customerServiceOrder': {
        'state': String
    };
    'journeyData': Object;
    'coreData': {
        'beneficiaryMsisdn': String;
        'currency': String;
        'summaryTextLabel': String;
        'transferQuantity': String;
        'customerAccountId': String;
    };
}
