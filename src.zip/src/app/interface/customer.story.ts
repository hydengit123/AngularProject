export interface ICustomerStory {
    id: string;
    journeyId: string;
    title:string;
    summary:string;
    createDate:string;
    statusType:string;
    status:string;
    type:string;
    channelName:string;
  }
  