
export interface RechargeOthersPayload {
    userId: string;
    partyId: string;
    customerId: string;
    journeyId: string;
    type: string;
    status: string;
    channelName: string;
    customerServiceOrder: {
        state: string
    };
    journeyData: Object;
    coreData: {
        refillAmount: number;
        currency: string;
        donorCustomerName: string;
        beneficiaryMsisdn: string;
        summaryTextLabel: string;
        donorMsisdn: string;
        donorEmail: string;
    };
  }
