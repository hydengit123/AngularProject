export interface IBanner{
    id:string,
    title:string,
    background:string,
    description:string,
    buttonName:string,
    buttonUrl:string,
    url:string,
    type:string
}