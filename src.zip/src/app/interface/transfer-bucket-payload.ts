export interface TransferBucketPayload {
    partyId: String;
    customerId: String;
    journeyId: String;
    type: String;
    status: String;
    channelName: String;
    customerServiceOrder: {
        state: String
    };
    journeyData: Object;
    coreData: {
        beneficiaryMsisdn: String;
        bucketId: String;
        bucketType: String;
        contractId: String;
        productId: String;
        quantityUnit: String;
        summaryTextLabel: String;
        transferQuantity: String;
        msisdn: String;
        srcProductInstanceId: string;
    };
}
