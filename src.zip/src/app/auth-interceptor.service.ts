
import {catchError,tap} from 'rxjs/operators';
import {Injectable} from '@angular/core';
import {HttpErrorResponse, HttpEvent, HttpHandler, HttpHeaders, HttpRequest, HttpResponse} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';


import {PersistenceService, StorageType} from 'angular-persistence';
import {AuthService} from './services/auth.service';
import {Router} from '@angular/router';
import {PERSISTANCEKEY} from '../application-constants';
import { environment } from '../environments/environment';


declare const alertify;

@Injectable()
export class AuthInterceptorService {

  constructor(private persistenceService: PersistenceService, private authService: AuthService, private router: Router) {
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const accessToken = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION)
                        || this.persistenceService.get(PERSISTANCEKEY.DUMMYTOKEN, StorageType.SESSION);
    let headers: any = {};
    if (accessToken && accessToken !== '') {

      headers = {
        'Content-Type': 'application/json; charset=UTF-8'
      };
      if(request.url.indexOf(environment.urls.login) === -1){
        headers['Authorization'] = 'Bearer ' + accessToken;
      }

    } else {
      headers = {
        'Content-Type': 'application/json; charset=UTF-8'
      };
    }
    const clonedRequest = request.clone({
      setHeaders: headers
    });


    return next.handle(clonedRequest).pipe(
      catchError((err: any) => {
        if (err instanceof HttpErrorResponse) {
          if (err.status === 401 &&
                ( err.message === 'TOKEN_EXPIRED' || err.message === 'MALFORMED_ERROR'
                || err.error === 'ACCESS DENIED : Token has expired')) {
            // alertify.error('session timed out');
            this.persistenceService.removeAll(StorageType.SESSION);
            this.router.navigateByUrl('/public');
          }
        }
        return throwError(err);
      })

    );
  }
}
