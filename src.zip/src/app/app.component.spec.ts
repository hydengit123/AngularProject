import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslateService } from '@ngx-translate/core';
import { ReplaySubject } from 'rxjs';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let routerSpy: jasmine.SpyObj<Router>;
  let translateServiceSpy: any;

  beforeEach(async(() => {
    const RouterSpy = jasmine.createSpyObj('Router', ['navigate']);
    translateServiceSpy = {
      setDefaultLang: () => { },
      getBrowserCultureLang: () => { return 'de-DE' },
      use: () => new ReplaySubject(1),
      instant: () => { },
    }

    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
      providers: [
        { provide: Router, useValue: RouterSpy },
        { provide: TranslateService, useValue: translateServiceSpy }
      ],
      imports: [
        RouterTestingModule,
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    routerSpy = TestBed.get(Router);
    component = fixture.componentInstance;
  });
  it('should create the app', async(() => {
    expect(component).toBeTruthy();
  }));
});
