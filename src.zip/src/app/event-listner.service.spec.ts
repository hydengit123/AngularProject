import { TestBed, inject } from '@angular/core/testing';
import { PersistenceService, StorageType } from 'angular-persistence';
import { EventListenerService } from './event-listener.service';

describe('EventListenerService', () => {
  let eventListenerService: EventListenerService;
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  beforeEach(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set'])

    TestBed.configureTestingModule({
      providers: [EventListenerService,
        { provide: PersistenceService, useValue: PersistenceServiceSpy }
      ]
    });
  });

  beforeEach(() => {
    eventListenerService = TestBed.get(EventListenerService);
    persistenceServiceSpy = TestBed.get(PersistenceService);

  });

  it('should be created', () => {
    expect(eventListenerService).toBeTruthy();
  });

  describe('customerDataChanges', () => {
    it('should call customerDataChangesEvent.emit with customerDataObj', () => {
      spyOn(eventListenerService.customerDataChangesEvent, 'emit').and.callThrough();

      eventListenerService.customerDataChanges('12', '23', '34');

      expect(eventListenerService.customerDataChangesEvent.emit).toHaveBeenCalledWith({ data: '12', voice: '23', sms: '34' });
    });
  });

  describe('addToMainBalance', () => {
    it('should call balanceEvent.emit', () => {
      persistenceServiceSpy.get.and.returnValue({ mainBalance: { unit: 200 } });
      spyOn(eventListenerService.balanceEvent, 'emit').and.callThrough();

      eventListenerService.addToMainBalance(100);
      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
      expect(eventListenerService.balanceEvent.emit).toHaveBeenCalledWith(0);
    });
  });
  describe('removeFromMainBalance', () => {
    it('should call balanceEvent.emit', () => {
      persistenceServiceSpy.get.and.returnValue({ mainBalance: { unit: 200 } });
      spyOn(eventListenerService.balanceEvent, 'emit').and.callThrough();

      eventListenerService.removeFromMainBalance(100);
      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
      expect(eventListenerService.balanceEvent.emit).toHaveBeenCalledWith(0);
    });
  });
  describe('addData', () => {
    it('should call balanceEvent.emit', () => {
      persistenceServiceSpy.get.and.returnValue({ data: 100 });
      spyOn(eventListenerService.balanceEvent, 'emit').and.callThrough();
      spyOn(eventListenerService, 'removeFromMainBalance');

      eventListenerService.addData(100, 200);

      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(persistenceServiceSpy.set).toHaveBeenCalledTimes(2);
      expect(eventListenerService.balanceEvent.emit).toHaveBeenCalledWith(1);
      expect(eventListenerService.removeFromMainBalance).toHaveBeenCalledWith(200);
    });
  });
  describe('removeData', () => {
    it('should call balanceEvent.emit', () => {
      persistenceServiceSpy.get.and.returnValue({ data: 100 });
      spyOn(eventListenerService.balanceEvent, 'emit').and.callThrough();

      eventListenerService.removeData(100);

      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
      expect(eventListenerService.balanceEvent.emit).toHaveBeenCalledWith(1);
    });
  });
  describe('addMinutes', () => {
    it('should call balanceEvent.emit', () => {
      persistenceServiceSpy.get.and.returnValue({ data: 100 });
      spyOn(eventListenerService.balanceEvent, 'emit').and.callThrough();
      spyOn(eventListenerService, 'removeFromMainBalance');

      eventListenerService.addMinutes(100, 200);

      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(persistenceServiceSpy.set).toHaveBeenCalledTimes(2);
      expect(eventListenerService.balanceEvent.emit).toHaveBeenCalledWith(2);
      expect(eventListenerService.removeFromMainBalance).toHaveBeenCalledWith(200);
    });
  });
  describe('removeMinutes', () => {
    it('should call balanceEvent.emit', () => {
      persistenceServiceSpy.get.and.returnValue({ data: 100 });
      spyOn(eventListenerService.balanceEvent, 'emit').and.callThrough();

      eventListenerService.removeMinutes(100);

      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
      expect(eventListenerService.balanceEvent.emit).toHaveBeenCalledWith(2);
    });
  });
  describe('addSMS', () => {
    it('should call balanceEvent.emit and removeFromMainBalance with given price', () => {
      persistenceServiceSpy.get.and.returnValue({ sms: 100 });
      spyOn(eventListenerService.balanceEvent, 'emit').and.callThrough();
      spyOn(eventListenerService, 'removeFromMainBalance');

      eventListenerService.addSMS(100, 200);

      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(persistenceServiceSpy.set).toHaveBeenCalledTimes(2);
      expect(eventListenerService.balanceEvent.emit).toHaveBeenCalledWith(3);
      expect(eventListenerService.removeFromMainBalance).toHaveBeenCalledWith(200);
    });
  });
  describe('removeSms', () => {
    it('should call balanceEvent.emit', () => {
      persistenceServiceSpy.get.and.returnValue({ sms: 100 });
      spyOn(eventListenerService.balanceEvent, 'emit').and.callThrough();

      eventListenerService.removeSms(100);

      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(persistenceServiceSpy.set).toHaveBeenCalled();
      expect(eventListenerService.balanceEvent.emit).toHaveBeenCalledWith(3);
    });
  });
  describe('profileUpdated', () => {
    it('should call balanceEvent.emit', () => {
      spyOn(eventListenerService.profileEvent, 'emit').and.callThrough();

      eventListenerService.profileUpdated();

      expect(eventListenerService.profileEvent.emit).toHaveBeenCalledWith(4);
    });
  });
});
