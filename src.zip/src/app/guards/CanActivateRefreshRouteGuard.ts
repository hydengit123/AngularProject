import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { FormMessageService } from '../customer-onboarding/services/form-message.service';
import { EventListenerService } from '../event-listener.service';
import { customerOnboard, CMUICONFIGKEY } from 'dxp-common';
import { CartService } from '../services/cart.service';

declare const alertify;

@Injectable()
export class CanActivateRefreshRouteGuard implements CanActivate {

  constructor(private router: Router,
    private persistenceService: PersistenceService,
    private formMessageService: FormMessageService,
    private cartService: CartService,
    private translateService: TranslateService,
    private eventListener: EventListenerService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<UrlTree | boolean> | UrlTree | boolean {
    const registerMandatory = this.persistenceService.get(CMUICONFIGKEY.REGISTRATIONMANDATORY, StorageType.SESSION);
    const enableOTP = this.persistenceService.get(CMUICONFIGKEY.ENABLEOTP, StorageType.SESSION);
    const fraudcheck = this.persistenceService.get(CMUICONFIGKEY.FRAUDCHECKOPTION, StorageType.SESSION);


    const customerOnBoardData: customerOnboard = this.formMessageService.onboardingForm.value as customerOnboard;
    if (customerOnBoardData && customerOnBoardData.currentStep) {
      if (customerOnBoardData.currentStep === 2) {//Plan
        if (((fraudcheck ==='ACTIVATION_CODE_REQUIRED' && customerOnBoardData.activationDetails.activationCode) || fraudcheck !=='ACTIVATION_CODE_REQUIRED' ) &&
          customerOnBoardData.activationDetails.phoneNumber
          && customerOnBoardData.activationDetails.location
          && customerOnBoardData.activationDetails.simCardNumber &&
          fraudcheck) {
          return true;
        }
      }
      if (customerOnBoardData.currentStep === 3) {//AddOn
        if (((fraudcheck ==='ACTIVATION_CODE_REQUIRED' && customerOnBoardData.activationDetails.activationCode) || fraudcheck !=='ACTIVATION_CODE_REQUIRED' ) &&
          customerOnBoardData.activationDetails.phoneNumber
          && customerOnBoardData.activationDetails.location
          && customerOnBoardData.activationDetails.simCardNumber && customerOnBoardData.shoppingCartId &&
          fraudcheck) {
          return true;
        }
      }
      if (customerOnBoardData.currentStep === 4) {//Contact Details
        if (((fraudcheck ==='ACTIVATION_CODE_REQUIRED' && customerOnBoardData.activationDetails.activationCode) || fraudcheck !=='ACTIVATION_CODE_REQUIRED' ) &&
          customerOnBoardData.activationDetails.phoneNumber
          && customerOnBoardData.activationDetails.location
          && customerOnBoardData.activationDetails.simCardNumber && customerOnBoardData.shoppingCartId && 
          customerOnBoardData.contactDetails.address && customerOnBoardData.contactDetails.signUInfo && 
        customerOnBoardData.contactDetails.personalInformation && customerOnBoardData.contactDetails.identity &&
        fraudcheck) {
          return true;
        }
      }
      if (customerOnBoardData.currentStep === 5) {//checkout page
        if (((fraudcheck ==='ACTIVATION_CODE_REQUIRED' && customerOnBoardData.activationDetails.activationCode) || fraudcheck !=='ACTIVATION_CODE_REQUIRED' ) &&
          customerOnBoardData.activationDetails.phoneNumber
          && customerOnBoardData.activationDetails.location
          && customerOnBoardData.activationDetails.simCardNumber && customerOnBoardData.shoppingCartId && 
          customerOnBoardData.contactDetails.address && customerOnBoardData.contactDetails.signUInfo && 
        customerOnBoardData.contactDetails.personalInformation && customerOnBoardData.contactDetails.identity && fraudcheck) {
          return true;
        }
      }
    }

    return this.router.parseUrl(this.formMessageService.getStepURL('1'));

  }
}
