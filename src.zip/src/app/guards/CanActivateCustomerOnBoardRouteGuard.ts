import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router,
  UrlTree
} from '@angular/router';
import { PersistenceService, StorageType } from 'angular-persistence';
import { JOURNEYDATADETAILS } from '../../application-constants';
import { FormMessageService } from '../customer-onboarding/services/form-message.service';
import { CartService } from '../services/cart.service';
import { TranslateService } from '@ngx-translate/core';
import { EventListenerService } from '../event-listener.service';
import { CMUICONFIGKEY, customerOnboard } from 'dxp-common';

declare const alertify;

@Injectable()
export class CanActivateCustomerOnBoardRouteGuard implements CanActivate {

  constructor(private router: Router,
    private persistenceService: PersistenceService,
    private formMessageService: FormMessageService,
    private cartService: CartService,
    private translateService: TranslateService,
    private eventListener: EventListenerService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<UrlTree | boolean> | UrlTree | boolean {
    const journeySessionId = this.persistenceService.get(JOURNEYDATADETAILS.JOURNEYSESSIONID, StorageType.SESSION);
    if (journeySessionId) {
      let currentStep = this.persistenceService.get(JOURNEYDATADETAILS.CURRENTSTEP, StorageType.SESSION);
      let journeyData = this.persistenceService.get(JOURNEYDATADETAILS.JOURNEYDATA, StorageType.SESSION);
      let journeyId = this.persistenceService.get(JOURNEYDATADETAILS.JOURNEYID, StorageType.SESSION);
      let journeyStatus = this.persistenceService.get(JOURNEYDATADETAILS.JOURNEYSTATUS, StorageType.SESSION);
      this.persistenceService.remove(JOURNEYDATADETAILS.JOURNEYSESSIONID, StorageType.SESSION);
      this.persistenceService.remove(JOURNEYDATADETAILS.CURRENTSTEP, StorageType.SESSION);
      this.persistenceService.remove(JOURNEYDATADETAILS.JOURNEYDATA, StorageType.SESSION);
      this.persistenceService.remove(JOURNEYDATADETAILS.JOURNEYID, StorageType.SESSION);
      this.persistenceService.remove(JOURNEYDATADETAILS.JOURNEYSTATUS, StorageType.SESSION);
      return this.setJourneyData(currentStep, journeyData, journeySessionId, journeyId, journeyStatus);
    }
    return true;
  }

  public async setJourneyData(journeyStep, journeyData, journeySessionId, journeyId, journeyStatus): Promise<UrlTree | boolean> {
    if (journeyId.toLowerCase() === JOURNEYDATADETAILS.ONBOARDTYPE.toLowerCase()) {
      this.formMessageService.onboardingForm.patchValue(journeyData);
      this.formMessageService.onboardingForm.controls.journeySessionId.patchValue(journeySessionId);
      this.formMessageService.onboardingForm.controls.preActivatedBaseOffer.patchValue(journeyData["pre-activatedBaseOffer"]);

      if (journeyData.shoppingCartId) {
        this.cartService.cartDetails = {
          id: journeyData.shoppingCartId,
          createdBy: null,
          createdByChannel: null,
          updatedBy: null,
          lastUpdatedByChannel: null,
          cartItem: null,
          cartList: null,
          totalPrice: null,
        };
        const productCategory = this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMES_FORADDONQUERY, StorageType.SESSION).concat(this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMESFORVASEOFFERQUERY, StorageType.SESSION));
        const isInValidPlanOrAddOn = await this.cartService.isInvalidPlanOrAddonAvailableInCart(productCategory, (this.formMessageService.onboardingForm.value as customerOnboard).activationDetails.location);
        const cartDetails = this.cartService.cartDetails;
        if (cartDetails) {
          this.formMessageService.onboardingForm.controls.shoppingCartId.setValue(cartDetails.id);
          this.eventListener.notifyCartUpdate(cartDetails);
          if (isInValidPlanOrAddOn) {
            const invalidMessageOnPlan = this.formMessageService.showAlertOnInvalidPlan(cartDetails);
            if (invalidMessageOnPlan) {
              alertify.error(invalidMessageOnPlan.invalidMessage);
              this.eventListener.updateStepperInfo(parseInt(invalidMessageOnPlan.step));
              return this.router.parseUrl(this.formMessageService.getStepURL(invalidMessageOnPlan.step));
            }
          }
          this.eventListener.updateStepperInfo(parseInt(journeyStep));
          return this.router.parseUrl(this.formMessageService.getStepURL(journeyStep));
        }
      }
    }
    else {
      return false;
    }

  }
}