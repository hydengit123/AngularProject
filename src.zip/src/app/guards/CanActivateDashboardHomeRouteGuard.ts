import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { EventListenerService } from '../event-listener.service';
import { CustomerSearchService } from '../services/customer-search.service';
import { CustomerSearchDataService } from '../services/customer-search-data.service';
import { PERSISTANCEKEY } from '../../application-constants';
import UserProfile from '../modals/ProfileModal';
import { AddSubscriptionService } from '../services/add-subscription.service';
import { UserContractModel } from 'dxp-common';

declare const alertify;

@Injectable()
export class CanActivateDashboardHomeRouteGuard implements CanActivate {

  constructor(private router: Router,
    private persistenceService: PersistenceService,
    private customerSearchService: CustomerSearchService,
    private customerSearchDataService: CustomerSearchDataService,
    private translateService: TranslateService,
    private addSubscriptionService: AddSubscriptionService,
    private eventListener: EventListenerService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<UrlTree | boolean> | UrlTree | boolean {

    return this.getDashboardUrl();

  }

  private async getDashboardUrl(): Promise<UrlTree | boolean> {
    const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
    let url: any = false;
    if (partyId) {
      const profiledata = await this.customerSearchDataService.setUserProfileData(partyId).toPromise();
      const profile = new UserProfile(profiledata, this.persistenceService);

      this.customerSearchService.setUserProfile(profile);
      const CustomerID = profile.customerId;
      if (CustomerID) {
        const contractResponse = await this.customerSearchDataService.getContract(CustomerID).toPromise();
        if (contractResponse) {

          let activeStatusProfile = [];
          const contractDetails: any = contractResponse;
          this.customerSearchService.setpendingJourneyStatus(false);
          if (contractDetails.length > 0) {
            activeStatusProfile = contractDetails.filter((item) => item.status.toLowerCase() === 'active');
          }
          if (contractDetails.length === 0) {
            url = await this.getJourneySessionDetails(CustomerID, profile, contractResponse, false);
          } else if (contractDetails.length > 0 && activeStatusProfile.length === 0) {
            url = await this.getJourneySessionDetails(CustomerID, profile, contractResponse, true);
          } else {
            url = this.getDashboardData(profile, contractResponse);
          }
        }
      }
    }
    return url;
  }
  private async getJourneySessionDetails(customerId, profile, contractResponse, contractExist: Boolean): Promise<UrlTree | boolean> {
    let url: any = false;
    try {
      const journeySessionData: any = await this.customerSearchDataService.getJourneySessionData(customerId).toPromise();
      this.customerSearchService.setPendingId(customerId);
      this.customerSearchService.setJourneyData(journeySessionData, journeySessionData.length);
      if (journeySessionData && journeySessionData.length > 0) {
        this.customerSearchService.setpendingJourneyStatus(true);
        this.eventListener.notifyPendingJourneyStatus(true);
        this.addSubscriptionService.setSubscriptionStatus(false);
        if (this.router.url.indexOf('/subscription') !== -1) {
          url = this.router.parseUrl('dashboard/subscription');
        } else if (this.router.url.indexOf('/support') !== -1) {
          url = this.router.parseUrl('dashboard/support');
        } else {
          url = this.router.parseUrl('dashboard/continueJourney');
        }

      }
    }
    catch (err) {
      if (contractExist) {
        this.getDashboardData(profile, contractResponse);
        url = true;
      } else {
        // call link subscription
        this.customerSearchService.setpendingJourneyStatus(false);
        this.addSubscriptionService.setSubscriptionStatus(true);
        if (err.error.code === '2002') {
          if (this.router.url.indexOf('/subscription') !== -1) {
            url = this.router.parseUrl('dashboard/subscription');
          } else if (this.router.url.indexOf('/support') !== -1) {
            url = this.router.parseUrl('dashboard/support');
          } else {
            url = this.router.parseUrl('customerOnboard');
          }
        } else {
          url = true;
        }
      }
    }
    return url;
  }

  private getDashboardData(profile, contractResponse) {
    const constracs = contractResponse;;
    this.customerSearchService.setUserProfile(profile);
    const userContracts = constracs.map(contract => {
      return new UserContractModel(contract);
    });
    this.customerSearchService.setUserContracts(userContracts);
    this.customerSearchService.setpendingJourneyStatus(false);
    this.addSubscriptionService.setSubscriptionStatus(false);
    this.customerSearchService.setCurrentContract(this.customerSearchService.getUserContracts()[0]);
    return true;
  }
}
