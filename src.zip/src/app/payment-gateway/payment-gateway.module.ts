import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {TranslateModule} from '@ngx-translate/core';
import { PaymentComponent } from './payment/payment.component';
import {TranslateLoader} from '@ngx-translate/core';
import { selfcareTranslateLoader } from '../factories/translate-loader.factory';
import { HttpClient } from '@angular/common/http';
import { PaymentGatewayRouting } from './payment-gateway.routing.module';
import { PaymentGatewayComponent } from './payment-gateway.component';

@NgModule({
  imports: [
    CommonModule,
    PaymentGatewayRouting,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: selfcareTranslateLoader,
        deps:[HttpClient]
      }
    }),
  ],
  declarations: [
    PaymentComponent,
    PaymentGatewayComponent
  ],
  exports: [
    TranslateModule
  ]
})
export class PaymentGatewayModule {
}
