import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { PaymentGatewayComponent } from './payment-gateway.component';
import { PaymentComponent } from './payment/payment.component';


const routes: Routes = [{
    path: '',
    component: PaymentGatewayComponent,
    children: [{
      path: 'payment', component: PaymentComponent, pathMatch: 'full'
    }]
}];

@NgModule({
imports: [RouterModule.forChild(routes)],
exports: [RouterModule]
})

export class PaymentGatewayRouting {
}
