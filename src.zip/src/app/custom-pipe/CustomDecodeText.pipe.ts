import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'textDecodedPipe',
})
export class CustomDecodeText implements PipeTransform {
    transform(source: any, key:string, input: string) {
        if (input && key) {
            input = input.toLowerCase();
            return source.filter((el) => {
                return atob(el[key]).toLowerCase().indexOf(input.toLowerCase()) !== -1;
            });
        }
        return source;
    }
}