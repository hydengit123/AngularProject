import { DateDiffPipe } from './date-diff.pipe';
import * as moment from 'moment';

describe('DateDiffPipe', () => {
  let pipe: DateDiffPipe;

  beforeEach(() => {
    pipe = new DateDiffPipe();
  });
  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });
  describe('Bad Inputs', () => {
    it('should return null', () => {
      expect(pipe.transform(null)).toEqual('');
    });
  });

  describe('Calculations', () => {
    it('should equal mockdiff ', () => {
      const date2 = new Date(new Date().setHours(0, 0, 0, 0));
      const mockdiff = moment(new Date('2019-03-01')).diff(moment(date2), 'days');
      expect(pipe.transform('01-03-2019 14:30:42')).toEqual(mockdiff);
    });
    it('should return 18', () => {
      expect(pipe.transform('01-03-2019 14:30:42', '02-11-2019')).toEqual(18);
    });
  });

});
