import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pager'
})
export class CustomPagination implements PipeTransform {

  transform(dataSource: any[], max:number): any[] {

    // Check if is not null
    if (!dataSource || !max ) return ["No Records"];
    let pageArray = [];
    if(dataSource.length==0){
      pageArray.push("No Records");
      return pageArray;
    }
    for(let i=0; i<Math.ceil(dataSource.length/max); i++){
      pageArray.push(i+1);
    }
    return pageArray;
    }

}