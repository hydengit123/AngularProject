import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'filterImageById'
})
export class FilterImageById implements PipeTransform {

  transform(value: any, args?: any): any {
    if(value){
    return value.filter(item => item.id == args);
  }
  return null;
  }
}
