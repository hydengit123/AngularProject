import { Pipe, PipeTransform } from '@angular/core';
import { CustomTableSortPipe } from './CustomTableSort.pipe';
import * as _ from 'lodash';

@Pipe({
  name: 'activePageRecords'
})
export class CustomPaginatedCollection implements PipeTransform {

  transform(dataSource: any[], activePage: number, max: number, path: string[], order: number): any[] {

    // Check if is not null
    if (!dataSource || !max) return [0];
    let activePageRecords;
    let start = max * (activePage - 1);
    let end;
    let clonedData = _.cloneDeep(dataSource);
    if(path && order){
      let sortData = new CustomTableSortPipe();
      clonedData = sortData.transform(clonedData, path, order);
    }
    if ((start + max) >= clonedData.length) {
      end = clonedData.length;
    }
    else {
      end = start + max;
    }
    activePageRecords = clonedData.slice(start, end);
    return activePageRecords;
  }

}