import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterByKeys'
})
export class CustomFilterByKey implements PipeTransform {

  transform(dataSource: any[], keyValuePairs: object, isOR: boolean = false): any[] {

    // Check if is not null
    if (!dataSource || !keyValuePairs) return dataSource;

    let filteredData = dataSource.filter((item: any, k: any) => {
      let isFiltered = {};
      // We go for each property followed by path
      Object.keys(keyValuePairs)
        .forEach(property => {
          if (typeof keyValuePairs[property] == 'boolean'
              && typeof item[property] == 'boolean') {
              isFiltered[property] = item[property] == keyValuePairs[property];
          }
          else if(!keyValuePairs[property]) {
            isFiltered[property] = true;
          }
          else if (typeof keyValuePairs[property] == 'number'
              && typeof item[property] == 'number') {
              isFiltered[property] = item[property] == keyValuePairs[property];
            }
          else if (item[property] && keyValuePairs[property]) {
            if (typeof keyValuePairs[property] == 'string'
              && typeof item[property] == 'string') {
              isFiltered[property] = item[property].toLowerCase().includes(keyValuePairs[property].toLowerCase());
            }
          }
      });
    let consolidatedFilterCheck = Object.keys(isFiltered);
    let consolidatedFilterVal = [];
    consolidatedFilterCheck.forEach(isPropMatchingKey => {
      consolidatedFilterVal.push(isFiltered[isPropMatchingKey]);
    });
    if (isOR) {
      if (consolidatedFilterVal.join(',').indexOf('true') >= 0) {
        return true;
      }
      else {
        return false;
      }
    }
    else {
      if (consolidatedFilterVal.join(',').indexOf('false') >= 0) {
        return false;
      }
      else {
        return true;
      }
    }

  });
return filteredData;
  }

}