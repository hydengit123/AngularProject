import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {StringToCapitalizePipe} from './string-to-capitalize.pipe';
import {GetLocalTimePipe} from './get-local-time.pipe';
import {SetToArrayPipe} from './set-to-array.pipe';
import {ValueFormatterPipe} from './value-formatter.pipe';
import {DateDiffPipe} from './date-diff.pipe';
import {FilterImageById} from './filter-image-by-id';
import { CustomTableSortPipe } from './CustomTableSort.pipe';
import { CustomPaginatedCollection } from './CustomPaginatedCollection.pipe';
import { CustomFilterByKey } from './CustomFilterByKey.pipe';
import { CustomPagination } from './CustomPagination.pipe';
import { DecodeMsgPipe } from './decode-msg.pipe';
import { CustomDecodeText } from './CustomDecodeText.pipe';
import { AddonFilterPipe } from './addon-filter.pipe';
import { HtmlsanitizePipe } from './htmlsanitize.pipe';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    StringToCapitalizePipe,
    GetLocalTimePipe,
    SetToArrayPipe,
    ValueFormatterPipe,
    DateDiffPipe,
    FilterImageById,
    CustomTableSortPipe,
    CustomFilterByKey,
    CustomPaginatedCollection,
    CustomPagination,
    DecodeMsgPipe,
    CustomDecodeText,
    AddonFilterPipe,
    HtmlsanitizePipe
  ],
  exports: [
    StringToCapitalizePipe,
    GetLocalTimePipe,
    SetToArrayPipe,
    ValueFormatterPipe,
    AddonFilterPipe,
    DateDiffPipe,
    FilterImageById,
    CustomTableSortPipe,
    CustomFilterByKey,
    CustomPaginatedCollection,
    CustomPagination,
    DecodeMsgPipe,
    CustomDecodeText,
    HtmlsanitizePipe
  ]
})
export class CustomPipeModule {
}
