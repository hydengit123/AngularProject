import { GetLocalTimePipe } from './get-local-time.pipe';

describe('GetLocalTimePipe', () => {
  let pipe: GetLocalTimePipe;

  beforeEach(() => {
    pipe = new GetLocalTimePipe();
  });
  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  describe('Bad Inputs', () => {
    it('should return null', () => {
      expect(pipe.transform(null)).toEqual('');
    });
    it('should return null', () => {
      expect(pipe.transform('')).toEqual('');
    });
  });

  describe('Calculations', () => {
    it('should return format DD/MM/YYYY h:mm a', () => {
      expect(pipe.transform('01-03-2019')).toEqual('03/01/2019 12:00 am');
    });
    it('should return format DD/MM/YYYY', () => {
      expect(pipe.transform('01-03-2019', 'day')).toEqual('03/01/2019');
    });
    it('should return format h:mm a', () => {
      expect(pipe.transform('01-03-2019', 'time')).toEqual('12:00 am');
    });
    it('should return format DD/MM/YYYY', () => {
      expect(pipe.transform('01-03-2019', 'assist')).toEqual('03/01/2019');
    });
    it('should return format h:mm a if the value is present day', () => {
      const value = new Date().toDateString();
      expect(pipe.transform(value, 'assist')).toEqual('12:00 am');
    });
  });

});
