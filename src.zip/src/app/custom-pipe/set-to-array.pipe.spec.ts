import { SetToArrayPipe } from './set-to-array.pipe';

describe('SetToArrayPipe', () => {
  let pipe: SetToArrayPipe;

  beforeEach(() => {
    pipe = new SetToArrayPipe();
  });
  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  describe('Bad Inputs', () => {
    it('should return blank array', () => {
      expect(pipe.transform(null)).toEqual([]);
    });
  });

  describe('Calculations', () => {
    it('should return array', () => {
      const mockSet = new Set([1, 2, 3]);
      expect(pipe.transform(mockSet)).toEqual([1, 2, 3]);
    });
  });
});
