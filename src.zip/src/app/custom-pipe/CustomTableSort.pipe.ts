import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortTableBy'
})
export class CustomTableSortPipe implements PipeTransform {

  transform(dataSource: any[], path: string[], order: number): any[] {

    // Check if is not null
    if (!dataSource || !path || !order) return dataSource;

    let sorteredData = dataSource.sort((a: any, b: any) => {
      // We go for each property followed by path
      path.forEach(property => {
        a = a[property];
        b = b[property];
      });

      if (a != null && b != null) {
        if(typeof a ==='string' && typeof b === 'string')
        return a.localeCompare(b, undefined, { numeric: true }) * order;
        else if((typeof a === 'number' && typeof b === 'number') || (typeof a === 'boolean' && typeof b === 'boolean'))
        return a > b ? 1 * order: -1 * order; 
      }
      else {
        return 0;
      }
    }
    );
    return sorteredData;
  }

}