import { ValueFormatterPipe } from './value-formatter.pipe';

describe('ValueFormatterPipe', () => {
  let pipe: ValueFormatterPipe;

  beforeEach(() => {
    pipe = new ValueFormatterPipe();
  });
  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  describe('Calculations', () => {
    describe('Calculations when given Value is string', () => {
      it('should format the value when args is data', () => {
        expect(pipe.transform('12345', 'data')).toEqual('0');
      });
      it('should format the value when args is voice', () => {
        expect(pipe.transform('12345', 'voice')).toEqual('205.75');
      });
      it('should format the value when args is price', () => {
        expect(pipe.transform('12345', 'price')).toEqual('123.45');
      });
      it('should format the value when args is credit', () => {
        expect(pipe.transform('12345', 'credit')).toEqual('123.45');
      });
      it('should format the value when args is mb', () => {
        expect(pipe.transform('12345', 'mb')).toEqual('0.01');
      });
      it('should format the value when args is mb-gb', () => {
        expect(pipe.transform('12345', 'mb-gb')).toEqual('12.06');
      });
    });
    describe('Calculations when given Value is numerical', () => {
      it('should format the value when args is data', () => {
        expect(pipe.transform(12345.78, 'data')).toEqual('0');
      });
      it('should format the value when args is voice', () => {
        expect(pipe.transform(12345.78, 'voice')).toEqual('205.76');
      });
      it('should format the value when args is price', () => {
        expect(pipe.transform(12345.78, 'price')).toEqual('123.46');
      });
      it('should format the value when args is credit', () => {
        expect(pipe.transform(12345.78, 'credit')).toEqual('123.46');
      });
      it('should format the value when args is mb', () => {
        expect(pipe.transform(12345.78, 'mb')).toEqual('0.01');
      });
      it('should format the value when args is mb-gb', () => {
        expect(pipe.transform(12345.78, 'mb-gb')).toEqual('12.06');
      });
    });
  });
});
