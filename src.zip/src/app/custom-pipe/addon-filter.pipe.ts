import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'addonFilter'
})
export class AddonFilterPipe implements PipeTransform {

    resultArray:any;

    transform(list: any[], filterText: string): any {
      return list ? this.customFilter(list,filterText) : [[]];
      // return list;
    }


    chunk(arr, chunkSize) {
      let R = [];
      for (let i = 0, len = arr.length; i < len; i += chunkSize) {
          R.push(arr.slice(i, i + chunkSize));
      }
      return R;
  }

    customFilter(list,filterText){
      this.resultArray=[];

      for(let i=0;i<list.length;i++){
        for(let j=0;j<list[i].length;j++){
        if(list[i][j].name.toLowerCase().indexOf(filterText)!=-1){
          this.resultArray.push(list[i][j]);
        }
        } 
      }

      return this.chunk(this.resultArray,4);
    }
  
  
}
