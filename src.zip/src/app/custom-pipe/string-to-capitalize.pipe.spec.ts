import { StringToCapitalizePipe } from './string-to-capitalize.pipe';

describe('StringToCapitalizePipe', () => {
  let pipe: StringToCapitalizePipe;

  beforeEach(() => {
    pipe = new StringToCapitalizePipe();
  });
  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  describe('Bad Inputs', () => {
    it('should return blank array', () => {
      expect(pipe.transform(null)).toEqual(null);
    });
  });
  describe('Formatting', () => {
    it('should return in Capital Alphabetical format if given input isNaN & length >0 ', () => {
      expect(pipe.transform('mock test')).toEqual('Mock Test');
    });

    it('should return in Numerical format if given input is Number ', () => {
      expect(pipe.transform('12345')).toEqual('12345');
    });
  });
});
