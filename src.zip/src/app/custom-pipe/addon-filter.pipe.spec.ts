import { AddonFilterPipe } from './addon-filter.pipe';

describe('AddonFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new AddonFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
