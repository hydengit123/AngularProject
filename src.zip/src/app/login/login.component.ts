import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { ModalDirective } from 'ng-uikit-pro-standard';
import { Subscription } from 'rxjs';
import { LOCALIZATIONPERSISTANCEKEY, PERSISTANCEKEY, WEBCONTENTPERSISTANCEKEY } from '../../application-constants';
import { EventListenerService } from '../event-listener.service';
import { WebContent } from '../interface/web.content';
import { AuthService } from '../services/auth.service';
import { CMSContentService } from '../services/cms-content.service';
import { CustomerSearchDataService } from '../services/customer-search-data.service';
import { CustomerSearchService } from '../services/customer-search.service';
import { CustomerService } from '../services/customer.service';
import { loginValidator } from '../shared/validators/LoginValidator';
import { resetValidator } from '../shared/validators/ResetFormValidate';
import { CMUICONFIGKEY } from 'dxp-common';


declare const alertify;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [CustomerService, CMSContentService]
})
export class LoginComponent implements OnInit {

  phoneNumberLength: any;
  phoneNumberMaxLength: number;
  enableResetPassword: boolean = false;
  registerForm: FormGroup;
  resetForm: FormGroup;
  resetSuccessfull: boolean = false;
  resetEmail: any = null;
  webContent: WebContent;
  cmsServiceSubscription: Subscription;
  userIdentity:any;
  public leftImg;
  @Input() showImage: boolean;
  @Input() basicModal: ModalDirective;


  constructor(
    private translateService: TranslateService,
    private eventService: EventListenerService,
    private persistenceService: PersistenceService,
    private router: Router,
    private customerService: CustomerService,
    private fb: FormBuilder,
    private cmsService: CMSContentService,
    private authService: AuthService,
    private customerSearchDataService: CustomerSearchDataService,
    private customerSearchService: CustomerSearchService,
  ) {

    // this.loginForm = fb.group({
    //   username: ['9831145107', [Validators.required]],
    //   password: ['', [Validators.required]]
    // });

    this.registerForm = new FormGroup({
      username: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required])

    },
      [loginValidator(this.persistenceService)]
    );


    this.resetForm = new FormGroup({
      password: new FormControl('', [Validators.required]),
      confirm_password: new FormControl('', [Validators.required])

    },
      [resetValidator(this.persistenceService)]
    );

  }


  ngOnInit() {
    this.updateWebContent();
    this.userIdentity = this.authService.getUserIdentity();
    if(this.userIdentity){
      this.registerForm.controls['username'].setValue(this.userIdentity.trim());
    }
  }

  updateWebContent() {
    const language = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
    this.phoneNumberLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERLENGTH, StorageType.SESSION);
    this.phoneNumberMaxLength = this.persistenceService.get(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, StorageType.SESSION);
    this.cmsServiceSubscription = this.cmsService.getWebPageContent('selfcare', language).subscribe((data: any) => {
      this.persistenceService.set(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, data, { type: StorageType.SESSION });
      this.webContent = this.persistenceService.get(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, StorageType.SESSION);
      if (this.webContent) {
        if (this.webContent.leftImage) {
          this.leftImg = this.webContent.leftImage.url;
        }
      }
    },
      (error) => {
        if (error.status == 404) {
          alertify.error(this.translateService.instant('CMS server down'));
        } else if (error.error) {
          alertify.error(error.error.message);
        }
        else {
          alertify.error(error.message);
        }
      });
  }

  doLogin(): void {
    this.authService.login(this.registerForm.value.username, this.registerForm.value.password)
      .subscribe(
        (res: any) => {
          this.persistenceService.set(PERSISTANCEKEY.ACCESSTOKEN, res["access_token"], { type: StorageType.SESSION });
          this.persistenceService.set(PERSISTANCEKEY.REGISTEREMAILMSISDN, this.registerForm.value.username, { type: StorageType.SESSION });

          if (res.mustChange === true) {
            this.resetEmail = this.registerForm.value.username;
            this.enableResetPassword = true;
          }
          else {
            this.persistenceService.set(PERSISTANCEKEY.PARTYID, res["partyId"], { type: StorageType.SESSION });
            this.enableResetPassword = false;

            this.customerSearchDataService.setUserProfileData(res["partyId"])
              .subscribe((profiledata) => {

                this.persistenceService.set(PERSISTANCEKEY.CUSTOMERID, profiledata.customerId, { type: StorageType.SESSION });
                this.basicModal.hide();

                if (this.router.url.indexOf('customerOnboard') !== -1) {

                  if (this.router.url.indexOf('paymentsuccessful') !== -1) {
                    this.router.navigate(['dashboard']);
                  } else {
                    this.eventService.notifyLogin(true);
                  }

                } else {
                  this.router.navigate(['dashboard']);
                }
              })


          }

        },
        (error) => {
          alertify.error(this.translateService.instant('Invalid Username/Password'));
        }
      )
  }

  onBlurValidation(fieldName) {
    loginValidator(this.persistenceService);
    let isError = false;
    const errors = this.registerForm.errors;
    const username = this.registerForm.controls.username.touched;
    if (errors && fieldName && !this.registerForm.controls[fieldName].value) {
      errors[fieldName + 'RequiredError'] = true;
      isError = true;
      // this.validationIniatiated = true;
    }
    if (fieldName === 'username') {
      const userName = {...this.registerForm.controls[fieldName]};
      this.registerForm.controls[fieldName].setValue(userName.value.trim());
    }
  }
  ngAfterViewInit() {
    // if(this.userIdentity){
    //   this.registerForm.controls['username'].setValue(this.userIdentity.trim());
    // }
    
  }
 

  reset() {
    this.enableResetPassword = false;
    this.resetSuccessfull = false;
    // setTimeout(()=>{
    //   this.registerForm.reset();
    // },1000)

    this.registerForm = new FormGroup({
      username: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required])

    },
      [resetValidator(this.persistenceService)]
    );

  }
  doReset(): void {

    let userObject = {
      "username": btoa(this.registerForm.value.username),
      "currentPassword": btoa(this.registerForm.value.password),
      "newPassword": btoa(this.resetForm.value.confirm_password)
    };

    this.authService.resetPassword(userObject)
      .subscribe(
        (data: any) => {

          this.resetSuccessfull = true;


        },
        (error) => {
          this.resetSuccessfull = false;
        }
      )
  }

  switchToForgot() {

  }

  // For Displaying Login Popup
  showRegisterPopup() {
    this.eventService.showRegisterPopupDetails();
  }

}
