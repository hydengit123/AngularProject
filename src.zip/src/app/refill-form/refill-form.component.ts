import { getCurrencySymbol } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CustomerInteractionRefill } from 'dxp-common';
import * as _ from 'lodash';
import { PERSISTANCEKEY } from '../../application-constants';
import { EventEnum } from '../enum/EventEnum';
import { EventListenerService } from '../event-listener.service';
import { PaymentRequestInfo, CMUICONFIGKEY } from 'dxp-common';
import { Refillinfo } from '../interface/Refillinfo';
import { CustomerSearchService } from '../services/customer-search.service';
import { CustomerService } from '../services/customer.service';
import { PaymentGatewayService } from '../services/payment-gateway.service';
import { RechargeTransferService } from '../services/recharge-transfer.service';
import { rechargeValidator, rechargeWithVoucherCodeValidator } from '../shared/validators/recharge.validators';

declare const alertify;

@Component({
    selector: 'app-refill-form',
    templateUrl: './refill-form.component.html',
    styleUrls: ['./refill-form.component.scss']
})



export class RefillFormComponent implements OnInit {

    public refillForm: FormGroup;
    public isNext = false;
    public rechargeFormSelf: boolean;
    public eventType: Number;
    public message;
    public amount;
    public msisdnNumber: string;
    public paymentProperty: any;
    public paymentRequestInfo: PaymentRequestInfo;
    public paymentRequest: any;
    public refillPayload: CustomerInteractionRefill;
    public paymentSuccess = false;
    public customerId: any;
    public userProfile: any;
    public userContractProfile: any;
    public refillInfo: Refillinfo;
    public orderIdMessage: any;
    public rechargeMessage: any;
    public transactionMessage: any;
    public creditBalance: any;
    public amountValidationMessage = { error: null, success: null };
    public voucherCodeValidationMessage = { error: null, success: null };
    public refillOptions: any;
    public currencySign: any;
    public currencySymbol: any;
    // public paymentRequest: PaymentRequestInfo;
    public successMessage: any;
    public vouchercode: any;
    public voucherPayload;

    constructor(private eventListenerService: EventListenerService,
        public paymentService: PaymentGatewayService,
        public customerSearchService: CustomerSearchService,
        public http: HttpClient,
        public rechargeTransferService: RechargeTransferService,
        public persistenceService: PersistenceService,
        public translateService: TranslateService,
        public customerService: CustomerService) {
        this.refillForm = new FormGroup({
            amount: new FormControl(),
            vouchercode: new FormControl(),
        });
    }

    ngOnInit() {
        const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
        const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        this.refillOptions = this.persistenceService.get(CMUICONFIGKEY.REFILLAMOUNTOPTIONS, StorageType.SESSION);
        if (this.eventType === EventEnum.refillPopup) {
            this.msisdnNumber = this.voucherPayload.coreData.msisdn;
        } else {
            this.msisdnNumber = this.voucherPayload.coreData.beneficiaryMsisdn;
        }
        this.currencySign = this.persistenceService.get(CMUICONFIGKEY.DEFAULTYCURRENCY, StorageType.SESSION);
        this.paymentProperty = this.paymentResponseHandler(this.paymentRequestInfo);

        // this.refillPayload = {
        //     userId: '', 
        //     partyId: partyId,
        //     customerId: this.customerId,
        //     journeyId: 'AccountRefill',
        //     type: 'ServiceOrder',
        //     status: 'InProgress',
        //     channelName: channelName,
        //     customerServiceOrder: {},
        //     journeyData: {},
        //     coreData: {
        //         refillAmount: 30,
        //         currency: this.currencySign,  
        //         customerAccountId: '9638527413',
        //         summaryTextLabel: 'AccountRefillSummary'
        //     }
        // };
        this.currencySymbol = getCurrencySymbol(this.refillPayload.coreData.currency, 'narrow');

        this.refillForm.valueChanges.subscribe(data => {
            if (data && data.amount) {
                let deepCloneOfPaymentRequest = _.cloneDeep(this.paymentRequest);
                this.paymentRequest = Object.assign({}, deepCloneOfPaymentRequest, data);
            }
        });

        //    this.paymentRequest.firstname = this.userProfile.firstName;
        //     this.paymentRequest.lastname = this.userProfile.lastName;
        //     this.paymentRequest.email = this.userProfile.email[0];
        //     this.paymentRequest.productinfo = 'Recharge';

        this.refillForm.controls.amount.valueChanges.subscribe(data => {
            if (this.refillForm.controls.amount.value) {
                this.refillPayload.coreData.refillAmount = this.refillForm.value.amount;
                this.paymentRequestInfo.amount = this.refillForm.controls.amount.value;
                this.refillForm.controls.vouchercode.setValue('');
            }
        });
        this.refillForm.controls.vouchercode.valueChanges.subscribe(data => {
            if (this.refillForm.controls.vouchercode.value) {
                this.refillForm.controls.amount.setValue('');
                this.isNext = false;
            }
        });

    }

    setActive(val) {
        this.refillForm.get('amount').setValue(val);
        this.onBlurOfAmount();
    }

    public paymentResponseHandler(paymentRequest: PaymentRequestInfo) {
        let responseData = {};
        //if (onBoardData2) {
        responseData = {
            responseHandler: (BOLT) => {
                return this.requestpaymentSuccessHandler(BOLT, paymentRequest);
            }
            // ,
            // catchException: (BOLT) => {
            //     return this.requestpaymentFailureHandler(BOLT, onBoardData2);
            // }
        }
        //}
        return responseData;
    }

    private async requestpaymentSuccessHandler(BOLT, paymentRequest: PaymentRequestInfo) {
        if (BOLT.response && BOLT.response.txnStatus == "SUCCESS"
            && BOLT.response.txnid) {
            let paymentTransactionRequest = {
                resourceNumber: this.paymentService.paymentConfigSelected.resourceNumber,//MSISDN from customer journey
                payer: BOLT.response.payer || 'NA',//NA in old code
                merchantRefNum: this.paymentService.paymentConfigSelected.merchantRefNum,//merchantRefNum from create payment service
                paymentGwTransactionId: BOLT.response.txnid || BOLT.response.payuMoneyId || paymentRequest.txnid,
                status: BOLT.response.status,
                paymentToken: BOLT.response.paymentId || '',//empty in old code
                paymentMethod: BOLT.response.mode,
                expiryDate: BOLT.response.addedon || '',//empty in old code
                cardNumber: BOLT.response.cardnum || '', //cardnum from payumoney
                amount: BOLT.response.amount
            };
            const paymentInfo = await this.paymentService.updatePayment(paymentTransactionRequest).toPromise();

            if (paymentInfo && paymentInfo.message && paymentInfo.message === 'SUCCESS') {
                // this.paymentRequestInfo.firstname = this.userProfile.firstName;
                // this.paymentRequestInfo.lastname = this.userProfile.lastName;
                // this.paymentRequestInfo.email = this.userProfile.email[0];
                // this.paymentRequestInfo.amount = this.activeDataSet;
                // this.paymentRequestInfo.phone = this.userProfile.phone[0] || this.msisdnNumber;
                // this.paymentRequestInfo.productinfo = 'Recharge';
                // this.refillPayload.customerId = this.userProfile.customerId;
                // this.refillPayload.partyId = this.userProfile.id;

                // this.refillPayload.coreData.refillAmount = this.refillForm.value.amount;
                // this.refillPayload.coreData.currency = this.creditBalance.currency;
                // this.refillPayload.coreData.customerAccountId = this.userContractProfile.msisdn;
                // this.refillPayload.coreData.summaryTextLabel = 'AccountRefillSummary';
                // const customerInteractionRefill: CustomerInteractionRefill = new CustomerInteractionRefill(this.refillPayload);
                const customerInteractionResponse = await this.rechargeTransferService.customerInteraction(this.refillPayload).toPromise();
                if (customerInteractionResponse) {
                    if (this.eventType === EventEnum.refillPopup) {
                        this.isNext = false;
                        this.eventListenerService.dashboardEvent.emit({ eventType: EventEnum.dashboardRefresh });
                        this.eventListenerService.showVoucherCodeSuccess(customerInteractionResponse);
                        // this.successMessage = this.translateService.instant(customerInteractionResponse.statusReason.code);
                        // this.paymentSuccess = true;
                    } else {
                        this.eventListenerService.closeCustomerOnBoardPopup();
                        this.eventListenerService.showPaymentSuccessMessage(customerInteractionResponse, EventEnum.showQuickRechageSuccessMessage);
                    }
                }
            }
            else {
                alertify.error(this.translateService.instant('Payment Failed'));
            }

        }
        else {
            alertify.error(this.translateService.instant('Payment has been cancelled'));
        }
    }

    public onBlurOfAmount() {
        const amountControl = this.refillForm.controls.amount;
        const voucherCodeControl = this.refillForm.controls.vouchercode;
        if (amountControl) {
            amountControl.setValidators(rechargeValidator(this.persistenceService, this.translateService, this.amountValidationMessage));
        }
        if (voucherCodeControl) {
            voucherCodeControl.setValidators(rechargeWithVoucherCodeValidator(this.translateService, this.persistenceService, this.voucherCodeValidationMessage));
        }
        amountControl.updateValueAndValidity();
        voucherCodeControl.updateValueAndValidity();
    }

    public refillButtonDisabled() {
        if ((!this.refillForm.value.amount && !this.refillForm.value.vouchercode) || this.refillForm.status === "PENDING" || this.refillForm.status === "INVALID") {
            return true;
        }
        return false;
    }

    public submitVouchercode() {
        // const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
        // const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        // this.refillOptions = this.persistenceService.get(CMUICONFIGKEY.REFILLAMOUNTOPTIONS, StorageType.SESSION);
        // this.msisdnNumber = this.userContractProfile.msisdn,
        // this.currencySign = this.persistenceService.get(CMUICONFIGKEY.DEFAULTYCURRENCY, StorageType.SESSION);
        if (this.refillForm.value.vouchercode) {
            this.isNext = false;
            this.voucherPayload.coreData.voucherCode = this.refillForm.value.vouchercode;
            // const requestPayload = {
            //     'partyId': partyId,
            //     'customerId': this.customerId,
            //     'journeyId': 'VoucherTopup_Self',
            //     'type': 'ServiceOrder',
            //     'status': 'InProgress',
            //     'channelName': 'SFWEB',
            //     'customerServiceOrder': {},
            //     'journeyData': {},
            //     'coreData': {
            //         'msisdn': this.msisdnNumber,
            //         'currency': 'INR',
            //         'summaryTextLabel': 'VoucherTopupSelfSummary',
            //         'voucherCode': this.refillForm.value.vouchercode
            //     }
            // }
            this.customerService.customerInteractionForRecharge(this.voucherPayload).subscribe(data => {
                // const response = data;
                if (data) {
                    if (this.eventType === EventEnum.refillPopup) {
                        this.eventListenerService.showVoucherCodeSuccess(data);
                        this.eventListenerService.dashboardEvent.emit({ eventType: EventEnum.dashboardRefresh });
                    } else {
                        this.eventListenerService.closeCustomerOnBoardPopup();
                        this.eventListenerService.showPaymentSuccessMessage(data, EventEnum.showQuickRechageSuccessMessage);
                    }
                }
            });
        } else {
            this.isNext = true;
        }
    }


}
