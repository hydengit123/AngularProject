import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GlobalPopupModalComponent } from './global-popup-modal.component';

describe('GlobalPopupModalComponent', () => {
  let component: GlobalPopupModalComponent;
  let fixture: ComponentFixture<GlobalPopupModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GlobalPopupModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GlobalPopupModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
