import { Component, ComponentFactoryResolver, Input, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { CartListComponent, PaymentRequestInfo, UserContractModel } from 'dxp-common';
import { ModalDirective } from 'ng-uikit-pro-standard';
import { Subscription } from 'rxjs';
import { FormMessageService } from '../customer-onboarding/services/form-message.service';
import { EventEnum } from '../enum/EventEnum';
import { EventListenerService } from '../event-listener.service';
import { LoginComponent } from '../login/login.component';
import UserProfile from '../modals/ProfileModal';
import { PaymentSuccessComponent } from '../payment-success/payment-success.component';
import { PendingJourneyComponent } from '../pending-journey/pending-journey.component';
import { RechargeSuccessPopupComponent } from '../recharge-success-popup/recharge-success-popup.component';
import { RefillFormComponent } from '../refill-form/refill-form.component';
import { RegisterComponent } from '../register/register.component';
import { CartService } from '../services/cart.service';
import { CustomerOnboardService } from '../services/customer-onboard.service';
import { CustomerSearchService } from '../services/customer-search.service';
import { DealsForYouService } from '../services/dfy.service';
import { PaymentGatewayService } from '../services/payment-gateway.service';
import { ShareWithConsumerService } from '../services/share-with-consumer.service';
import { PaymentPopupComponent } from './../payment-popup/payment-popup.component';
import { AuthService } from '../services/auth.service';



@Component({
  selector: 'app-global-popup-modal',
  templateUrl: './global-popup-modal.component.html',
  styleUrls: ['./global-popup-modal.component.scss']
})
export class GlobalPopupModalComponent implements OnInit {

  public title: string;
  public popUpSize: Boolean = true;
  @ViewChild('modalBody', { read: ViewContainerRef }) modalBody: ViewContainerRef;
  @ViewChild('modalFooter', { read: ViewContainerRef }) modalFooter: ViewContainerRef;
  @Input() modalBodyComponent: any;
  @ViewChild('basicModal') basicModal: ModalDirective;
  showImage: boolean = true;
  private refillEventSubsciption: Subscription;


  constructor(
    private componentFactoryResolver: ComponentFactoryResolver,
    private eventService: EventListenerService,
    private translateService: TranslateService,
    private router: Router,
    private formMessageService: FormMessageService,
    private cartService: CartService,
    private paymentGatewayService: PaymentGatewayService,
    private customerOnboardService: CustomerOnboardService,
    private customerSearchService: CustomerSearchService,
    private dealsForYouService: DealsForYouService,
    private shareWithConsumerService: ShareWithConsumerService,
    private authService: AuthService
  ) {
  }

  onClose(e) {

  }

  ngOnInit() {


    this.eventService.paymentSuccess.subscribe(d => {
      this.showPaymentSuccessPopup();
    });

    this.eventService.showPendingJourneyEvent.subscribe((d: any) => {
      this.showPendingJourney(d.journeyType);
    })
    this.eventService.showLoginEvent.subscribe(d => {
      this.showImage = d.showImage;
      this.showLoginDetails(d.showImage);
    });

    this.eventService.showRegisterEvent.subscribe(d => {
      this.showRegisterDetails();
    });

    this.eventService.showPaymentPopupEvent.subscribe((data) => {
      if (data && data.eventType === EventEnum.paymentPopup && data.paymentRequestInfo && data.handler) {
        this.showPaymentPopup(data.paymentRequestInfo, data.paymentGateWayList, data.showPaymentList, data.handler);
      }
    });

    this.eventService.showCartDetailsEvent.subscribe(d => {
      this.showCartDetails();
    });

    this.eventService.closeCustomerOnBoardPopupEvent.subscribe(d => {
      this.basicModal.hide();
    });

    this.eventService.closePendingJourneyPopUpEvent.subscribe(d => {
      this.basicModal.hide();
    });

    this.refillEventSubsciption = this.eventService.refillPopupEvent.subscribe(item => {
      if (item && (item.eventType === EventEnum.refillPopup || item.eventType === EventEnum.showQuickRechageSuccessMessage)) {
        // this.refillPopup(item.mainBalanceValue, item.userProfile, item.userContractProfile, item.rechargeFormSelf, item.isNext, item.paymentRequest);
        this.accountRefillPopup(item.refillPayload, item.voucherPayload, item.paymentRequestInfo, item.eventType);
      }
    });

    this.eventService.voucherCodeSuccessEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.showVoucherCodeSuccess) {
        this.showRechargeSuccessPopup(data.response);
      }
    });

  }
  modelClose(){
  this.basicModal.hide();
  this.authService.reset();
  }  

  showLoginDetails(showImg: boolean) {
    this.popUpSize = false;
    //set title
    this.title = null;

    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(LoginComponent);

    let viewContainerRef = this.modalBody;
    viewContainerRef.clear();

    let componentRef: any = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.showImage = showImg;
    componentRef.instance.basicModal = this.basicModal;
    this.basicModal.show();
  }

  showRegisterDetails() {
    this.popUpSize = false;
    //set title
    this.title = null;

    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(RegisterComponent);

    let viewContainerRef = this.modalBody;
    viewContainerRef.clear();

    let componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.basicModal = this.basicModal;
    this.basicModal.show();
  }

  showPaymentSuccessPopup() {
    this.popUpSize = false;
    //set title
    this.title = null;

    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(PaymentSuccessComponent);

    let viewContainerRef = this.modalBody;
    viewContainerRef.clear();

    let componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.basicModal = this.basicModal;
    this.basicModal.show();
  }

  showPaymentPopup(paymentRequestInfo: PaymentRequestInfo, paymentGateWayList:any, showPaymentList:any, handler: any) {
    this.popUpSize = true;
    // set title
    this.title = 'Recharge';

    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(PaymentPopupComponent);

    const viewContainerRef = this.modalBody;
    viewContainerRef.clear();

    const componentRef: any = viewContainerRef.createComponent(componentFactory);
    // componentRef.instance.showImage = showImg;
    componentRef.instance.basicModal = this.basicModal;
    componentRef.instance.paymentRequestInfo = paymentRequestInfo;
    componentRef.instance.handler = handler;
    componentRef.instance.showPaymentList = showPaymentList;
    componentRef.instance.paymentGateWayList = paymentGateWayList;
    this.basicModal.show();
  }

  showPendingJourney(journeyType) {
    // PendingJourneyComponent
    this.popUpSize = false;
    this.title = this.translateService.instant("Incomplete orders");

    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(PendingJourneyComponent);

    let viewContainerRef = this.modalBody;
    viewContainerRef.clear();

    let componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.type = journeyType;
    this.basicModal.show();

  }
  showCartDetails() {
    this.popUpSize = false;
    let showPayment = true;
    if (this.router.url.indexOf('/customerOnboard/') !== -1) {
      showPayment = false;
    }
    //set title
    this.title = this.translateService.instant("Cart");

    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(CartListComponent);

    let viewContainerRef = this.modalBody;
    viewContainerRef.clear();

    let componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.setOneTimeCol = false;
    componentRef.instance.showFooterAction = true;
    componentRef.instance.showUpdateQuantity = true;
    componentRef.instance.basicModal = this.basicModal;
    componentRef.instance.showPayment = showPayment;
    componentRef.instance.formMessageService = this.formMessageService;
    componentRef.instance.event = this.eventService;
    componentRef.instance.cartService = this.cartService;
    componentRef.instance.paymentGatewayService = this.paymentGatewayService;
    componentRef.instance.customerOnboardService = this.customerOnboardService;
    componentRef.instance.customerSearchService = this.customerSearchService;
    componentRef.instance.dealsForYouService = this.dealsForYouService;
    componentRef.instance.shareWithConsumerService = this.shareWithConsumerService;
    componentRef.instance.notifyCartUpdatedEventEnum = EventEnum.notifyCartUpdated;
    this.basicModal.show();

  }

  refillPopup(mainBalanceValue, userProfile: UserProfile, userContractProfile: UserContractModel[], rechargeFormSelf: boolean, isNext: boolean, paymentRequest) {
    this.popUpSize = true;
    //set title
    this.title = this.translateService.instant("Recharge");
    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(RefillFormComponent);

    let viewContainerRef = this.modalBody;
    viewContainerRef.clear();

    let componentRef = viewContainerRef.createComponent(componentFactory);
    // componentRef.instance.showFooterAction = true;
    componentRef.instance.creditBalance = mainBalanceValue;
    componentRef.instance.customerId = userProfile.customerId;
    componentRef.instance.userProfile = userProfile;
    componentRef.instance.userContractProfile = userContractProfile[0];
    componentRef.instance.rechargeFormSelf = rechargeFormSelf;
    componentRef.instance.isNext = isNext;
    componentRef.instance.paymentRequest = paymentRequest;
    this.basicModal.show();
  }

  showRechargeSuccessPopup(response) {
    this.popUpSize = true;
    //set title
    this.title = this.translateService.instant('Recharge');

    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(RechargeSuccessPopupComponent);

    let viewContainerRef = this.modalBody;
    viewContainerRef.clear();

    let componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.voucherCodeResponse = response;
    componentRef.instance.basicModal = this.basicModal;
    this.basicModal.show();
  }

  accountRefillPopup(refillPayload, voucherPayload, paymentRequestInfo, eventType) {
    this.popUpSize = true;
    this.title = this.translateService.instant('Recharge');
    let componentFactory = this.componentFactoryResolver.resolveComponentFactory(RefillFormComponent);
    let viewContainerRef = this.modalBody;
    viewContainerRef.clear();
    let componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.refillPayload = refillPayload;
    componentRef.instance.voucherPayload = voucherPayload;
    componentRef.instance.paymentRequestInfo = paymentRequestInfo;
    componentRef.instance.eventType = eventType;
    this.basicModal.show();
  }

  ngOnDestroy() {
    // for hide the all backdrops of popup
    this.basicModal.hide();
  }

}
