import { Component, OnInit, Input } from '@angular/core';
import { ModalDirective } from 'ng-uikit-pro-standard';
import { PaymentGatewayService } from '../services/payment-gateway.service';
import { Router } from '@angular/router';
import { EventListenerService } from '../event-listener.service';
import { EventEnum } from '../enum/EventEnum';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-payment-success',
  templateUrl: './payment-success.component.html',
  styleUrls: ['./payment-success.component.scss']
})
export class PaymentSuccessComponent implements OnInit {

  @Input() basicModal: ModalDirective;
  public orderLabel: string;
  public transactionLabel: string;

  constructor(private paymentGatewayService: PaymentGatewayService,
    private router: Router,
    private translate: TranslateService,
    private eventListenerService: EventListenerService) { }

  ngOnInit() {
    if (this.paymentGatewayService.orderId) {
      this.orderLabel = this.translate.instant("yourOrderIdIs", {id:this.paymentGatewayService.orderId});
      if(this.paymentGatewayService.transactionId){
        this.transactionLabel = this.translate.instant("yourTransactionIdIs", {id:this.paymentGatewayService.transactionId});
      }
      else{
        this.transactionLabel = null;
      }
      this.eventListenerService.dashboardEvent.emit({ eventType: EventEnum.dashboardRefresh });
    } else {
      this.router.navigate(('/public').split('/'));
    }
  }

}
