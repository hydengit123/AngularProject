import { HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { DataClientService } from './data-client.service';
import { Observable } from 'rxjs';
import { EnvService } from 'services/env.service';

describe('DataClientService', () => {
  let dataClientService: DataClientService;
  let httpClientSpy: jasmine.SpyObj<HttpClient>;
  let envServiceSpy: jasmine.SpyObj<EnvService>;
  beforeEach(() => {
    const HttpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'post', 'delete', 'put']);
    const EnvServiceSpy = jasmine.createSpyObj('EnvService', ['']);

    TestBed.configureTestingModule({
      providers: [
        DataClientService,
        { provide: HttpClient, useValue: HttpClientSpy },
        { provide: EnvService, useValue: EnvServiceSpy }
      ]
    });
  });

  beforeEach(() => {
    dataClientService = TestBed.get(DataClientService);
    envServiceSpy = TestBed.get(EnvService);
    httpClientSpy = TestBed.get(HttpClient);
  });

  it('should be created', () => {
    expect(DataClientService).toBeTruthy();
  });

  it('getRestUrls method should return restUrls', () => {
    const urls = ['url_a', 'url_b']
    dataClientService.restUrls = urls;
    expect(dataClientService.getRestUrls()).toBe(urls);
  });

  describe('buildBaseUrl method should return baseUrl when', () => {
    it('serverConfig is available and sslEnabled is true', () => {
      const config = { sslEnabled: true, domain: 'ericsson-dxp-business-online.cis.curie003.seli.gic.ericsson.se', port: '5180', appContext: 'cisBusiness', restContext: 'rest' };
      dataClientService.serverConfig = config;
      const expectedUrl = `${config.sslEnabled ? 'https://' : 'http://'}${config.domain}:${config.port}/${config.appContext}/${config.restContext}/`;
      expect(dataClientService.buildBaseUrl()).toBe(expectedUrl);
    });

    it('serverConfig is available  and sslEnabled is false', () => {
      const config = { sslEnabled: false, domain: 'ericsson-dxp-business-online.cis.curie003.seli.gic.ericsson.se', port: '5180', appContext: 'cisBusiness', restContext: 'rest' };
      dataClientService.serverConfig = config;
      const expectedUrl = `${config.sslEnabled ? 'https://' : 'http://'}${config.domain}:${config.port}/${config.appContext}/${config.restContext}/`;
      expect(dataClientService.buildBaseUrl()).toBe(expectedUrl);
    });

    it('serverConfig is unavailable', () => {
      dataClientService.serverConfig = undefined;
      envServiceSpy.apiUrl = 'https://test.com';
      expect(dataClientService.buildBaseUrl()).toBe('https://test.com/cisBusiness/rest/');
    });
  });

  describe('buildUrl method should return url', () => {
    it('when urlParams and searchParams are available', () => {
      dataClientService.baseUrl = 'https://test.com/';
      const url = dataClientService.buildUrl('unit_testing', ['param_a', 'param_b'], { 'search_key': 'case_a' });

      expect(url).toBe('https://test.com/unit_testing/param_a/param_b?search_key=case_a');
    });

    it('when urlParams are unavailable but searchParams are available', () => {
      dataClientService.baseUrl = 'https://test.com/';
      const url = dataClientService.buildUrl('unit_testing', [], { 'search_key': 'case_a' });

      expect(url).toBe('https://test.com/unit_testing?search_key=case_a');
    });

    it('when urlParams are available but searchParams are unavailable', () => {
      dataClientService.baseUrl = 'https://test.com/';
      const url = dataClientService.buildUrl('unit_testing', ['param_a', 'param_b'], {});

      expect(url).toBe('https://test.com/unit_testing/param_a/param_b?');
    });

    it('when urlParams and searchParams are available but url already starts with http', () => {

      const url = dataClientService.buildUrl('http://125.22.2.38:5180/cisBusiness/rest/unit_testing', ['param_a', 'param_b'], { 'search_key': 'case_a' });

      expect(url).toBe('http://125.22.2.38:5180/cisBusiness/rest/unit_testing/param_a/param_b?search_key=case_a');
    });
  });

  describe('get method should return observable of response from API', () => {
    it('when responseType is "text"', () => {
      const url = 'http://125.22.2.38:5180/cisBusiness/rest/unit_testing';
      const urlParams = ['param_a', 'param_b'];
      const searchParams = { 'search_key': 'case_a' };
      spyOn(dataClientService, 'buildUrl').and.returnValue(url);
      httpClientSpy.get.and.returnValue(Observable.of('Response'));

      dataClientService.get(url, urlParams, searchParams, 'text').subscribe((res) => {
        expect(httpClientSpy.get).toHaveBeenCalledWith(url, {
          observe: 'response',
          responseType: 'text'
        });
        expect(res).toBe('Response');
      });
    });

    it('when responseType is null', () => {
      const url = 'http://125.22.2.38:5180/cisBusiness/rest/unit_testing';
      const urlParams = ['param_a', 'param_b'];
      const searchParams = { 'search_key': 'case_a' };
      spyOn(dataClientService, 'buildUrl').and.returnValue(url);
      httpClientSpy.get.and.returnValue(Observable.of('Response'));

      dataClientService.get(url, urlParams, searchParams).subscribe((res) => {
        expect(httpClientSpy.get).toHaveBeenCalledWith(url);
        expect(res).toBe('Response');
      });
    });
  });

  describe('post method should return observable of response from API', () => {
    it('when responseType is "text"', () => {
      const url = 'http://125.22.2.38:5180/cisBusiness/rest/unit_testing';
      const urlParams = ['param_a', 'param_b'];
      const searchParams = { 'search_key': 'case_a' };
      const postData = { userName: 'Try', password: 'Try1234' };
      spyOn(dataClientService, 'buildUrl').and.returnValue(url);
      httpClientSpy.post.and.returnValue(Observable.of('posted'));

      dataClientService.post(postData, url, urlParams, searchParams, 'text').subscribe((res) => {
        expect(httpClientSpy.post).toHaveBeenCalledWith(url, postData, {
          observe: 'response',
          responseType: 'text'
        });
        expect(res).toBe('posted');
      });
    });

    it('when responseType is null', () => {
      const url = 'http://125.22.2.38:5180/cisBusiness/rest/unit_testing';
      const urlParams = ['param_a', 'param_b'];
      const searchParams = { 'search_key': 'case_a' };
      const postData = { userName: 'Try', password: 'Try1234' };
      spyOn(dataClientService, 'buildUrl').and.returnValue(url);
      httpClientSpy.post.and.returnValue(Observable.of('posted'));

      dataClientService.post(postData, url, urlParams, searchParams).subscribe((res) => {
        expect(httpClientSpy.post).toHaveBeenCalledWith(url, postData);
        expect(res).toBe('posted');
      });
    });
  });

  describe('delete method should return observable of response from API', () => {
    it('when responseType is "text"', () => {
      const url = 'http://125.22.2.38:5180/cisBusiness/rest/unit_testing';
      const urlParams = ['param_a', 'param_b'];
      const searchParams = { 'search_key': 'case_a' };
      spyOn(dataClientService, 'buildUrl').and.returnValue(url);
      httpClientSpy.delete.and.returnValue(Observable.of('deleted'));

      dataClientService.delete(url, urlParams, searchParams, 'text').subscribe((res) => {
        expect(httpClientSpy.delete).toHaveBeenCalledWith(url, {
          observe: 'response',
          responseType: 'text'
        });
        expect(res).toBe('deleted');
      });
    });

    it('when responseType is null', () => {
      const url = 'http://125.22.2.38:5180/cisBusiness/rest/unit_testing';
      const urlParams = ['param_a', 'param_b'];
      const searchParams = { 'search_key': 'case_a' };
      spyOn(dataClientService, 'buildUrl').and.returnValue(url);
      httpClientSpy.delete.and.returnValue(Observable.of('deleted'));

      dataClientService.delete(url, urlParams, searchParams).subscribe((res) => {
        expect(httpClientSpy.delete).toHaveBeenCalledWith(url);
        expect(res).toBe('deleted');
      });
    });
  });

  describe('put method should return observable of response from API', () => {
    it('when responseType is "text"', () => {
      const url = 'http://125.22.2.38:5180/cisBusiness/rest/unit_testing';
      const urlParams = ['param_a', 'param_b'];
      const searchParams = { 'search_key': 'case_a' };
      const putData = { userName: 'Try', password: 'Try1234' };
      spyOn(dataClientService, 'buildUrl').and.returnValue(url);
      httpClientSpy.put.and.returnValue(Observable.of('Put'));

      dataClientService.put(putData, url, urlParams, searchParams, 'text').subscribe((res) => {
        expect(httpClientSpy.put).toHaveBeenCalledWith(url, putData, {
          observe: 'response',
          responseType: 'text'
        });
        expect(res).toBe('Put');
      });
    });

    it('when responseType is null', () => {
      const url = 'http://125.22.2.38:5180/cisBusiness/rest/unit_testing';
      const urlParams = ['param_a', 'param_b'];
      const searchParams = { 'search_key': 'case_a' };
      const putData = { userName: 'Try', password: 'Try1234' };
      spyOn(dataClientService, 'buildUrl').and.returnValue(url);
      httpClientSpy.put.and.returnValue(Observable.of('Put'));

      dataClientService.put(putData, url, urlParams, searchParams).subscribe((res) => {
        expect(httpClientSpy.put).toHaveBeenCalledWith(url, putData);
        expect(res).toBe('Put');
      });
    });
  });
});
