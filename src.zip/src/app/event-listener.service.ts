import { EventEmitter, Injectable } from '@angular/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { ProductBucketShared, UserContractModel, CMUICONFIGKEY, cartDetails, PaymentRequestInfo, CONTACTDETAILSCONSTS } from 'dxp-common';
import * as _ from 'lodash';
import { CHATBOT, LOCALIZATIONPERSISTANCEKEY, PERSISTANCEKEY } from '../application-constants';
import { FormMessageService } from './customer-onboarding/services/form-message.service';
import { EventEnum } from './enum/EventEnum';
import UserProfile from './modals/ProfileModal';
import { CustomerOnboardService } from './services/customer-onboard.service';


@Injectable({
    providedIn: 'root',
})
export class EventListenerService {


    public shareAndTransferEvent: EventEmitter<any> = new EventEmitter<any>();
    public mainBalanceChangesEvent: EventEmitter<any> = new EventEmitter<any>();
    public msisdnChangeEvent: EventEmitter<any> = new EventEmitter<any>();
    public pendingJourneyCount: EventEmitter<any> = new EventEmitter<any>();
    public fetchPendingJourneyEvent: EventEmitter<any> = new EventEmitter<any>();
    public showPendingJourneyEvent: EventEmitter<any> = new EventEmitter<any>();
    public pendingJourneyStatus: EventEmitter<any> = new EventEmitter<any>();
    public paymentSuccess: EventEmitter<any> = new EventEmitter<any>();
    public balanceEvent: EventEmitter<any> = new EventEmitter<any>();
    public profileEvent: EventEmitter<any> = new EventEmitter<any>();
    public customerDataChangesEvent: EventEmitter<any> = new EventEmitter<any>();
    public lanuageChangeEvent: EventEmitter<any> = new EventEmitter<any>();
    public cmUIDataUpdateEvent: EventEmitter<any> = new EventEmitter<any>();
    public chatbotDataUpdateEvent: EventEmitter<any> = new EventEmitter<any>();
    public updateStepperInfoEvent: EventEmitter<any> = new EventEmitter<any>();
    public notifyCartUpdateEvent: EventEmitter<any> = new EventEmitter<any>();
    public setSavedJourneyCountEvent: EventEmitter<any> = new EventEmitter<any>();
    public showCartDetailsEvent: EventEmitter<any> = new EventEmitter<any>();
    public saveCartDetailsPopupEvent: EventEmitter<any> = new EventEmitter<any>();
    public customerOnAbortJourneyEvent: EventEmitter<any> = new EventEmitter<any>();
    public customerOnSaveJourneyExplicitlyEvent: EventEmitter<any> = new EventEmitter<any>();
    public closeCustomerOnBoardPopupEvent: EventEmitter<any> = new EventEmitter<any>();
    public closePendingJourneyPopUpEvent: EventEmitter<any> = new EventEmitter<any>();
    public confirmPopupEvent: EventEmitter<any> = new EventEmitter<any>();
    public showLoginEvent: EventEmitter<any> = new EventEmitter<any>();
    public showRegisterEvent: EventEmitter<any> = new EventEmitter<any>();
    public notifyLoginEvent: EventEmitter<any> = new EventEmitter<any>();
    public redirectDashboardEvent: EventEmitter<any> = new EventEmitter<any>();
    public showPaymentPopupEvent: EventEmitter<any> = new EventEmitter<any>();
    public refillPopupEvent: EventEmitter<any> = new EventEmitter<any>();
    public transferCreditPopupEvent: EventEmitter<any> = new EventEmitter<any>();
    public enableLoginPopupEvent: EventEmitter<any> = new EventEmitter<any>();
    public showPaymentSuccessMessageEvent: EventEmitter<any> = new EventEmitter<any>();
    public userProfileDashboardEvent: EventEmitter<any> = new EventEmitter<any>();
    public transferBucketEvent: EventEmitter<any> = new EventEmitter<any>();
    public dashboardEvent: EventEmitter<any> = new EventEmitter<any>();
    public showSubscriptionMenuEvent: EventEmitter<any> = new EventEmitter<any>();
    public updateChatbotPaymentEvent: EventEmitter<any> = new EventEmitter<any>();

    //dahsboard and consumer popups event
    public closeDashBoardPopupEvent: EventEmitter<any> = new EventEmitter<any>();
    public consumersEvent: EventEmitter<any> = new EventEmitter<any>();
    public voucherCodeSuccessEvent: EventEmitter<any> = new EventEmitter<any>();
    public dfySearchChangeEvent: EventEmitter<any> = new EventEmitter<any>();
    public dfySortChangeEvent: EventEmitter<any> = new EventEmitter<any>();


    constructor(private persistenceService: PersistenceService) {
    }

    notifyPendingJourneyCount() {
        this.pendingJourneyCount.emit();
    }

    fetchPendingJourney() {
        this.fetchPendingJourneyEvent.emit();
    }
    notifyLogin(loginStatus) {
        this.notifyLoginEvent.emit({ "isLogin": loginStatus });
    }

    notifyCartUpdate(cartDetails: cartDetails) {
        const cartObject = { 'eventType': EventEnum.notifyCartUpdated, 'cartDetails': cartDetails }
        this.notifyCartUpdateEvent.emit(cartObject);
    }



    msisdnChange(msisdn: string) {
        this.msisdnChangeEvent.emit({ 'eventType': EventEnum.misdinChanged, 'msisdn': msisdn });
    }

    dfySearchValChanged(searchStr: string) {
        this.dfySearchChangeEvent.emit({ 'eventType': EventEnum.dfySearchChange, 'searchStr': searchStr });
    }

    dfySortValChanged(sortStr: string) {
        this.dfySortChangeEvent.emit({ 'eventType': EventEnum.dfySortChange, 'sortStr': sortStr });
    }

    customerDataChanges(data, voice, sms) {
        const customerDataObj = { 'data': data, 'voice': voice, 'sms': sms };
        this.customerDataChangesEvent.emit(customerDataObj);
    }

    addToMainBalance(value) {
        const res = this.persistenceService.get(PERSISTANCEKEY.MAINBALANCE, StorageType.SESSION);
        res.mainBalance.unit = res.mainBalance.unit + value;
        this.persistenceService.set(PERSISTANCEKEY.MAINBALANCE, res, { type: StorageType.SESSION });
        this.balanceEvent.emit(EventEnum.mainBalanceUpdated);
    }

    removeFromMainBalance(value) {
        const res = this.persistenceService.get(PERSISTANCEKEY.MAINBALANCE, StorageType.SESSION);
        res.mainBalance.unit = res.mainBalance.unit - value;
        this.persistenceService.set(PERSISTANCEKEY.MAINBALANCE, res, { type: StorageType.SESSION });
        this.balanceEvent.emit(EventEnum.mainBalanceUpdated);
    }

    addData(data, price) {
        const availableQuota = this.persistenceService.get(PERSISTANCEKEY.AVAILABLEQUOTA, StorageType.SESSION);
        const provisionedQuota = this.persistenceService.get(PERSISTANCEKEY.PROVISIONEDQUOTA, StorageType.SESSION);

        availableQuota.data = availableQuota.data + data;
        if (provisionedQuota.data >= 0) {
            provisionedQuota.data = provisionedQuota.data + data;
        }

        this.persistenceService.set(PERSISTANCEKEY.AVAILABLEQUOTA, availableQuota, { type: StorageType.SESSION });
        this.persistenceService.set(PERSISTANCEKEY.PROVISIONEDQUOTA, provisionedQuota, { type: StorageType.SESSION });
        this.balanceEvent.emit(EventEnum.dataUpdated);
        this.removeFromMainBalance(price);
    }

    removeData(data) {
        const availableQuota = this.persistenceService.get(PERSISTANCEKEY.AVAILABLEQUOTA, StorageType.SESSION);
        availableQuota.data = availableQuota.data - data;
        this.persistenceService.set(PERSISTANCEKEY.AVAILABLEQUOTA, availableQuota, { type: StorageType.SESSION });
        this.balanceEvent.emit(EventEnum.dataUpdated);
    }

    showPaymentSuccess() {
        this.paymentSuccess.emit(EventEnum.showPaymentSuccess);
    }

    showVoucherCodeSuccess(response) {
        this.voucherCodeSuccessEvent.emit({ 'eventType': EventEnum.showVoucherCodeSuccess, 'response': response });
    }


    addMinutes(voice, price) {
        const availableQuota = this.persistenceService.get(PERSISTANCEKEY.AVAILABLEQUOTA, StorageType.SESSION);
        const provisionedQuota = this.persistenceService.get(PERSISTANCEKEY.PROVISIONEDQUOTA, StorageType.SESSION);

        availableQuota.voice = availableQuota.voice + voice;
        if (provisionedQuota.voice >= 0) {
            provisionedQuota.voice = provisionedQuota.voice + voice;
        }

        this.persistenceService.set(PERSISTANCEKEY.AVAILABLEQUOTA, availableQuota, { type: StorageType.SESSION });
        this.persistenceService.set(PERSISTANCEKEY.PROVISIONEDQUOTA, provisionedQuota, { type: StorageType.SESSION });

        this.balanceEvent.emit(EventEnum.voiceUpdated);
        this.removeFromMainBalance(price);
    }

    removeMinutes(voice) {
        const availableQuota = this.persistenceService.get(PERSISTANCEKEY.AVAILABLEQUOTA, StorageType.SESSION);
        this.persistenceService.set(PERSISTANCEKEY.AVAILABLEQUOTA, availableQuota, { type: StorageType.SESSION });
        this.balanceEvent.emit(EventEnum.voiceUpdated);
    }

    addSMS(sms, price) {
        const availableQuota = this.persistenceService.get(PERSISTANCEKEY.AVAILABLEQUOTA, StorageType.SESSION);
        const provisionedQuota = this.persistenceService.get(PERSISTANCEKEY.PROVISIONEDQUOTA, StorageType.SESSION);

        availableQuota.sms = availableQuota.sms + sms;
        if (provisionedQuota.sms >= 0) {
            provisionedQuota.sms = provisionedQuota.sms + sms;
        }
        this.persistenceService.set(PERSISTANCEKEY.AVAILABLEQUOTA, availableQuota, { type: StorageType.SESSION });
        this.persistenceService.set(PERSISTANCEKEY.PROVISIONEDQUOTA, provisionedQuota, { type: StorageType.SESSION });

        this.balanceEvent.emit(EventEnum.smsUpdated);
        this.removeFromMainBalance(price);
    }

    removeSms(sms) {
        const availableQuota = this.persistenceService.get(PERSISTANCEKEY.AVAILABLEQUOTA, StorageType.SESSION);
        // availableQuota.sms = availableQuota.sms - sms;
        this.persistenceService.set(PERSISTANCEKEY.AVAILABLEQUOTA, availableQuota, { type: StorageType.SESSION });
        this.balanceEvent.emit(EventEnum.smsUpdated);
    }

    profileUpdated() {
        this.profileEvent.emit(EventEnum.profileUpdated);
    }

    public changeLanguage(languageSelected, isUserSelected: boolean = false) {
        const langCode = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
        // force langcode to 'en' if it is en-US
        if (languageSelected === 'en-US') {
            languageSelected = 'en';
        }
        this.persistenceService.set(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, languageSelected, { type: StorageType.LOCAL });
         if (langCode !== languageSelected) {
            this.lanuageChangeEvent.emit({ eventType: EventEnum.languageUpdated, languageSelected, isUserSelected: isUserSelected });
        }
    }

    // Any Key in CMUICONFIGKEY will get
    // automatically added if avaiable
    public updateCMUIData(data) {
        const configData = data.data;
        _.values(CMUICONFIGKEY).forEach(configValue => {
            if (configData[configValue] != null) {
                this.persistenceService.set(configValue, configData[configValue], { type: StorageType.SESSION });
            }
        });

        // this code is for the multi level exptions keys,
        // kesy should be fixed inside code, and this if section should get remove
        if (configData.hasOwnProperty(CMUICONFIGKEY.PHONENUMBERLENGTH)) {
            this.persistenceService.set(CMUICONFIGKEY.PHONENUMBERLENGTH, configData[CMUICONFIGKEY.MSISDNLENGTH][CMUICONFIGKEY.MINLENGTH], { type: StorageType.SESSION });
            this.persistenceService.set(CMUICONFIGKEY.PHONENUMBERMAXLENGTH, configData[CMUICONFIGKEY.MSISDNLENGTH][CMUICONFIGKEY.MAXLENGTH], { type: StorageType.SESSION });
        }
        if (configData.hasOwnProperty(CMUICONFIGKEY.SIMNUMBERLENGTH)) {
            this.persistenceService.set(CMUICONFIGKEY.MINLENGTH, configData[CMUICONFIGKEY.SIMNUMBERLENGTH][CMUICONFIGKEY.MINLENGTH], { type: StorageType.SESSION });
            this.persistenceService.set(CMUICONFIGKEY.MAXLENGTH, configData[CMUICONFIGKEY.SIMNUMBERLENGTH][CMUICONFIGKEY.MAXLENGTH], { type: StorageType.SESSION });
        }
        if (configData.hasOwnProperty(CMUICONFIGKEY.PASSWORDLENTH)) {
            this.persistenceService.set(CMUICONFIGKEY.PASSWORDMINLENGTH, configData[CMUICONFIGKEY.PASSWORDLENTH][CMUICONFIGKEY.MINLENGTH], { type: StorageType.SESSION });
            this.persistenceService.set(CMUICONFIGKEY.PASSWORDMAXLENGTH, configData[CMUICONFIGKEY.PASSWORDLENTH][CMUICONFIGKEY.MAXLENGTH], { type: StorageType.SESSION });
        }

        if (configData.hasOwnProperty(CMUICONFIGKEY.VOUCHERCODELENGTH)) {
            this.persistenceService.set(CMUICONFIGKEY.VOUCHERCODEMINLENGTH, configData[CMUICONFIGKEY.VOUCHERCODELENGTH][CMUICONFIGKEY.MINLENGTH], { type: StorageType.SESSION });
            this.persistenceService.set(CMUICONFIGKEY.VOUCHERCODEMAXLENGTH, configData[CMUICONFIGKEY.VOUCHERCODELENGTH][CMUICONFIGKEY.MAXLENGTH], { type: StorageType.SESSION });
        }

        if (configData.hasOwnProperty(CMUICONFIGKEY.ZIPCODE)) {
            this.persistenceService.set(CONTACTDETAILSCONSTS.ZIPCODEMAXLENGTH, configData[CMUICONFIGKEY.ZIPCODE][CONTACTDETAILSCONSTS.LENGTH], { type: StorageType.SESSION });
            this.persistenceService.set(CONTACTDETAILSCONSTS.ZIPCHARSALLOWED, configData[CMUICONFIGKEY.ZIPCODE][CONTACTDETAILSCONSTS.CHARACTERSALLOWED], { type: StorageType.SESSION });
        }

        this.cmUIDataUpdateEvent.emit(EventEnum.CMUIDataUpdated);
    }

    public updateChatbotData(data) {
        const configData = data.data;
        if (configData['URL']) {
            // let url = 'https://c8.avaamo.com/web_channels/1d8482ee-3dca-4b21-890d-036768704a66?bot_typing_duration=120000&history=true&theme=avm-blue&user_info=';
            // this.persistenceService.set(CHATBOT.CHATBOTURL, url, { type: StorageType.SESSION });
            this.persistenceService.set(CHATBOT.CHATBOTURL, configData['URL'], { type: StorageType.SESSION });
        }
        if (configData['secret']) {
            // let key = 'f00e903f-9af9-4b9b-8d7a-586dd2a8f1b2'
            // this.persistenceService.set(CHATBOT.SECRETKEY, key, { type: StorageType.SESSION });
            this.persistenceService.set(CHATBOT.SECRETKEY, configData['secret'], { type: StorageType.SESSION });
        }
        this.chatbotDataUpdateEvent.emit(EventEnum.chatbotDataUpdated);
    }

    updateStepperInfo(step) {
        this.updateStepperInfoEvent.emit({ "eventType": EventEnum.stepperUpdated, "step": step });
    }

    setSavedJourneyCount(count) {
        this.setSavedJourneyCountEvent.emit({ "eventType": EventEnum.savedJourneyCount, "count": count });
    }

    showCartDetailsPopup() {
        this.showCartDetailsEvent.emit({ "eventType": EventEnum.showCartDetails });
    }

    saveCartDetailsPopup(customerOnBoard: CustomerOnboardService, formMessage: FormMessageService, retainState: boolean) {

        this.saveCartDetailsPopupEvent.emit({
            "eventType": EventEnum.saveCartDetails,
            customerOnBoard: customerOnBoard, formMessage: formMessage, retainState: retainState
        });


    }

    customerIsAbortingJourney(retainState: boolean = false) {
        this.customerOnAbortJourneyEvent.emit({ "eventType": EventEnum.customerOnAbortJourney, "retainState": retainState });
    }

    customerIsSavingJourneyExplicitly(retainState: boolean) {
        this.customerOnSaveJourneyExplicitlyEvent.emit({ "eventType": EventEnum.customerOnSaveJourneyExplicitly, "retainState": retainState });
    }

    setSaveCart(saveCartData) {
        this.persistenceService.set('customerId', saveCartData.customerId);
        this.persistenceService.set('partyId', saveCartData.partyId);
        this.persistenceService.set('userProfileId', saveCartData.userProfileId);
    }

    closeCustomerOnBoardPopup() {
        this.closeCustomerOnBoardPopupEvent.emit({ eventType: EventEnum.closeCustomerOnBoardPopup });
    }

    closePendingJourneyPopUp() {
        this.closePendingJourneyPopUpEvent.emit({ eventType: EventEnum.closePendingJourneyPopUp });
    }

    notifyPendingJourneyStatus(pendingJourneyStatus) {
        this.pendingJourneyStatus.emit({ pendingJourneyStatus: pendingJourneyStatus });
    }

    confirmPopup(customerOnBoard: CustomerOnboardService, formMessage: FormMessageService, retainState: boolean = false) {

        this.confirmPopupEvent.emit({
            'eventType': EventEnum.confirmPopup,
            customerOnBoard: customerOnBoard, formMessage: formMessage, retainState: retainState
        });


    }
    // refillPopup(mainBalanceValue, userProfile: UserProfile, userContractProfile: UserContractModel[], rechargeFormSelf: boolean, isNext: boolean, paymentRequest: any) {
    //     this.refillPopupEvent.emit({
    //         eventType: EventEnum.refillPopup,
    //         mainBalanceValue: mainBalanceValue,
    //         userProfile: userProfile,
    //         userContractProfile: userContractProfile,
    //         rechargeFormSelf: rechargeFormSelf,
    //         isNext: isNext,
    //         paymentRequest: paymentRequest
    //     });
    // }

    accountRefill(refillPayload, voucherPayload, paymentRequestInfo, eventNumber) {
        this.refillPopupEvent.emit({
            refillPayload: refillPayload,
            voucherPayload: voucherPayload,
            paymentRequestInfo: paymentRequestInfo,
            eventType: eventNumber,
        });
    }

    transferCreditPopup(itemDetails, payload) {
        this.transferCreditPopupEvent.emit({ eventType: EventEnum.transferCreditPopup, 'item': itemDetails, 'requestPayload': payload });
    }


    showLoginPopupDetails(showImage) {
        this.showLoginEvent.emit({ "eventType": EventEnum.showLogin, "showImage": showImage });
    }


    showRegisterPopupDetails() {
        this.showRegisterEvent.emit({ "eventType": EventEnum.showRegister })
    }

    closeDashboardPopup() {
        this.closeDashBoardPopupEvent.emit({ eventType: EventEnum.closeDashboardPopup });
    }

    showAllConsumersInPopup() {
        this.consumersEvent.emit({ 'eventType': EventEnum.showAllConsumersInPopup });
    }

    showUpdateConsumersInPopup(productBucketShared: ProductBucketShared, userProfile: UserProfile, userContractProfile: UserContractModel[], productId: string) {
        this.consumersEvent.emit({
            'eventType': EventEnum.showUpdateConsumersInPopup,
            'userProfile': userProfile,
            'userContractProfile': userContractProfile,
            'productBucketShared': productBucketShared,
            productId: productId
        });
    }

    showSuccessAfterSharedBucketUpdateInPopup(id: string, title: string, message: string, showId: boolean) {
        this.consumersEvent.emit({
            'eventType': EventEnum.showSuccessAfterSharedBucketUpdateInPopup,
            'id': id,
            'title': title,
            'message': message,
            'showId': showId
        });
        this.dashboardEvent.emit({ eventType: EventEnum.dashboardRefresh });
    }

    refreshConsumerList(refresh: boolean, message: string, isError: boolean) {
        this.consumersEvent.emit({
            'eventType': EventEnum.refreshConsumerList,
            'refresh': refresh,
            'message': message,
            'isError': isError
        });
    }

    showPendingJourney(type) {
        this.showPendingJourneyEvent.emit({ "journeyType": type });
    }
    goToDashboard() {
        this.redirectDashboardEvent.emit({ "eventType": EventEnum.dashboardRedirect });
    }

    showPaymentPopupDetails(paymentRequestInfo: PaymentRequestInfo, paymentGatewayList:any, showPaymentList:any, handler: any) {
        //refillInfo
        this.showPaymentPopupEvent.emit({ 'eventType': EventEnum.paymentPopup, paymentRequestInfo: paymentRequestInfo, paymentGatewayList:paymentGatewayList, showPaymentList:showPaymentList, handler: handler });
    }

    showPaymentSuccessMessage(customerInteractionResponse, eventEnumber) {
        this.showPaymentSuccessMessageEvent.emit({ 'eventType': eventEnumber, 'response': customerInteractionResponse });
    }

    transferBucketPopup(itemDetails, payload) {
        this.transferBucketEvent.emit({ 'eventType': EventEnum.transferBucket, 'item': itemDetails, 'requestPayload': payload });
    }

    showSubscriptionMenu(status: Boolean) {
        this.showSubscriptionMenuEvent.emit({ 'eventType': EventEnum.subscriptionMenu, 'statusValue': status });
    }

}

