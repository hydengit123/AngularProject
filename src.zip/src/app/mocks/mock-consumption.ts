export class MockConsumptionData {
    public static getMockLastrecharge() {
        return {
            'lastRechargeDate': '2019-05-16T06:43:44.000+0000'
        };
    }

    public static getMockConsumption(): Array<any> {
        let consumptionData = [
            {
                'communicationID': '2200220000',
                'productId': 'string',
                'bucketId': 'string',
                'type': 'AccountRefill',
                'dateTime': '2019-05-16T12:08:15.025+0000',
                'eventDetail': 'Refill of INR 500 done for 2200220000',
                'volume': 500,
                'balance': 1600,
                'status': 'success',
                'unit': 'seconds'
            },
            {
                'communicationID': '9638527413',
                'productId': 'string',
                'bucketId': 'string',
                'type': 'AccountAdjustment',
                'dateTime': '2019-05-15T12:08:15.025+0000',
                'eventDetail': 'Added INR 500 to 9638527413',
                'volume': 50000,
                'balance': 10000000,
                'status': 'success',
                'unit': 'byte',
            },
            {
                'communicationID': '2200220000',
                'productId': 'CM_Combo_1322',
                'bucketId': '484',
                'type': 'ProductBucketTransfer_Beneficiary',
                'dateTime': '2019-05-22T09:23:31.000+0000',
                'eventDetail': 'Testing SMS transfer',
                'volume': -200,
                'unit': 'SMS',
                'status': 'completed'
            }
        ];

        let returnValue = [];
        for (let index = 0; index < 10; index++) {
            let val1 = Object.assign({}, consumptionData[0]);
            let val2 = Object.assign({}, consumptionData[1]);
            let val3 = Object.assign({}, consumptionData[2]);
            val1.type = val1.type + ' I:' + (Math.random() * 10 + index).toFixed(1);
            val2.type = val2.type + ' I:' + (Math.random() * 10 + index).toFixed(1);
            val3.type = val3.type + ' I:' + (Math.random() * 10 + index).toFixed(1);
            returnValue.push(val1);
            returnValue.push(val2);
            returnValue.push(val3);
        }
        return returnValue;
    }
}
