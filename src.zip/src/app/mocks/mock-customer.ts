export class MockCustomerData {
    constructor() { }


    public static getMockContract() {
        return [
            {
                'id': 'ee84f315-28eb-42d4-a74b-c7f9afcdcde7',
                'status': 'Active',
                'contractNumber': 'b571d97b-1ac3-4309-a78d-14984e4f1b53',
                'products': [
                    {
                        'id': 'CM_Combo_1239',
                        'name': 'Addon_7',
                        'type': 'Addon',
                        'status': 'Active',
                        'resources': [
                            {
                                'resourceNumber': '2200220000',
                                'type': 'L',
                                'subType': 'MSISDN',
                                'status': 'Active'
                            }
                        ],
                        'prices': [
                            {
                                'price': '26.0',
                                'priceType': 'Recurring',
                                'currency': 'INR',
                                'recurrenceFrequency': 'Custom',
                                'recurrencePeriod': {
                                    'periodType': 'Months',
                                    'periodLength': '2'
                                },
                                'nextRenewalDate': '2019-03-01T12:26:49.000+0000'
                            }
                        ],
                        'productBuckets': [
                            {
                                'id': '179',
                                'name': 'Data_10GB_CPO',
                                'currentBalance': 21474836480.0,
                                'initialBalance': 10737418240.0,
                                'unit': 'byte',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'DATA'
                            },
                            {
                                'id': '465',
                                'name': 'Voice_1000_CPO',
                                'currentBalance': 12000.0,
                                'initialBalance': 6000.0,
                                'unit': 'second',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'VOICE'
                            },
                            {
                                'id': '103',
                                'name': 'SMS_1000_CPO',
                                'currentBalance': 2000.0,
                                'initialBalance': 1000.0,
                                'unit': 'unit',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'SMS'
                            }
                        ]
                    },
                    {
                        'id': 'CM_Combo_1241',
                        'name': 'Addon_9',
                        'type': 'Addon',
                        'status': 'Active',
                        'resources': [
                            {
                                'resourceNumber': '2200220000',
                                'type': 'L',
                                'subType': 'MSISDN',
                                'status': 'Active'
                            }
                        ],
                        'prices': [
                            {
                                'price': '26.0',
                                'priceType': 'Recurring',
                                'currency': 'INR',
                                'recurrenceFrequency': 'Custom',
                                'recurrencePeriod': {
                                    'periodType': 'Days',
                                    'periodLength': '1'
                                },
                                'nextRenewalDate': '2019-04-30T12:26:49.000+0000'
                            }
                        ],
                        'productBuckets': [
                            {
                                'id': '179',
                                'name': 'Data_10GB_CPO',
                                'currentBalance': 21474836480.0,
                                'initialBalance': 10737418240.0,
                                'unit': 'byte',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'DATA'
                            },
                            {
                                'id': '465',
                                'name': 'Voice_1000_CPO',
                                'currentBalance': 12000.0,
                                'initialBalance': 6000.0,
                                'unit': 'second',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'VOICE'
                            },
                            {
                                'id': '103',
                                'name': 'SMS_1000_CPO',
                                'currentBalance': 2000.0,
                                'initialBalance': 1000.0,
                                'unit': 'unit',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'SMS'
                            }
                        ]
                    },
                    {
                        'id': 'CM_Combo_1262',
                        'name': '429_SCP',
                        'type': 'BaseOffer',
                        'status': 'Active',
                        'resources': [
                            {
                                'resourceNumber': '2200220000',
                                'type': 'L',
                                'subType': 'MSISDN',
                                'status': 'Active'
                            }
                        ],
                        'prices': [
                            {
                                'price': '15.0',
                                'priceType': 'Recurring',
                                'currency': 'INR',
                                'recurrenceFrequency': 'Custom',
                                'recurrencePeriod': {
                                    'periodType': 'Days',
                                    'periodLength': '1'
                                },
                                'nextRenewalDate': '2019-04-30T12:26:50.000+0000'
                            }
                        ],
                        'productBuckets': [
                            {
                                'id': '478',
                                'name': '429_DataProviderComponent',
                                'currentBalance': 214434434.0,
                                'initialBalance': 214434434.0,
                                'unit': 'byte',
                                'validUntil': '2019-04-30T12:26:50.000+0000',
                                'bucketType': 'DATA',
                                'sharedBucketType': 'SHARED_PROVIDER',
                                'maxSharedQuota': 2144344
                            },
                            {
                                'id': '480',
                                'name': '429_SMSProviderComponent',
                                'currentBalance': 1000.0,
                                'initialBalance': 1000.0,
                                'unit': 'unit',
                                'validUntil': '2019-04-30T12:26:50.000+0000',
                                'bucketType': 'SMS',
                                'sharedBucketType': 'SHARED_PROVIDER',
                                'maxSharedQuota': 500
                            },
                            {
                                'id': '482',
                                'name': '429_VoiceProviderComponent',
                                'currentBalance': 6000.0,
                                'initialBalance': 6000.0,
                                'unit': 'second',
                                'validUntil': '2019-04-30T12:26:50.000+0000',
                                'bucketType': 'VOICE',
                                'sharedBucketType': 'SHARED_PROVIDER',
                                'maxSharedQuota': 100
                            }
                        ]
                    }
                ],
                'resources': [
                    {
                        'resourceNumber': '2200220000',
                        'type': 'L',
                        'subType': 'MSISDN',
                        'status': 'Active'
                    },
                    {
                        'resourceNumber': '22002200002200220000',
                        'type': 'P',
                        'status': 'Active'
                    }
                ],
                'customerAccountAssignmentRules': [
                    {
                        'customerAccount': {
                            'id': '2200220000',
                            'mainBalance': '133.0',
                            'lifeCycleState': {
                                'currentState': 'ACTIVE',
                                'nextState': 'SUPERVISION_EXPIRY',
                                'transitionDate': '2019-12-05T11:00:00.000+0000'
                            },
                            'currency': 'INR'
                        }
                    }
                ]
            },
            {
                'id': 'ee84f315-28eb-42d4-a74b-c7f9afcdcde8',
                'status': 'Active',
                'contractNumber': 'b571d97b-1ac3-4309-a78d-14984e4f1b54',
                'products': [
                    {
                        'id': 'MK_Combo_1239',
                        'name': 'Addon_MK',
                        'type': 'Addon',
                        'status': 'Active',
                        'resources': [
                            {
                                'resourceNumber': '2200220001',
                                'type': 'L',
                                'subType': 'MSISDN',
                                'status': 'Active'
                            }
                        ],
                        'prices': [
                            {
                                'price': '26.0',
                                'priceType': 'Recurring',
                                'currency': 'INR',
                                'recurrenceFrequency': 'Custom',
                                'recurrencePeriod': {
                                    'periodType': 'Months',
                                    'periodLength': '2'
                                },
                                'nextRenewalDate': '2019-03-01T12:26:49.000+0000'
                            }
                        ],
                        'productBuckets': [
                            {
                                'id': '179',
                                'name': 'Data_12GB_CPO',
                                'currentBalance': 21474836480.0,
                                'initialBalance': 10737418240.0,
                                'unit': 'byte',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'DATA'
                            },
                            {
                                'id': '465',
                                'name': 'Voice_1200_CPO',
                                'currentBalance': 12000.0,
                                'initialBalance': 6000.0,
                                'unit': 'second',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'VOICE'
                            },
                            {
                                'id': '103',
                                'name': 'SMS_1200_CPO',
                                'currentBalance': 2000.0,
                                'initialBalance': 1000.0,
                                'unit': 'unit',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'SMS'
                            }
                        ]
                    },
                    {
                        'id': 'CM_Combo_1241',
                        'name': 'Addon_MK9',
                        'type': 'Addon',
                        'status': 'Active',
                        'resources': [
                            {
                                'resourceNumber': '2200220001',
                                'type': 'L',
                                'subType': 'MSISDN',
                                'status': 'Active'
                            }
                        ],
                        'prices': [
                            {
                                'price': '26.0',
                                'priceType': 'Recurring',
                                'currency': 'INR',
                                'recurrenceFrequency': 'Custom',
                                'recurrencePeriod': {
                                    'periodType': 'Days',
                                    'periodLength': '1'
                                },
                                'nextRenewalDate': '2019-04-30T12:26:49.000+0000'
                            }
                        ],
                        'productBuckets': [
                            {
                                'id': '179',
                                'name': 'Data_12GB_CPO',
                                'currentBalance': 21474836480.0,
                                'initialBalance': 10737418240.0,
                                'unit': 'byte',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'DATA'
                            },
                            {
                                'id': '465',
                                'name': 'Voice_1200_CPO',
                                'currentBalance': 12000.0,
                                'initialBalance': 6000.0,
                                'unit': 'second',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'VOICE'
                            },
                            {
                                'id': '103',
                                'name': 'SMS_1200_CPO',
                                'currentBalance': 2000.0,
                                'initialBalance': 1000.0,
                                'unit': 'unit',
                                'validUntil': '2019-04-30T12:26:49.000+0000',
                                'bucketType': 'SMS'
                            }
                        ]
                    },
                    {
                        'id': 'CM_Combo_1262',
                        'name': '429_SCP',
                        'type': 'BaseOffer',
                        'status': 'Active',
                        'resources': [
                            {
                                'resourceNumber': '2200220001',
                                'type': 'L',
                                'subType': 'MSISDN',
                                'status': 'Active'
                            }
                        ],
                        'prices': [
                            {
                                'price': '15.0',
                                'priceType': 'Recurring',
                                'currency': 'INR',
                                'recurrenceFrequency': 'Custom',
                                'recurrencePeriod': {
                                    'periodType': 'Days',
                                    'periodLength': '1'
                                },
                                'nextRenewalDate': '2019-04-30T12:26:50.000+0000'
                            }
                        ],
                        'productBuckets': [
                            {
                                'id': '478',
                                'name': '429_DataProviderComponent_MK',
                                'currentBalance': 214434434.0,
                                'initialBalance': 214434434.0,
                                'unit': 'byte',
                                'validUntil': '2019-04-30T12:26:50.000+0000',
                                'bucketType': 'DATA',
                                'sharedBucketType': 'SHARED_PROVIDER',
                                'maxSharedQuota': 2144344
                            },
                            {
                                'id': '480',
                                'name': '429_SMSProviderComponent_MK',
                                'currentBalance': 1000.0,
                                'initialBalance': 1000.0,
                                'unit': 'unit',
                                'validUntil': '2019-04-30T12:26:50.000+0000',
                                'bucketType': 'SMS',
                                'sharedBucketType': 'SHARED_PROVIDER',
                                'maxSharedQuota': 500
                            },
                            {
                                'id': '482',
                                'name': '429_VoiceProviderComponent_MK',
                                'currentBalance': 6000.0,
                                'initialBalance': 6000.0,
                                'unit': 'second',
                                'validUntil': '2019-04-30T12:26:50.000+0000',
                                'bucketType': 'VOICE',
                                'sharedBucketType': 'SHARED_PROVIDER',
                                'maxSharedQuota': 100
                            }
                        ]
                    }
                ],
                'resources': [
                    {
                        'resourceNumber': '2200220001',
                        'type': 'L',
                        'subType': 'MSISDN',
                        'status': 'Active'
                    },
                    {
                        'resourceNumber': '22002200002200220000',
                        'type': 'P',
                        'status': 'Active'
                    }
                ],
                'customerAccountAssignmentRules': [
                    {
                        'customerAccount': {
                            'id': '2200220001',
                            'mainBalance': '133.0',
                            'lifeCycleState': {
                                'currentState': 'ACTIVE',
                                'nextState': 'SUPERVISION_EXPIRY',
                                'transitionDate': '2019-12-05T11:00:00.000+0000'
                            },
                            'currency': 'INR'
                        }
                    }
                ]
            }
        ];
    }
}
