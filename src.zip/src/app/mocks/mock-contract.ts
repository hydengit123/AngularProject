export class MockCustomerContract {


    public static getMockData(): Array<any> {
        let consumptionData = [
      {
        'communicationID': '7654321217',
        'type': 'AccountTransfer',
        'dateTime': '2019-05-29T04:03:49.000+0000',
        'eventDetail': 'Transferred 200 INR to 7654321218',
        'volume': -1,
        'unit': 'INR',
        'status': 'completed',
        'coreData': {
          'beneficiaryMsisdn': '7654321218',
          'currency': 'INR',
          'customerAccountId': '7654321217',
          'donorEmailId': 'jayasri.elango@wipro.com',
          'summaryTextLabel': 'AccountTransferDonorSummary',
          'transferQuantity': '1'
        }
      },
      {
        'communicationID': '7654321217',
        'type': 'AccountTransfer',
        'dateTime': '2019-05-29T05:33:25.000+0000',
        'eventDetail': 'Transferred 10 INR to 7654321217',
        'volume': 10,
        'unit': 'INR',
        'balance': 1815.2,
        'status': 'completed',
        'coreData': {
          'beneficiaryMsisdn': '7654321217',
          'currency': 'INR',
          'currentBalance': '1815.2',
          'customerAccountId': '7654321218',
          'summaryTextLabel': 'AccountTransferBeneficiarySummary',
          'transferQuantity': '10'
        }
      },
      {
        'communicationID': '7654321217',
        'productId': 'CM_Combo_1420',
        'bucketId': '519',
        'type': 'ProductBucketTransfer',
        'dateTime': '2019-05-29T10:51:47.000+0000',
        'eventDetail': 'Testing productbucket transfer',
        'volume': -10,
        'unit': 'second',
        'balance': 58170,
        'status': 'completed',
        'coreData': {
          'beneficiaryMsisdn': '7654321218',
          'bucketId': '519',
          'bucketType': 'VOICE',
          'contractId': 'c42444e0-60c2-45f3-89b4-5018fe185dd9',
          'currentBalance': '58170.0',
          'msisdn': '7654321217',
          'productId': 'CM_Combo_1420',
          'quantityUnit': 'second',
          'summaryTextLabel': 'BucketTransferDonorSummary',
          'transferQuantity': '10'
        }
      },
      {
        'communicationID': '7654321218',
        'productId': 'CM_Data2Share_1364',
        'bucketId': '519',
        'type': 'ProductBucketTransfer_Beneficiary',
        'dateTime': '2019-05-27T12:40:44.000+0000',
        'eventDetail': 'Bucket product details backup test',
        'volume': 1,
        'balance': 1,
        'unit': 'byte',
        'status': 'completed',
        'coreData': {
          'beneficiaryMsisdn': '7654321218',
          'bucketId': '519',
          'currentBalance': '1',
          'donorMsisdn': '7654321217',
          'productId': 'CM_Data2Share_1364',
          'productType': 'Data2Share',
          'transferQuantity': '1',
          'msisdn': '7654321217',
          'quantityUnit': 'byte',
          'summaryTextLabel': 'BucketTransferBeneficiary_Summary'
        }
      },
      {
        'communicationID': '7654321217',
        'type': 'AccountAdjustment',
        'dateTime': '2019-05-29T13:02:17.000+0000',
        'eventDetail': 'Deducted INR 50 done to 7654321217',
        'volume': -50,
        'unit': 'INR',
        'status': 'completed',
        'coreData': {
          'adjustmentAmount': '-50',
          'currency': 'INR',
          'customerAccountId': '7654321217',
          'summaryTextLabel': 'AccountAdjustmentNegativeSummary'
        }
      },
      {
        'communicationID': '7654321217',
        'type': 'AccountRefill_ForOthers_Beneficiary',
        'dateTime': '2019-05-29T04:00:34.000+0000',
        'eventDetail': 'Refill of INR 50 done for 7654321217 by DXP',
        'volume': 50,
        'unit': 'INR',
        'status': 'completed',
        'coreData': {
          'beneficiaryMsisdn': '7654321217',
          'currency': 'INR',
          'donorCustomerName': 'DXP',
          'donorMsisdn': '7654321218',
          'refillAmount': '50',
          'summaryTextLabel': 'AccountRefillBeneficiarySummary'
        }
      },
      {
        'communicationID': '7654321217',
        'type': 'AccountRefill',
        'dateTime': '2019-05-29T09:47:16.000+0000',
        'eventDetail': 'Refill of INR 150 done for 7654321217',
        'volume': 150,
        'unit': 'INR',
        'status': 'completed',
        'coreData': {
          'currency': 'INR',
          'customerAccountId': '7654321217',
          'refillAmount': '150',
          'summaryTextLabel': 'AccountRefillSummary'
        }
      },
      {
        'communicationID': '7654321217',
        'type': 'AccountRefill_ForOthers_Anon',
        'dateTime': '2019-05-29T13:41:26.000+0000',
        'eventDetail': 'Refill of INR 50 done for 7654321217 by anonymous user',
        'volume': 50,
        'unit': 'INR',
        'status': 'completed',
        'coreData': {
          'beneficiaryMsisdn': '7654321217',
          'currency': 'INR',
          'refillAmount': '50',
          'summaryTextLabel': 'AccountRefillAnonSummary'
        }
      }
    ];

        let returnValue = [];
        for (let index = 0; index < 1; index++) {
            let val1 = Object.assign({}, consumptionData[0]);
            let val2 = Object.assign({}, consumptionData[1]);
            let val3 = Object.assign({}, consumptionData[2]);
            val1.type = val1.type + ' I:' + (Math.random() * 10 + index).toFixed(1);
            val2.type = val2.type + ' I:' + (Math.random() * 10 + index).toFixed(1);
            val3.type = val3.type + ' I:' + (Math.random() * 10 + index).toFixed(1);
            returnValue.push(val1);
            returnValue.push(val2);
            returnValue.push(val3);
        }
        return returnValue;
    }
}
