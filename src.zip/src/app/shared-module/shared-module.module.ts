import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateModule } from '@ngx-translate/core';
import { DxpCommonModule, DxpPipeModule } from 'dxp-common';
import { MDBBootstrapModulesPro } from 'ng-uikit-pro-standard';
import { CustomPipeModule } from '../custom-pipe/custom-pipe.module';
import { AddonContainerComponent } from './addon-container/addon-container.component';
import { PaymentFormComponent } from './payment-form/payment-form.component';
import { WaterGlassComponent } from './water-glass/water-glass.component';


@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    CustomPipeModule,
    DxpPipeModule,
    MDBBootstrapModulesPro,
     NgbModule,
    DxpCommonModule
  ],
  declarations: [
    PaymentFormComponent,
    WaterGlassComponent,
    AddonContainerComponent
  ],
  exports: [
    PaymentFormComponent,
    WaterGlassComponent,
    TranslateModule,
    AddonContainerComponent,
    CustomPipeModule
  ]
})
export class SharedModuleModule {
}
