import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WaterGlassComponent } from './water-glass.component';
import { SimpleChanges } from '@angular/core';
import { testBedModule } from '../../test-bed-module-mock';

describe('WaterGlassComponent', () => {
  let component: WaterGlassComponent;
  let fixture: ComponentFixture<WaterGlassComponent>;
  let test: SimpleChanges;
  const testBedModules = testBedModule().testBedModules;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [WaterGlassComponent, ...testBedModules.declarations],
      providers: [...testBedModules.providers],
      imports: [...testBedModules.imports],
    }).compileComponents();
    fixture = TestBed.createComponent(WaterGlassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('ngOnChanges', () => {
    it('should set the height property if provisioned < 0', () => {
      component.provisioned = -1;
      component.ngOnChanges(test);
      expect(component.height).toEqual(100);
    });

    it('should set the height property if available = provisioned', () => {
      component.provisioned = 1;
      component.available = 1;
      component.ngOnChanges(test);
      expect(component.height).toEqual(100);
    });
    it('should set the height property if available > provisioned', () => {
      component.provisioned = 1;
      component.available = 5;
      component.ngOnChanges(test);
      expect(component.height).toEqual(100);
    });
    it('should set the height property if available < provisioned', () => {
      component.provisioned = 2;
      component.available = 1;
      component.ngOnChanges(test);
      expect(component.height).toEqual(50);
    });
  });

});
