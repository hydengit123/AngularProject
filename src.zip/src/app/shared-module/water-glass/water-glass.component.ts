import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';

@Component({
  selector: 'app-water-glass',
  templateUrl: './water-glass.component.html',
  styleUrls: ['./water-glass.component.scss']
})
export class WaterGlassComponent implements OnInit, OnChanges {

  @Input() provisioned = 0;
  @Input() available = 0;
  @Input() colorscheme ;
  height = 0;

  constructor() {
  }

  ngOnInit() {

  }

  ngOnChanges(changes: SimpleChanges): void {
    // document.getElementById("water").style.backgroundImage = 'url("assets/imgs/vectorpaint'+this.colorscheme+  '.svg")';
    if (this.provisioned < 0) {
      this.height = 100;
    } else if (this.available >= this.provisioned) {
      this.height = 100;
    } else {
      this.height = this.available / this.provisioned * 100;
    }
  }


}
