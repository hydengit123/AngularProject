import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddonContainerComponent } from './addon-container.component';

describe('AddonContainerComponent', () => {
  let component: AddonContainerComponent;
  let fixture: ComponentFixture<AddonContainerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddonContainerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddonContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
