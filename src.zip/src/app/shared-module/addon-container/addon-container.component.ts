import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService } from 'angular-persistence';
import { FormMessageService } from '../../customer-onboarding/services/form-message.service';
import { EventListenerService } from '../../event-listener.service';
import { cartDetails, customerOnboard } from 'dxp-common';
import { AuthService } from '../../services/auth.service';
import { CartService } from '../../services/cart.service';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { CustomerSearchService } from '../../services/customer-search.service';
import { DealsForYouService } from '../../services/dfy.service';


declare const alertify;
declare var jQuery: any;

@Component({
  selector: 'app-addon-container',
  templateUrl: './addon-container.component.html',
  styleUrls: ['./addon-container.component.scss']
})
export class AddonContainerComponent implements OnInit,OnDestroy{


  @Input() card: any = null;
  @Input() selectedAddOns: any = null;
  @Input() count: any = null;
  @Input() activationJourney:any =false;
  contractDetails: any;
  userProfile: any;
  contractActive: boolean = true;

  notificationCount: any = 0;

  constructor(private router: Router, private formBuilder: FormBuilder,
    private persistenceService: PersistenceService,
    private authService: AuthService,
    private translate: TranslateService,
    private event: EventListenerService,
    private formMessageService: FormMessageService,
    private customerOnBoardService: CustomerOnboardService,
    private dealsForYouService: DealsForYouService,
    private customerSearchService: CustomerSearchService,
    private cartService: CartService) { }

  ngOnInit() {
    if (this.count) {
      this.notificationCount = this.count;
    }
    if (this.card && this.card.description) {
      this.card.description = this.card.description.replace('<p>', '').replace('</p>', '');
    }
    this.contractDetails = this.customerSearchService.getCurrentContract();
    this.userProfile = this.customerSearchService.getUserProfile();

    this.cartService.localCartEvent.subscribe((data)=>{
      if (this.cartService.cartDetails) {
        this.notificationCount=this.cartService.getQuantity(this.card.name)||0;
    }
    })
  }

  isActive(item) {
    return this.selectedAddOns && this.selectedAddOns.filter(x => x.productOffering.id === item.id).length === 1;
  };

   async addToCart(productItem) {
    
     if(this.activationJourney)
     {
      const cartInfo = await this.customerOnBoardService.addToCart(productItem, this.formMessageService.onboardingForm.value as customerOnboard).toPromise();
        const cartDetails: cartDetails = await this.cartService.getCartDetails().toPromise();
        alertify.success(this.translate.instant('Added to cart'));
        this.event.notifyCartUpdate(cartDetails);
     }
     else{

      if ( this.contractDetails.status !== 'Active') {
        alertify.error('Contract is Inactive');
       } else {
         let createSaveCart = true;
         if (this.cartService.cartDetails && this.cartService.cartDetails.id) {
           createSaveCart = false;
           this.itemToCart(productItem, createSaveCart);
         } else {
           this.cartService.getAddonJourneySessionData(this.userProfile.customerId, 'BuyAddon').subscribe(result =>{
             if (result.length > 0) {
               this.event.showPendingJourney('addon');
             }
           }, error => {
               this.itemToCart(productItem, createSaveCart);
           });
         }
       }
     }
  
  }

  async itemToCart(productItem, createSaveCart) {
      this.notificationCount++;
      const cartInfo = await this.dealsForYouService.addToCart(productItem, this.contractDetails, this.userProfile).toPromise();
      const cartDetails: cartDetails = await this.cartService.getCartDetails().toPromise();
      const journeySessionId = await this.dealsForYouService.createSaveCartJourney(this.contractDetails, cartDetails, this.userProfile, null, createSaveCart).toPromise();
      this.dealsForYouService.journeySessionId = journeySessionId.id;
      alertify.success(this.translate.instant('Added to cart'));
      this.event.notifyCartUpdate(cartDetails);
  }

  ngOnDestroy(){
    this.notificationCount = 0;
  }
}
