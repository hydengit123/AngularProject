import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentFormComponent } from './payment-form.component';
import { testBedModule } from '../../test-bed-module-mock';

describe('PaymentFormComponent', () => {
  let component: PaymentFormComponent;
  let fixture: ComponentFixture<PaymentFormComponent>;
  const testBedModules = testBedModule().testBedModules;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PaymentFormComponent, ...testBedModules.declarations],
      providers: [...testBedModules.providers],
      imports: [...testBedModules.imports],
    }).compileComponents();

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentFormComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('selectCard', () => {
    it('should set the selectedPayment property', () => {
      component.selectCard(12);
      expect(component.selectedPayment).toEqual(12);
    });
  });
});
