import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PaymentRequestInfo } from 'dxp-common';
import { CustomerOnboardService } from '../../services/customer-onboard.service';
import { CustomerService } from '../../services/customer.service';
import { PaymentGatewayService } from '../../services/payment-gateway.service';


@Component({
  selector: 'app-payment-form',
  templateUrl: './payment-form.component.html',
  styleUrls: ['./payment-form.component.scss']
})
export class PaymentFormComponent implements OnInit, OnChanges {
  @Input() cardType = 'Credit Card';

  public paymentGateWayList: any;
  public showPaymentList: boolean;
  public enablePayment: Boolean = true;
  public enablePayBtn: Boolean = false;
  @Input() paymentRequestInfo: PaymentRequestInfo;
  @Input() msisdn: string;
  @Input() paymentResponseHandler: any;

  isRTL:boolean = false;
  constructor(public customerOnBoardService: CustomerOnboardService, private paymentGatewayService: PaymentGatewayService, private customerService: CustomerService,
    private translate: TranslateService)  {
    // this language will be used as a fallback when a translation isn't found in the current language
    translate.setDefaultLang('en');
    //use browser cultural language

    // the lang to use, if the lang isn't available, it will use the current loader to get them
    translate.use(translate.getBrowserCultureLang()).subscribe((res)=>{
      if(translate.instant("text-direction") == "rtl"){
        this.isRTL = true;
      }
    });
    
  }

  ngOnInit() {
    this.paymentGatewayService.paymentGatewayList().subscribe(data => {
      this.paymentGateWayList = data;
      this.showPaymentList = this.paymentGateWayList && this.paymentGateWayList.length && this.paymentGateWayList.length > 1;
    });

  }

  ngOnChanges(changes: SimpleChanges) {
    if(changes.paymentRequestInfo.previousValue && changes.paymentRequestInfo.currentValue !== changes.paymentRequestInfo.previousValue){
      this.showPaymentBtn();
    }
    else if(changes.paymentRequestInfo.currentValue && !changes.paymentRequestInfo.previousValue){
      this.showPaymentBtn();
    }
  }

  get selectedPayment():any{
    if(this.paymentGateWayList){
    const selectedPayments = this.paymentGateWayList.filter(item => item.checked == true);
    if(selectedPayments.length > 0){
      return selectedPayments[0];
    }
  }
    return null;
  }

  showPaymentBtn(){
    if(this.selectedPayment && this.paymentRequestInfo.amount > 0){
      this.enablePayBtn = true;
    }
    else{
      this.enablePayBtn = false;
    }
  }

  paymentGatewayRadioClicked(paymentGatewaySelected) {
    let list = this.paymentGateWayList.map( d => {
      d.value == paymentGatewaySelected.value? d.checked = !d.checked: d.checked = false;
      return d;
    });
    this.paymentGateWayList = [...list];
    this.showPaymentBtn();
  }

  doPayment(e){
    
    if(this.selectedPayment && this.selectedPayment.value){
    
      const successURL = '/customerOnboard/paymentsuccessful';
      const failureURL = '/customerOnboard/paymentsuccessful';
      const currencyy: any = 'INR';  // Pass CM UI currency

      this.paymentGatewayService.launchPaymentBolt(this.paymentRequestInfo, 
        this.selectedPayment.value,
        this.msisdn,
        currencyy,
        successURL,
        failureURL,
        this.paymentResponseHandler
        );
    }

  }

}
