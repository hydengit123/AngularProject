import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { ErrorsHandlerService } from './errors-handler.service';
import { HttpErrorResponse } from '@angular/common/http';
import { testBedModule } from './test-bed-module-mock';
import { TranslateService } from '@ngx-translate/core';


declare const alertify;

fdescribe('ErrorsHandlerService', () => {
  let errorsHandlerService: ErrorsHandlerService;
  let httpTestingControllerSpy: HttpTestingController;
  let translateServiceSpy: TranslateService;

  const testBedModules = testBedModule().testBedModules;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [...testBedModules.imports ],
      providers: [...testBedModules.providers]
    });
  });

  beforeEach(() => {
    httpTestingControllerSpy = TestBed.get(HttpTestingController);
    errorsHandlerService = TestBed.get(ErrorsHandlerService);
    translateServiceSpy = TestBed.get(TranslateService);
  });

  it('should be created', () => {
    expect(errorsHandlerService).toBeTruthy();
  });

  describe('handleError', () => {
    it('Should call alertify.error when error.status = 400 ', () => {
      const error = new HttpErrorResponse({ status: 400 });
      spyOn(alertify, 'error');
      errorsHandlerService.handleError(error);

      expect(alertify.error).toHaveBeenCalledWith('400');
    });

    it('Should call alertify.error when error.status = 401 ', () => {
      const error = new HttpErrorResponse({ status: 401 });
      spyOn(alertify, 'error');
      errorsHandlerService.handleError(error);

      expect(alertify.error).toHaveBeenCalledWith('401');
    });

    it('Should call alertify.error when navigator.onLine = false ', () => {
      const error = new HttpErrorResponse({});
      spyOnProperty(navigator, 'onLine').and.returnValue(false);
      spyOn(alertify, 'error');
      errorsHandlerService.handleError(error);

      expect(alertify.error).toHaveBeenCalledWith('No internet connection');
    });

    it('Should call alertify.error when navigator.onLine = true ', () => {
      const error = new HttpErrorResponse({});
      spyOnProperty(navigator, 'onLine').and.returnValue(true);
      spyOn(alertify, 'error');
      errorsHandlerService.handleError(error);

      expect(alertify.error).not.toHaveBeenCalledWith('No internet connection');
    });
    it('Should call alertify.error when error is not type of HttpErrorResponse ', () => {
      const error = new Error();
      spyOn(alertify, 'error');
      errorsHandlerService.handleError(error);

      expect(alertify.error).toHaveBeenCalledWith('400');
    });
  });
});
