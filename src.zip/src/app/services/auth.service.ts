import { Injectable } from '@angular/core';
import { DataClientService } from '../data-client.service';
import { PersistenceService, StorageType } from 'angular-persistence';
import { PERSISTANCEKEY } from '../../application-constants';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable()
export class AuthService {

  public userIdentity: any;
  constructor(private dataClientService: DataClientService,
    private http: HttpClient,
    private persistanceService: PersistenceService) {      

  }

  setUserIdentity(userIdentity){
    this.userIdentity = userIdentity;
  }
  getUserIdentity(){
    return this.userIdentity;
  }
  reset(){
    this.userIdentity = null;
  }
  login(username: string, password: string) {
    // username = "wipro546@email.com";
    // password = "helloworldd";
    return this.http.get(`${environment.urls.login}?username=${btoa(username)}&password=${btoa(password)}`)
  }

  resetPassword(userObject) {
    let headers: any = {};
    let access_token = this.persistanceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
    headers['Authorization'] = 'Bearer ' + access_token;

    return this.http.put(environment.urls.credUrl, userObject,headers)
  }

  logout() {
    return this.dataClientService.post(null, 'user', ['logout'], null, null);
  }


  getCustomerInfo(msisdn) {
    return this.dataClientService.get('customer', [msisdn]);
  }

  saveProfile(params) {
    return this.dataClientService.put(params, 'customer', [''], null, 'text');
  }

  // async refreshToken() {
  //   const user = JSON.parse(atob(this.persistanceService.get(PERSISTANCEKEY.USER, StorageType.SESSION)));
  //   const username = user.loginName;
  //   const password = user.loginName;
  //   const res = await this.login(username, password).toPromise();
  //   const token = res.access_token;
  //   this.persistanceService.set(PERSISTANCEKEY.ACCESSTOKEN, { type: StorageType.SESSION });
  //   return token;
  // }
}
