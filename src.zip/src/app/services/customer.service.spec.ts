import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs';
import { DataClientService } from '../data-client.service';
import { CustomerService } from './customer.service';

describe('CustomerService', () => {

    let dataClientServiceSpy: jasmine.SpyObj<DataClientService>;
    let customerService: CustomerService;
    beforeEach(() => {
        const DataClientServiceSpy = jasmine.createSpyObj('DataClientService', ['get', 'post', 'put', 'delete']);

        TestBed.configureTestingModule({
            providers: [
                CustomerService,
                { provide: DataClientService, useValue: DataClientServiceSpy }
            ],
            imports: [RouterTestingModule]
        });
    });
    beforeEach(() => {
        dataClientServiceSpy = TestBed.get(DataClientService);
        customerService = TestBed.get(CustomerService)
    });
    it('should be created', () => {
        expect(CustomerService).toBeTruthy();
    });

    describe('registerUser', () => {
        it('should call dataClientService.post method ', () => {
            customerService.registerUser('param');
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith('param', 'customer', ['register'], null, 'text');
        });
    });

    describe('getCustomerInfo', () => {
        it('should call dataClientService.get method ', () => {
            customerService.getCustomerInfo('123456');
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('customer', ['123456']);
        });
    });

    describe('getAggregatedSubscription', () => {
        it('should call dataClientService.get method ', () => {
            customerService.getAggregatedSubscription('123456');
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('customer', ['subscription', 'balance'], {
                msisdn: '123456',
                subscriberCategory: 'PREPAID'
            });
        });
    });

    describe('getSubscriptionDetail', () => {
        it('should call dataClientService.get method ', () => {
            customerService.getSubscriptionDetail('123456');
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('customer', ['subscription', 'details'], { msisdn: '123456' });
        });
    });

    describe('removeSharedAccount', () => {
        it('should call dataClientService.delete method ', () => {
            customerService.removeSharedAccount('123456', '789654');
            expect(dataClientServiceSpy.delete).toHaveBeenCalledWith('customerGroup', ['123456', 'sharedAccount', '789654']);
        });
    });

    describe('removeMsisdnFromInventory', () => {
        it('should call dataClientService.delete method ', () => {
            customerService.removeMsisdnFromInventory('123456');
            expect(dataClientServiceSpy.delete).toHaveBeenCalledWith('inventory', ['123456']);
        });
    });

    describe('recharge', () => {
        it('should call dataClientService.post method ', fakeAsync(() => {
            dataClientServiceSpy.post.and.callFake(() => { return Observable.of({ access_token: 'accessToken' }) })
            customerService.recharge('123456', 1);
            tick();
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith(null, 'customer', ['123456', 'balance', 'credit'.toString(), (1).toString(10)], null);
        }));


        it('should throw error if quota = 0 ', fakeAsync(() => {
            let error = new Error('Please enter amount')
            tick();
            customerService.recharge('123456').catch(res => {
                expect(res).toEqual(error);
            })

        }));
    });

    describe('buyPlan', () => {
        it('should call dataClientService.post method ', fakeAsync(() => {
            const params = {
                msisdn: '123456',
                productId: 'abc',
                buyOption: 'RACT'
            };
            dataClientServiceSpy.post.and.callFake(() => { return Observable.of({ access_token: 'accessToken' }) })
            customerService.buyPlan('123456', 'abc');
            tick();
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith(params, 'customer', ['subscription', 'product'], {});
        }));
    });

    describe('removePlan', () => {
        it('should call dataClientService.post method ', fakeAsync(() => {
            const params = {
                msisdn: '123456',
                productId: 'abc',
                buyOption: 'DACT'
            };
            dataClientServiceSpy.post.and.callFake(() => { return Observable.of({ access_token: 'accessToken' }) })
            customerService.removePlan('123456', 'abc');
            tick();
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith(params, 'customer', ['subscription', 'product'], {});
        }));
    });

    describe('getRechargeHistory', () => {
        it('should call dataClientService.get method ', fakeAsync(() => {
            dataClientServiceSpy.get.and.callFake(() => { return Observable.of({ access_token: 'accessToken' }) })
            customerService.getRechargeHistory('123456');
            tick();
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('customer', ['123456', 'balance', 'credit'], null);
        }));
    });

    describe('getTransferHistory', () => {
        it('should call dataClientService.get method ', fakeAsync(() => {
            dataClientServiceSpy.get.and.callFake(() => { return Observable.of('success') })
            customerService.getTransferHistory('123456');
            tick();
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('customer', ['subscription', 'transferHistory'], { msisdn: '123456' });
        }));
    });

    describe('getTransferHistory', () => {
        it('should call dataClientService.get method ', fakeAsync(() => {
            dataClientServiceSpy.get.and.callFake(() => { return Observable.of('success') })
            customerService.getTransferHistory('123456');
            tick();
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('customer', ['subscription', 'transferHistory'], { msisdn: '123456' });
        }));
    });

    describe('subscriptionDetail', () => {
        it('should call dataClientService.get method ', fakeAsync(() => {
            dataClientServiceSpy.get.and.callFake(() => { return Observable.of('success') })
            customerService.subscriptionDetail('123456');
            tick();
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('customer', ['subscription', 'details'], { msisdn: '123456' });
        }));
    });
    describe('shareQuota', () => {
        it('should call dataClientService.post method through private buyProduct method ', fakeAsync(() => {
            dataClientServiceSpy.post.and.returnValue(Observable.of('mock'));
            let result = customerService.shareQuota('params');
            tick();
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith('params', 'customer', ['subscription', 'product'], {});
            result.subscribe(res => {
                expect(res).toEqual('mock');
            })
        }));
    });
    describe('transferCreditBalance', () => {
        it('should call dataClientService.post method through private buyProduct method 1', fakeAsync(() => {
            dataClientServiceSpy.post.and.returnValue(Observable.of('mock'));
            let result = customerService.transferCreditBalance('params');
            tick();
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith('params', 'customer', ['subscription', 'product'], {});
            result.subscribe(res => {
                expect(res).toEqual('mock');
            })
        }));
    });
    describe('addAddon', () => {
        it('should call dataClientService.post method through private buyProduct method', fakeAsync(() => {
            dataClientServiceSpy.post.and.returnValue(Observable.of('mock'));
            let result = customerService.addAddon('params');
            tick();
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith('params', 'customer', ['subscription', 'product'], {});
            result.subscribe(res => {
                expect(res).toEqual('mock');
            })
        }));
    });
    describe('removeAddon', () => {
        it('should call dataClientService.post method through private buyProduct method', fakeAsync(() => {
            dataClientServiceSpy.post.and.returnValue(Observable.of('mock'));
            let result = customerService.removeAddon('params');
            tick();
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith('params', 'customer', ['subscription', 'product'], {});
            result.subscribe(res => {
                expect(res).toEqual('mock');
            })
        }));
    });
    describe('transferItem', () => {
        it('should call dataClientService.post method through private buyProduct method', fakeAsync(() => {
            dataClientServiceSpy.post.and.returnValue(Observable.of('mock'));
            let result = customerService.transferItem('params');
            tick();
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith('params', 'customer', ['subscription', 'product'], {});
            result.subscribe(res => {
                expect(res).toEqual('mock');
            })
        }));
    });
    describe('addQuota', () => {
        it('should call dataClientService.post method through private buyProduct method', fakeAsync(() => {
            dataClientServiceSpy.post.and.returnValue(Observable.of('mock'));
            let result = customerService.addQuota('params');
            tick();
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith('params', 'customer', ['subscription', 'product'], {});
            result.subscribe(res => {
                expect(res).toEqual('mock');
            })
        }));
    });
    describe('setupsisdn', () => {
        it('should call dataClientService.post method through private buyProduct method', fakeAsync(() => {
            dataClientServiceSpy.post.and.returnValue(Observable.of('mock'));
            let result = customerService.setupsisdn('params');
            tick();
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith('params', 'customer', ['subscription', 'product'], {});
            result.subscribe(res => {
                expect(res).toEqual('mock');
            })
        }));
    });
});