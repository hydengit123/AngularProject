
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PaymentRequestInfo } from 'dxp-common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { EventListenerService } from '../event-listener.service';
import { PaymentGatewayService } from './payment-gateway.service';
declare const alertify;

@Injectable({
  providedIn: 'root'
})
export class RechargeTransferService {

  constructor(private http: HttpClient,
    private paymentService: PaymentGatewayService,
    private eventListenerService: EventListenerService,
    private translateService: TranslateService) { }


  public customerInteraction(customerInteractionRefill: any): Observable<any> {

    let url = '';
    let httpResponse: Observable<any>;
    if (environment.urls.customerInteraction.indexOf(".json") !== -1) {
      url = environment.urls.customerInteraction;
      httpResponse = this.http.get(url);
    }
    else {
      url = environment.urls.customerInteraction;
      delete customerInteractionRefill.userId;
      httpResponse = this.http.post(url, customerInteractionRefill);
    }
    return httpResponse.pipe(map((response: any) => {
      let mappedData: any = response;
      return mappedData;
    }
    ));
  }

  async paymentSuccessHandler(BOLT, paymentRequest: PaymentRequestInfo, customerInteractionRefill: any, eventNumber) {
    if (BOLT.response && BOLT.response.txnStatus === 'SUCCESS'
      && BOLT.response.txnid) {
      const paymentTransactionRequest = {
        resourceNumber: this.paymentService.paymentConfigSelected.resourceNumber, // MSISDN from customer journey
        payer: BOLT.response.payer || 'NA', // NA in old code
        merchantRefNum: this.paymentService.paymentConfigSelected.merchantRefNum, // merchantRefNum from create payment service
        paymentGwTransactionId: BOLT.response.txnid || BOLT.response.payuMoneyId || paymentRequest.txnid,
        status: BOLT.response.status,
        paymentToken: BOLT.response.paymentId || '', // empty in old code
        paymentMethod: BOLT.response.mode,
        expiryDate: BOLT.response.addedon || '', // empty in old code
        cardNumber: BOLT.response.cardnum || '', //cardnum from payumoney
        amount: BOLT.response.amount
      };

      if (this.paymentService.msisdn === paymentTransactionRequest.resourceNumber && this.paymentService.allowPayment) {
        this.paymentService.allowPayment = false;
        const paymentInfo = await this.paymentService.updatePayment(paymentTransactionRequest).toPromise();
        if (paymentInfo && paymentInfo.message && paymentInfo.message === 'SUCCESS') {
          const customerInteractionResponse = await this.customerInteraction(customerInteractionRefill).toPromise();
          if (customerInteractionResponse) {
            this.redirectToSucessView(customerInteractionResponse, eventNumber);
          }

        } else {
          alertify.error(this.translateService.instant('Payment Failed'));
        }
      }
    } else {
      alertify.error(this.translateService.instant('Payment has been cancelled'));
    }
  }

  public redirectToSucessView(customerInteractionResponse, eventNumber) {
    this.paymentService.orderId = customerInteractionResponse.id;
    this.eventListenerService.showPaymentSuccessMessage(customerInteractionResponse, eventNumber);
  }

  paymentFailureHandler(BOLT) {
    alertify.error(this.translateService.instant(BOLT.message));
  }

}
