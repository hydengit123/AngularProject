import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { cartDetails, CARTACTION, CARTITEM, CMUICONFIGKEY, productItem, productItemSelected, STATUS } from 'dxp-common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
@Injectable({
    providedIn: 'root'
})
export class CartService {

    public cartDetails: cartDetails;
    quantityMap: any = {};
    public localCartEvent: EventEmitter<any> = new EventEmitter<any>();

    constructor(private http: HttpClient,
        private persistenceService: PersistenceService
    ) { }

    public resetServiceData() {
        this.cartDetails = null;
        this.quantityMap = {};
    }

    public createQuantityMap() {
        if (this.cartDetails.cartList.length > 0) {
            this.cartDetails.cartList.forEach(product => {
                this.quantityMap[product.productOffering.name] = product.quantity;
            });
        }
        this.localCartEvent.emit();
        // this.event.notifylocalCart();
        // this.slides = this.slides.slice();
    }

    public getQuantity(name) {
        return this.quantityMap[name];
    }




    public createCart(cartItems: productItem[], cartDetails: cartDetails): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.createCart.indexOf(".json") !== -1) {
            url = environment.urls.createCart;
            httpResponse = this.http.get(url);
        } else {
            url = environment.urls.createCart;
            cartDetails.cartItem.push(...cartItems);
            httpResponse = this.http.post(url, cartDetails);
        }
        return httpResponse.pipe(map((response: any) => {
            let mappedData: any = response;
            if (mappedData && mappedData.id && (!this.cartDetails || !this.cartDetails.id)) {
                this.cartDetails = {
                    id: mappedData.id,
                    createdBy: null,
                    createdByChannel: null,
                    updatedBy: null,
                    lastUpdatedByChannel: null,
                    cartItem: null,
                    cartList: null,
                    totalPrice: null,
                };
            }
            return mappedData;
        }
        ));
    }

    public updateCart(cartItems: productItem[], noPreactivatedPlan: boolean = true): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        let cartUpdate = { cartItem: [] }
        if (environment.urls.createCart.indexOf(".json") !== -1) {
            url = environment.urls.createCart;
            httpResponse = this.http.get(url);
        } else {
            url = `${environment.urls.createCart}/${this.cartDetails.id}`;
            cartUpdate.cartItem = cartItems;
            let existingSwappedCartItems: productItem[] = [];

            if (this.cartDetails && this.cartDetails.cartList && !noPreactivatedPlan) {
                // mark for existing offer as delete
                existingSwappedCartItems = this.cartDetails.cartList.filter(x => x.productOffering.offerType !== CARTITEM.ADDON && x.action === CARTACTION.SWAP);
                if (existingSwappedCartItems && existingSwappedCartItems instanceof Array) {
                    existingSwappedCartItems = existingSwappedCartItems.map(item => {
                        delete item.productOffering.status;
                        item.action = CARTACTION.DELETE;
                        return item;
                    });
                }
                cartUpdate.cartItem.concat(existingSwappedCartItems)
            }

            httpResponse = this.http.post(url, { cartItem: [...cartItems, ...existingSwappedCartItems] });
        }
        return httpResponse.pipe(map((response: any) => {
            let mappedData: any = response;
            return mappedData;
        }
        ));
    }

    public deleteFromCart(carItems: productItem[]): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        let cartUpdate = { cartItem: [] }
        if (environment.urls.createCart.indexOf(".json") !== -1) {
            url = environment.urls.createCart;
            httpResponse = this.http.get(url);
        }
        else {
            url = `${environment.urls.createCart}/${this.cartDetails.id}`;
            const cartItemsWithActionDelete = carItems.map(x => {
                delete x.productOffering.status;
                x.action = CARTACTION.DELETE;
                return x;
            });
            cartUpdate.cartItem = cartItemsWithActionDelete;
            httpResponse = this.http.post(url, cartUpdate);
        }
        return httpResponse.pipe(map((response: any) => {
            let mappedData: any = response;
            return mappedData;
        }
        ));
    }

    clearCart(): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        let cartUpdate = { cartItem: [] }
        if (environment.urls.createCart.indexOf(".json") !== -1) {
            url = environment.urls.createCart;
            httpResponse = this.http.get(url);
        }
        else {
            url = `${environment.urls.createCart}/${this.cartDetails.id}`;
            httpResponse = this.http.post(url, cartUpdate);
        }
        return httpResponse.pipe(map((response: any) => {
            let mappedData: any = response;
            return mappedData;
        }
        ));
    }

    clearCartData(): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        let cartUpdate = { cartItem: [] }
        if (environment.urls.createCart.indexOf(".json") !== -1) {
            url = environment.urls.createCart;
            httpResponse = this.http.get(url);
        }
        else {
            url = `${environment.urls.createCart}/${this.cartDetails.id}`;
            this.cartDetails.cartItem.forEach(cartItem => {
                if (cartItem.type !== 'ContractItem') {
                    cartItem.action = CARTACTION.DELETE;
                    delete cartItem.productOffering.status;//API throws error when sttaus is invalid
                    delete cartItem.productValid;
                    cartUpdate.cartItem.push(cartItem);
                }
            });
            httpResponse = this.http.post(url, cartUpdate);
        }
        return httpResponse.pipe(map((response: any) => {
            let mappedData: any = response;
            return mappedData;
        }
        ));
    }

    updateQuantityOnTheCart(carItem: productItem): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        let cartUpdate = { cartItem: [] }
        if (environment.urls.createCart.indexOf(".json") !== -1) {
            url = environment.urls.createCart;
            httpResponse = this.http.get(url);
        }
        else {
            url = `${environment.urls.createCart}/${this.cartDetails.id}`;
            cartUpdate.cartItem.push(carItem);
            httpResponse = this.http.post(url, cartUpdate);
        }
        return httpResponse.pipe(map((response: any) => {
            let mappedData: any = response;
            return mappedData;
        }
        ));
    }

    private setAndRetreiveCartDetails(response: any): cartDetails {
        this.cartDetails = { ...response };
        if (this.cartDetails && this.cartDetails.cartItem) {
            this.cartDetails.cartList = this.cartDetails.cartItem.filter(x => x.type === CARTITEM.PRODUCTITEM);
        }
        else {
            //empty cart after clear
            this.cartDetails.cartList = [];
            this.cartDetails.totalPrice = [];
        }

        return this.cartDetails;
    }

    public getCartDetails(cartId: string = null): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.createCart.indexOf(".json") !== -1) {
            url = environment.urls.createCart;
            httpResponse = this.http.get(url);
        }
        else {
            cartId = cartId || this.cartDetails.id;
            url = environment.urls.createCart + '/' + cartId;
            httpResponse = this.http.get(url)
        }
        return httpResponse.pipe(map((response: any) => {
            return this.setAndRetreiveCartDetails(response);
        }
        ));
    }

    public getTotalPrice(type: string) {
        let totalPrice = 0;
        if (this.cartDetails && this.cartDetails.totalPrice && this.cartDetails.totalPrice.length > 0) {
            const priceObj = this.cartDetails.totalPrice.filter(x => x.priceType === type);
            if (priceObj && priceObj[0]) {
                totalPrice = priceObj[0].price.amount;
            }
        }
        const totalPriceDisplay = !totalPrice ?
            0 :
            totalPrice
        return totalPriceDisplay;
    }

    public replaceBaseOfferFromCart(cartItems: productItem[]): Observable<any> {
        let url = '';
        let localDomain = '';
        let httpResponse: Observable<any>;
        if (!environment.production) {
            localDomain = environment.localCMSDomain;
        }
        if (environment.urls.createCart.indexOf(".json") !== -1) {
            url = environment.urls.createCart;
            httpResponse = this.http.get(url);
        } else {
            url = `${environment.urls.createCart}/${this.cartDetails.id}`;
            let existingCartBasePlanItem: productItem[] = [];
            // mark for new item action as add
            cartItems.forEach(item => item.action = CARTACTION.ADD);

            if (this.cartDetails && this.cartDetails.cartList) {
                // mark for existing offer as delete
                existingCartBasePlanItem = this.cartDetails.cartList.filter(x => x.productOffering.offerType !== CARTITEM.ADDON);
                if (existingCartBasePlanItem && existingCartBasePlanItem instanceof Array) {
                    existingCartBasePlanItem = existingCartBasePlanItem.map(item => {
                        delete item.productOffering.status;
                        item.action = CARTACTION.DELETE;
                        return item;
                    });
                }
            }
            httpResponse = this.http.post(url, { cartItem: [...cartItems, ...existingCartBasePlanItem] });
        }
        return httpResponse.pipe(map((response: any) => {
            let mappedData: any = response;
            return mappedData;
        }
        ));
    }

    public getSelectedPlanFromCart(): productItemSelected[] {
        let planProducts;
        if (this.cartDetails) {
            planProducts = this.cartDetails.cartList.filter(x => x.productOffering.offerType != CARTITEM.ADDON);
        }

        let planProductsSelected;
        if (planProducts) {
            planProductsSelected = planProducts.map(x => {
                return {
                    productOffering: x.productOffering,
                    //itemPrice: x.itemPrice
                }
            })
        }
        return planProductsSelected;
    }

    public getSelectedAddOnFromCart(): productItemSelected[] {
        let planProducts;
        if (this.cartDetails) {
            planProducts = this.cartDetails.cartList.filter(x => x.productOffering.offerType == CARTITEM.ADDON);
        }

        // const planProducts = this.cartDetails.cartList.filter(x => x.productOffering.offerType == CARTITEM.ADDON);
        let planProductsSelected;
        if (planProducts) {
            planProductsSelected = planProducts.map(x => {
                return {
                    productOffering: x.productOffering,
                    //quantity: x.quantity
                }
            })
        }
        return planProductsSelected;
    }

    validateCart(productCategory: string[] = ['all'], location: string = '', customerSegment: string = ''): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.createCart.indexOf(".json") !== -1) {
            url = environment.urls.createCart;
            httpResponse = this.http.get(url);
        }
        else {
            const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
            const offerType = this.persistenceService.get(CMUICONFIGKEY.PRODUCTCATEGORY_FORPRODUCTSEARCHQUERY, StorageType.SESSION).map(x => { return x.name });
            const cartUpdate = {
                "offerType": offerType,
                "productCategory": productCategory,
                "salesChannel": channelName,
                "location": location,
                "customerSegment": customerSegment
            };
            url = `${environment.urls.createCart}/${this.cartDetails.id}` + '/validate';
            httpResponse = this.http.post(url, cartUpdate);
        }
        return httpResponse.pipe(map((response: any) => {
            return this.setAndRetreiveCartDetails(response);
        }
        ));
    }

    async isInvalidPlanOrAddonAvailableInCart(productCategory: string[] = ['all'], location: string = '', customerSegment: string = ''): Promise<boolean> {
        let isInvalid = false;
        if (this.cartDetails && this.cartDetails.id) {
            const cartDetails: cartDetails = await this.validateCart(productCategory, location, customerSegment).toPromise();
            if (cartDetails) {
                cartDetails.cartList.forEach((item) => {
                    if (item.productOffering.status
                        && item.productOffering.status.toLowerCase() === STATUS.INVALID) {
                        isInvalid = true;
                    }
                });
            }
        }
        return Promise.resolve(isInvalid);
    }

    async isInvalidPlanAvailableInCart(productCategory: string[] = ['all'], location: string = '', customerSegment: string = ''): Promise<boolean> {
        let isInvalid = false;
        if (this.cartDetails && this.cartDetails.id) {
            const cartDetails: cartDetails = await this.validateCart(productCategory, location, customerSegment).toPromise();
            if (cartDetails) {
                if (this.isInvalidPlanInCartList(cartDetails)) {
                    isInvalid = true;
                }
            }
        }
        return Promise.resolve(isInvalid);
    }

    async isInvalidAddonAvailableInCart(productCategory: string[] = ['all'], location: string = '', customerSegment: string = ''): Promise<boolean> {
        let isInvalid = false;
        if (this.cartDetails && this.cartDetails.id) {
            const cartDetails: cartDetails = await this.validateCart(productCategory, location, customerSegment).toPromise();
            if (cartDetails) {
                if (this.isInvalidAddOnInCartList(cartDetails)) {
                    isInvalid = this.isInvalidAddOnInCartList(cartDetails).length > 0;
                }
            }
        }
        return Promise.resolve(isInvalid);
    }

    public isInvalidAddOnInCartList(cartDetails: cartDetails): productItem[] {
        const invalidProducts = cartDetails.cartList.filter(item => {
            return item.productOffering.offerType.toLowerCase() === CARTITEM.ADDON.toLowerCase()
                && item.productOffering.status
                && item.productOffering.status.toLowerCase() === STATUS.INVALID
        });
        if (invalidProducts.length > 0) {
            return invalidProducts;
        }
        return null;
    }

    public isInvalidPlanInCartList(cartDetails: cartDetails): productItem {
        const invalidProducts = cartDetails.cartList.filter(item => {
            return item.productOffering.offerType.toLowerCase() !== CARTITEM.ADDON.toLowerCase()
                && item.productOffering.status
                && item.productOffering.status.toLowerCase() === STATUS.INVALID
        });
        if (invalidProducts.length > 0) {
            return invalidProducts[0];
        }
        return null;
    }

    public isInvalidPreActivatedPlanInCartList(cartDetails: cartDetails): productItem {
        const invalidProducts = cartDetails.cartList.filter(item => {
            return item.productOffering.offerType.toLowerCase() !== CARTITEM.ADDON.toLowerCase()
                && item.action.toLowerCase() === CARTACTION.ACTIVE.toLowerCase()
                && item.productOffering.status
                && item.productOffering.status.toLowerCase() === STATUS.INVALID
        });
        if (invalidProducts.length > 0) {
            return invalidProducts[0];
        }
        return null;

    }

    public isInvalidSwapPlanInCartList(cartDetails: cartDetails): productItem {

        const invalidProducts = cartDetails.cartList.filter(item => {
            return item.productOffering.offerType.toLowerCase() !== CARTITEM.ADDON.toLowerCase()
                && item.action.toLowerCase() === CARTACTION.SWAP.toLowerCase()
                && item.productOffering.status
                && item.productOffering.status.toLowerCase() === STATUS.INVALID
        });
        if (invalidProducts.length > 0) {
            return invalidProducts[0];
        }
        return null;
    }

    public isValidSwapPlanInCartList(cartDetails: cartDetails): productItem {

        const validProducts = cartDetails.cartList.filter(item => {
            return item.productOffering.offerType.toLowerCase() !== CARTITEM.ADDON.toLowerCase()
                && item.action.toLowerCase() === CARTACTION.SWAP.toLowerCase()
                && !item.productOffering.status
        });
        if (validProducts.length > 0) {
            return validProducts[0];
        }
        return null;
    }

    getAddonJourneySessionData(customerId, journeyId) {
        let httpResponse: Observable<any>;
        const url = environment.urls.getAddonJourneySession.replace('{customerId}', customerId).replace('{journeyId}', journeyId);
        httpResponse = this.http.get(url);
        return httpResponse;
    }

}
