import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY, PaymentRequestInfo } from 'dxp-common';
import { Observable } from 'rxjs';
import { DataClientService } from '../data-client.service';
import { EventListenerService } from '../event-listener.service';
import { SubscriptionProduct } from '../interface/subscription';
import { environment } from './../../environments/environment';
import { PaymentGatewayService } from './../services/payment-gateway.service';
import { RechargeTransferService } from './recharge-transfer.service';
import Product = SubscriptionProduct.Product;

declare const alertify;

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  quickRechargeFormDetails: any;
  formResponseDetails: any;
  defaultCurrency: String = '';
  transferBucketItemDetails: any;
  constructor(private dataClientService: DataClientService,
    private http: HttpClient,
    private paymentService: PaymentGatewayService,
    private translateService: TranslateService,
    private rechargeTransferService: RechargeTransferService,
    private router: Router,
    private persistenceService: PersistenceService,
    private eventListenerService: EventListenerService) {
  }

  registerUser(param) {
    return this.dataClientService.post(param, 'customer', ['register'], null, 'text');
  }

  getCustomerInfo(msisdn) {
    return this.dataClientService.get('customer', [msisdn]);
  }

  getAggregatedSubscription(msisdn) {
    return this.dataClientService.get('customer', ['subscription', 'balance'], {
      msisdn: msisdn,
      subscriberCategory: 'PREPAID'
    });
  }

  getSubscriptionDetail(msisdn) {
    return this.dataClientService.get('customer', ['subscription', 'details'], { msisdn: msisdn });
  }

  removeSharedAccount(mysmsisdn, msisdn) {
    return this.dataClientService.delete('customerGroup', [mysmsisdn, 'sharedAccount', msisdn]);
  }

  removeMsisdnFromInventory(msisdn) {
    return this.dataClientService.delete('inventory', [msisdn]);
  }

  async recharge(msisdn: string, quota: number = 0, type: string = 'credit'): Promise<any> {
    if (quota === 0) {
      throw new Error('Please enter amount');
    }
    return await this.dataClientService.post(null, 'customer', [msisdn, 'balance', type.toString(), quota.toString(10)], null).toPromise();
  }


  async buyPlan(msisdn, productId): Promise<any> {
    const params = {
      msisdn: msisdn,
      productId: productId,
      buyOption: 'RACT'
    };
    return await
      this.dataClientService.post(params, 'customer', ['subscription', 'product'], {}).toPromise();
  }

  async removePlan(msisdn, productId) {
    const params = {
      msisdn: msisdn,
      productId: productId,
      buyOption: 'DACT'
    };
    return await
      this.dataClientService.post(params, 'customer', ['subscription', 'product'], {}).toPromise();
  }

  async getRechargeHistory(msisdn: string, type: string = 'credit') {
    return await this.dataClientService.get('customer', [msisdn, 'balance', type], null).toPromise();
  }

  async getTransferHistory(msisdn) {
    return await this.dataClientService.get('customer', ['subscription', 'transferHistory'], { msisdn: msisdn }).toPromise();
  }


  async subscriptionDetail(msisdn): Promise<{ msisdn: string, products: Product[] }> {
    return await this.dataClientService.get('customer', ['subscription', 'details'], { msisdn: msisdn }).toPromise();
  }

  private buyProduct(params) {
    return this.dataClientService.post(params, 'customer', ['subscription', 'product'], {});
  }

  shareQuota(params) {
    return this.buyProduct(params);
  }

  transferCreditBalance(param) {
    return this.buyProduct(param);
  }

  addAddon(param) {
    return this.buyProduct(param);
  }

  removeAddon(param) {
    return this.buyProduct(param);
  }

  transferItem(param) {
    return this.buyProduct(param);
  }

  addQuota(param) {
    return this.buyProduct(param);
  }
  setupsisdn(param) {
    return this.buyProduct(param);
  }

  customerSearchProfile(formDetails: any): Observable<any> {
    let url = '';
    let httpResponse: Observable<any>;
    const phoneNumber = formDetails.phoneNumber;

    const requestPayload = {
      'name': 'msisdn',
      'value': phoneNumber,
      'operator': '=='
    };
    url = environment.urls.customerProfileSearch;
    httpResponse = this.http.post(url, requestPayload);
    return httpResponse;
  }

  validateMSISDN(formDetails: any): Observable<any> {
    let url = '';
    let httpResponse: Observable<any>;
    const phoneNumber = formDetails.phoneNumber;

    const requestPayload = {
      'name': 'msisdn',
      'value': phoneNumber,
      'operator': '=='
    };
    url = environment.urls.validateMSISDN;
    httpResponse = this.http.post(url, requestPayload);
    return httpResponse;
  }

  setQuickRechargeFormDetails(formDetails, formResponseDetails) {
    this.quickRechargeFormDetails = formDetails;
    this.formResponseDetails = formResponseDetails;
  }

  getQuickRechargeFormDetails() {
    return this.quickRechargeFormDetails;
  }

  getQuickRechargeFormResponseDetails() {
    return this.formResponseDetails;
  }


  async paymentSuccessHandler(BOLT, paymentRequest: PaymentRequestInfo, partyId: string, customerId: string, requestPayload, eventEnumber) {
    if (BOLT.response && BOLT.response.txnStatus === 'SUCCESS'
      && BOLT.response.txnid) {
      const paymentTransactionRequest = {
        resourceNumber: this.paymentService.paymentConfigSelected.resourceNumber, // MSISDN from customer journey
        payer: BOLT.response.payer || 'NA', // NA in old code
        merchantRefNum: this.paymentService.paymentConfigSelected.merchantRefNum, // merchantRefNum from create payment service
        paymentGwTransactionId: BOLT.response.txnid || BOLT.response.payuMoneyId || paymentRequest.txnid,
        status: BOLT.response.status,
        paymentToken: BOLT.response.paymentId || '', // empty in old code
        paymentMethod: BOLT.response.mode,
        expiryDate: BOLT.response.addedon || '', // empty in old code
        cardNumber: BOLT.response.cardnum || '', //cardnum from payumoney
        amount: BOLT.response.amount
      };
      if (this.paymentService.msisdn === paymentTransactionRequest.resourceNumber && this.paymentService.allowPayment) {
        this.paymentService.allowPayment = false;
        const paymentInfo = await this.paymentService.updatePayment(paymentTransactionRequest).toPromise();
        if (paymentInfo && paymentInfo.message && paymentInfo.message === 'SUCCESS') {
          // const customerInteractionResponse = await this.createCustomerInteraction(partyId, customerId, paymentRequest.phone, paymentRequest.amount).toPromise();
          const customerInteractionResponse = await this.customerInteractionForRecharge(requestPayload).toPromise();
          if (customerInteractionResponse) {
            this.redirectToSucessView(customerInteractionResponse, eventEnumber);
          }
        } else {
          alertify.error(this.translateService.instant('Payment Failed'));
        }
      }
    } else {
      alertify.error(this.translateService.instant('Payment has been cancelled'));
    }
  }

  public redirectToSucessView(customerInteractionResponse, eventEnumber) {
    this.paymentService.orderId = customerInteractionResponse.id;
    this.eventListenerService.showPaymentSuccessMessage(customerInteractionResponse, eventEnumber);
  }

  paymentFailureHandler(BOLT) {
    alertify.error(this.translateService.instant(BOLT.message));
  }

  private createCustomerInteraction(partyId, customerId, phoneNumber, amount) {
    let url = '';
    let httpResponse;
    this.defaultCurrency = this.persistenceService.get(CMUICONFIGKEY.DEFAULTYCURRENCY, StorageType.SESSION);
    const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
    const requestPayload = {
      'userId': '',
      'partyId': partyId,
      'customerId': customerId,
      'journeyId': 'AccountRefill_ForOthers_Anon',
      'type': 'ServiceOrder',
      'status': 'InProgress',
      'channelName': channelName,
      'customerServiceOrder': {
        'state': 'InProgress'
      },
      'journeyData': {},
      'coreData': {
        'refillAmount': amount,
        'currency': this.defaultCurrency,
        'beneficiaryMsisdn': phoneNumber,
        'summaryTextLabel': 'AccountRefillAnonSummary'
      }
    };
    url = environment.urls.customerInteraction;
    httpResponse = this.http.post(url, requestPayload);
    return httpResponse;
  }

  setTransferBucketItemDetails(itemDetails) {
    this.transferBucketItemDetails = itemDetails;
  }

  getTransferBucketItemDetails() {
    return this.transferBucketItemDetails;
  }

  customerInteractionForRecharge(requestPayload) {
    let url = '';
    let httpResponse;
    url = environment.urls.customerInteraction;
    httpResponse = this.http.post(url, requestPayload);
    return httpResponse;
  }

}
