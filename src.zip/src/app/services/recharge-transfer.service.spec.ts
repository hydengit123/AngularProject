import { TestBed } from '@angular/core/testing';

import { RechargeTransferService } from './recharge-transfer.service';

describe('RechargeTransferService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RechargeTransferService = TestBed.get(RechargeTransferService);
    expect(service).toBeTruthy();
  });
});
