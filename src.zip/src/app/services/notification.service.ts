import { DatePipe } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PERSISTANCEKEY } from "../../application-constants";
import { environment } from '../../environments/environment';
import { DataClientService } from '../data-client.service';
import { Notification } from '../shared/model//notification';



@Injectable()
export class NotificationService implements OnInit {

    httpOptions: any = null;
    private datepipeInstance:DatePipe = new DatePipe('en-US');

    constructor(
        private http: HttpClient,
        private persistenceService: PersistenceService,
        private dataClientService: DataClientService) {

    }
    ngOnInit() {
    }

    getNotification(data): Observable<any> {
        let url = '';
        let requestPayload = {};
        let httpResponse: Observable<any>;

        let access_token = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
        let customer_id = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);

        // this.httpOptions = {
        //     headers: new HttpHeaders({
        //         'Authorization': 'Bearer '+access_token
        //     })
        // };
        //63bce2b6-d675-4144-8648-dff12c8f2419
        let cusotmParam = (data.channel === 'ALL')?'':('&channel='+data.channel)
        return this.http.get(`${environment.urls.customerInteraction}?customerId=${customer_id}${cusotmParam}&from=${data.fromDate}&to=${data.toDate}&type=NotificationHistory`).pipe(
            map((response:any) => {
                return response.map((item) => {
                    let mappedData:Notification = {
                        lastModifiedDate: this.datepipeInstance.transform(item.lastModifiedDate, 'yyyy-MM-dd', 'es-ES') || "",
                        time:this.datepipeInstance.transform(item.lastModifiedDate, 'hh:mm:ss')  || "",
                        deliveredMessage: item.journeyData.notification ? item.journeyData.notification.deliveredMessage:''

                    }
                    return mappedData;
                });
            })
        )
        //return this.http.get(`${environment.urls.customerInteraction}?customerId=${customer_id}&channel=${data.channel}&from=${data.toDate}&to=${data.fromDate}&type=NotificationHistory`,this.httpOptions);
    }
}
