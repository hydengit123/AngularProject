import { HttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';
import { DataClientService } from '../data-client.service';
import { ProductService } from './product.service';
import * as _ from 'underscore';

xdescribe('ProductService', () => {
    let dataClientServiceSpy: jasmine.SpyObj<DataClientService>;
    let httpClientSpy: jasmine.SpyObj<HttpClient>;
    let productService: ProductService;
    beforeEach(() => {
        const DataClientServiceSpy = jasmine.createSpyObj('DataClientService', ['get']);
        const HttpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);

        TestBed.configureTestingModule({
            providers: [
                ProductService,
                { provide: HttpClient, useValue: HttpClientSpy },
                { provide: DataClientService, useValue: DataClientServiceSpy }
            ]
        });
    });

    beforeEach(() => {
        dataClientServiceSpy = TestBed.get(DataClientService);
        httpClientSpy = TestBed.get(HttpClient);
        productService = TestBed.get(ProductService);
    });

    it('should be created', () => {
        expect(ProductService).toBeTruthy();
    });

    xdescribe('getCustomOffer method should', () => {
        it('return plan object', () => {
            const offersData = [{
                productId: 'CM_Combo_571', productName: 'National data 10gb 1000mins 1000sms', productType: 'data', productGroup: 'Addon', productDescription: 'Description CM_Combo_574', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 1, unitType: '' },
                    voice: { unit: 1, unitType: '' },
                    sms: { unit: 1, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_572', productName: 'International data 20gb 2000mins 2000sms', productType: 'voice', productGroup: 'Addon', productDescription: 'Description CM_Combo_575', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 2, unitType: '' },
                    voice: { unit: 2, unitType: '' },
                    sms: { unit: 2, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_573', productName: 'Circle data 30gb 3000mins 3000sms', productType: 'sms', productGroup: 'Addon', productDescription: 'Description CM_Combo_576', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 3, unitType: '' },
                    voice: { unit: 3, unitType: '' },
                    sms: { unit: 3, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_574', productName: 'State data 14gb 4000mins 4000sms', productType: 'data', productGroup: 'Addon', productDescription: 'Description CM_Combo_574', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 4, unitType: '' },
                    voice: { unit: 4, unitType: '' },
                    sms: { unit: 4, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_575', productName: 'City data 50gb 5000mins 5000sms', productType: 'voice', productGroup: 'Addon', productDescription: 'Description CM_Combo_576', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 5, unitType: '' },
                    voice: { unit: 5, unitType: '' },
                    sms: { unit: 5, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            }];
            spyOn(_, 'sortBy');
            dataClientServiceSpy.get.and.returnValue(Observable.of(offersData));

            productService.getCustomOffer().then((res) => {
                expect(res.dataPlans.length).toBe(2);
                expect(res.smsPlans.length).toBe(1);
                expect(res.voicePlans.length).toBe(2);
                expect(dataClientServiceSpy.get).toHaveBeenCalledWith('product', ['findByQuery'], {
                    productType: 'DATA,VOICE,SMS',
                    productStatus: 'ACTIVE',
                    isRecurring: 'BOTH',
                    productGroup: 'CustomizePlanOffer',
                });
                expect(_.sortBy).toHaveBeenCalledTimes(6);
            });
        });

        it('return plan object with name as "unlimited" for negative quantities', () => {
            const offersData = [{
                productId: 'CM_Combo_571', productName: 'National data 10gb 1000mins 1000sms', productType: 'data', productGroup: 'Addon', productDescription: 'Description CM_Combo_574', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: -1, unitType: '' },
                    voice: { unit: -1, unitType: '' },
                    sms: { unit: -1, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_572', productName: 'International data 20gb 2000mins 2000sms', productType: 'voice', productGroup: 'Addon', productDescription: 'Description CM_Combo_575', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: -2, unitType: '' },
                    voice: { unit: -2, unitType: '' },
                    sms: { unit: -2, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_573', productName: 'Circle data 30gb 3000mins 3000sms', productType: 'sms', productGroup: 'Addon', productDescription: 'Description CM_Combo_576', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: -3, unitType: '' },
                    voice: { unit: -3, unitType: '' },
                    sms: { unit: -3, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_574', productName: 'State data 14gb 4000mins 4000sms', productType: 'data', productGroup: 'Addon', productDescription: 'Description CM_Combo_574', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: -4, unitType: '' },
                    voice: { unit: -4, unitType: '' },
                    sms: { unit: -4, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_575', productName: 'City data 50gb 5000mins 5000sms', productType: 'voice', productGroup: 'Addon', productDescription: 'Description CM_Combo_576', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: -5, unitType: '' },
                    voice: { unit: -5, unitType: '' },
                    sms: { unit: -5, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            }];

            dataClientServiceSpy.get.and.returnValue(Observable.of(offersData));

            productService.getCustomOffer().then((res) => {
                expect(res.dataPlans.length).toBe(2);
                expect(res.dataPlans[0].name).toBe('unlimited');
                expect(res.smsPlans.length).toBe(1);
                expect(res.smsPlans[0].name).toBe('unlimited');
                expect(res.voicePlans.length).toBe(2);
                expect(res.voicePlans[0].name).toBe('unlimited');
                expect(dataClientServiceSpy.get).toHaveBeenCalledWith('product', ['findByQuery'], {
                    productType: 'DATA,VOICE,SMS',
                    productStatus: 'ACTIVE',
                    isRecurring: 'BOTH',
                    productGroup: 'CustomizePlanOffer',
                })
            });
        });
    });

    xdescribe('getPlanByType method should', () => {
        it('return standard plan', () => {
            const offersData = [{
                productId: 'CM_Combo_571', productName: 'National data 10gb 1000mins 1000sms', productType: 'data', productGroup: 'Addon', productDescription: 'Description CM_Combo_574', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 1, unitType: '' },
                    voice: { unit: 1, unitType: '' },
                    sms: { unit: 1, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_572', productName: 'International data 20gb 2000mins 2000sms', productType: 'voice', productGroup: 'Addon', productDescription: 'Description CM_Combo_575', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 2, unitType: '' },
                    voice: { unit: 2, unitType: '' },
                    sms: { unit: 2, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_573', productName: 'Circle data 30gb 3000mins 3000sms', productType: 'sms', productGroup: 'Addon', productDescription: 'Description CM_Combo_576', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 3, unitType: '' },
                    voice: { unit: 3, unitType: '' },
                    sms: { unit: 3, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_574', productName: 'State data 14gb 4000mins 4000sms', productType: 'data', productGroup: 'Addon', productDescription: 'Description CM_Combo_574', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 4, unitType: '' },
                    voice: { unit: 4, unitType: '' },
                    sms: { unit: 4, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_575', productName: 'City data 50gb 5000mins 5000sms', productType: 'voice', productGroup: 'Addon', productDescription: 'Description CM_Combo_576', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 5, unitType: '' },
                    voice: { unit: 5, unitType: '' },
                    sms: { unit: 5, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            }];
            const type = 'standard';
            dataClientServiceSpy.get.and.returnValue(Observable.of(offersData));

            productService.getPlanByType(type).then((res) => {
                expect(res.productId).toBe("CM_Combo_571");
                expect(dataClientServiceSpy.get).toHaveBeenCalledWith('product', ['findByQuery'], {
                    productType: 'DATA,VOICE,SMS,COMBO',
                    productStatus: 'ACTIVE',
                    isRecurring: 'BOTH',
                    productGroup: type,
                })
            });
        });

        it('return premium plan', () => {
            const offersData = [{
                productId: 'CM_Combo_571', productName: 'National data 10gb 1000mins 1000sms', productType: 'data', productGroup: 'Addon', productDescription: 'Description CM_Combo_574', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 1, unitType: '' },
                    voice: { unit: 1, unitType: '' },
                    sms: { unit: 1, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_572', productName: 'International data 20gb 2000mins 2000sms', productType: 'voice', productGroup: 'Addon', productDescription: 'Description CM_Combo_575', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 2, unitType: '' },
                    voice: { unit: 2, unitType: '' },
                    sms: { unit: 2, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_573', productName: 'Circle data 30gb 3000mins 3000sms', productType: 'sms', productGroup: 'Addon', productDescription: 'Description CM_Combo_576', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 3, unitType: '' },
                    voice: { unit: 3, unitType: '' },
                    sms: { unit: 3, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_574', productName: 'State data 14gb 4000mins 4000sms', productType: 'data', productGroup: 'Addon', productDescription: 'Description CM_Combo_574', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 4, unitType: '' },
                    voice: { unit: 4, unitType: '' },
                    sms: { unit: 4, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            },
            {
                productId: 'CM_Combo_575', productName: 'City data 50gb 5000mins 5000sms', productType: 'voice', productGroup: 'Addon', productDescription: 'Description CM_Combo_576', productValidityDays: 5, productStatus: 'Active', quota: {
                    data: { unit: 5, unitType: '' },
                    voice: { unit: 5, unitType: '' },
                    sms: { unit: 5, unitType: '' }
                }, price: 100, issharedaccount: true, isSplit: true, isRecurring: true, BuyForOther: true, isSelected: true
            }];
            const type = 'premium';
            dataClientServiceSpy.get.and.returnValue(Observable.of(offersData));

            productService.getPlanByType(type).then((res) => {
                //console.log(res);
                expect(res.productId).toBe("CM_Combo_571");
                expect(dataClientServiceSpy.get).toHaveBeenCalledWith('product', ['findByQuery'], {
                    productType: 'DATA,VOICE,SMS,COMBO',
                    productStatus: 'ACTIVE',
                    isRecurring: 'BOTH',
                    productGroup: type,
                })
            });
        });
    });

    it('getInventory method should return inventory', () => {
        const inventory = ['item_a', 'item_b', 'item_c', 'item_d'];
        dataClientServiceSpy.get.and.returnValue(Observable.of(inventory));

        productService.getInventory().then((res) => {
            expect(res.length).toBe(4);
            expect(res[2]).toBe(inventory[2]);
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('inventory', null, null, null)
        });
    });

    it('getUpcomingOffers method should return upcomingOffers', () => {
        const upcomingOffers = ['item_a', 'item_b', 'item_c', 'item_d'];
        dataClientServiceSpy.get.and.returnValue(Observable.of(upcomingOffers));

        productService.getUpcomingOffers().then((res) => {
            expect(res.length).toBe(4);
            expect(upcomingOffers[2]).toBe(upcomingOffers[2]);
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('product', ['findByQuery'], {
                productType: 'COMBO,DATA,VOICE,SMS',
                productStatus: 'ACTIVE',
                isRecurring: 'BOTH',
                productGroup: 'UpcomingOffer'
            });
        });
    });

    it('getAddons method should return adddons', () => {
        const addons = ['item_a', 'item_b', 'item_c', 'item_d'];
        dataClientServiceSpy.get.and.returnValue(Observable.of(addons));

        productService.getAddons().subscribe((res) => {
            expect(res.length).toBe(4);
            expect(addons[2]).toBe(addons[2]);
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('product', ['findByQuery'], {
                productType: 'DATA,VOICE,SMS,COMBO',
                productStatus: 'ACTIVE',
                isRecurring: 'BOTH',
                productGroup: 'Addon'
            });
        });
    });

    it('getRechargeOptions method should return rechargeOptions', () => {
        const options = ['item_a', 'item_b', 'item_c', 'item_d'];
        dataClientServiceSpy.get.and.returnValue(Observable.of(options));
        const type = 'sms'
        productService.getRechargeOptions(type).subscribe((res) => {
            expect(res.length).toBe(4);
            expect(options[2]).toBe(options[2]);
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('product', ['findByQuery'], {
                productType: type,
                productStatus: 'ACTIVE',
                isRecurring: 'BOTH',
                productGroup: 'Recharge',
            });
        });
    });

    it('getAllProducts method should return allProducts', () => {
        const products = ['item_a', 'item_b', 'item_c', 'item_d'];
        dataClientServiceSpy.get.and.returnValue(Observable.of(products));

        productService.getAllProducts().subscribe((res) => {
            expect(res.length).toBe(4);
            expect(products[2]).toBe(products[2]);
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('product', ['findByQuery'], {
                productType: 'DATA,VOICE,SMS,COMBO',
                productStatus: 'ACTIVE',
                isRecurring: 'BOTH',
                productGroup: 'ALL'
            })
        });
    });

    it('getProductByPlanId method should return ProductByPlanId', () => {
        const products = ['item_a', 'item_b', 'item_c', 'item_d'];
        dataClientServiceSpy.get.and.returnValue(Observable.of(products[1]));
        const id = 'testID'
        productService.getProductByPlanId(id).subscribe((res) => {
            expect(res).toBe(products[1]);
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('product', [id]);

        });
    });

    it('getInsightURL method should return URL', () => {
        const url = 'home/new_path'
        dataClientServiceSpy.get.and.returnValue(Observable.of(url));
        productService.getInsightURL().subscribe((res) => {
            expect(res).toBe(url);
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('external/insight/url', null, null, null);
        });
    });

    it('getPersonalisedOffers method should return offer', () => {
        const products = ['item_a', 'item_b', 'item_c', 'item_d'];
        httpClientSpy.get.and.returnValue(Observable.of(products[1]));
        const url = 'home/test_path'
        productService.getPersonalisedOffers(url).subscribe((res) => {
            expect(res).toBe(products[1]);
            expect(httpClientSpy.get).toHaveBeenCalledWith(url);
        });
    });

});