import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { PersistenceService } from 'angular-persistence';
import { Observable } from 'rxjs';
import { DataClientService } from '../data-client.service';
import { AuthService } from './auth.service';

describe('AuthService', () => {

    let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
    let dataClientServiceSpy: jasmine.SpyObj<DataClientService>;
    let authService: AuthService;
    beforeEach(() => {
        const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set']);
        const DataClientServiceSpy = jasmine.createSpyObj('DataClientService', ['get', 'post', 'put']);

        TestBed.configureTestingModule({
            providers: [
                AuthService,
                { provide: PersistenceService, useValue: PersistenceServiceSpy },
                { provide: DataClientService, useValue: DataClientServiceSpy }
            ],
            imports: [RouterTestingModule]
        });
    });
    beforeEach(() => {
        dataClientServiceSpy = TestBed.get(DataClientService);
        persistenceServiceSpy = TestBed.get(PersistenceService);
        authService = TestBed.get(AuthService)
    });
    it('should be created', () => {
        expect(AuthService).toBeTruthy();
    });

    describe('login', () => {
        it('should call dataClientService.get method', () => {
            authService.login('Nick', 'pwd')

            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('user', ['login'], {
                username: 'Nick',
                password: btoa('pwd')
            });

        })
    });

    describe('logout', () => {
        it('should call dataClientService.post method', () => {
            authService.logout();
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith(null, 'user', ['logout'], null, null);
        });
    });

    describe('getCustomerInfo', () => {
        it('should call dataClientService.get method', () => {
            authService.getCustomerInfo('12345');
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('customer', ['12345']);
        });
    });

    describe('saveProfile', () => {
        it('should call dataClientService.put method ', () => {
            authService.saveProfile('params');
            expect(dataClientServiceSpy.put).toHaveBeenCalledWith('params', 'customer', [''], null, 'text');
        });
    });

});
