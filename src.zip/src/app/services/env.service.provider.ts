import { EnvService } from './env.service';
import { environment } from '../../environments/environment';

export const EnvServiceFactory = () => {  
  // Create env
  const env = new EnvService();

  //environment keys are mapped to EnvService
  for (const key in environment) {
    if (environment.hasOwnProperty(key)) {
      env[key] = environment[key];
    }
  }

  return env;
};

export const EnvServiceProvider = {  
  provide: EnvService,
  useFactory: EnvServiceFactory,
  deps: [],
};