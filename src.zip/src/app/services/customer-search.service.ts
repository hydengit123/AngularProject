import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import * as _ from 'lodash';
import { productBucketCard, SHAREDBUCKETTYPE } from 'dxp-common';

@Injectable({
    providedIn: 'root'
})
export class CustomerSearchService {

    private contractList: any = null;//list of all contracts
    private currentSelectedContract: any = null;//current selected contract
    private UserProfile: any = null;// common profile for all contracts
    private pendingCustomerId: any = null;//id of pending customer
    private journeyData: any = {};
    private pendingJourneyStatus: boolean = false;//journey pending status

    constructor(private translateService: TranslateService) { }

    /////////////////journey status setter getter///////////////////
    getpendingJourneyStatus() {
        return this.pendingJourneyStatus;
    }

    setpendingJourneyStatus(status) {
        this.pendingJourneyStatus = status;
    }

    //////////////////journey data setter getter//////////////////
    setJourneyData(data, length) {
        this.journeyData["data"] = data;
        this.journeyData["journeyLength"] = length;
    }

    getJourneyData() {
        return this.journeyData;
    }


    ////////////////journey id setter getter////////////////////
    setPendingId(id) {
        this.pendingCustomerId = id;
    }

    getPendingId() {
        return this.pendingCustomerId;
    }


    ///////////////profile details object setter getter/////////////////////
    setUserProfile(profile) {
        this.UserProfile = profile;
    }

    getUserProfile() {
        return this.UserProfile;
    }


    ///////////////////contractlist setter getter/////////////////

    setUserContracts(contractList) {
        this.contractList = contractList;
    }

    getUserContracts() {
        return this.contractList;
    }


    /////////////////////reset profile and contract///////////////
    resetUserProfileandContracts() {
        this.contractList = null;
        this.UserProfile = null;
        this.currentSelectedContract = null;
    }


    //////////////////set current selected contract //////////////////
    setCurrentContract(contract) {
        this.currentSelectedContract = contract;
    }

    getCurrentContract() {
        return this.currentSelectedContract;
    }

    getCurrentContractBasePlan(basePlanTypes) {
        let basePlan;
        let baseOffers;
        if (this.currentSelectedContract && this.currentSelectedContract.contract && this.currentSelectedContract.contract.products) {
            baseOffers = _.filter(this.currentSelectedContract.contract.products, (o) => { return o.productBuckets.filter(x => !x.providerMSISDN).length > 0 && _.filter(basePlanTypes, (x) => x.toLowerCase() === o.type.toLowerCase()).length > 0 });
            if (baseOffers.length > 1) {
                basePlan = _.cloneDeep(baseOffers[0]);
                basePlan.name = this.translateService.instant('Custom Plan');
                basePlan.cmsName = this.translateService.instant('Custom Plan');
                let price = 0;
                baseOffers.forEach(element => {
                    price += parseFloat(element.prices[0].price);
                });
                basePlan.prices[0].price = price;
            }
            else if (baseOffers.length === 1) {
                basePlan = _.cloneDeep(baseOffers[0]);
            }
        }
        if(basePlan && basePlan.productBuckets) {
        basePlan.productBuckets = this.getCurrentContractProductBucketsOfRelatedPlanOffers(baseOffers, basePlanTypes);
        return [basePlan];
        }
    }

    getCurrentContractProductBucketsWithProductIdAndInstanceId(offerTypes:any) {
        let productBucketsWithInstance = [];
        if (this.currentSelectedContract && this.currentSelectedContract.contract && this.currentSelectedContract.contract.products) {
            this.currentSelectedContract.contract.products.forEach((e) => {
                e.productBuckets.forEach((x) => {
                    x.productInstanceId = e.productInstanceId;
                    x.productId = e.id;
                    if(_.filter(offerTypes, (x) => x.toLowerCase() === e.type.toLowerCase()).length > 0)
                    productBucketsWithInstance.push(x);
                })
            });
        }
        return productBucketsWithInstance;
    }

    getCurrentContractProductBucketsOfRelatedPlanOffers(planOffers: any[], basePlanTypes) {
        if (this.currentSelectedContract && this.currentSelectedContract.contract && this.currentSelectedContract.contract.products) {
            return _.filter(this.getCurrentContractProductBucketsWithProductIdAndInstanceId(basePlanTypes), (a) => { return _.filter(planOffers, (x) => x.productInstanceId === a.productInstanceId && x.id === a.productId).length > 0 });
        }
        return null;
    }

    getProductBucketCards(basePlanTypes, transferPlanTypes, groupBy): productBucketCard[] {

        if (this.currentSelectedContract && this.currentSelectedContract.contract && this.currentSelectedContract.contract.products) {
            let basePlanOffer = this.getCurrentContractBasePlan(basePlanTypes);
            let productBucketCards: productBucketCard[] = [];
            if (basePlanOffer && basePlanOffer[0].productBuckets && basePlanOffer[0].productBuckets.length > 0) {
                const groupedObjects = _.groupBy(basePlanOffer[0].productBuckets, groupBy);
                _.forOwn(groupedObjects, (val, key) => {
                    val.forEach(prod => {
                        let productCard: productBucketCard = Object.assign({}, prod);
                        productCard.isBasePlanBucket = true;
                        if (productCard.initialBalance && productCard.currentBalance) {
                            productCard.progressBarValue = (productCard.currentBalance * 100) / productCard.initialBalance
                        }
                        else {
                            productCard.progressBarValue = 0;
                        }
                        if (!productCard.sharedBucketType) {
                            if (productCard.isBasePlanBucket){
                            productCard.isTransferrable = true;}
                            productCard.isSharable = false;
                        }
                        else{
                            productCard.isTransferrable = false;
                        }
                        if (productCard.sharedBucketType && productCard.sharedBucketType === SHAREDBUCKETTYPE.SHAREDCONSUMER) {
                            productCard.isSharable = false;
                        }
                        if (productCard.sharedBucketType && productCard.sharedBucketType === SHAREDBUCKETTYPE.SHAREDPROVIDER) {
                            productCard.isSharable = true;
                        }
                        productBucketCards.push(productCard);
                    });
                });
            }
            this.getCurrentContractProductBucketsWithProductIdAndInstanceId(basePlanTypes.concat(transferPlanTypes)).forEach(prod => {
                if (_.findIndex(this.getCurrentContractBasePlan(basePlanTypes)[0].productBuckets, prod) === -1) {
                    let productCard: productBucketCard = Object.assign({}, prod);
                    if (productCard.initialBalance && productCard.currentBalance) {
                        productCard.progressBarValue = (productCard.currentBalance * 100) / productCard.initialBalance
                    }
                    else {
                        productCard.progressBarValue = 0;
                    }
                    if (!productCard.sharedBucketType) {
                        if (productCard.isBasePlanBucket){

                        productCard.isTransferrable = true;}
                        productCard.isSharable = false;
                    }else{
                        productCard.isTransferrable = false;
                    }
                    if (productCard.sharedBucketType && productCard.sharedBucketType === SHAREDBUCKETTYPE.SHAREDCONSUMER) {
                        productCard.isSharable = false;
                    }
                    if (productCard.sharedBucketType && productCard.sharedBucketType === SHAREDBUCKETTYPE.SHAREDPROVIDER) {
                        productCard.isSharable = true;
                    }
                    if(productCard.validUntil)
                    {
                            const dt1 = new Date();
                            const dt2 = new Date(productCard.validUntil);
                            productCard.expiryDate = `Expire in ${(Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate())) / (1000 * 60 * 60 * 24))).toString()} days`;
                    }
                    productCard.isBasePlanBucket = false;
                    productBucketCards.push(productCard);
                }
            });
            return productBucketCards;
        }
        return null;

    }

    public productBundleAddToCarousel(collection: any[], keysToAggredate: any[], groupBy: string) {
        let productsGroupedByInput = [];

        if (groupBy) {
            const groupedObjects = _.groupBy(collection, groupBy);
            _.forOwn(groupedObjects, (val, key) => {
                if(!val[0].isBasePlanBucket){
                    let dummyProduct:any =  Object.assign({}, val[0]);
                    dummyProduct.id= null;
                    dummyProduct.name= dummyProduct.bucketType;
                    dummyProduct.currentBalance= null;
                    dummyProduct.initialBalance= null;
                    dummyProduct.unit= dummyProduct.unit;
                    dummyProduct.validUntil= null;
                    dummyProduct.sharedBucketType=null;
                    dummyProduct.providerMSISDN= null;
                    dummyProduct.productInstanceId= null;
                    dummyProduct.productId= null;
                    dummyProduct.progressBarValue= null;
                    dummyProduct.isTransferrable= null;
                    dummyProduct.isSharable= null;
                    dummyProduct.isBasePlanBucket= null;
                    val.unshift(dummyProduct);
                }
                let productBundle;
                productBundle = Object.assign({}, val[0]);
                productBundle.isCollapsed = true;
                if (val.length > 1) {
                    productBundle.otherItems = _.drop(val);
                    productBundle.expandable = true;
                    if (keysToAggredate && keysToAggredate.length > 0) {
                        keysToAggredate.forEach(item => {
                            productBundle[`${item}More`] = 0;
                            productBundle.otherItems.forEach(element => {
                                productBundle[`${item}More`] += element[item];
                            });
                        });
                    }
                }
                else {
                    productBundle.otherItems = null;
                    productBundle.expandable = false;
                }
                productsGroupedByInput.push(productBundle);
            });
            return productsGroupedByInput;
        }
        else {
            return collection;
        }
    }

}
