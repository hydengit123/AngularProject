import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';


@Injectable()
export class CMSContentService {
    constructor(private http: HttpClient, private translate: TranslateService) {

    }

    getCollaterals(productId: string): Observable<any> {
        let url = '';
        let localDomain = '';
        let httpResponse: Observable<any>;
        if (!environment.production) {
            localDomain = environment.localCMSDomain;
        }
        if (environment.urls.getCollaterals.indexOf(".json") !== -1) {
            url = environment.urls.getCollaterals;
            httpResponse = this.http.get(url);
        }
        else {
            url = environment.urls.getCollaterals;
            httpResponse = this.http.post(url, {

                "languageCode": navigator.language,

                "products": [

                    {

                        "id": productId

                    }

                ]

            })
        }
        return httpResponse.pipe(map((response: any) => {
            let mappedData: any = {};
            if (response && response.products) {
                mappedData =
                    !response.products.collaterals
                        ? []
                        : !response.products.collaterals.length
                            ? [{
                                "id": response.products.collaterals.id,
                                "type": response.products.collaterals.type,
                                "url": localDomain + response.products.collaterals.url
                            }]
                            : response.products.collaterals.map((item) => {
                                return {
                                    "id": item.id,
                                    "type": item.type,
                                    "url": localDomain + item.url
                                }
                            });
            }

            return mappedData;
        }
        ));


    }


    getWebPageContent(pageId: string, langCode: string): Observable<any> {
        let url = '';
        let localDomain = '';
        let httpResponse: Observable<any>;
        if (!environment.production) {
            localDomain = environment.localCMSDomain;
        }
        if (environment.urls.getWebPageContent.indexOf(".json") !== -1) {
            url = environment.urls.getWebPageContent;
            httpResponse = this.http.get(url);
        }
        else {
            url = environment.urls.getWebPageContent;
            httpResponse = this.http.post(url, {

                "languageCode": langCode,

                "webPages": [

                    {

                        "webPageId": pageId

                    }

                ]

            })
        }
        return httpResponse.pipe(map((response: any) => {
            let mappedData: any = {};
            if (response && response.webPageContents
                && response.webPageContents.length
                && response.webPageContents.length > 1) {
                throw new Error(`${this.translate.instant('Please publish only one webcontent for page id')} ${pageId}`);
            }
            if (response && response.webPageContents) {
                mappedData = {
                    "banner":
                        !response.webPageContents.banner ? { url: "" }
                            : {
                                url: localDomain + response.webPageContents.banner.url,
                            }
                    ,
                    "leftImage":
                        !response.webPageContents.leftImage ? { url: "" }
                            : {
                                url: localDomain + response.webPageContents.leftImage.url,
                            }
                    ,
                    "offersBanner":
                        !response.webPageContents.offersBanner ? { url: "" }
                            : {
                                url: localDomain + response.webPageContents.offersBanner.url,
                            }
                    ,
                    "bottomRightImage":
                        !response.webPageContents.bottomRightImage ? { url: "" }
                            : {
                                url: localDomain + response.webPageContents.bottomRightImage.url,
                            },
                    "footerImage":
                        !response.webPageContents.footerImage ? { url: "" }
                            : {
                                url: localDomain + response.webPageContents.footerImage.url,
                            },
                    "footerLightImage":
                        !response.webPageContents.footerLightImage ? { url: "" }
                            : {
                                url: localDomain + response.webPageContents.footerLightImage.url,
                            },
                    "paymentServiceImages":
                        !response.webPageContents.paymentServiceImages ? { url: "" }
                            : response.webPageContents.paymentServiceImages.url 
                            ? [response.webPageContents.paymentServiceImages]
                            : response.webPageContents.paymentServiceImages

                };
            }

            return mappedData;
        }
        ));


    }

}
