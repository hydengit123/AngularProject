import { TestBed, inject } from '@angular/core/testing';

import { ShareWithConsumerService } from './share-with-consumer.service';

describe('ShareWithConsumerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ShareWithConsumerService]
    });
  });

  it('should be created', inject([ShareWithConsumerService], (service: ShareWithConsumerService) => {
    expect(service).toBeTruthy();
  }));
});
