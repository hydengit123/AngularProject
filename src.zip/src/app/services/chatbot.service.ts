import { Injectable } from '@angular/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { PERSISTANCEKEY, CHATBOT, WEBCONTENTPERSISTANCEKEY } from '../../application-constants';
import * as crypto from 'crypto-js';
import { Subscription } from 'rxjs';

declare let window: any;

@Injectable({
    providedIn: 'root'
})
export class ChatbotService {

    Avaamo: any;
    private chatbotPaymentSubscription: Subscription

    private avaamoChatBotLoader: any;

    constructor(private persistenceService: PersistenceService) { }

    private getPaymentUrl(): string{
        const baseElement = document.getElementsByTagName('base')[0];
        const url = !!baseElement ? baseElement.href : window.location.origin;
        const urlJoiner = url.endsWith('/') ? '' : '/';
        return `${url}${urlJoiner}intermediaryPayment`;
    }

    identifyuser(msisdn) {
        let accessToken = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
        let key = this.persistenceService.get(CHATBOT.SECRETKEY, StorageType.SESSION);
      // let key = 'f00e903f-9af9-4b9b-8d7a-586dd2a8f1b2';
        let header = { 'alg': 'HS256', 'typ': 'JWT' };
        let p1: any;
        let p2: any;
        let b: any;
        let token: any;
        let body = {
            'uuid': this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION) || '', // unique identifier
            'MSISDN': msisdn, // msisdn numbner,
            'BearerToken': accessToken,
            'partyId': this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION) || '',
            'partyRole': 'customer',
            'paymentUrl': this.getPaymentUrl()
        };
        let context = 'Low Data Balance';
        if (context && context !== '') {
            body['context'] = '';
        }
        p1 = Base64EncodeUrl(btoa(JSON.stringify(header)));
        p2 = Base64EncodeUrl(btoa(JSON.stringify(body)));
        b = p1 + '.' + p2;
        if (p1 && p2 && key) {
            token = crypto.HmacSHA256(p1 + '.' + p2, key);
            token = crypto.enc.Base64.stringify(token);
            token = Base64EncodeUrl(token);
            token = b + '.' + token;
            this.loadChatbot(token);
        }
        function Base64EncodeUrl(str) {
            return str.replace(/\+/g, '-').replace(/\//g, '_').replace(/\=+$/, '');
        }
    }

    loadChatbot(token) {
        const url = this.persistenceService.get(CHATBOT.CHATBOTURL, StorageType.SESSION);
       // const url ='https://c8.avaamo.com/web_channels/1d8482ee-3dca-4b21-890d-036768704a66?bot_typing_duration=120000&history=true&theme=avm-blue&user_info=';
        // let element = document.getElementById("avvamo");
        // if ( !!element ) {
        //     element.parentNode.removeChild(element);
        //     window.Avvamo = null;
        //     this.Avaamo = null;
        //     const avvamoDivElement = document.getElementById('avm_chat_widget_39b5a198-37a5-4059-83bd-3d660acfe6fb');
        //     if(!!avvamoDivElement ) {
        //         console.log('Avvomo div removed')
        //         avvamoDivElement.parentNode.removeChild(avvamoDivElement);
        //     }
        // }
        //this.avaamoChatBotLoader = function (t) { function o(t, o) { var n = document.createElement("script"); n.setAttribute("src", t), n.setAttribute("id", "avvamo"), n.onload = o, document.body.appendChild(n) } return this.options = t || {}, this.load = function (t) { o(this.options.url, function () { window.Avaamo.addFrame(), t && "function" == typeof (t) && t(window.Avaamo) }) }, this };
        this.avaamoChatBotLoader = function (t) { function o(t, o) { var n = document.createElement("script"); n.setAttribute("src", t), n.onload = o, document.body.appendChild(n) } return this.options = t || {}, this.load = function (t) { o(this.options.url, function () { window.Avaamo.addFrame(), t && "function" == typeof (t) && t(window.Avaamo) }) }, this };
        const tokenUrl = url + token;
        this.Avaamo = this.avaamoChatBotLoader({ url: tokenUrl });
        this.Avaamo.load();
        if (!!this.chatbotPaymentSubscription) {
            this.chatbotPaymentSubscription.unsubscribe();
        }
        this.updateChatBotPayment();
    }

    private updateChatBotPayment() {
        const paymentData = this.persistenceService.get(WEBCONTENTPERSISTANCEKEY.PAYMENT_STATUS, StorageType.SESSION);
        this.persistenceService.remove(WEBCONTENTPERSISTANCEKEY.PAYMENT_STATUS, StorageType.SESSION);
        if (!!paymentData) {
            this.updateChatBot(paymentData.status, paymentData.transactionData);
        }
    }

    private updateChatBot(status, payload) {
        if (!!window.Avaamo) {
            window.Avaamo.openChatBox();
            setTimeout(() => {
                window.Avaamo.sendMessage(status, JSON.stringify(payload));
            }, 3000);
        } else {
            setTimeout(() => {
                this.updateChatBot(status, payload);
            }, 1000);
        }
    }

    logoutChatbot() {
        if (window.Avaamo) {
            window.Avaamo.logout();
        }
    }
}
