import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CARTACTION, cartDetails, CARTITEM, CMUICONFIGKEY, contractItem, customerIdentities, customerOnboard, customerPurchaseOrder, DataFormatterPipe, identities, itemPrice, orderItem, PaymentRequestInfo, PaymentTransactionRequest, planoffer, PLANTYPE, PRICETYPE, productBucket, productItem, resource } from 'dxp-common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PERSISTANCEKEY } from '../../application-constants';
import { environment } from '../../environments/environment';
import { customerInteraction } from '../interface/customer.interaction';
import { CartService } from '../services/cart.service';
import { PaymentGatewayService } from '../services/payment-gateway.service';

declare const alertify;

@Injectable()
export class CustomerOnboardService implements OnInit {
    customerOnBoardingData: customerOnboard;
    planAddonsData: any;
    public someData: any;
    public langs: any;
    public journeySessionData: any;
    private dataFormatterPipe: DataFormatterPipe = new DataFormatterPipe(this.translateService);
    constructor(private http: HttpClient,
        private persistenceService: PersistenceService,
        private cartService: CartService,
        private translateService: TranslateService,
        private router: Router,
        private paymentService: PaymentGatewayService) {

    }
    ngOnInit() {

        // this.langs = this.persistenceService.get(CMUICONFIGKEY.LANGUAGES, StorageType.SESSION);
    }
    fraudCheck(activationDetails: any): Observable<any> {
        let url = '';

        let httpResponse: Observable<any>;
        if (environment.urls.fraudCheck.indexOf('.json') !== -1) {
            url = environment.urls.fraudCheck;
            httpResponse = this.http.get(url);
        } else {
            // Request payload{
            // "msisdn": "1236985236",
            //  "simNumber": "4569632587",
            //  "activationCode": "1236985214",
            //  "location":"India",
            //  "place":"Karnataka"
            // }
            const requestPayload = {
                'msisdn': activationDetails.phoneNumber,
                'simNumber': activationDetails.simCardNumber,
                'activationCode': activationDetails.activationCode,
                'location': activationDetails.location
            };
            url = environment.urls.fraudCheck;
            httpResponse = this.http.post(url, requestPayload);
        }
        return httpResponse;


    }


    getCustomerOnBoardDetails(customerId: string): Observable<any> {
        let url = '';
        let localDomain = '';
        let httpResponse: Observable<any>;
        if (!environment.production) {
            localDomain = environment.localCMSDomain;
        }
        if (environment.urls.getCustomerOnBoardDetails.indexOf('.json') !== -1) {
            url = environment.urls.getCustomerOnBoardDetails;
            httpResponse = this.http.get(url);
        } else {
            url = environment.urls.getCollaterals;
            httpResponse = this.http.post(url, {

                'languageCode': navigator.language,
                'products': [
                    {
                        'id': customerId
                    }
                ]

            });
        }
        return httpResponse.pipe(map((response: any) => {
            const mappedData: any = response;
            this.customerOnBoardingData = response;

            return mappedData;
        }
        ));


    }

    getPlanAddonsDetails(lang: string, offerType: any, onBoardData: customerOnboard): Observable<any> {
        let url = '';
        let localDomain = '';
        let httpResponse: Observable<any>;
        if (!environment.production) {
            localDomain = environment.localCMSDomain;
        }
        if (environment.urls.getCustomerPlanDetails.indexOf(".json") !== -1) {
            url = environment.urls.getCustomerPlanDetails;
            httpResponse = this.http.get(url);
        }
        else {
            url = environment.urls.getCustomerPlanDetails;
            httpResponse = this.http.post(url, {
                'eligibilityDate': new Date().toISOString(),
                'offerType': offerType,
                'productCategory': this.persistenceService.get(CMUICONFIGKEY.PRODUCTCATEGORY_FORPRODUCTSEARCHQUERY, StorageType.SESSION),
                'language': lang,
                'contextCharacteristic': [
                    {
                        'name': 'salesChannel',
                        'valueInstances': [
                            {
                                'values': [
                                    {
                                        'value': this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'],
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "name": "location",
                        "valueInstances": [
                            {
                                "values": [
                                    {
                                        "value": onBoardData.activationDetails.location,
                                    }
                                ]
                            }
                        ]
                    }
                ]
            });
        }

        return httpResponse.pipe(
            map((res: any) => {
                this.someData = res;
                return res;
            }));
    }
    public productBucketArray = ['data', 'voice', 'sms'];

    getCMSDigitalAssets(items, lang, offerType): Observable<planoffer[]> {
        let url = '';
        let localDomain = '';
        let httpResponse: Observable<any>;
        // let products = items.map(data => {
        //     return { id: data.id };
        // })
        // let productTypes =  offerType;


        if (!environment.production) {
            localDomain = environment.localCMSDomain;
        }
        if (environment.urls.getPlanOffersImages.indexOf('.json') !== -1) {
            url = environment.urls.getPlanOffersImages;
            httpResponse = this.http.get(url);
        } else {

            url = environment.urls.getPlanOffersImages;
            httpResponse = this.http.post(url, {
                'languageCode': lang,
                'productTypes': offerType,
                'channels': [],
                'locations': [],
                'products': []

            });
        }

        return httpResponse.pipe(map((response: any) => {
            if (response && response.products) {
                let productList: any[] = [];
                if (Array.isArray(response.products)) {
                    productList = response.products;
                } else {
                    productList.push(response.products);
                }
                return productList.map((prod) => {
                    let filteredItem = {};
                    const filteredItems = items.filter(d => d.id === prod.id);
                    let noCMSImage: boolean = false;
                    if (filteredItems && filteredItems[0]) {
                        filteredItem = filteredItems[0];
                    } else if (!prod.coverImage) {

                        noCMSImage = true;
                    }
                    let mappedData: planoffer = {
                        'title': prod.title || '',
                        'summary': prod.summary || '',
                        // 'description': res.description,
                        'coverImage': noCMSImage ? '/assets/imgs/no-image-icon.png' : localDomain + prod.coverImage,
                        'frontImage': prod.frontImage || '',
                        'backImage': prod.backImage || '',
                        'id': filteredItem['id'] || prod.id || '',
                        'name': filteredItem['name'] || '',
                        'description': prod.description || '',

                        'offerType': filteredItem['offerType'] || '',
                        'productOfferingPrice': filteredItem['productOfferingPrice']
                            && filteredItem['productOfferingPrice']['0']
                            && filteredItem['productOfferingPrice']['0']['price']
                            && filteredItem['productOfferingPrice']['0']['price']['amount']
                            ? filteredItem['productOfferingPrice']['0']['price']['amount'] : 0,
                        "priceType": filteredItem['productOfferingPrice']
                            && filteredItem['productOfferingPrice']['0']
                            && filteredItem['productOfferingPrice']['0']['priceType']
                            ? filteredItem['productOfferingPrice']['0']['priceType'] : null,
                        'productBuckets': filteredItem['productBuckets'] ?
                            filteredItem['productBuckets'].map(item => {
                                const productBucket: productBucket = this.calculateDisplay(item);
                                return productBucket;
                            }) : null,
                        periodTypes: filteredItem['productOfferingPrice']
                            && filteredItem['productOfferingPrice']['0']
                            && filteredItem['productOfferingPrice']['0']['recurrencePeriod']
                            && filteredItem['productOfferingPrice']['0']['recurrencePeriod']['periodType']
                            ? filteredItem['productOfferingPrice']['0']['recurrencePeriod']['periodType'] : null,
                        recurrencePeriod: filteredItem['productOfferingPrice']
                            && filteredItem['productOfferingPrice']['0']
                            && filteredItem['productOfferingPrice']['0']['recurrencePeriod']
                            ? filteredItem['productOfferingPrice']['0']['recurrencePeriod'] : null,
                        currency: filteredItem['productOfferingPrice']
                            && filteredItem['productOfferingPrice']['0']
                            && filteredItem['productOfferingPrice']['0']['price']
                            && filteredItem['productOfferingPrice']['0']['price']['currency'] ?
                            filteredItem['productOfferingPrice']['0']['price']['currency']
                            // this.checkProductCurrency(filteredItem['productOfferingPrice']['0']['price']['currency'])
                            : null
                    }

                    return mappedData;
                })
            } else if (Object.keys(response).length === 0) {
                return [];
            }
        }
        ));


    }
    // checkProductCurrency(currency)
    // {
    //     const productCurrencyType = this.persistenceService.get(CMUICONFIGKEY.PRODUCTPRICECURRENY, StorageType.SESSION);
    //     const currencyName = productCurrencyType.filter(x=>x.currencyName == currency);
    //     return currencyName[0] && currencyName[0].currencySymbol ? currencyName[0].currencySymbol:null;
    // }

    calculateDisplay(prod: productBucket): productBucket {
        if (prod.initialBalance === 0) {
            prod.forDisplay = null;
        }
        else if (prod.serviceName === 'sms') {
            prod.forDisplay = `${this.dataFormatterPipe.transform(prod.initialBalance, prod.unitOfMeasure)}`;
        }
        else if (prod.serviceName === 'data') {
            prod.forDisplay = `${this.dataFormatterPipe.transform(prod.initialBalance, prod.unitOfMeasure, false)}`;
        }
        else if (prod.serviceName === 'voice') {
            prod.forDisplay = `${this.dataFormatterPipe.transform(prod.initialBalance, prod.unitOfMeasure)}`;
        }
        return prod;
    }

    calculateSMS(sms: number): any {
        if (sms === -1) {
            return 'Unlimited';
        }
        return sms;
    }

    calculateData(bytes: number, decimals: number = 0): number {
        const k = 1024;
        const dm = decimals <= 0 ? 0 : decimals || 2;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, 3)).toFixed(dm));

    }

    calculateVoice(voice: number): any {
        const sec = 60;
        const converted = Math.floor(voice / sec);
        if (converted === -1) {
            return 'Unlimited';
        }
        return converted;
    }

    loginDummyUser(userName, password): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        // if (environment.urls.login.indexOf('.json') !== -1) {
        //     url = environment.urls.login;
        //     httpResponse = this.http.get(url);
        // }
        // else {
        url = `${environment.urls.login}?username=${btoa(userName)}&password=${btoa(password)}`;
        httpResponse = this.http.get(url);


        return httpResponse.pipe(map((response: any) => {
            const mappedData: any = response;
            return mappedData;
        }
        ));


    }

    signUpEmailExist(signUpDetails: any, activationDetails): Observable<any> {
        let url = '';
        let sendData = {};
        const phoneNumber = activationDetails.phoneNumber;
        const email = signUpDetails['signUpEmail'];
        if (!email) {
            // phoneNumber = customerOnBoardDetails.customerOnBoardingData.activationDetails.phoneNumber;
            sendData = {
                'name': 'msisdn',
                'value': phoneNumber,
                'operator': '=='
            }
        } else {
            sendData = {
                'name': 'email',
                'value': email,//sam@wipro.com
                'operator': '=='
            }
        }
        let httpResponse: Observable<any>;
        url = environment.urls.userprofile;
        httpResponse = this.http.post(url, sendData);
        return httpResponse;
    }

    customerSearch(activationDetails: any): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.customersearch.indexOf('.json') !== -1) {
            url = environment.urls.customersearch;
            httpResponse = this.http.get(url);
        } else {
            const requestPayload = {
                'msisdn': activationDetails.phoneNumber,
                'journeyId': 'Onboarding' //Onboarding
            }
            url = environment.urls.customersearch;
            httpResponse = this.http.post(url, requestPayload);
        }
        return httpResponse;
    }

    getJourneySessionData(id) {
        let httpResponse: Observable<any>;
        let customerId = '';
        if (id) {
            customerId = id;
        } else {
            customerId = '08034996-919e-4c91-a886-5449a00b08c5'; // 7d337124-93e1-4c15-9060-62e4720f5679
        }
        const url = environment.urls.getJourneySession + customerId; httpResponse = this.http.get(url);
        return httpResponse;
    }

    deleteJourneySessionData(journeySessionId) {
        let httpResponse: Observable<any>;
        // let journeySessionId = "7bc4c25f-bd1a-4942-a44d-3aaf927647bd";
        const url = environment.urls.deleteJourneySession + journeySessionId;
        httpResponse = this.http.delete(url);
        return httpResponse;
    }



    createCartDetailsWithResource(customerOnboard: customerOnboard): cartDetails {
        const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        let fullName = `${customerOnboard.contactDetails.personalInformation.firstName} ${customerOnboard.contactDetails.personalInformation.lastName}`;
        if(fullName === 'null null'){
            fullName = channelName;
        }
        let cartDetails: cartDetails = {
            createdBy: fullName,
            createdByChannel: channelName,
            updatedBy: fullName,
            lastUpdatedByChannel: channelName,
            cartItem: [],
            id: null,
            cartList: null,
            totalPrice: []
        };
        let contractItem = this.createContractItem(customerOnboard);
        cartDetails.cartItem.push(contractItem);
        return cartDetails;
    }

    createContractItem(customerOnBoard: customerOnboard): contractItem {
        let contractItem: contractItem = {
            action: CARTACTION.ADD,
            type: CARTITEM.CONTRACTITEM,
            paymentContext: 'Prepaid',
            resource: [],
            id: customerOnBoard.contractId
        };
        const MSISDNResource: resource = {
            resourceNumber: customerOnBoard.activationDetails.phoneNumber || '',
            resourceType: CARTITEM.MSISDNRESOURCETYPE,
            resourceSubType: null,

        }

        contractItem.resource.push(MSISDNResource);

        return contractItem;
    }





    convertXChannelPlanToCartProductItem(plan: planoffer, transactionType: string, customerOnBoard: customerOnboard): productItem {
        let productItem: productItem = {
            action: transactionType,
            type: 'ProductItem',
            quantity: 1,
            productOffering: {
                id: plan.id,
                name: plan.name,
                offerType: plan.offerType
            },
            itemPrice: [],
            resource: [],
        }
        let itemPrice: itemPrice = Object.assign({}, plan.productOfferingPrice[0]);
        itemPrice.recurrenceFrequency = itemPrice.priceType === PRICETYPE.RECURRING ? 'Custom' : null;


        const MSISDNResource: resource = {
            resourceNumber: customerOnBoard.activationDetails.phoneNumber || '',
            resourceType: CARTITEM.MSISDNRESOURCETYPE,
            resourceSubType: null,

        }
        const SIMResource: resource = {
            resourceNumber: customerOnBoard.activationDetails.simCardNumber || '',
            resourceType: CARTITEM.SIMRESOURCETYPE,
            resourceSubType: null
        }
        //if (plan.offerType != CARTITEM.ADDON) {
        productItem.resource.push(MSISDNResource);
        productItem.resource.push(SIMResource);
        // }
        // else {
        //     delete productItem.resource
        // }
        productItem.itemPrice.push(itemPrice);
        return productItem;
    }

    convertPlanToCartProductItem(plan: planoffer, transactionType: string, customerOnBoard: customerOnboard): productItem {
        let productItem: productItem = {
            action: transactionType,
            type: 'ProductItem',
            quantity: 1,
            productOffering: {
                id: plan.id,
                name: plan.name,
                offerType: plan.offerType
            },
            itemPrice: [],
            resource: []
        }

        let itemPrice: itemPrice = {
            priceType: plan.priceType,
            recurrenceFrequency: plan.priceType === PRICETYPE.RECURRING ? 'Custom' : null,
            recurrencePeriod: plan.recurrencePeriod,
            price: {
                amount: plan.productOfferingPrice,
                currency: plan.currency
            }
        }
        const MSISDNResource: resource = {
            resourceNumber: customerOnBoard.activationDetails.phoneNumber || '',
            resourceType: CARTITEM.MSISDNRESOURCETYPE,
            resourceSubType: null,

        }
        const SIMResource: resource = {
            resourceNumber: customerOnBoard.activationDetails.simCardNumber || '',
            resourceType: CARTITEM.SIMRESOURCETYPE,
            resourceSubType: null
        }
        // if (plan.offerType != CARTITEM.ADDON) {
        productItem.resource.push(MSISDNResource);
        productItem.resource.push(SIMResource);
        // }
        // else {
        //     delete productItem.resource
        // }
        productItem.itemPrice.push(itemPrice);
        return productItem;
    }



    public addCustomPlanToCart(items: planoffer[], customerOnBoard: customerOnboard,
        cartDetails: cartDetails = null) {
        if (items && (!(items instanceof Array) || items.filter(item => item.offerType !== PLANTYPE.CUSTOMIZEPLANOFFER).length > 0)) {
            console.error('Please add a custom plan only');
            return;
        }
        let cartItems = items.map(item => this.convertPlanToCartProductItem(item, CARTACTION.ADD, customerOnBoard));

        if (this.cartService.cartDetails && this.cartService.cartDetails.id) {
            const isPreactivatedPlan = this.cartService.cartDetails.cartList.filter(item => { return item.action.toLowerCase() === CARTACTION.ACTIVE }).length > 0;
            if (isPreactivatedPlan) {//swap preactived plans
                cartItems = cartItems.map(x => {
                    x.action = CARTACTION.SWAP;
                    return x;
                })
                return this.cartService.updateCart(cartItems, !isPreactivatedPlan);
            }
            return this.cartService.replaceBaseOfferFromCart(cartItems);
        } else {
            return this.cartService.createCart(cartItems, this.createCartDetailsWithResource(customerOnBoard))
        }
    }

    public addToCart(item: planoffer, customerOnBoard: customerOnboard, cartDetails: cartDetails = null) {
        if (this.cartService.cartDetails && this.cartService.cartDetails.id) {
            const isPreactivatedPlan = this.cartService.cartDetails.cartList.filter(item => { return item.action.toLowerCase() === CARTACTION.ACTIVE }).length > 0;
            if (item.offerType === CARTITEM.ADDON) { //add-ons
                return this.cartService.updateCart([this.convertPlanToCartProductItem(item, CARTACTION.ADD, customerOnBoard)])
            } else if (isPreactivatedPlan) {//swap preactived plans
                return this.cartService.updateCart([this.convertPlanToCartProductItem(item, CARTACTION.SWAP, customerOnBoard)], !isPreactivatedPlan);
            } else { //delete old plan and add new plan when no pre-activated plan
                return this.cartService.replaceBaseOfferFromCart([this.convertPlanToCartProductItem(item, CARTACTION.SWAP, customerOnBoard)]);
            }

        } else {
            return this.cartService.createCart([this.convertPlanToCartProductItem(item, CARTACTION.ADD, customerOnBoard)], this.createCartDetailsWithResource(customerOnBoard))
        }
    }


    // Save Cart-------------------------------

    saveCart(formValue, msisdn, customerId, userId, partyId): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        const identities: any = [];

        if (formValue.identifier) {
            const identitiesEmail = {
                'identifier': formValue.identifier,
                'identityType': 'Email'
            };
            const identitiesMsisdn = {
                'identifier': msisdn,
                'identityType': 'MSISDN'
            };
            identities.push(identitiesEmail);
            identities.push(identitiesMsisdn);
        } else {
            const identitiesMsisdn = {
                'identifier': msisdn,
                'identityType': 'MSISDN'
            };
            identities.push(identitiesMsisdn);
        }
        formValue.credentialType = 'PASSWORD';
        if (environment.urls.saveCart.indexOf('.json') !== -1) {
            url = environment.urls.saveCart;
            httpResponse = this.http.get(url);
        } else {
            const requestPayload = {
                'firstName': formValue.firstName,
                'lastName': formValue.lastName,
                'optedForSelfcareRegistration': 'true',
                'identities': identities,
                'credential': btoa(formValue.credential),
                'credentialType': 'PASSWORD',
                'customerId': customerId,
                'userId': userId,
                'partyId': partyId
            }
            url = environment.urls.saveCart;
            httpResponse = this.http.post(url, requestPayload)
        }
        return httpResponse;
    }
    // end of save cart------------------------

    public paymentResponseHandler(onBoardData: customerOnboard, paymentRequest: PaymentRequestInfo) {
        let responseData = {};
        if (onBoardData) {
            responseData = {
                responseHandler: (BOLT) => {
                    return this.paymentSuccessHandler(BOLT, onBoardData, paymentRequest);
                },
                catchException: (BOLT) => {
                    return this.paymentFailureHandler(BOLT, onBoardData);
                }
            };
        }
        return responseData;
    }

    private async paymentSuccessHandler(BOLT, onBoardData: customerOnboard, paymentRequest: PaymentRequestInfo) {
        if (BOLT.response && BOLT.response.txnStatus === 'SUCCESS'
            && BOLT.response.txnid) {
            const paymentTransactionRequest = {
                resourceNumber: this.paymentService.paymentConfigSelected.resourceNumber, // MSISDN from customer journey
                payer: BOLT.response.payer || 'NA', // NA in old code
                merchantRefNum: this.paymentService.paymentConfigSelected.merchantRefNum, // merchantRefNum from create payment service
                paymentGwTransactionId: BOLT.response.txnid || BOLT.response.payuMoneyId || paymentRequest.txnid,
                status: BOLT.response.status,
                paymentToken: BOLT.response.paymentId || '', // empty in old code
                paymentMethod: BOLT.response.mode,
                expiryDate: BOLT.response.addedon || '', // empty in old code
                cardNumber: BOLT.response.cardnum || '', // cardnum from payumoney,
                amount: BOLT.response.amount
            };
            const paymentInfo = await this.paymentService.updatePayment(paymentTransactionRequest).toPromise();
            if (this.paymentService.msisdn === paymentTransactionRequest.resourceNumber && this.paymentService.allowPayment && this.paymentService.totalAmount === this.cartService.cartDetails.totalPrice[0].price.amount) {
                this.paymentService.allowPayment = false;
                const paymentInfo = await this.paymentService.updatePayment(paymentTransactionRequest).toPromise();
                if (paymentInfo && paymentInfo.message && paymentInfo.message === 'SUCCESS') {
                    const customerInteractionResponse = await this.createCustomerInteraction(onBoardData, paymentTransactionRequest).toPromise();
                    if (customerInteractionResponse) {
                        this.redirectToSucessView(customerInteractionResponse, BOLT.response.txnid);
                    }
                } else {
                    alertify.error(this.translateService.instant('Payment Failed'));
                }
            }
        } else {
            alertify.error(this.translateService.instant('Payment has been cancelled'));
        }
    }
    // BOLT.response.txnMessage
    public redirectToSucessView(customerInteractionResponse, txnId = null) {
        this.cartService.cartDetails = {
            cartItem: [],
            cartList: [],
            id: '',
            createdBy: '',
            createdByChannel: '',
            updatedBy: '',
            lastUpdatedByChannel: '',
            totalPrice: []
        };
        this.paymentService.orderId = customerInteractionResponse.id;
        this.paymentService.transactionId = txnId;
        const routeUrl = 'customerOnboard/paymentsuccessful';
        this.router.navigate(routeUrl.split('/'));
    }

    private paymentFailureHandler(BOLT, onBoardData: customerOnboard) {
        alertify.error(this.translateService.instant(BOLT.message));
        //TODO need to save error message in DB
        // if (BOLT.response && BOLT.response.status
        //   && BOLT.response.txnid) {
        //   let paymentTransactionRequest = {
        //     resourceNumber: BOLT.response.mihpayid,
        //     payer: BOLT.response.email,
        //     merchantRefNum: BOLT.response.meCode,
        //     paymentGwTransactionId: BOLT.response.txnid,
        //     status: BOLT.response.status,
        //     paymentToken: BOLT.response.paymentId,
        //     paymentMethod: BOLT.response.mode,
        //     expiryDate: BOLT.response.addedon,
        //     cardNumber: BOLT.response.bankcode
        //   };
        //   this.updatePayment(paymentTransactionRequest).subscribe(data => {
        //     if(data && data.message && data.message == "SUCCESS"){
        //       //TODO error handling
        //     }
        //   });
        // }
    }

    private generateOrderItems(onBoardData: customerOnboard, cartDetails: cartDetails): orderItem[] {
        if (cartDetails) {
            const fullName: string = `${onBoardData.contactDetails.personalInformation.firstName} ${onBoardData.contactDetails.personalInformation.lastName}`;
            const orders: orderItem[] = cartDetails.cartList.map(x => {
                //if (x.action !== CARTACTION.ACTIVE)
                return {
                    type: 'ProductOrderItem',//x.type,
                    msisdn: onBoardData.activationDetails.phoneNumber,
                    action: x.action, //CARTACTION.ADD
                    description: x.productOffering.id,
                    createdBy: fullName,
                    updatedBy: fullName
                };
            });
            return orders;
        }
        else {
            return [];
        }
    }

    private generateCustomerPurchaseOrder(onBoardData: customerOnboard, cartDetails: cartDetails): customerPurchaseOrder {
        const fullName: string = `${onBoardData.contactDetails.personalInformation.firstName} ${onBoardData.contactDetails.personalInformation.lastName}`;
        const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        const customerOrder: customerPurchaseOrder = {
            createdBy: fullName,
            customerId: null,
            createdByChannel: channelName,
            description: 'Onboarding',
            lastUpdatedByChannel: channelName,
            msisdn: onBoardData.activationDetails.phoneNumber,
            shoppingCartId: cartDetails ? cartDetails.id : '',
            state: 'InProgress',
            type: 'PurchaseOrder',
            updatedBy: fullName,
            orderItem: this.generateOrderItems(onBoardData, cartDetails)
        };
        return customerOrder;
    }

    private generateCustomerIdentities(onBoard: customerOnboard): customerIdentities {
        const customerIdentities: customerIdentities = {
            credential: onBoard.contactDetails.signUInfo.password,
            credentialType: !onBoard.contactDetails.signUInfo.enableOTP ? 'PASSWORD' : 'OTP',
            firstName: onBoard.contactDetails.personalInformation.firstName,
            lastName: onBoard.contactDetails.personalInformation.lastName,
            optedForSelfcareRegistration: !onBoard.contactDetails.signUInfo.signupForOnlineManagement ? false : true,
            identities: []
        };
        const msisdnIdentity: identities = {
            identifier: onBoard.activationDetails.phoneNumber,
            identityType: 'MSISDN'
        };
        customerIdentities.identities.push(msisdnIdentity);
        if (onBoard.contactDetails && onBoard.contactDetails.signUInfo
            && onBoard.contactDetails.signUInfo.signUpEmail) {
            customerIdentities.identities.push({
                identifier: onBoard.contactDetails.signUInfo.signUpEmail,
                identityType: 'Email'
            });
        }
        return customerIdentities;
    }

    private generateCustomerInteractionData(onBoard: customerOnboard,
        cartDetails: cartDetails,
        paymentTransactionRequest: PaymentTransactionRequest, isSaveCart: boolean = false): customerInteraction {
        if (onBoard && onBoard.contactDetails && onBoard.contactDetails.signUInfo && onBoard.contactDetails.signUInfo.password) {
            onBoard.contactDetails.signUInfo.password = btoa(onBoard.contactDetails.signUInfo.password);
        }
        if (onBoard && onBoard.contactDetails && onBoard.contactDetails.signUInfo && onBoard.contactDetails.signUInfo.repassword) {
            onBoard.contactDetails.signUInfo.repassword = btoa(onBoard.contactDetails.signUInfo.repassword);
        }
        const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        const customerInteractionData = {
            summary: 'test data',
            journeyData: {
                activationDetails: onBoard.activationDetails,
                plan: this.cartService.getSelectedPlanFromCart() || [],
                addons: this.cartService.getSelectedAddOnFromCart(),
                contactDetails: onBoard.contactDetails,
                payment: paymentTransactionRequest,
                partyId: null,
                userId: null,
                customerId: this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION),
                customerStatus: 'In Progress',
                contractId: null,
                contractStatus: null,
                journeySessionId: null,
                shoppingCartId: cartDetails ? cartDetails.id : '',
                'pre-activatedBaseOffer': {
                    id: null
                }
            },
            currentStep: onBoard.currentStep,
            journeyId: 'Onboarding',
            journeyStatus: 'InProgress',
            journeyType: 'ONBOARDING',
            status: 'InProgress',
            type: 'PurchaseOrder',
            channelName: channelName,
            externalId: null,
            customerPurchaseOrder: this.generateCustomerPurchaseOrder(onBoard, cartDetails),
            customerIdentities: this.generateCustomerIdentities(onBoard),
            customerId: null,
            partyId: null,
            journeySessionId: null,
            userId: null,
            coreData: null
        };

        //pre-activated customer
        customerInteractionData.journeyData = Object.assign(customerInteractionData.journeyData, onBoard);
        customerInteractionData.journeyData['pre-activatedBaseOffer'].id = onBoard.preActivatedBaseOffer.id;

        //set customer id, party id outside
        customerInteractionData.customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION) || customerInteractionData.journeyData.customerId;
        customerInteractionData.journeyData.customerId = customerInteractionData.customerId;

        customerInteractionData.partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION) || customerInteractionData.journeyData.partyId;
        customerInteractionData.journeyData.partyId = customerInteractionData.partyId;

        customerInteractionData.journeySessionId = customerInteractionData.journeyData.journeySessionId;
        customerInteractionData.userId = customerInteractionData.journeyData.userId;

        //remove when customer id & journey session id is set
        if (customerInteractionData.journeyData.customerId
            &&
            customerInteractionData.journeyData.journeySessionId) {
            delete customerInteractionData.customerIdentities;
        }

        if (isSaveCart) {
            delete customerInteractionData.customerIdentities;
            delete customerInteractionData.customerPurchaseOrder;
            delete customerInteractionData.externalId;
            delete customerInteractionData.journeySessionId;
            delete customerInteractionData.summary;
            delete customerInteractionData.type;
            delete customerInteractionData.status;
        } else {
            delete customerInteractionData.currentStep;
            delete customerInteractionData.journeyStatus;
            delete customerInteractionData.journeyType;
        }

        if (!paymentTransactionRequest) {
            delete customerInteractionData.journeyData.payment;
        }

        //core data
        // {
        //     "productsAdded": 2,						<<No.of Products in Shopping cart with Action as add, if custom plan consider all custom products as 1>>
        //     "productsActive": 1,					<<No.of Products in Shopping cart with Action as active, if no products send 0>>
        //     "productsSwapped": 1,					<<No.of Products in Shopping cart with Action as swap, if no products send 0>>
        //     "summaryTextLabel": "OnboardingSummary" << OnboardingSummary,  Incase of Pre-ACtivated, OnboardingPreactivatedSummary Incase of Incase of Pre-ACtivated Swap, OnboardingPreactivatedSwapSummary >>
        // }
        // "OnboardingSummary": "{{noOfproductsAdded}} Product(s) Added"
        // "OnboardingPreactivatedSummary": "{{noOfproductsAdded}} Product(s) Added, {{noOfproductsActive}} Product Active"
        // "OnboardingPreactivatedSwapSummary": "{{noOfproductsAdded}} Product(s) Added, {{noOfproductsActive}} Product Active, {{noOfproductsSwapped}} Product Swap"
        if (cartDetails && cartDetails.cartList) {
            const customProductsAdded = cartDetails.cartList.filter(item => { return item.action === CARTACTION.ADD && item.productOffering.offerType.toLowerCase() === PLANTYPE.CUSTOMIZEPLANOFFER.toLowerCase() }).length;
            const productsAdded = cartDetails.cartList.filter(item => { return item.action === CARTACTION.ADD }).length;
            const productsActive = cartDetails.cartList.filter(item => { return item.action === CARTACTION.ACTIVE }).length;
            const productsSwapped = cartDetails.cartList.filter(item => { return item.action === CARTACTION.SWAP }).length;
            let summaryTextLabel;
            if (productsSwapped > 0) {
                summaryTextLabel = "OnboardingPreactivatedSwapSummary";
            }
            else if (productsSwapped > 0) {
                summaryTextLabel = "OnboardingPreactivatedSummary";
            }
            else {
                summaryTextLabel = "OnboardingSummary";
            }
            customerInteractionData.coreData = {
                productsAdded: customProductsAdded > 0 && customProductsAdded > 1 ? productsAdded - customProductsAdded + 1:  productsAdded,//consider custom plan as one product added to cart
                productsActive: productsActive,
                productsSwapped: productsSwapped,
                summaryTextLabel: summaryTextLabel
            }
        }


        return customerInteractionData;
    }

    public createCustomerInteraction(onBoard: customerOnboard,
        paymentRequest: PaymentTransactionRequest): Observable<any> {
        const cartDetails: cartDetails = this.cartService.cartDetails;
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.customerInteraction.indexOf('.json') !== -1) {
            url = environment.urls.paymentUpdate;
            httpResponse = this.http.get(url);
        } else {
            url = environment.urls.customerInteraction;
            httpResponse = this.http.post(url,
                this.generateCustomerInteractionData(onBoard, cartDetails, paymentRequest)
            );
        }
        return httpResponse.pipe(map((response: any) => {
            const mappedData: any = response;
            return mappedData;
        }
        ));
    }

    public createSaveCartJourneySessionInteraction(onBoard: customerOnboard,
        cartDetails: cartDetails, paymentTransactionRequest: PaymentTransactionRequest): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.saveCartJourneySession.indexOf('.json') !== -1) {
            url = environment.urls.saveCartJourneySession;
            httpResponse = this.http.get(url);
        } else {
            url = environment.urls.saveCartJourneySession;
            httpResponse = this.http.post(url,
                this.generateCustomerInteractionData(onBoard, cartDetails, paymentTransactionRequest, true)
            );
        }
        return httpResponse;
    }

    public updateSaveCartJourneySessionInteraction(onBoard: customerOnboard,
        cartDetails: cartDetails, paymentTransactionRequest: PaymentTransactionRequest): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.saveCartJourneySession.indexOf('.json') !== -1) {
            url = environment.urls.saveCartJourneySession;
            httpResponse = this.http.get(url);
        } else {
            url = `${environment.urls.saveCartJourneySession}/${onBoard.journeySessionId}`;
            httpResponse = this.http.put(url,
                this.generateCustomerInteractionData(onBoard, cartDetails, paymentTransactionRequest, true)
            );
        }
        return httpResponse;
    }
}
