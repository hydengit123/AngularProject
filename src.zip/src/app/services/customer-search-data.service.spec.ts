import { TestBed, inject } from '@angular/core/testing';

import { CustomerSearchDataService } from './customer-search-data.service';

describe('CustomerSearchDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CustomerSearchDataService]
    });
  });

  it('should be created', inject([CustomerSearchDataService], (service: CustomerSearchDataService) => {
    expect(service).toBeTruthy();
  }));
});
