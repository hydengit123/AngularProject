import { TestBed } from '@angular/core/testing';
import { SubscriptionProduct } from '../interface/subscription';
import { UtilService } from './util.service';
import Product = SubscriptionProduct.Product;

describe('UtilService', () => {
    let utilService: UtilService;
    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [UtilService]
        });
    });

    beforeEach(() => {
        utilService = TestBed.get(UtilService);
    });

    it('should be created', () => {
        expect(utilService).toBeTruthy();
    });

    describe('getCustomerPlanFromSubscription method should', () => {
        it('retrun currentPlan for "Premium" productGroup', () => {
            const products: Product[] = [
                {
                    "productId": "CM_Combo_556",
                    "productName": "50GB and Unlimited SMS and Voice Combo",
                    "productType": "Combo",
                    "productGroup": "Premium",
                    "price": 2500,
                    "paymentMode": "AIR",
                    "srcChannel": "SELFCARE",
                    "numberOfPendingRenewals": 9998,
                    "nextRenewalDate": "01-03-2019 14:30:42",
                    "provisionedQuota": {
                        "voice": {
                            "unit": -1,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": -1,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "availableQuota": {
                        "voice": {
                            "unit": -1,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": -1,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 53687091200,
                            "unitType": "6"
                        },
                        "other": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "activationDate": "30-01-2019 14:30:00",
                    "expiryDate": "01-03-2019 14:30:42",
                    "isRecurring": true
                },
                {
                    "productId": "CM_Combo_574",
                    "productName": "Roaming data 10gb 1000mins 1000sms",
                    "productType": "Combo",
                    "productGroup": "standard",
                    "price": 2500,
                    "paymentMode": "AIR",
                    "srcChannel": "SELFCARE",
                    "numberOfPendingRenewals": 0,
                    "nextRenewalDate": "01-03-2019 14:30:00",
                    "provisionedQuota": {
                        "voice": {
                            "unit": 60000,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": 1000,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 10737418240,
                            "unitType": "6"
                        }
                    },
                    "availableQuota": {
                        "voice": {
                            "unit": 60000,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": 1000,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 10737418240,
                            "unitType": "6"
                        },
                        "other": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "activationDate": "30-01-2019 14:30:43",
                    "expiryDate": "01-03-2019 14:30:00",
                    "isRecurring": false
                }
            ]

            const result = utilService.getCustomerPlanFromSubscription(products);
            expect(result).toBe(products[0]);
        });

        it('retrun currentPlan for "Standard" productGroup', () => {
            const products: Product[] = [
                {
                    "productId": "CM_Combo_556",
                    "productName": "50GB and Unlimited SMS and Voice Combo",
                    "productType": "Combo",
                    "productGroup": "addon",
                    "price": 2500,
                    "paymentMode": "AIR",
                    "srcChannel": "SELFCARE",
                    "numberOfPendingRenewals": 9998,
                    "nextRenewalDate": "01-03-2019 14:30:42",
                    "provisionedQuota": {
                        "voice": {
                            "unit": -1,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": -1,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "availableQuota": {
                        "voice": {
                            "unit": -1,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": -1,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 53687091200,
                            "unitType": "6"
                        },
                        "other": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "activationDate": "30-01-2019 14:30:00",
                    "expiryDate": "01-03-2019 14:30:42",
                    "isRecurring": true
                },
                {
                    "productId": "CM_Combo_574",
                    "productName": "Roaming data 10gb 1000mins 1000sms",
                    "productType": "Combo",
                    "productGroup": "standard",
                    "price": 2500,
                    "paymentMode": "AIR",
                    "srcChannel": "SELFCARE",
                    "numberOfPendingRenewals": 0,
                    "nextRenewalDate": "01-03-2019 14:30:00",
                    "provisionedQuota": {
                        "voice": {
                            "unit": 60000,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": 1000,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 10737418240,
                            "unitType": "6"
                        }
                    },
                    "availableQuota": {
                        "voice": {
                            "unit": 60000,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": 1000,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 10737418240,
                            "unitType": "6"
                        },
                        "other": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "activationDate": "30-01-2019 14:30:43",
                    "expiryDate": "01-03-2019 14:30:00",
                    "isRecurring": false
                }
            ]

            const result = utilService.getCustomerPlanFromSubscription(products);
            expect(result).toBe(products[1]);
        });

        it('retrun currentPlan for "Standard" productGroup', () => {
            const products: Product[] = [
                {
                    "productId": "CM_Combo_556",
                    "productName": "50GB and Unlimited SMS and Voice Combo",
                    "productType": "Combo",
                    "productGroup": "addon",
                    "price": 2500,
                    "paymentMode": "AIR",
                    "srcChannel": "SELFCARE",
                    "numberOfPendingRenewals": 9998,
                    "nextRenewalDate": "01-03-2019 14:30:42",
                    "provisionedQuota": {
                        "voice": {
                            "unit": -1,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": -1,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "availableQuota": {
                        "voice": {
                            "unit": -1,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": -1,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 53687091200,
                            "unitType": "6"
                        },
                        "other": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "activationDate": "30-01-2019 14:30:00",
                    "expiryDate": "01-03-2019 14:30:42",
                    "isRecurring": true
                },
                {
                    "productId": "CM_Combo_574",
                    "productName": "Roaming data 10gb 1000mins 1000sms",
                    "productType": "Combo",
                    "productGroup": "standard",
                    "price": 2500,
                    "paymentMode": "AIR",
                    "srcChannel": "SELFCARE",
                    "numberOfPendingRenewals": 0,
                    "nextRenewalDate": "01-03-2019 14:30:00",
                    "provisionedQuota": {
                        "voice": {
                            "unit": 60000,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": 1000,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 10737418240,
                            "unitType": "6"
                        }
                    },
                    "availableQuota": {
                        "voice": {
                            "unit": 60000,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": 1000,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 10737418240,
                            "unitType": "6"
                        },
                        "other": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "activationDate": "30-01-2019 14:30:43",
                    "expiryDate": "01-03-2019 14:30:00",
                    "isRecurring": false
                }
            ]

            const result = utilService.getCustomerPlanFromSubscription(products);
            expect(result).toBe(products[1]);
        });

        it('retrun currentPlan for "customPlans" productGroup', () => {
            const products: Product[] = [
                {
                    "productId": "CM_Combo_556",
                    "productName": "50GB and Unlimited SMS and Voice Combo",
                    "productType": "data",
                    "productGroup": "customizeplanoffer",
                    "price": 2500,
                    "paymentMode": "AIR",
                    "srcChannel": "SELFCARE",
                    "numberOfPendingRenewals": 9998,
                    "nextRenewalDate": "01-03-2019 14:30:42",
                    "provisionedQuota": {
                        "voice": {
                            "unit": -1,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": -1,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "availableQuota": {
                        "voice": {
                            "unit": -1,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": -1,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 53687091200,
                            "unitType": "6"
                        },
                        "other": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "activationDate": "30-01-2019 14:30:00",
                    "expiryDate": "01-03-2019 14:30:42",
                    "isRecurring": true
                },
                {
                    "productId": "CM_Combo_574",
                    "productName": "Roaming data 10gb 1000mins 1000sms",
                    "productType": "voice",
                    "productGroup": "customizeplanoffer",
                    "price": 2500,
                    "paymentMode": "AIR",
                    "srcChannel": "SELFCARE",
                    "numberOfPendingRenewals": 0,
                    "nextRenewalDate": "01-03-2019 14:30:00",
                    "provisionedQuota": {
                        "voice": {
                            "unit": 60000,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": 1000,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 10737418240,
                            "unitType": "6"
                        }
                    },
                    "availableQuota": {
                        "voice": {
                            "unit": 60000,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": 1000,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 10737418240,
                            "unitType": "6"
                        },
                        "other": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "activationDate": "30-01-2019 14:30:43",
                    "expiryDate": "01-03-2019 14:30:00",
                    "isRecurring": false
                },
                {
                    "productId": "CM_Combo_575",
                    "productName": "Roaming data 10gb 1000mins 1000sms",
                    "productType": "sms",
                    "productGroup": "customizeplanoffer",
                    "price": 2500,
                    "paymentMode": "AIR",
                    "srcChannel": "SELFCARE",
                    "numberOfPendingRenewals": 0,
                    "nextRenewalDate": "01-03-2019 14:30:00",
                    "provisionedQuota": {
                        "voice": {
                            "unit": 60000,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": 1000,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 10737418240,
                            "unitType": "6"
                        }
                    },
                    "availableQuota": {
                        "voice": {
                            "unit": 60000,
                            "unitType": "0"
                        },
                        "sms": {
                            "unit": 1000,
                            "unitType": "1"
                        },
                        "data": {
                            "unit": 10737418240,
                            "unitType": "6"
                        },
                        "other": {
                            "unit": 53687091200,
                            "unitType": "6"
                        }
                    },
                    "activationDate": "30-01-2019 14:30:43",
                    "expiryDate": "01-03-2019 14:30:00",
                    "isRecurring": false
                }
            ]
            const result = utilService.getCustomerPlanFromSubscription(products);
            //console.log(result);
            expect(result.productId).toBe('CM_Combo_556^^CM_Combo_574^^CM_Combo_575');
            expect(result.productType).toBe('null^^data^^voice^^sms');
            expect(result.productGroup).toBe('custom');

            expect(result.activationDate).toBe('30-01-2019 14:30:43');
            expect(result.expiryDate).toBe('01-03-2019 14:30:00');
            expect(result.isRecurring).toBeFalsy();
        });
    });
});
