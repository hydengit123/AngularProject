import { TestBed, inject } from '@angular/core/testing';

import { PreviousRouteService } from './previous-route.service';
import { Router, NavigationStart } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
describe('PreviousRouteService', () => {

  let previousRouteService: PreviousRouteService;
  let routerSpy: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const RouterSpy = jasmine.createSpyObj('Router', ['get']);
    let event = new NavigationStart(1, 'home');
    RouterSpy['events'] = { subscribe: (cb) => { cb(event) } };
    RouterSpy['url'] = 'demourl';
    TestBed.configureTestingModule({
      providers: [
        PreviousRouteService,
        { provide: Router, useValue: RouterSpy }
      ],
      imports: [RouterTestingModule]
    });
  });

  beforeEach(() => {
    previousRouteService = TestBed.get(PreviousRouteService);
    routerSpy = TestBed.get(Router);
  })

  it('should be created', () => {
    expect(previousRouteService).toBeTruthy();
  });

  it('Get Previous Url', () => {
    const url = previousRouteService.getPreviousUrl();
    expect(url).toBe('demourl');
  })
});
