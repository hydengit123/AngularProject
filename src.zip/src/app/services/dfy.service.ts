import { HttpClient } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CARTACTION, cartDetails, CARTITEM, CMUICONFIGKEY, contractItem, DataFormatterPipe, itemPrice, orderItem, PaymentRequestInfo, planoffer, PRICETYPE, productBucket, productItem, resource } from 'dxp-common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PERSISTANCEKEY } from '../../application-constants';
import { environment } from '../../environments/environment';
import { EventListenerService } from '../event-listener.service';
import { CartService } from '../services/cart.service';
import { PaymentGatewayService } from '../services/payment-gateway.service';
import { CustomerSearchService } from './customer-search.service';
import { EventEnum } from '../enum/EventEnum';

declare const alertify;

@Injectable({
    providedIn: 'root'
})
export class DealsForYouService implements OnInit {

    public someData: any;
    private dataFormatterPipe: DataFormatterPipe = new DataFormatterPipe(this.translateService);
    public currentContract = null;
    public journeySessionId = null;

    constructor(private http: HttpClient,
        private persistenceService: PersistenceService,
        private cartService: CartService,
        private paymentGatewayService: PaymentGatewayService,
        private translateService: TranslateService,
        private router: Router,
        private customerSearchService: CustomerSearchService,
        private event: EventListenerService, ) {

    }

    ngOnInit() {

    }

    getPromottedOffers() {
        let currentContract = this.customerSearchService.getCurrentContract();
        let url = environment.urls.promotedoffers;
        let configUrl = 'https://' + this.persistenceService.get(CMUICONFIGKEY.CI_SERVICE_NAME, StorageType.SESSION);

        const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';

        return this.http.get(configUrl + url + currentContract.msisdn + '?identityType=MSISDN&channel=' + channelName);
    }

    loadPromotedOffers(): Observable<any> {
        let currentContract = this.customerSearchService.getCurrentContract();
        let httpResponse: Observable<any>;
        let url = environment.urls.promotedoffers;
        let configUrl = 'https://' + this.persistenceService.get(CMUICONFIGKEY.CI_SERVICE_NAME, StorageType.SESSION);

        const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        httpResponse = this.http.get(configUrl + url + currentContract.msisdn + '?identityType=MSISDN&channel=' + channelName)

        return httpResponse.pipe(
            map((offers: any) => {
                return offers.promotions[0].offers.map((offer) => {
                    return offer.prodOfferId;
                });
            }));


    }

    loadRecommendedOffers(id): Observable<any> {
        let httpResponse: Observable<any>;
        let url = environment.urls.recommendedoffers;
        let configUrl = 'https://' + this.persistenceService.get(CMUICONFIGKEY.CI_SERVICE_NAME, StorageType.SESSION);

        httpResponse = this.http.get(configUrl + url + id + '?type=WHOBOUGHT&similarType=true&numrec=100')

        return httpResponse.pipe(
            map((offers: any) => {
                return offers;
            }));


    }


    getPlanAddonsDetails(lang: string, offerType: any, customerProfile): Observable<any> {
        let url = '';
        let localDomain = '';
        const channel = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        const location = customerProfile.address[3];
        //const segment = customerProfile.customerSegment.segmentId;
        let httpResponse: Observable<any>;
        if (!environment.production) {
            localDomain = environment.localCMSDomain;
        }
        if (environment.urls.getCustomerPlanDetails.indexOf(".json") !== -1) {
            url = environment.urls.getCustomerPlanDetails;
            httpResponse = this.http.get(url);
        }
        else {
            url = environment.urls.getCustomerPlanDetails;
            let requestObject = {
                "eligibilityDate": new Date(),
                "offerType": offerType,
                "productCategory": [
                    {
                        "name": "COMBO"
                    },
                    {
                        "name": "DATA"
                    },
                    {
                        "name": "VOICE"
                    },
                    {
                        "name": "SMS"
                    }
                ],
                "productOfferingRelationship": {
                    "relationType": "string"
                },
                "language": lang,
                "contextCharacteristic": []
            };
            requestObject.contextCharacteristic.push(this.createcontextCharacteristic('salesChannel', channel));
            if (location) {
                requestObject.contextCharacteristic.push(this.createcontextCharacteristic('location', location));
            }
            //if (segment) {
            //requestObject.contextCharacteristic.push(this.createcontextCharacteristic('customerType', 'New'));
            //}
            httpResponse = this.http.post(url, requestObject);
        }

        return httpResponse.pipe(
            map((res: any) => {
                this.someData = res;

                return res;
            }));
    }

    createcontextCharacteristic(name, value) {
        const contextObj = {
            "name": name,
            "valueInstances": [
                {
                    "values": [
                        {
                            "value": value
                        }
                    ]
                }
            ]
        };
        return contextObj;
    }

    fetchLocation(customerProfile) {
        let locationValue = '';
        //const locationType = this.persistenceService.get(CMUICONFIGKEY.CONTACT_MEDIUM_FOR_LOCATION, StorageType.SESSION)['type'];
        const locationType = 'PostalContact';
        customerProfile.contactMedium.forEach(medium => {
            if (medium.toLowerCase() === locationType.toLowerCase()) {
                medium.value.forEach(mediumValue => {
                    if (mediumValue.purpose.toLowerCase() === 'city') {
                        locationValue = mediumValue.value;
                    }
                });
            }
        });
        return locationValue;
    }

    public productBucketArray = ["data", "voice", "sms"];

    getCMSDigitalAssets(items, lang, offerType): Observable<planoffer[]> {
        let url = '';
        let localDomain = '';
        let httpResponse: Observable<any>;
        // let products = items.map(data => {
        //     return { id: data.id };
        // })
        // let productTypes =  offerType;


        if (!environment.production) {
            localDomain = environment.localCMSDomain;
        }
        if (environment.urls.getPlanOffersImages.indexOf(".json") !== -1) {
            url = environment.urls.getPlanOffersImages;
            httpResponse = this.http.get(url);
        }
        else {

            url = environment.urls.getPlanOffersImages;
            httpResponse = this.http.post(url, {
                "languageCode": lang,
                "productTypes": offerType,
                "channels": [],
                "locations": [],
                "products": []

            }
            )
        }

        return httpResponse.pipe(map((response: any) => {
            if (response && response.products) {
                let productList: any[] = [];
                if (Array.isArray(response.products)) {
                    productList = response.products;
                } else {
                    productList.push(response.products);
                }
                return productList.map((prod) => {
                    let filteredItem = {};
                    let filteredItems = items.filter(d => d.id === prod.id);
                    let noCMSImage: boolean = false;
                    if (filteredItems && filteredItems[0]) {
                        filteredItem = filteredItems[0];
                    }
                    else if (!prod.coverImage) {

                        noCMSImage = true;
                    }
                    let mappedData: planoffer = {
                        "deal": false,
                        "title": prod.title || "",
                        "summary": prod.summary || "",
                        // "description": res.description,
                        "coverImage": noCMSImage ? "/assets/imgs/no-image-icon.png" : localDomain + prod.coverImage,
                        "frontImage": prod.frontImage || "",
                        "backImage": prod.backImage || "",
                        "id": filteredItem['id'] || prod.id || "",
                        "name": filteredItem['name'] || "",
                        "description": prod.description || "",

                        "offerType": filteredItem['offerType'] || "",
                        "productOfferingPrice": filteredItem['productOfferingPrice']
                            && filteredItem['productOfferingPrice']['0']
                            && filteredItem['productOfferingPrice']['0']['price']
                            && filteredItem['productOfferingPrice']['0']['price']['amount']
                            ? filteredItem['productOfferingPrice']['0']['price']['amount'] : 0,
                        "priceType": filteredItem['productOfferingPrice']
                            && filteredItem['productOfferingPrice']['0']
                            && filteredItem['productOfferingPrice']['0']['priceType']
                            ? filteredItem['productOfferingPrice']['0']['priceType'] : null,
                        "productBuckets": filteredItem['productBuckets'] ?
                            filteredItem['productBuckets'].map(item => {
                                const productBucket: productBucket = this.calculateDisplay(item);
                                return productBucket;
                            }) : null,
                        periodTypes: filteredItem['productOfferingPrice']
                            && filteredItem['productOfferingPrice']['0']
                            && filteredItem['productOfferingPrice']['0']['recurrencePeriod']
                            && filteredItem['productOfferingPrice']['0']['recurrencePeriod']['periodType']
                            ? filteredItem['productOfferingPrice']['0']['recurrencePeriod']['periodType'] : null,
                        recurrencePeriod: filteredItem['productOfferingPrice']
                            && filteredItem['productOfferingPrice']['0']
                            && filteredItem['productOfferingPrice']['0']['recurrencePeriod']
                            ? filteredItem['productOfferingPrice']['0']['recurrencePeriod'] : null,
                        currency: filteredItem['productOfferingPrice']
                            && filteredItem['productOfferingPrice']['0']
                            && filteredItem['productOfferingPrice']['0']['price']
                            && filteredItem['productOfferingPrice']['0']['price']['currency'] ?
                            filteredItem['productOfferingPrice']['0']['price']['currency']
                            // this.checkProductCurrency(filteredItem['productOfferingPrice']['0']['price']['currency'])
                            : null
                    }

                    return mappedData;
                })
            } else if (Object.keys(response).length === 0) {
                return [];
            }
        }
        ));


    }

    calculateDisplay(prod: productBucket): productBucket {
        if (prod.initialBalance === 0) {
            prod.forDisplay = null;
        }
        else if (prod.serviceName === "sms") {
            prod.forDisplay = `${this.dataFormatterPipe.transform(prod.initialBalance, prod.unitOfMeasure)}`;
        }
        else if (prod.serviceName === "data") {
            prod.forDisplay = `${this.dataFormatterPipe.transform(prod.initialBalance, prod.unitOfMeasure, false)} Data`;
        }
        else if (prod.serviceName === "voice") {
            prod.forDisplay = `${this.dataFormatterPipe.transform(prod.initialBalance, prod.unitOfMeasure)}`;
        }
        return prod;
    }

    public addToCart(item: planoffer, contractDetails, userProfile) {
        if (this.cartService.cartDetails && this.cartService.cartDetails.id) {
            return this.cartService.updateCart([this.convertPlanToCartProductItem(item, CARTACTION.ADD, contractDetails)]);
        } else {
            return this.cartService.createCart([this.convertPlanToCartProductItem(item, CARTACTION.ADD, contractDetails)], this.createCartDetailsWithResource(contractDetails, userProfile));
        }
    }

    public createSaveCartJourney(contractDetails, cartDetails, userProfile, paymentRequest, createSaveCartJourney) {
        let userData = {
            phoneNumber: contractDetails.msisdn
        };
        if (createSaveCartJourney) {
            return this.createSaveCartJourneySessionInteraction(userData, cartDetails, userProfile, paymentRequest);
        } else {
            return this.updateSaveCartJourneySessionInteraction(userData, cartDetails, userProfile, paymentRequest);
        }
    }

    convertPlanToCartProductItem(plan: planoffer, transactionType: string, contractDetails): productItem {
        this.currentContract = this.customerSearchService.getCurrentContract();
        const productItem: productItem = {
            action: transactionType,
            type: 'ProductItem',
            quantity: 1,
            productOffering: {
                id: plan.id,
                name: plan.name,
                offerType: plan.offerType
            },
            itemPrice: [],
            resource: [],
        };

        const itemPrice: itemPrice = {
            priceType: plan.priceType,
            recurrenceFrequency: plan.priceType === PRICETYPE.RECURRING ? 'Custom' : null,
            recurrencePeriod: plan.recurrencePeriod,
            price: {
                amount: plan.productOfferingPrice,
                currency: plan.currency
            }
        };
        if (contractDetails.contract.resources[0]) {
            const MSISDNResource: resource = {
                resourceNumber: contractDetails.contract.resources[0].resourceNumber || '',
                resourceType: CARTITEM.MSISDNRESOURCETYPE,
                resourceSubType: null,
            };
            productItem.resource.push(MSISDNResource);
        }
        if (contractDetails.contract.resources[1]) {
            const SIMResource: resource = {
                resourceNumber: contractDetails.contract.resources[1].resourceNumber || '',
                resourceType: CARTITEM.SIMRESOURCETYPE,
                resourceSubType: null
            };
            productItem.resource.push(SIMResource);
        }
        productItem.itemPrice.push(itemPrice);
        return productItem;
    }

    createCartDetailsWithResource(contractDetails, userProfile): cartDetails {
        const name = userProfile.firstName + ' ' + userProfile.lastName
        const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        const cartDetails: cartDetails = {
            createdBy: name,
            createdByChannel: channelName,
            updatedBy: name,
            lastUpdatedByChannel: channelName,
            cartItem: [],
            id: null,
            cartList: null,
            totalPrice: []
        };


        if (this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION)) {
            cartDetails["relatedParty"] = [
                {
                    "id": this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION),
                    "partyRoleType": "customer",
                    "role": "customer"
                }

            ]
        }
        const contractItem = this.createContractItem(contractDetails);
        cartDetails.cartItem.push(contractItem);
        return cartDetails;
    }

    createContractItem(contractDetails): contractItem {
        this.currentContract = this.customerSearchService.getCurrentContract();
        let msisdn;
        if (contractDetails.contract.resources[0].subType.toLowerCase() === 'msisdn') {
            msisdn = contractDetails.contract.resources[0].resourceNumber;
        }
        const contractItem: contractItem = {
            action: CARTACTION.ADD,
            type: CARTITEM.CONTRACTITEM,
            paymentContext: 'Prepaid',
            resource: [],
            id: contractDetails.contract.id
        };
        const MSISDNResource: resource = {
            resourceNumber: msisdn || '',
            resourceType: CARTITEM.MSISDNRESOURCETYPE,
            resourceSubType: null,

        };
        contractItem.resource.push(MSISDNResource);
        return contractItem;
    }

    public paymentResponseHandler(userData, paymentRequest: PaymentRequestInfo, customerProfile) {
        let responseData = {};
        if (userData) {
            responseData = {
                responseHandler: (BOLT) => {
                    return this.paymentSuccessHandler(BOLT, userData, paymentRequest, customerProfile);
                },
                catchException: (BOLT) => {
                    return this.paymentFailureHandler(BOLT, userData);
                }
            }
        }
        return responseData;
    }

    private async paymentSuccessHandler(BOLT, userData, paymentRequest: PaymentRequestInfo, customerProfile) {
        let contractDetails = this.customerSearchService.getCurrentContract();
        let userProfile = this.customerSearchService.getUserProfile();
        if (BOLT.response && BOLT.response.txnStatus == "SUCCESS"
            && BOLT.response.txnid) {
            let paymentTransactionRequest = {
                resourceNumber: this.paymentGatewayService.paymentConfigSelected.resourceNumber,//MSISDN from customer journey
                payer: BOLT.response.payer || 'NA',//NA in old code
                merchantRefNum: this.paymentGatewayService.paymentConfigSelected.merchantRefNum,//merchantRefNum from create payment service
                paymentGwTransactionId: BOLT.response.txnid || BOLT.response.payuMoneyId || paymentRequest.txnid,
                status: BOLT.response.status,
                paymentToken: BOLT.response.paymentId || '',//empty in old code
                paymentMethod: BOLT.response.mode,
                expiryDate: BOLT.response.addedon || '',//empty in old code
                cardNumber: BOLT.response.cardnum || '', //cardnum from payumoney
                amount: BOLT.response.amount
            };
            const paymentInfo = await this.paymentGatewayService.updatePayment(paymentTransactionRequest).toPromise();
            if (this.paymentGatewayService.msisdn === paymentTransactionRequest.resourceNumber && this.paymentGatewayService.allowPayment && this.paymentGatewayService.totalAmount === this.cartService.cartDetails.totalPrice[0].price.amount) {
                this.paymentGatewayService.allowPayment = false;
                const paymentInfo = await this.paymentGatewayService.updatePayment(paymentTransactionRequest).toPromise();
                if (paymentInfo && paymentInfo.message && paymentInfo.message === 'SUCCESS') {
                    this.createSaveCartJourney(contractDetails, this.cartService.cartDetails, userProfile, paymentRequest, false).subscribe(result => {
                        this.journeySessionId = result.id;
                    }, error => {
                    });
                    const customerInteractionResponse = await this.createCustomerInteraction(userData, customerProfile, paymentTransactionRequest).toPromise();
                    if (customerInteractionResponse) {
                        this.redirectToSucessView(customerInteractionResponse);

                    }
                } else {
                    alertify.error(this.translateService.instant('Payment Failed'));
                }
            }
        }
        else {
            alertify.error(this.translateService.instant('Payment has been cancelled'));
        }
    }

    public redirectToSucessView(customerInteractionResponse) {
        this.cartService.cartDetails = {
            cartItem: [],
            cartList: [],
            id: '',
            createdBy: '',
            createdByChannel: '',
            updatedBy: '',
            lastUpdatedByChannel: '',
            totalPrice: []
        };
        this.paymentGatewayService.orderId = customerInteractionResponse.id;
        this.cartService.cartDetails.cartList = [];
        this.cartService.cartDetails.totalPrice = [];
        this.cartService.cartDetails.id = '';
        this.cartService.cartDetails.cartItem = [];
        // this.cartService.clearCart();
        this.cartService.quantityMap = {};
        this.event.showPaymentSuccess();
        this.event.dashboardEvent.emit({ eventType: EventEnum.dashboardRefresh });
        this.event.notifyCartUpdate(this.cartService.cartDetails);
        this.router.navigate(['/dashboard']);
    }

    private paymentFailureHandler(BOLT, userData) {
        alertify.error(this.translateService.instant(BOLT.message));
    }

    private generateCustomerInteractionData(userData, cartDetails: cartDetails, customerProfile, paymentRequest) {
        const channelName = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        const locationName = customerProfile.address[3];
        let customerInteractionData = {
            partyId: null,
            status: 'InProgress',
            customerId: null,
            journeyId: "BuyAddon",
            journeySessionId: null,
            type: "PurchaseOrder",
            channelName: cartDetails.createdByChannel,
            customerPurchaseOrder: this.generateCustomerPurchaseOrder(userData, cartDetails),
            coreData: {
                noAddOns: this.cartService.getSelectedAddOnFromCart().length,
                summaryTextLabel: 'BUY_AN_ADDON_CI_SUMMARY_LABEL'
            },
            journeyData: {
                addons: this.cartService.getSelectedAddOnFromCart(),
                offerType: [
                    "DATA",
                    "VOICE",
                    "SMS",
                    "COMBO"
                ],
                productCategory: this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMES_FORADDONQUERY, StorageType.SESSION),
                salesChannel: channelName,
                location: locationName,
                // customerSegment: "New",
                currentStep: 6,
                shoppingCartId: cartDetails.id,
                payment: paymentRequest
            }
        };

        //set customer id, party id outside
        customerInteractionData.customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
        customerInteractionData.partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
        customerInteractionData.journeySessionId = this.journeySessionId;


        return customerInteractionData;
    }

    public createCustomerInteraction(userData, customerProfile, paymentTransactionRequest): Observable<any> {
        const cartDetails: cartDetails = this.cartService.cartDetails;
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.customerInteraction.indexOf(".json") !== -1) {
            url = environment.urls.paymentUpdate;
            httpResponse = this.http.get(url);
        }
        else {
            url = environment.urls.customerInteraction;
            httpResponse = this.http.post(url,
                this.generateCustomerInteractionData(userData, cartDetails, customerProfile, paymentTransactionRequest)
            );
        }
        return httpResponse.pipe(map((response: any) => {
            let mappedData: any = response;
            return mappedData;
        }
        ));
    }

    private generateOrderItems(userData, cartDetails: cartDetails): orderItem[] {
        const orders: orderItem[] = cartDetails.cartList.map(x => {
            //if (x.action !== CARTACTION.ACTIVE)
            return {
                type: "ProductOrderItem",//x.type,
                msisdn: userData.phoneNumber,
                action: x.action, //CARTACTION.ADD
                description: x.productOffering.id,
                createdBy: cartDetails.createdBy,
                updatedBy: cartDetails.updatedBy
            }
        });
        return orders;
    }

    private generateCustomerPurchaseOrder(userData, cartDetails: cartDetails) {
        const customerOrder = {
            createdBy: cartDetails.createdBy,
            orderDate: '',
            updatedBy: cartDetails.updatedBy,
            createdByChannel: cartDetails.createdByChannel,
            lastUpdatedByChannel: cartDetails.createdByChannel,
            state: "InProgress",
            type: "PurchaseOrder",
            orderItem: this.generateOrderItems(userData, cartDetails)
        }
        return customerOrder;
    }

    public createSaveCartJourneySessionInteraction(userData, cartDetails: cartDetails, customerProfile, paymentRequest): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.saveCartJourneySession.indexOf(".json") !== -1) {
            url = environment.urls.saveCartJourneySession;
            httpResponse = this.http.get(url);
        }
        else {
            url = environment.urls.saveCartJourneySession;
            httpResponse = this.http.post(url,
                this.generateCustomerInteractionDataSaveJourney(userData, cartDetails, customerProfile, paymentRequest)
            );
        }
        return httpResponse;
    }

    public updateSaveCartJourneySessionInteraction(userData, customerProfile,
        cartDetails: cartDetails, paymentRequest): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.saveCartJourneySession.indexOf(".json") !== -1) {
            url = environment.urls.saveCartJourneySession;
            httpResponse = this.http.get(url);
        }
        else {
            url = `${environment.urls.saveCartJourneySession}/${this.journeySessionId}`;
            httpResponse = this.http.put(url,
                this.generateCustomerInteractionDataSaveJourney(userData, cartDetails, customerProfile, paymentRequest)
            );
        }
        return httpResponse;
    }

    private generateCustomerInteractionDataSaveJourney(userData, cartDetails: cartDetails, customerProfile, paymentRequest) {
        const channel = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION)['channelName'] || 'SelfCare';
        const locationName = (customerProfile && customerProfile.address) ? customerProfile.address[3] : '';
        let customerInteractionData = {
            partyId: null,
            journeyStatus: 'InProgress',
            customerId: null,
            journeyId: "BuyAddon",
            journeyType: "BuyAddon",
            currentStep: 6,
            channelName: channel,
            journeyData: {
                addons: this.cartService.getSelectedAddOnFromCart(),
                offerType: [
                    "DATA",
                    "VOICE",
                    "SMS",
                    "COMBO"
                ],
                productCategory: this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMES_FORADDONQUERY, StorageType.SESSION),
                currentStep: 6,
                shoppingCartId: cartDetails.id || this.cartService.cartDetails.id,
                payment: paymentRequest,
                salesChannel: channel,
                location: locationName
            }
        };

        //set customer id, party id outside
        customerInteractionData.customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
        customerInteractionData.partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);


        return customerInteractionData;
    }

    getJourneySessionData(id) {
        let httpResponse: Observable<any>;
        let customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
        const url = environment.urls.getAddonJourneySession.replace('{customerId}', customerId).replace('{journeyId}', 'BuyAddon');
        httpResponse = this.http.get(url);
        return httpResponse;
    }

    deleteJourneySessionData(journeySessionId) {
        let httpResponse: Observable<any>;
        const url = environment.urls.deleteJourneySession + journeySessionId;
        httpResponse = this.http.delete(url);
        return httpResponse;
    }


}
