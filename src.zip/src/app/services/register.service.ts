import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, OnInit } from '@angular/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PERSISTANCEKEY, REGEX } from "../../application-constants";
import { environment } from '../../environments/environment';
import { DataClientService } from '../data-client.service';



@Injectable()
export class RegisterService implements OnInit {
    httpOptions: any = null;
    constructor(
        private http: HttpClient,
        private persistenceService: PersistenceService,
        private dataClientService: DataClientService) {

    }
    ngOnInit() {
    }

    emailCheck(value): Observable<any> {
        let url = '';
        let requestPayload = {};
        let httpResponse: Observable<any>;
        let email = value;
        const name = value.match(REGEX.ONLYDIGIT) ?'msisdn' : 'email';
        
        requestPayload = {
        "name":name,
        "value":email,
        "operator":"=="
        }

        let access_token = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);

        this.httpOptions = {
            headers: new HttpHeaders({
                'Authorization': 'Bearer '+access_token
            })
        };

        url = environment.urls.userprofile;

        httpResponse = this.http.post(url,requestPayload,this.httpOptions);

        return httpResponse.pipe(map((response:any) => {
            return response;
        }));
    }

    userRegister(param){
        let url = '';
        const name = param.username.match(REGEX.ONLYDIGIT) ?'MSISDN' : 'Email';
        let httpResponse: Observable<any>;
        if (environment.urls.fraudCheck.indexOf(".json") !== -1) {
            url = environment.urls.fraudCheck;
            httpResponse = this.http.get(url);
        }
        else {
            let headers: any = {};
        let access_token = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
        headers['Authorization'] = 'Bearer ' + access_token;
            const requestPayload = {
                "firstName": "undefined",
                "lastName": "undefined",
                "optedForSelfcareRegistration": "true",
                "identities": [  {
                    "identifier": param.username,
                    "identityType": name 
                }
            ]
            } 
        
            url = environment.urls.saveCart;
            httpResponse = this.http.post(url, requestPayload,headers)
        }
        return httpResponse;
    }

    userLoginCheck(param){
        let username = param.username;
        let password = param.user_otp;
        return this.http.get(`${environment.urls.login}?username=${btoa(username)}&password=${btoa(password)}`)
    }

    resetPassword(userObject) {
        let headers: any = {};
        let access_token = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
        headers['Authorization'] = 'Bearer ' + access_token;
    
        return this.http.put(environment.urls.credUrl, userObject,headers)
    }
    otpResent(data){
        //const name = data.username;
        let httpResponse: Observable<any>;
        httpResponse = this.http.get(`${environment.urls.otpUrl}?username=${btoa(data)}`)

        return httpResponse;
    }

}
