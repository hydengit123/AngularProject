import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { PaymentConfigResponse, PaymentRequestInfo, PaymentTransactionRequest } from 'dxp-common';
import { sha512 } from 'js-sha512';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { WEBCONTENTPERSISTANCEKEY } from '../../application-constants';
import { environment } from '../../environments/environment';
import { EventListenerService } from '../event-listener.service';
import { CartService } from './cart.service';

declare const alertify;

@Injectable({
    providedIn: 'root'
})
export class PaymentGatewayService {
    public boltRef: any = window['bolt'];
    public paymentConfigSelected: PaymentConfigResponse;
    public orderId: string;
    public transactionId: string;
    public email: string;
    public msisdn: string;
    public name: string;
    public totalAmount: number;
    public allowPayment: boolean;


    constructor(private http: HttpClient,
        private translateService: TranslateService,
        private router: Router,
        private persistanceService: PersistenceService,
    private cartService: CartService,
    private eventListenerService: EventListenerService) { }

    private generateRandomNumber() {
        const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz';
        const string_length = 50;
        let randomstring = '';
        for (let i = 0; i < string_length; i++) {
            const rnum = Math.floor(Math.random() * chars.length);
            randomstring += chars.substring(rnum, rnum + 1);
        }
        return randomstring;
    }

    public launchPaymentBolt(paymentRequest: PaymentRequestInfo,
        paymentGatewaySelected: string,
        msisdn: string,
        currency: string,
        successURL: string,
        failureURL: string,
        responseHandler: any) {
        this.msisdn = msisdn;
        paymentRequest.txnid = this.generateRandomNumber();
        paymentRequest.surl = window.location.origin + successURL;
        paymentRequest.furl = window.location.origin + failureURL;
        paymentRequest.phone = this.msisdn;
        this.totalAmount = paymentRequest.amount;
        this.allowPayment = true;
        this.msisdn = msisdn;
        this.name = `${paymentRequest.firstname} ${paymentRequest.lastname}`;
        const handler = responseHandler;
        // get config
        const requestPayload = {
            'paymentGwProviderID': paymentGatewaySelected,
            'resourceNumber': msisdn,
            'payer': `${paymentRequest.firstname} ${paymentRequest.lastname}`,
            'amount': paymentRequest.amount,
            'currency': currency,
            'email': paymentRequest.email,
            'channel': 'Mobile' // cartDetails.createdByChannel
         };
        this.getPaymentGateWayConfig(requestPayload).subscribe((data: PaymentConfigResponse) => {
            paymentRequest.salt = data.salt;
            paymentRequest.key = data.merchantKey;
            // generate hash value
            paymentRequest.hash = this.paymentHash(paymentRequest);
            window['removeAllListeners']('message');
            this.boltRef.launch(paymentRequest, handler);

        });
    }



    private getPaymentGateWayConfig(requestData: any): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.paymentGatewayConfiguration.indexOf('.json') !== -1) {
            url = environment.urls.paymentGatewayConfiguration;
            httpResponse = this.http.get(url);
        } else {
            url = environment.urls.paymentGatewayConfiguration;
            httpResponse = this.http.post(url,
                requestData
            );
        }
        return httpResponse.pipe(map((response: any) => {
            this.paymentConfigSelected = {
                resourceNumber: response.resourceNumber,
                payer: response.payer,
                merchantID: response.merchantID,
                merchantKey: response.merchantKey,
                merchantRefNum: response.merchantRefNum,
                paymentUrl: response.paymentUrl,
                returnUrl: response.returnUrl,
                email: response.email,
                authorizationHeader: response.authorizationHeader,
                salt: response.salt
            };
            return this.paymentConfigSelected;
        }
        ));
    }

    public paymentGatewayList(): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        const webContent = this.persistanceService.get(WEBCONTENTPERSISTANCEKEY.WEBCONTENT, StorageType.SESSION);
        if (environment.urls.paymentGatewayList.indexOf('.json') !== -1) {
            url = environment.urls.paymentGatewayList;
            httpResponse = this.http.get(url);
        } else {
            url = environment.urls.paymentGatewayList;
            httpResponse = this.http.get(url);
        }
        return httpResponse.pipe(map((response: any) => {
            let mappedData: any = response.map(data => {
                const obj = { checked: false, value: data, url: null };
                if (webContent && webContent.paymentServiceImages) {
                    const imageObjs = webContent.paymentServiceImages.filter(x => x.id === data);
                    if (imageObjs && imageObjs[0]) {
                        obj.url = imageObjs[0].url;
                    } else {
                        obj.url = 'assets/imgs/no-image-icon.png';
                    }
                }    else {
                    obj.url = 'assets/imgs/no-image-icon.png';
                }
                return obj;
            });
            if(response && response.length ===1){
                mappedData[0].checked = true;
            }
            return mappedData;
        }
        ));
    }

    public updatePayment(paymentTransactionRequest: PaymentTransactionRequest): Observable<any> {
        let url = '';
        let httpResponse: Observable<any>;
        if (environment.urls.paymentUpdate.indexOf('.json') !== -1) {
            url = environment.urls.paymentUpdate;
            httpResponse = this.http.get(url);
        } else {
            url = environment.urls.paymentUpdate;
            httpResponse = this.http.put(url,
                paymentTransactionRequest
            );
        }
        return httpResponse.pipe(map((response: any) => {
            const mappedData: any = response;
            return mappedData;
        }
        ));
    }

    private paymentHash(paymentRequest: PaymentRequestInfo) {
        // key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5||||||salt
        const hashString = paymentRequest.key // Merchant Key
            + '|' + paymentRequest.txnid
            + '|' + paymentRequest.amount + '|' + paymentRequest.productinfo + '|'
            + paymentRequest.firstname + '|' + paymentRequest.email + '|'
            + '||||||||||'
            + paymentRequest.salt ; // Your salt value
        const sha = sha512.update(hashString);
        const hash = sha.hex();
        return hash;
    }

    public paymentResponseHandler(userData, paymentRequest: PaymentRequestInfo, customerProfile) {
        let responseData = {};
        if (userData) {
            responseData = {
                responseHandler: (BOLT) => {
                    return this.paymentSuccessHandler(BOLT, userData, paymentRequest, customerProfile);
                },
                catchException: (BOLT) => {
                    return this.paymentFailureHandler(BOLT, userData);
                }
            }
        }
        return responseData;
    }

    private async paymentSuccessHandler(BOLT, userData, paymentRequest: PaymentRequestInfo, customerProfile) {
        if (BOLT.response && BOLT.response.txnStatus === 'SUCCESS' && BOLT.response.txnid) {
            let paymentTransactionRequest = {
                resourceNumber: this.paymentConfigSelected.resourceNumber,//MSISDN from customer journey
                payer: BOLT.response.payer || 'NA',//NA in old code
                merchantRefNum: this.paymentConfigSelected.merchantRefNum,//merchantRefNum from create payment service
                paymentGwTransactionId: BOLT.response.txnid || BOLT.response.payuMoneyId || paymentRequest.txnid,
                status: BOLT.response.status,
                paymentToken: BOLT.response.paymentId || '',//empty in old code
                paymentMethod: BOLT.response.mode,
                expiryDate: BOLT.response.addedon || '',//empty in old code
                cardNumber: BOLT.response.cardnum || '', //cardnum from payumoney
                amount: BOLT.response.amount
            };
            const paymentInfo = await this.updatePayment(paymentTransactionRequest).toPromise();
            if (this.msisdn === paymentTransactionRequest.resourceNumber && this.allowPayment) {
                this.allowPayment = false;
                const paymentInfo = await this.updatePayment(paymentTransactionRequest).toPromise();
                if (paymentInfo && paymentInfo.message && paymentInfo.message === 'SUCCESS') {
                    this.persistanceService.set(WEBCONTENTPERSISTANCEKEY.PAYMENT_STATUS, { status: paymentInfo.message, transactionData: paymentTransactionRequest }, { type: StorageType.SESSION });
                    this.navigateToBaseUrl(userData.redirectUrl);
                }
            } else {
                this.persistanceService.set(WEBCONTENTPERSISTANCEKEY.PAYMENT_STATUS, { status: paymentInfo.message, transactionData: paymentTransactionRequest }, { type: StorageType.SESSION });
                this.navigateToBaseUrl(userData.redirectUrl);
                alertify.error(this.translateService.instant('Payment Failed'));
            }
        }
        else {
            alertify.error(this.translateService.instant('Payment has been cancelled'));
        }
    }

    private navigateToBaseUrl(baseUrl?: string) {
        if (baseUrl) {
            this.router.navigate([baseUrl]);
        } else {
            this.router.navigate(['/dashboard/home']);
        }
    }

    private paymentFailureHandler(BOLT, userData) {
        alertify.error(this.translateService.instant(BOLT.message));
    }

}

