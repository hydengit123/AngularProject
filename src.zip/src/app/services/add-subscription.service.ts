import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PersistenceService, StorageType } from 'angular-persistence';
import { PERSISTANCEKEY } from '../../application-constants';
import { environment } from './../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AddSubscriptionService {

  subscribedMSISDN: String = "";
  subscribedCustomerId: String = "";
  subscriptionStatus: Boolean = false;
  constructor(private persistenceService: PersistenceService, private http: HttpClient, ) { }

  getMobileNumberStatus(subscriptionFormDetails: any): Observable<any> {
    let url = '';
    let httpResponse: Observable<any>;
    let mobileNumber = subscriptionFormDetails.mobileNumber;

    const requestPayload = {
      "msisdn": mobileNumber,
      "journeyId": "Onboarding" //Onboarding
    }
    url = environment.urls.customersearch;
    httpResponse = this.http.post(url, requestPayload);
    return httpResponse;
  }

  sendVerificationCodeToMobile(partyId, subscriptionFormDetails): Observable<any> {
    let url = '';
    const registrationemailmsisdn = this.persistenceService.get(PERSISTANCEKEY.REGISTEREMAILMSISDN, StorageType.SESSION);
    const msisdn = subscriptionFormDetails.mobileNumber;
    let httpResponse: Observable<any>;

    const requestPayload = {
      "selfcareIdentity": registrationemailmsisdn,
      "selfcarePartyId": partyId,
      "MSISDN": msisdn
    }
    url = environment.urls.sendVerificationCode;
    httpResponse = this.http.post(url, requestPayload);
    return httpResponse;
  }

  validateVerificationCode(partyId, subscriptionFormDetails): Observable<any> {
    let url = '';
    const registrationemailmsisdn = this.persistenceService.get(PERSISTANCEKEY.REGISTEREMAILMSISDN, StorageType.SESSION);
    const msisdn = subscriptionFormDetails.mobileNumber;
    const verificationCode = subscriptionFormDetails.verficationCode;
    let httpResponse: Observable<any>;

    const requestPayload = {
      "loginIdentity": "",
      "selfcareIdentity": registrationemailmsisdn,
      "selfcarePartyId": partyId,
      "MSISDN": msisdn,
      "vCode": verificationCode
    }
    url = environment.urls.linkSubscription;
    httpResponse = this.http.post(url, requestPayload);
    return httpResponse;
  }

  setSubscribedMSISDN(msisdn) {
    this.subscribedMSISDN = msisdn;
  }

  getSubscribedMSISDN() {
    return this.subscribedMSISDN;
  }

  setSubscriptionStatus(status) {
    this.subscriptionStatus = status;
  }

  getSubscriptionStatus() {
    return this.subscriptionStatus;
  }

  setSubscribedCustomerId(customerId) {
    this.subscribedCustomerId = customerId;
  }

  getSubscribedCustomerId() {
    return this.subscribedCustomerId;
  }

}
