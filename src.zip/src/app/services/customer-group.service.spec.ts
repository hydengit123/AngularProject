import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { DataClientService } from '../data-client.service';
import { CustomerGroupService } from './customer-group.service';
import { Observable } from 'rxjs';

describe('CustomerGroupService', () => {

    let dataClientServiceSpy: jasmine.SpyObj<DataClientService>;
    let customerGroupService: CustomerGroupService;
    beforeEach(() => {
        const DataClientServiceSpy = jasmine.createSpyObj('DataClientService', ['get', 'post', 'put', 'delete']);

        TestBed.configureTestingModule({
            providers: [
                CustomerGroupService,
                { provide: DataClientService, useValue: DataClientServiceSpy }
            ],
            imports: [RouterTestingModule]
        });
    });
    beforeEach(() => {
        dataClientServiceSpy = TestBed.get(DataClientService);
        customerGroupService = TestBed.get(CustomerGroupService)
    });
    it('should be created', () => {
        expect(CustomerGroupService).toBeTruthy();
    });

    describe('getSharedAccount', () => {
        it('should call dataClientService.get method ', fakeAsync(() => {
            dataClientServiceSpy.get.and.callFake(() => { return Observable.of({ access_token: 'accessToken' }) })
            let result = customerGroupService.getSharedAccount('123456');
            tick();
            result.then(res => {
                expect(dataClientServiceSpy.get).toHaveBeenCalledWith('customerGroup', ['123456', 'sharedAccount', 'balance']);
            })

        }));
    });

    describe('removeSharedAccount', () => {
        it('should call dataClientService.delete method ', () => {
            customerGroupService.removeSharedAccount('123456', '789654');
            expect(dataClientServiceSpy.delete).toHaveBeenCalledWith('customerGroup', ['123456', 'sharedAccount', '789654']);
        });
    });

    describe('getFAF', () => {
        it('should call dataClientService.get method ', () => {
            customerGroupService.getFAF('123456');
            expect(dataClientServiceSpy.get).toHaveBeenCalledWith('customerGroup', ['FAF', '123456']);
        });
    });

    describe('removeFAF', () => {
        it('should call dataClientService.delete method ', () => {
            customerGroupService.removeFAF('123456', '789654');
            expect(dataClientServiceSpy.delete).toHaveBeenCalledWith('customerGroup', ['FAFMember', '123456', '789654']);
        });
    });

    describe('addFAF', () => {
        it('should call dataClientService.post method ', () => {
            customerGroupService.addFAF('123456', '789654');
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith(null, 'customerGroup', ['FAFMember', '123456', '789654']);
        });
    });

    describe('registerFAF', () => {
        it('should call dataClientService.post method ', () => {
            customerGroupService.registerFAF('123456');
            expect(dataClientServiceSpy.post).toHaveBeenCalledWith(null, 'customerGroup', ['FAF', '123456']);
        });
    });
});