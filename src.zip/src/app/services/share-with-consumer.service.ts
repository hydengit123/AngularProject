import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY, Consumer, CustomerInteractionShared, ProductBucketShared, UserContractModel } from 'dxp-common';
import { Observable } from 'rxjs';
import { PERSISTANCEKEY, SHAREDCONSUMER } from '../../application-constants';
import { environment } from '../../environments/environment';
import UserProfile from '../modals/ProfileModal';

@Injectable({
  providedIn: 'root'
})
export class ShareWithConsumerService {

  constructor(private http: HttpClient, private persistenceService: PersistenceService) { }

  public getConsumers(customerId: string, contractId: string): Observable<any> {
    let url = '';
    let httpResponse: Observable<any>;
    if (environment.urls.getConsumers.indexOf(".json") !== -1) {
      url = environment.urls.getConsumers;
      httpResponse = this.http.get(url);
    }
    else {
      url = environment.urls.getConsumers.replace('{customerId}', customerId).replace('{contractId}', contractId);
      httpResponse = this.http.get(url);
    }
    return httpResponse;
  }

  private updateConsumer(customerInteractionShared: CustomerInteractionShared): Observable<any> {
    let url = '';
    let httpResponse: Observable<any>;
    if (environment.urls.customerInteraction.indexOf(".json") !== -1) {
      url = environment.urls.customerInteraction;
      httpResponse = this.http.get(url);
    }
    else {
      url = environment.urls.customerInteraction.replace('{customerId}', customerInteractionShared.customerId).replace('{contractId}', customerInteractionShared.contractId);
      httpResponse = this.http.post(url, customerInteractionShared);
    }
    return httpResponse;
  }

  public searchConsumers(customerId: string, contractId: string, bucketName: string, bucketValue: string): Observable<any> {
    let url = '';
    let httpResponse: Observable<any>;
    if (environment.urls.searchConsumer.indexOf(".json") !== -1) {
      url = environment.urls.searchConsumer;
      httpResponse = this.http.get(url);
    }
    else {
      //request payload
      const requestPayload = {
        name: bucketName,
        value: bucketValue,
        operator: "=="
      };
      url = environment.urls.searchConsumer.replace('{customerId}', customerId).replace('{contractId}', contractId);
      httpResponse = this.http.post(url, requestPayload);
    }
    return httpResponse;
  }

  validateMSISDN(name: string, value: string): Observable<any> {
    let url = '';
    let httpResponse: Observable<any>;
    if (environment.urls.validateMSISDN.indexOf(".json") !== -1) {
      url = environment.urls.validateMSISDN;
      httpResponse = this.http.get(url);
    }
    else {
      //request payload
      const requestPayload = {
        name: name,
        value: value,
        operator: "=="
      };
      url = environment.urls.validateMSISDN;
      httpResponse = this.http.post(url, requestPayload);
    }
    return httpResponse;
  }

  private getDummyCustomerInteractionShared(): CustomerInteractionShared {

    return {
      id: '',
      channelName: '',
      contractId: '',
      customerId: '',
      customerServiceOrder: {
        state: '',
        orderItem: [],
        type: ''
      },
      journeyData: {
        bucketType: '',
        bucketName: '',
        bucketValue: 0,
        consumerMSISDN: '',
        componentId: 0,
        MSISDN: '',
        oldBucketValue: 0,
        productId: '',
        unitOfMeasure: '',
        validUntil: '',
      },
      journeyId: '',
      partyId: '',
      status: '',
      type: '',
      userId: '',
      coreData: {
        bucketType: '',
        bucketName: '',
        bucketValue: '',
        consumerMSISDN: '',
        MSISDN: '',
        unitOfMeasure: '',
        summaryTextLabel: '',
      }
    };
  }

  private generateCustomerInteractionShared(userContractProfile: UserContractModel, userProfile: UserProfile, productBucketShared: ProductBucketShared, consumer: Consumer, productId: string, action: string, oldBucketValue: number = null) {

    let customerInteractionShared: CustomerInteractionShared = this.getDummyCustomerInteractionShared();
    const channelConfig = this.persistenceService.get(CMUICONFIGKEY.SELFCARECHANNELCONFIGURATION, StorageType.SESSION);
    const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
    customerInteractionShared.channelName = channelConfig.channelName || "Selfcare";
    customerInteractionShared.contractId = userContractProfile.contract.id;
    customerInteractionShared.customerId = userProfile.customerId;
    customerInteractionShared.partyId = partyId;
    customerInteractionShared.status = SHAREDCONSUMER.CUSTOMERSERVICEORDERSTATE;
    customerInteractionShared.type = SHAREDCONSUMER.CUSTOMERSERVICEORDERTYPE;

    //Customer service order
    // customerInteractionShared.customerServiceOrder.createdBy = `${userProfile.firstName} ${userProfile.lastName}`;
    // customerInteractionShared.customerServiceOrder.createdByChannel = channelConfig?channelConfig.channelName: "CSR";
    // customerInteractionShared.customerServiceOrder.customerId = userProfile.customerId;
    // customerInteractionShared.customerServiceOrder.description = action;
    // customerInteractionShared.customerServiceOrder.lastUpdatedByChannel = channelConfig?channelConfig.channelName: "CSR";
    // customerInteractionShared.customerServiceOrder.msisdn = userContractProfile.msisdn;
    customerInteractionShared.customerServiceOrder.state = SHAREDCONSUMER.CUSTOMERSERVICEORDERSTATE;
    customerInteractionShared.customerServiceOrder.type = SHAREDCONSUMER.CUSTOMERSERVICEORDERTYPE;
    customerInteractionShared.customerServiceOrder.orderItem = [];

    //Journey Data
    customerInteractionShared.journeyData.bucketType = productBucketShared.bucketType;
    customerInteractionShared.journeyData.bucketName = productBucketShared.name;
    customerInteractionShared.journeyData.bucketValue = Math.round(consumer.consumerBuckets[0].bucketValue);
    customerInteractionShared.journeyData.consumerMSISDN = consumer.consumerResource;
    customerInteractionShared.journeyData.componentId = parseInt(productBucketShared.id);
    customerInteractionShared.journeyData.MSISDN = userContractProfile.msisdn;
    customerInteractionShared.journeyData.productId = productId;
    customerInteractionShared.journeyData.unitOfMeasure = productBucketShared.unit;
    //const currentDate = new Date().setDate(new Date().getDate() + 1);
    customerInteractionShared.journeyData.validUntil = productBucketShared.validUntil;//new Date(currentDate).toISOString();

    delete customerInteractionShared.userId;
    //API Adjustment
    //delete customerInteractionShared.journeyData.bucketType;

    //core data
    customerInteractionShared.coreData.MSISDN = customerInteractionShared.journeyData.MSISDN;
    customerInteractionShared.coreData.bucketName = customerInteractionShared.journeyData.bucketName;
    customerInteractionShared.coreData.bucketType = customerInteractionShared.journeyData.bucketType;
    customerInteractionShared.coreData.bucketValue = customerInteractionShared.journeyData.bucketValue.toString();
    customerInteractionShared.coreData.consumerMSISDN = customerInteractionShared.journeyData.consumerMSISDN;
    customerInteractionShared.coreData.unitOfMeasure = customerInteractionShared.journeyData.unitOfMeasure;

    if (action === SHAREDCONSUMER.ADDSHAREDCONSUMER) {
      customerInteractionShared.journeyId = SHAREDCONSUMER.ADDSHAREDCONSUMERJOURNEYID;

      //core data summary
      customerInteractionShared.coreData.summaryTextLabel = "AddSharedConsumer_ProviderSummary";

      //delete irrelevant properties
      delete customerInteractionShared.journeyData.oldBucketValue;
      delete customerInteractionShared.id;
    }
    else if (action === SHAREDCONSUMER.UPDATESHAREDCONSUMER) {
      customerInteractionShared.journeyId = SHAREDCONSUMER.UPDATESHAREDCONSUMERJOURNEYID;
      customerInteractionShared.journeyData.oldBucketValue = Math.round(oldBucketValue ? oldBucketValue : 0);

      //core data summary
      customerInteractionShared.coreData.summaryTextLabel = "UpdateSharedConsumer_ProviderSummary";

      //delete irrelevant properties
      delete customerInteractionShared.id;
    }
    else if (action === SHAREDCONSUMER.DELETESHAREDCONSUMER) {
      customerInteractionShared.journeyId = SHAREDCONSUMER.DELETESHAREDCONSUMERJOURNEYID;

      //core data summary
      customerInteractionShared.coreData.summaryTextLabel = "DeleteSharedConsumer_ProviderSummary";

      //delete irrelevant properties
      delete customerInteractionShared.journeyData.oldBucketValue;
      delete customerInteractionShared.id;
    }
    return customerInteractionShared;
  }

  public updateSharedConsumerCustomerInteraction(
    userContractProfile: UserContractModel,
    userProfile: UserProfile,
    productBucketShared: ProductBucketShared,
    consumer: Consumer,
    productId: string,
    action: string,
    oldBucketValue: number = null): Observable<any> {
    const customerInteractionShared: CustomerInteractionShared = this.generateCustomerInteractionShared(userContractProfile,
      userProfile,
      productBucketShared,
      consumer,
      productId,
      action,
      oldBucketValue);
    return this.updateConsumer(customerInteractionShared);
  }

  public getLoweredUnitValue(value, productBucketShared: ProductBucketShared): number {
    if (productBucketShared && productBucketShared.bucketType.toUpperCase() === SHAREDCONSUMER.DATA.toUpperCase()) {
      return value * (1024 * 1024 * 1024);
    }
    if (productBucketShared && productBucketShared.bucketType.toUpperCase() === SHAREDCONSUMER.VOICE.toUpperCase()) {
      return value * 60;
    }
    if (productBucketShared && productBucketShared.bucketType.toUpperCase() === SHAREDCONSUMER.SMS.toUpperCase()) {
      return value;
    }

  }

  public isMaxQuotaExceeded(enteredQuota: number,
    productBucketShared: ProductBucketShared,
    quotaConsumed: number):boolean {
    const quotaConsumedAfterCheckingAvailableBalance: number = productBucketShared.currentBalance < quotaConsumed ? productBucketShared.currentBalance : quotaConsumed;
    const enteredLoweredUnitQuota = this.getLoweredUnitValue(enteredQuota, productBucketShared);
    const maxQuotaAllowed = productBucketShared.maxSharedQuota;
    if ((maxQuotaAllowed - quotaConsumedAfterCheckingAvailableBalance) !== enteredLoweredUnitQuota
      && (maxQuotaAllowed - quotaConsumedAfterCheckingAvailableBalance) < enteredLoweredUnitQuota) {
      return true;
    }
    return false;
  }



}
