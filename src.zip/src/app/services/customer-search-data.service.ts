import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { CMUICONFIGKEY } from 'dxp-common';
import * as _ from 'lodash';
import { Observable, of } from 'rxjs';
import { flatMap, map } from 'rxjs/operators';
import { PERSISTANCEKEY } from '../../application-constants';
import { environment } from '../../environments/environment';
import { MockCustomerContract } from '../mocks/mock-contract';
declare const jQuery: any;
declare const alertify;

@Injectable({
    providedIn: 'root'
})
export class CustomerSearchDataService {

    httpOptions: any = null;

    private cmsProductCache: any = {};

    constructor(
        private persistenceService: PersistenceService,
        private http: HttpClient,
        private translateService: TranslateService
    ) {
        const accessToken = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
        this.httpOptions = {
            headers: new HttpHeaders({
                'Authorization': 'Bearerabc'
            })
        };
    }

    public setUserProfileData(partyId: string): Observable<any> {
        return this.http.get(`${environment.urls.apiUrl}/xCACcore/v1/customer/customerprofile?partyId=${partyId}&partyRole=customer`, this.httpOptions);
    }

    public searchCustomer(searchText: string): Observable<any> {
        const data = {
            'name': 'msisdn',
            'value': searchText,
            'operator': '=='
        };
        return this.http.post(environment.urls.apiUrl + '/xCACcore/v1/customer/customerprofile/search', data,
        );
    }

    public getPlanAddonsDetails(lang: string, offerTypes: Array<string>): Observable<any> {
        const url = `${environment.urls.apiUrl}/xCACcore/v1/productOffering/search`;
        return this.http.post(url, {
            'eligibilityDate': new Date(),
            'offerType': offerTypes,
            'productCategory': [
                {
                    'name': 'COMBO'
                },
                {
                    'name': 'DATA'
                },
                {
                    'name': 'VOICE'
                },
                {
                    'name': 'SMS'
                }
            ],
            'productOfferingRelationship': {
                'relationType': 'string'
            },
            'language': lang,
            'contextCharacteristic': [
                {
                    'name': 'string',
                    'valueInstances': [
                        {
                            'values': [
                                {
                                    'value': 'string'
                                }
                            ]
                        }
                    ]
                }
            ]
        });
    }

    public getProductDetailsFromCMS(lang: string, productsIds: Array<string>): Observable<any> {
        if (!this.cmsProductCache[lang]) {
            this.cmsProductCache[lang] = {};
        }
        const langProducts = this.cmsProductCache[lang];
        const requiredProductsFromCMS = [];
        const alreadyHaveItProductsFromCMS = [];
        _.forEach(productsIds, (productId) => {
            if (!langProducts[productId]) {
                requiredProductsFromCMS.push(productId);
            } else {
                alreadyHaveItProductsFromCMS.push(langProducts[productId]);
            }
        });
        if (requiredProductsFromCMS.length === 0) {
            return of({ products: alreadyHaveItProductsFromCMS });
        }
        const url = `${environment.urls.cmsUrl}/o/cmsConnector/v1/productOfferings/search`;
        const mappedProducts = _.map(requiredProductsFromCMS, productId => ({ 'id': productId }));
        const productTypes = [...this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMES_FORADDONQUERY, StorageType.SESSION),
        ...this.persistenceService.get(CMUICONFIGKEY.PRODUCTGROUPNAMESFORVASEOFFERQUERY, StorageType.SESSION)];
        return this.http.post(url, {
            'productType': productTypes,
            'products': mappedProducts,
            'languageCode': lang,
        }).pipe(map((response: any) => {
            if (!(response.products instanceof Array)) {
                response.products = [response.products];
            }
            _.forEach(response.products, cmsProduct => {
                if (!!cmsProduct.id) {
                    langProducts[cmsProduct.id] = cmsProduct;
                }
            });
            response.products = [...response.products, ...alreadyHaveItProductsFromCMS];
            return response;
        }));
    }

    public getContract(customerId: string, getExpiredProducts = false): Observable<any> {
        let fetchedContracts;
        return this.http.get(`${environment.urls.apiUrl}/xCACcore/v1/customer/customercontract?customerId=${customerId}?expiredProducts=${getExpiredProducts}`, this.httpOptions)
            .pipe(flatMap((contracts: any) => {
                const productIds = [];
                if (contracts && contracts.length > 0) {
                    contracts.map(contract => {
                        if (contract.products) {
                            const productBucketsWithIdAndType = contract.products.filter(x => x.id && x.type);
                            contract.products = [...productBucketsWithIdAndType];
                            contract.products.forEach(product => {
                                productIds.push(product.id);
                            });
                            return contract;
                        }
                    });
                }
                fetchedContracts = contracts;
                return this.getProductDetailsFromCMS(this.translateService.currentLang, productIds);
            }))
            .pipe(flatMap((productResponse) => {
                const productMap = {};
                _.forEach(productResponse.products, product => {
                    if (!product.errorMessage) {
                        productMap[product.id] = product;
                    }
                });
                _.forEach(fetchedContracts, contract => {
                    _.forEach(contract.products, product => {
                        product.cmsName = !!productMap[product.id] ? productMap[product.id].title : product.name;
                        product.cmsDescription = !!productMap[product.id] ? productMap[product.id].description : product.description;
                    });
                });
                return of(fetchedContracts);
            }));
    }

    public searchCustomerInteraction(customerId, storyType?: string): Observable<any> {
        return this.http.get(`${environment.urls.apiUrl}/xCACcore/v1/customerInteraction?customerId=${customerId}&scope=summary&sort=recentfirst&type=${storyType}`);
    }

    public searchCustomerInteractionRecentFirst(customerId, recordLimit = 5): Observable<any> {
        const interActionType = 'PurchaseOrder,ServiceOrder';
        return this.http.get(`${environment.urls.apiUrl}/xCACcore/v1/customerInteraction?customerId=${customerId}&sort=recentfirst&type=${interActionType}&limit=${recordLimit}`);
    }


    public getJourneySessionData(id) {
        let httpResponse: Observable<any>;
        const url = environment.urls.getJourneySession + id;
        httpResponse = this.http.get(url);
        return httpResponse;
    }

    public getMockContract() {
        // let httpResponse: Observable<any>;
        let url = environment.urls.mockContranct
        return this.http.get(url);
    }

    public getCustomerContract(): Observable<any> {
        return of(MockCustomerContract.getMockData());
    }

    public getCustomerOrderHistory(values): Observable<any> {
        return of(MockCustomerContract.getMockData());
    }




    // calculateData(bytes: number, decimals: number = 0): number {
    //     const k = 1024;
    //     const dm = decimals <= 0 ? 0 : decimals || 2;
    //     const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    //     const i = Math.floor(Math.log(bytes) / Math.log(k));
    //     return parseFloat((bytes / Math.pow(k, 3)).toFixed(dm));

    // }

    // calculateVoice(voice: number): any {
    //     const sec = 60;
    //     const converted = Math.floor(voice / sec);
    //     if (converted === -1) {
    //         return "Unlimited";
    //     }
    //     return converted;
    // }

    getConsumerData(customerID, contractID, items) {
        let httpResponse: Observable<any>;
        const url = environment.urls.consumerSearch + customerID + "/contract/" + contractID + "/sharedConsumers/search";
        const requestPayload = {
            "name": "name",
            "value": items.name,
            "operator": "=="

        }
        httpResponse = this.http.post(url, requestPayload);
        return httpResponse;
    }

    getSharedConsumerData(customerID, contractID) {
        let httpResponse: Observable<any>;
        const url = environment.urls.consumerSharedSearch + customerID + "/contract/" + contractID + "/sharedConsumers";
        httpResponse = this.http.get(url);
        return httpResponse;
    }

    public getConsumption(values: any): Observable<any> {
        // return of(MockConsumptionData.getMockConsumption());
        let bucketId = values.bucketId ? `&bucketId=${values.bucketId}` : ``;
        let productId = values.productId ? `&productId=${values.productId}` : ``;
        return this.http.get(`${environment.urls.apiUrl}/xCACcore/v1/customer/consumptionDetails?communicationId=${values.communicationId}${productId}${bucketId}&startDate=${values.startDate}&endDate=${values.endDate}&isExport=${values.isExport}`, this.httpOptions).pipe(map((response: any) => {
            return response;
        }));
    }

    public getLastRechargeFromMsisdn(msisdn: string): Observable<any> {
        // return of(MockConsumptionData.getMockLastrecharge());
        return this.http.get(`${environment.urls.apiUrl}/xCACcore/v1/customer/last-recharge-date?msisdn=${msisdn}`);
    }

    public searchCustomerInteractionInDateRange(customerId, dates:any): Observable<any> {
        const interActionType = 'PurchaseOrder,ServiceOrder';
        return this.http.get(`${environment.urls.apiUrl}/xCACcore/v1/customerInteraction?customerId=${customerId}&sort=recentfirst&type=${interActionType}&from=${dates.startDate}&to=${dates.endDate}`);
    }

}
