import { TestBed, inject } from '@angular/core/testing';
import { map } from 'rxjs/operators';
import { CMSContentService } from './cms-content.service';
import { Observable, pipe } from 'rxjs';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HttpClient, HttpResponse } from '@angular/common/http';

describe('CMSContentService', () => {
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  beforeEach(() => {

    TestBed.configureTestingModule({
      providers: [CMSContentService],
      imports: [HttpClientTestingModule]
    });

    // Inject the http service and test controller for each test
    httpClient = TestBed.get(HttpClient);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  it('CMS content service should be created', inject([CMSContentService], (service: CMSContentService) => {
    expect(service).toBeTruthy();
  }));


});
