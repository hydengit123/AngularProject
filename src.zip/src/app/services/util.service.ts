import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PLANTYPE } from 'dxp-common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { QUOTATYPE } from '../../application-constants';
import { environment } from '../../environments/environment';
import { SubscriptionProduct } from '../interface/subscription';
import Product = SubscriptionProduct.Product;
import { CMUICONFIGKEY, UserProfileConfiguration } from 'dxp-common';
import { PersistenceService, StorageType } from 'angular-persistence';

@Injectable({
  providedIn: 'root'
})
export class UtilService {

  constructor(private http: HttpClient,
    private persistenceService: PersistenceService) {
  }

  /**
   * Parsing subscription api to get current plan and merge custom plan
   * @param {Product[]} products
   * @returns {Product}
   */
  getCustomerPlanFromSubscription(products: Product[]) {
    let currentPlan: Product = null;
    currentPlan = products.find(x => x.productGroup.toString().toLowerCase() === PLANTYPE.STANDARD || x.productGroup.toString().toLowerCase() === PLANTYPE.PREMIUM);
    if (!currentPlan) {
      /* standard and premium plan not available */
      const customPlans = products.filter(x => x.productGroup.toLowerCase() === PLANTYPE.CUSTOMIZEPLANOFFER);
      if (customPlans.length > 0) {
        /* initiate current plan */
        currentPlan = {
          productId: '',
          productName: null,
          productType: null,
          productGroup: null,
          price: 0,
          paymentMode: null,
          srcChannel: null,
          numberOfPendingRenewals: null,
          nextRenewalDate: null,
          provisionedQuota: {
            data: null,
            voice: null,
            sms: null
          },
          availableQuota: {
            data: null,
            voice: null,
            sms: null,
            other: null
          },
          activationDate: null,
          expiryDate: null,
          isRecurring: null
        };
        customPlans.forEach(x => {
          currentPlan.price = currentPlan.price + x.price;
          currentPlan.productId = currentPlan.productId + (currentPlan.productId === '' ? x.productId : '^^' + x.productId);
          currentPlan.productName = currentPlan.productName + (currentPlan.productName === '' ? x.productName : '^^' + x.productName);
          currentPlan.productType = currentPlan.productType + (currentPlan.productType === '' ? x.productType : '^^' + x.productType);
          currentPlan.productGroup = PLANTYPE.CUSTOM;
          if (x.productType.toString().toLowerCase() === QUOTATYPE.DATA) {
            currentPlan.provisionedQuota.data = x.provisionedQuota.data || null;
          }
          if (x.productType.toString().toLowerCase() === QUOTATYPE.VOICE) {
            currentPlan.provisionedQuota.voice = x.provisionedQuota.voice || null;
          }
          if (x.productType.toString().toLowerCase() === QUOTATYPE.SMS) {
            currentPlan.provisionedQuota.sms = x.provisionedQuota.sms || null;
          }
          if (x.productType.toString().toLowerCase() === QUOTATYPE.DATA) {
            currentPlan.availableQuota.data = x.availableQuota.data || null;
          }
          if (x.productType.toString().toLowerCase() === QUOTATYPE.VOICE) {
            currentPlan.availableQuota.voice = x.availableQuota.voice || null;
          }
          if (x.productType.toString().toLowerCase() === QUOTATYPE.SMS) {
            currentPlan.availableQuota.sms = x.availableQuota.sms || null;
          }
          currentPlan.activationDate = x.activationDate;
          currentPlan.expiryDate = x.expiryDate;
          currentPlan.isRecurring = x.isRecurring;
        });
      }
    }
    return currentPlan;
  }

  public populateProfileConfiguration(): UserProfileConfiguration {
    const profileConfiguration: UserProfileConfiguration = {};
    profileConfiguration.communicationAddressType = this.persistenceService.get(CMUICONFIGKEY.COMMUNICATION_ADDRESS, StorageType.SESSION);
    profileConfiguration.communicationEmailType = this.persistenceService.get(CMUICONFIGKEY.COMMUNICATION_EMAIL, StorageType.SESSION);
    profileConfiguration.shippingAddressType = this.persistenceService.get(CMUICONFIGKEY.SHIPPING_ADDRESS, StorageType.SESSION);
    profileConfiguration.shippingEmailType = this.persistenceService.get(CMUICONFIGKEY.SHIPPING_EMAIL, StorageType.SESSION);
    profileConfiguration.identityDocumentType = this.persistenceService.get(CMUICONFIGKEY.IDENTITYDOCTYPE, StorageType.SESSION);

    profileConfiguration.cmsUrl = environment.urls.cmsUrl;

    return profileConfiguration;
  }

  getCMUIDetails(): Observable<any> {
    let url = '';
    let httpResponse:Observable<any>;

    if (environment.urls.getCMUIDetails.indexOf(".json") !== -1) {
        url = environment.urls.getCollaterals;
        httpResponse = this.http.get(url);
    }
    else {
        url = environment.urls.getCMUIDetails;
        httpResponse = this.http.get(url)
    }
    return httpResponse.pipe(map((response: any) => {
            let mappedData: any = response;


            return mappedData;
        }
        ));
}
    getChatbotDetails(): Observable<any> {
      let url = '';
      let httpResponse:Observable<any>;

      url = environment.urls.getChatbotDetails;
      httpResponse = this.http.get(url)
      return httpResponse.pipe(map((response: any) => {
         let mappedData: any = response;
         return mappedData;
        }
      ));
    }

}
