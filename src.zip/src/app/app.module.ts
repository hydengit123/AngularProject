import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ErrorHandler, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { PersistenceModule, PersistenceService } from 'angular-persistence';
import { MDBBootstrapModulesPro } from 'ng-uikit-pro-standard';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthInterceptorService } from './auth-interceptor.service';
import { AuthGuard } from './auth.guard';
import { CisSettingsService } from './cis-settings.service';
import { CisComponent } from './cis/cis.component';
import { CustomPipeModule } from './custom-pipe/custom-pipe.module';
import { DataClientService } from './data-client.service';
import { ErrorsHandlerService } from './errors-handler.service';
import { EventListenerService } from './event-listener.service';
import { selfcareTranslateLoader } from './factories/translate-loader.factory';
import { AuthService } from './services/auth.service';
import { CMSContentService } from './services/cms-content.service';
import { EnvServiceProvider } from './services/env.service.provider';
import { PreviousRouteService } from './services/previous-route.service';
import { ProductService } from './services/product.service';
import { CommonNavigationFormModule } from './custom-component/common-navigation-form.module';
import { ModalBodyDirective } from './customer-onboarding/directives/modal-body.directive';
import { ModalFooterDirective } from './customer-onboarding/directives/modal-footer.directive';
import { GlobalPopupModalComponent } from './global-popup-modal/global-popup-modal.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { PasswordShowHideDirective } from './directives/password-show-hide.directive';
import { CustomerOnboardService } from './services/customer-onboard.service';
import { PaymentPopupComponent } from './payment-popup/payment-popup.component';
import { CustomerService } from './services/customer.service';
import { PaymentSuccessComponent } from './payment-success/payment-success.component';
import { FormMessageService } from './customer-onboarding/services/form-message.service';
import { PendingJourneyComponent } from './pending-journey/pending-journey.component';

import { SharedModuleModule } from './shared-module/shared-module.module';
import { RefillFormComponent } from './refill-form/refill-form.component';
import { CanActivateCustomerOnBoardRouteGuard } from './guards/CanActivateCustomerOnBoardRouteGuard';
import { DxpCommonModule, DxpPipeModule } from 'dxp-common';
import { AddSubscriptionService } from './services/add-subscription.service';
import { RechargeSuccessPopupComponent } from './recharge-success-popup/recharge-success-popup.component';
import { IntermediatePaymentComponent } from './intermediate-payment/intermediate-payment.component';
import { CanActivateRefreshRouteGuard } from './guards/CanActivateRefreshRouteGuard';


@NgModule({
  declarations: [
    AppComponent,
    CisComponent,
    ModalBodyDirective,
    ModalFooterDirective,
    GlobalPopupModalComponent,
    LoginComponent,
    RegisterComponent,
    PasswordShowHideDirective,
    PaymentPopupComponent,
    PaymentSuccessComponent,
    PendingJourneyComponent,
    RefillFormComponent,
    RechargeSuccessPopupComponent,
    IntermediatePaymentComponent,

  ],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    HttpClientModule,
    SharedModuleModule,
    AppRoutingModule,
    PersistenceModule,
    DxpCommonModule,
    CustomPipeModule,
    DxpPipeModule,
    CommonNavigationFormModule,
    MDBBootstrapModulesPro.forRoot(),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: selfcareTranslateLoader,
        deps: [HttpClient]
      }
    }),
  ],
  providers: [
    CisSettingsService,
    DataClientService,
    EventListenerService,
    CustomerOnboardService,
    FormMessageService,
    PersistenceService,
    AddSubscriptionService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptorService,
      multi: true
    },
    {
      provide: ErrorHandler,
      useClass: ErrorsHandlerService,
    },
    AuthGuard,
    AuthService,
    PreviousRouteService,
    ProductService,
    CMSContentService,
    EnvServiceProvider,
    CustomerService,
    CanActivateCustomerOnBoardRouteGuard,
    CanActivateRefreshRouteGuard
  ],
  bootstrap: [AppComponent],
  entryComponents: [LoginComponent, RegisterComponent, PaymentPopupComponent,PendingJourneyComponent,RefillFormComponent,PaymentSuccessComponent,RechargeSuccessPopupComponent, IntermediatePaymentComponent]
})
export class AppModule {
}
