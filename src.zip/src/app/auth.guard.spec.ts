import { TestBed, async, inject } from '@angular/core/testing';

import { AuthGuard } from './auth.guard';
import { Router } from '@angular/router';
import { PersistenceService } from 'angular-persistence';
import { RouterTestingModule } from '@angular/router/testing';

describe('AuthGuard', () => {
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let routerSpy: Router;
  let authGuard: AuthGuard;

  beforeEach(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get']);
    const RouterSpy = jasmine.createSpyObj('Router', ['navigate']);
    TestBed.configureTestingModule({
      providers: [
        AuthGuard,
        { provide: PersistenceService, useValue: PersistenceServiceSpy },
        { provide: Router, useValue: RouterSpy }
      ],
      imports: [RouterTestingModule]
    });
  });
  beforeEach(() => {
    persistenceServiceSpy = TestBed.get(PersistenceService);
    authGuard = TestBed.get(AuthGuard);
    routerSpy = TestBed.get(Router);
  });
  it('should be created', () => {
    expect(authGuard).toBeTruthy();
  });

  describe('canActivate', () => {
    it('should call return true if persistence.get returns accesstoken', () => {
      persistenceServiceSpy.get.and.returnValue({ access_Token: 'accessToken' });

      const result = authGuard.canActivate();

      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(result).toBeTruthy();
    });
    it('should call router.navigate if doesnot recive accessToken from persistence.get', () => {
      persistenceServiceSpy.get.and.returnValue(undefined);
      authGuard.canActivate();

      expect(persistenceServiceSpy.get).toHaveBeenCalled();
      expect(routerSpy.navigate).toHaveBeenCalledWith(['/public']);
    });
  });
});
