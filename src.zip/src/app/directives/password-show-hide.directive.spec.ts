import { PasswordShowHideDirective } from './password-show-hide.directive';

describe('PasswordShowHideDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordShowHideDirective(null);
    expect(directive).toBeTruthy();
  });
});
