import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appPasswordShowHide]'
})
export class PasswordShowHideDirective {

  private _shown = false;

  constructor(private el: ElementRef) { 
    this.setup();
  }

  toggle(span: HTMLElement) {
    this._shown = !this._shown;
    if (this._shown) {
      this.el.nativeElement.setAttribute('type', 'text');
      span.classList.remove('fa-eye');
      span.classList.add('fa-eye-slash');
    } else {
      this.el.nativeElement.setAttribute('type', 'password');
      span.classList.remove('fa-eye-slash');
      span.classList.add('fa-eye');
    }
  }

  setup(){
    const parent = this.el.nativeElement.parentNode;
    const span = document.createElement('span');
    span.className = "fa fa-fw fa-eye field-icon toggle-password";
    span.setAttribute("style","float: right;margin-left: -25px;margin-top: -31px;position: relative;z-index: 2;");
    span.addEventListener('click', (event) => { 
      this.toggle(span);
    });
    parent.appendChild(span);
  }


}
