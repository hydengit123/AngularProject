import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { DxpCommonService } from 'dxp-common';
import { LOCALIZATIONPERSISTANCEKEY } from '../application-constants';
import { EventEnum } from './enum/EventEnum';
import { EventListenerService } from './event-listener.service';
import { ChatbotService } from './services/chatbot.service';
import { CustomerSearchDataService } from './services/customer-search-data.service';
import { UtilService } from './services/util.service';
import { CustomerOnboardingComponent } from './customer-onboarding/customer-onboarding.component';
import { FormMessageService } from './customer-onboarding/services/form-message.service';
import { CartService } from './services/cart.service';

declare let window: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'app';
  isRTL: boolean = false;
  constructor(private router: Router,
    private translate: TranslateService,
    private event: EventListenerService,
    private persistenceService: PersistenceService,
    private utilService: UtilService,
    private chatbotService: ChatbotService,
    private dxpCommonService: DxpCommonService,
    private searchDataService: CustomerSearchDataService,
    private cartService: CartService,
    private formMessageService: FormMessageService) {
    this.dxpCommonService.setCMSConnectionProvider(this.searchDataService.getProductDetailsFromCMS.bind(this.searchDataService));
  }

  ngOnInit() {
    //priopritize language selection
    // if (!this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL)) {
    //   this.event.changeLanguage(this.translate.getBrowserCultureLang());
    // } else {
    //   this.event.changeLanguage(this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL));
    // }

    // fetch CM UI config
    // this.chatbotService.loadChatbot('');
    this.utilService.getCMUIDetails().subscribe(data => {
      this.event.updateCMUIData(data);
    });

    this.utilService.getChatbotDetails().subscribe(data => {
      this.event.updateChatbotData(data);
    });

    // on language update
    this.event.lanuageChangeEvent.subscribe(data => {
      if (data && data.eventType && data.eventType === EventEnum.languageUpdated) {
        const language = this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
        this.loadLanguage(language);
      }
    });

    this.event.msisdnChangeEvent.subscribe((data) => {
      // this.chatbotService.closeChatbox();
      this.chatbotService.identifyuser(data.msisdn);
    });
  }

  loadLanguage(language: string) {
    this.translate.use(language).subscribe(
      (res) => {
        // check for RTL (Right to left)
      }
    );
  }

  loadChatbot() {
    this.chatbotService.identifyuser('');
    // if (!!window.Avaamo) {
    //   this.chatbotService.identifyuser(data.msisdn);
    //  } else {
    //   setTimeout(() => {
    //       this.loadChatbot(data);
    //   }, 1000);
    // }
  }

  activatedComponentOnRouting(moduleParentComponent: any) {
    if (moduleParentComponent.constructor.name !== CustomerOnboardingComponent.name) {
      //clear service data of customer on board module when user switch to other modules
      this.cartService.resetServiceData();
      this.formMessageService.resetServiceData();
      this.event.notifyCartUpdate(null);
    }
  }
}
