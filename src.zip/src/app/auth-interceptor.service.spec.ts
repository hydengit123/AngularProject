import { HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { PersistenceService } from 'angular-persistence';
import { AuthInterceptorService } from './auth-interceptor.service';
import { AuthService } from './services/auth.service';

describe('AuthInterceptorService', () => {
  let persistenceServiceSpy: jasmine.SpyObj<PersistenceService>;
  let routerSpy: jasmine.SpyObj<Router>;
  let authServiceSpy: jasmine.SpyObj<AuthService>;

  beforeEach(() => {
    const PersistenceServiceSpy = jasmine.createSpyObj('PersistenceService', ['get', 'set', 'removeAll']);
    const AuthServiceSpy = jasmine.createSpyObj('AuthService', ['login']);
    const RouterSpy = jasmine.createSpyObj('Router', ['get', 'navigateByUrl']);
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [
        {
          provide: HTTP_INTERCEPTORS,
          useClass: AuthInterceptorService,
          multi: true
        },
        { provide: PersistenceService, useValue: PersistenceServiceSpy },
        { provide: AuthService, useValue: AuthServiceSpy },
        { provide: Router, useValue: RouterSpy }
      ]
    });
  });

  beforeEach(() => {
    persistenceServiceSpy = TestBed.get(PersistenceService);
    routerSpy = TestBed.get(Router);
    authServiceSpy = TestBed.get(AuthService);
  });
  afterEach(inject([HttpTestingController], (mock: HttpTestingController) => {
    mock.verify();
  }));

  it('should add Accept-Language to Headers', inject([HttpClient, HttpTestingController],
    (http: HttpClient, mock: HttpTestingController) => {
      persistenceServiceSpy.get.and.returnValue('access-token-from-pers');
      http.get('/api').subscribe(response => expect(response).toBeTruthy());
      const request = mock.expectOne(req => {
        return (req.headers.has('Content-Type') && req.headers.get('Content-Type') === 'application/json; charset=UTF-8') && (req.headers.has('Authorization') && req.headers.get('Authorization') === 'Bearer access-token-from-pers');
      });

      request.flush({ data: 'Response' });
      mock.verify();
    }));

  it('should call persistenceService.removeAll,router.navigateByUrl when err.status =401', inject([HttpClient, HttpTestingController],
    (http: HttpClient, mock: HttpTestingController) => {
      persistenceServiceSpy.get.and.returnValue('access-token-from-pers');
      http.get('/error').subscribe(response =>
        expect(response).toBeTruthy(), () => {
          expect(persistenceServiceSpy.removeAll).toHaveBeenCalled();
          expect(routerSpy.navigateByUrl).toHaveBeenCalledWith('/public');
        });

      mock.expectOne('/error').error(new ErrorEvent('Unauthorized error'), {
        status: 401
      })
      mock.verify();
    }));

  it('should call persistenceService.removeAll,router.navigateByUrl when err.status != 401', inject([HttpClient, HttpTestingController],
    (http: HttpClient, mock: HttpTestingController) => {
      persistenceServiceSpy.get.and.returnValue('access-token-from-pers');
      http.get('/error').subscribe(response =>
        expect(response).toBeTruthy(), () => {
          expect(persistenceServiceSpy.removeAll).not.toHaveBeenCalled();
          expect(routerSpy.navigateByUrl).not.toHaveBeenCalledWith('/public');
        });

      mock.expectOne('/error').error(new ErrorEvent('Unauthorized error'), {
        status: 402
      });
      mock.verify();
    }));
});
