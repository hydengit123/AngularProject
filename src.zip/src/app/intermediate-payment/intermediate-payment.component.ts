import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PaymentRequestInfo } from 'dxp-common';
import { CustomerService } from '../services/customer.service';
import { PaymentGatewayService } from '../services/payment-gateway.service';

declare const alertify;

@Component({
  selector: 'app-intermediate-payment',
  templateUrl: './intermediate-payment.component.html',
  styleUrls: ['./intermediate-payment.component.scss']
})
export class IntermediatePaymentComponent implements OnInit {
  contractDetails: any;
  customerProfile: any;
  amount: any;
  msisdn: any;
  userData: any = {};
  public paymentRequestInfo: PaymentRequestInfo = {
    key: "",
    hash: "",
    txnid: "",
    amount: 0,
    productinfo: "",
    firstname: "",
    lastname: "",
    email: "",
    phone: "",
    surl: "",
    furl: "",
    address1: "",
    address2: "",
    city: "",
    state: "",
    country: "",
    zipcode: "",
    salt: ""
  };

  constructor(private route: ActivatedRoute,
    private customerService: CustomerService,
    private paymentGatewayService: PaymentGatewayService) { }

  ngOnInit() {
    // TODO : Values should be retreived from URL
    const redirectUrl: string = this.route.snapshot.queryParamMap.get('redirectURL');
    this.amount = this.route.snapshot.queryParamMap.get('amount');
    this.userData.phoneNumber = this.route.snapshot.queryParamMap.get('msisdn');
    if (!!redirectUrl) {
      const urlArray: Array<string> = redirectUrl.split('//')[1].split('/');
      urlArray.shift();
      this.userData.redirectUrl = urlArray.join('/');
    } else {
      this.userData.redirectUrl = 'dashboard/home';
    }
    this.userPayment();
  }

  async doPayment() {
    const selectedPayments = 'PayUMoney';
    const successURL = '';
    const failureURL = '';
    this.paymentRequestInfo.amount = this.amount;
    this.paymentRequestInfo.productinfo = 'ProductItem';
    // TODO : Customer Profile needs to fetched from API
    if (this.customerProfile) {
      this.paymentRequestInfo.firstname = this.customerProfile[0].firstName;
      this.paymentRequestInfo.lastname = this.customerProfile[0].lastName;
      this.paymentRequestInfo.email = this.customerProfile.email;
    } else {
      this.paymentRequestInfo.firstname = 'Will';
      this.paymentRequestInfo.lastname = 'Smith';
      this.paymentRequestInfo.email = 'Will.Smith@email.com';
    }
    this.paymentGatewayService.launchPaymentBolt(this.paymentRequestInfo,
      selectedPayments,
      this.userData.phoneNumber,
      'INR',
      successURL,
      failureURL,
      this.paymentGatewayService.paymentResponseHandler(this.userData, this.paymentRequestInfo, this.customerProfile)
    );
  }

  fetchCustomerProfile() {
    return this.customerService.customerSearchProfile(this.userData).toPromise();
  }

  async userPayment( ) {
    this.customerProfile = await this.fetchCustomerProfile();
    const emailExist = this.customerProfile[0]['contactMedium'].filter(data => data.type === 'EmailContact');
    if (emailExist && emailExist.length > 0) {
      const email = emailExist[0].value[0].value;
      this.customerProfile.email = email;
    }
    setTimeout(() => {
      if (this.amount && this.userData['phoneNumber']) {
        this.doPayment();
      } else {
        alertify.error('Required Data Missing');
      }
    }, 3000);
  }
}
