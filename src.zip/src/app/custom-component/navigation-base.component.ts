
import { PersistenceService, StorageType } from 'angular-persistence';
import { EventListenerService } from '../event-listener.service';
import { LOCALIZATIONPERSISTANCEKEY } from '../../application-constants';
import { EventEnum } from '../enum/EventEnum';
import { TranslateService } from '@ngx-translate/core';
import { CMUICONFIGKEY } from 'dxp-common';


export class NavigationBaseComponent {
    public allAvaiableLanguages: [];
    public defaultLanguageCode: string;

    constructor(
        private eventListner: EventListenerService,
        private basePersistenceService: PersistenceService,
        private baseTranslateService: TranslateService) {

    }

    protected baseInit() {
        // when CM data updated
        this.populateLanguage();
        this.eventListner.cmUIDataUpdateEvent.subscribe(data => {
            this.populateLanguage();
        });
        this.eventListner.lanuageChangeEvent.subscribe( (languageData) => {
            if (languageData && languageData.eventType === EventEnum.languageUpdated
                && !!languageData.isUserSelected) {
                // const langCode = this.basePersistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL);
                this.defaultLanguageCode = languageData.languageSelected;
              }
        });
    }

    populateLanguage() {
        this.defaultLanguageCode =
            this.basePersistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL)
            || this.baseTranslateService.getBrowserCultureLang();

        this.allAvaiableLanguages = this.basePersistenceService.get(CMUICONFIGKEY.LANGUAGES, StorageType.SESSION);
    }

    onLanguageSelect(languageObj) {

        // this.basePersistenceService.set(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, languageObj.languageCode, { type: StorageType.LOCAL });
        this.eventListner.changeLanguage(languageObj.languageCode, languageObj.isUserSelected);
    }
}
