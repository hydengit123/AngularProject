import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PersistenceService, StorageType } from 'angular-persistence';
import { PERSISTANCEKEY } from '../../../application-constants';
import { FormMessageService } from '../../customer-onboarding/services/form-message.service';
import { EventListenerService } from '../../event-listener.service';
import { CartService } from '../../services/cart.service';
import { ChatbotService } from '../../services/chatbot.service';
import { CustomerSearchDataService } from '../../services/customer-search-data.service';
import { DealsForYouService } from '../../services/dfy.service';
import { UtilService } from '../../services/util.service';
import { NavigationBaseComponent } from '../navigation-base.component';
import { EventEnum } from './../../enum/EventEnum';

declare let window: any;

@Component({
  selector: 'app-common-navigation-form',
  templateUrl: './common-navigation-form.component.html',
  styleUrls: ['./common-navigation-form.component.scss']
})
export class CommonNavigationFormComponent extends NavigationBaseComponent implements OnInit, OnDestroy {

  public languages = [];
  public languageForm: FormGroup = new FormGroup({
    'language': new FormControl('en')
  });
  public isLogin: boolean;
  public isCustomerOnBoarding: boolean;
  public savedJourneyCount: Number = 0;
  public pendingJourneyCount: any = 0;
  public fetchPendingJourney: any;
  public notifyCartUpdatedEventNum: number;

  constructor(public translateService: TranslateService, public persistenceService: PersistenceService,
    public event: EventListenerService, public router: Router, public utilService: UtilService,
    public cartService: CartService, public customerSearchDataService: CustomerSearchDataService,
    public formMessageService: FormMessageService, public dealsForYouService: DealsForYouService,
    public chatbotService: ChatbotService) {
    super(event, persistenceService, translateService);
  }



  ngOnInit() {
    this.notifyCartUpdatedEventNum = EventEnum.notifyCartUpdated;
    this.baseInit();
    this.event.pendingJourneyCount.subscribe(() => {
      this.pendingJourneyCount--;
    });

    this.fetchPendingJourney = this.event.fetchPendingJourneyEvent.subscribe(() => {
      this.loadpendingjourneys();
    });


    //when login status change
    this.event.notifyLoginEvent.subscribe((data) => {
      this.isLogin = data.isLogin;
    });

    // when language change
    // this.languageForm.valueChanges.subscribe((data) => {
    //   this.event.changeLanguage(data.language);
    // });

    // when get count of saved journey
    this.event.setSavedJourneyCountEvent.subscribe(data => {
      if (data && data.eventType === EventEnum.savedJourneyCount && data.count) {
        this.savedJourneyCount = data.count;
      }
    });

    // when CM data updated
    this.populateLanguage();
    this.event.cmUIDataUpdateEvent.subscribe(data => {
      this.populateLanguage();
    });

    // if (this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL)) {
    //   this.languageForm.patchValue({ language: this.persistenceService.get(LOCALIZATIONPERSISTANCEKEY.LANGUAGE, StorageType.LOCAL) });
    // }

    // enable logout
    if (this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION)) {
      this.isLogin = true;
    }
    // enable cart in customerOnboarding
    if (this.router.url.toLowerCase().indexOf('customeronboard') !== -1) {
      this.isCustomerOnBoarding = true;
    }

  }

  loadpendingjourneys() {
    let customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
    this.customerSearchDataService.getJourneySessionData(customerId).subscribe(journeydata => {
      this.pendingJourneyCount = journeydata.length;
    },
      error => {
        if (error.error.code === "2002") {
          this.pendingJourneyCount = 0;
        }
      });

  }

  showNotifications() {
    if (this.pendingJourneyCount != 0) {
      this.event.showPendingJourney('all');
    }

  }

  logout() {
    // trigger implicit save logic is in customer onboard service file
    //this.loadChatbot();
    this.chatbotService.logoutChatbot();
    this.formMessageService.implictSaveJourney();
    this.clearData();
  }

  loadChatbot() {
    this.chatbotService.loadChatbot('');
    if (!!window.Avaamo) {
      this.chatbotService.loadChatbot('');
    } else {
      setTimeout(() => {
        this.loadChatbot();
      }, 1000);
    }
  }

  clearData() {
    if (this.cartService.cartDetails && this.cartService.cartDetails.id) {
      if (this.cartService.cartDetails.cartList.length === 0) {
        this.dealsForYouService.deleteJourneySessionData(this.dealsForYouService.journeySessionId).subscribe(result => {
          this.clearCart();
        }, error => {
          this.clearCart();
        });
      } else {
        this.clearCart();
      }
    }
    this.persistenceService.removeAll(StorageType.SESSION);
    this.persistenceService.removeAll(StorageType.LOCAL);
    this.utilService.getCMUIDetails().subscribe(data => {
      this.event.updateCMUIData(data);
      this.router.navigate(['/']);
    });
  }

  clearCart() {
    this.cartService.resetServiceData();
    this.formMessageService.resetServiceData();
    this.event.notifyCartUpdate(null);
  }

  //   populateLanguage() {
  //     const allLanguages = this.persistenceService.get(CMUICONFIGKEY.LANGUAGES, StorageType.SESSION);
  //     if (allLanguages) {
  //       this.languages = allLanguages.map(item => {
  //         return { value: item.languageCode, label: this.translateService.instant(item.language) };
  //       });
  //     } else {
  //       this.languages = [{ value: "en", label: this.translateService.instant("English") }];
  //     }
  //   }

  goToContinueJourney() {
    this.event.updateStepperInfo(99);
    this.router.navigate(['/customerOnboard/ContinueJourney'])
  }

  goToCustomerOnboard() {
    this.event.updateStepperInfo(1);
  }

  showLoginPopup() {
    this.event.showLoginPopupDetails(true);
  }

  onClickToNavigate(id) {
    this.event.customerIsAbortingJourney();
  }

  ngOnDestroy() {
    this.fetchPendingJourney.unsubscribe();
  }
}
