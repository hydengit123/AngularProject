import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonNavigationFormComponent } from './common-navigation-form.component';

describe('CommonNavigationFormComponent', () => {
  let component: CommonNavigationFormComponent;
  let fixture: ComponentFixture<CommonNavigationFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonNavigationFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonNavigationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
