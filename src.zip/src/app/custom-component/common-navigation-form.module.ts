import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';
import { MDBBootstrapModulesPro } from 'ng-uikit-pro-standard';
import { CommonNavigationFormComponent } from './common-navigation-form/common-navigation-form.component';
import { CommonNavbarComponent } from './common-navbar/common-navbar.component';
import { CommonFooterComponent } from './common-footer/common-footer.component';
import { DxpCommonModule } from 'dxp-common';


@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    MDBBootstrapModulesPro,
    DxpCommonModule
  ],
  declarations: [
    CommonNavigationFormComponent,
    CommonNavbarComponent,
    CommonFooterComponent
  ],
  exports: [
    CommonNavigationFormComponent,
    CommonNavbarComponent,
    CommonFooterComponent
  ]
})
export class CommonNavigationFormModule {
}
