import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subject, Subscription } from 'rxjs';
import { EventListenerService } from '../../event-listener.service';
import { CustomerSearchService } from './../../services/customer-search.service';
import { AddSubscriptionService } from './../../services/add-subscription.service';
import { EventEnum } from '../../enum/EventEnum';

@Component({
  selector: 'app-common-navbar',
  templateUrl: './common-navbar.component.html',
  styleUrls: ['./common-navbar.component.scss']
})
export class CommonNavbarComponent implements OnInit, OnDestroy {

  pendingJourney: any;
  subscription: Boolean = false;
  pendingJourneyStatus:any;
  private showSubscriptionMenu: Subscription;
  constructor(private router: Router, private customerSearchService: CustomerSearchService, private addSubscriptionService: AddSubscriptionService, 
    private eventListenerService: EventListenerService) { }

  ngOnInit() {

    this.showSubscriptionMenu = this.eventListenerService.showSubscriptionMenuEvent.subscribe((data) => {
      if (data && data.eventType && data.eventType === EventEnum.subscriptionMenu) {
        this.addSubscriptionService.setSubscriptionStatus(data.statusValue);
        this.subscription = data.statusValue;
      }
    });
    this.pendingJourneyStatus=this.eventListenerService.pendingJourneyStatus.subscribe((data)=>{
      this.pendingJourney = data.pendingJourneyStatus;
    });
    this.pendingJourney = this.customerSearchService.getpendingJourneyStatus();
    this.subscription = this.addSubscriptionService.getSubscriptionStatus();
  }

  openRoute(route) {
    this.router.navigate(route.split('/'));
  }

  redirectTo(){
    if(this.pendingJourney){
      this.router.navigate(['dashboard/home']);
    }else {
      this.router.navigate(['customerOnboard']);
    }
  }

  ngOnDestroy() {
    if (this.showSubscriptionMenu) {
      this.showSubscriptionMenu.unsubscribe();
    }
    if(this.pendingJourneyStatus){
      this.pendingJourneyStatus.unsubscribe();
    }
 
  }

}
