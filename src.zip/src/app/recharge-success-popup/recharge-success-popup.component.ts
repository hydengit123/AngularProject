import { Component, OnInit, Input } from '@angular/core';
import { ModalDirective } from 'ng-uikit-pro-standard';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-recharge-success-popup',
  templateUrl: './recharge-success-popup.component.html',
  styleUrls: ['./recharge-success-popup.component.scss']
})
export class RechargeSuccessPopupComponent implements OnInit {

  @Input() basicModal: ModalDirective;
  voucherCodeResponse;
  voucherCodeMessage: String = '';

  constructor(
    public translateService:TranslateService
  ) { }

  ngOnInit() {
    this.voucherCodeMessage = this.translateService.instant(this.voucherCodeResponse.statusReason.code);
  }

}
