import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RechargeSuccessPopupComponent } from './recharge-success-popup.component';

describe('RechargeSuccessPopupComponent', () => {
  let component: RechargeSuccessPopupComponent;
  let fixture: ComponentFixture<RechargeSuccessPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RechargeSuccessPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RechargeSuccessPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
