import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {CisComponent} from './cis/cis.component';
import {AuthGuard} from './auth.guard';
import { CustomerOnboardingComponent } from './customer-onboarding/customer-onboarding.component';
import { LoginComponent } from './login/login.component';
import { IntermediatePaymentComponent } from './intermediate-payment/intermediate-payment.component';

const routes: Routes = [
  {path: '', redirectTo: '/public', pathMatch: 'full'},
  {path: 'public', component: CisComponent, canActivate: [AuthGuard]},
  {path: 'login', component : LoginComponent},
  {path: 'intermediaryPayment', component : IntermediatePaymentComponent},
  {path:  'customerOnboard', loadChildren: 'app/customer-onboarding/customer-onboarding.module#CustomerOnboardingModule'},
  {path: 'dashboard', loadChildren: 'app/dashboard/dashboard.module#DashboardModule', canActivate: [AuthGuard]},
  {path: '**', redirectTo: '/public', pathMatch: 'full'}
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule {
}
