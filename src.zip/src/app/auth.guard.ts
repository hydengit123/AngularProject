import { Injectable } from '@angular/core';
import { CanActivate, CanDeactivate, Router, RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';
import { PersistenceService, StorageType } from 'angular-persistence';
import { PERSISTANCEKEY } from '../application-constants';
import { CisComponent } from './cis/cis.component';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private persistenceService: PersistenceService, private router: Router) {

  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {

    const accessToken = this.persistenceService.get(PERSISTANCEKEY.ACCESSTOKEN, StorageType.SESSION);
    const partyId = this.persistenceService.get(PERSISTANCEKEY.PARTYID, StorageType.SESSION);
    const customerId = this.persistenceService.get(PERSISTANCEKEY.CUSTOMERID, StorageType.SESSION);
    if (accessToken && partyId && customerId) {
      if (state.url === '/public') {
        this.router.navigate(['/dashboard']);
      } else if (state.url.indexOf('/dashboard') !== -1) {
        return true;
      }
    } else {

        if (state.url !== '/public') {
          this.router.navigate(['/public']);
        } else {
          return true;
        }
      }
    }


  }
