// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular.json`.

export const environment = {
  production: false,
  urls:{
    promotedoffers:'/dxp-ci-insight-api/insights/v1/promotedoffers/customer/',
    recommendedoffers:'/dxp-ci-insight-api/insights/v1/similaritylookup/product/',
    login:'https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/securityService/v1/login',
    credUrl:'https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/securityService/v1/credential',
    otpUrl: 'https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se:80/securityService/v1/otp',
    apiUrl:'https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se',
    cmsUrl:'https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se',
    // i18n: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/o/cmsConnector/v1/translations/search/selfcare?language=",
    i18n: './assets/i18n/',
    getWebPageContent: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/o/cmsConnector/v1/webPageContents/selfcare/search",
    getCollaterals: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/o/cmsConnector/v1/productOfferings/search?fields=collaterals",
    getCustomerOnBoardDetails: "../assets/mock/customerOnBoardingDetails.json",
    getCustomerPlanDetails:"https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/productOffering/search",
    getPlanOffersImages:"https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/o/cmsConnector/v1/productOfferings/search",
    getCMUIDetails: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/cmConfiguration/UIConfiguration",
    getChatbotDetails: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/cmConfiguration/ChatbotConfiguration",
    fraudCheck: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/fraudCheck" ,
    paymentGatewayList: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/paymentManagement/v1/paymentGateway",
    paymentGatewayConfiguration: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/paymentManagement/v1/payment",
    paymentUpdate: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/paymentManagement/v1/payment",
    userprofile: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/userProfile/search",
    customersearch: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/customer/activationStatusCheck",
    getJourneySession: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/jis/v1/journeySession?customerId=",
    deleteJourneySession: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/jis/v1/journeySession/",
    getAddonJourneySession: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/jis/v1/journeySession?customerId={customerId}&journeyId={journeyId}",
    createCart: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/shoppingCart",
    customerInteraction: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/customerInteraction",
    saveCart:"https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/customer/register",
    saveCartJourneySession:"https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/jis/v1/journeySession",
    sendVerificationCode: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/securityService/v1/vCode/set",
    linkSubscription: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/subscription/link",
    consumerSearch: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/customer/",
    mockContranct: "assets/mock/customerContract.json",
    consumerSharedSearch: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/customer/",
    getConsumers:"https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/customer/{customerId}/contract/{contractId}/sharedConsumers",
    //getConsumers: "assets/mock/getConsumers.json",
    searchConsumer:"https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/customer/{customerId}/contract/{contractId}/sharedConsumers/search",
    //validateMSISDN: "assets/mock/validateMSISDN.json",
    validateMSISDN: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/customer/customercontract/search",
    customerProfileSearch: 'https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/xCACcore/v1/customer/customerprofile/search',
    pendingjourneyfetch: "https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se/jis/v1/journeySession"
  },
 localCMSDomain: 'https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se',
 apiUrl:'https://dxp-wipro-sec.todd061.rnd.gic.ericsson.se',
 enableDebug:true
};
