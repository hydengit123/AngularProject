export const QUOTATYPE = {
  'DATA': 'data',
  'VOICE': 'voice',
  'SMS': 'sms'
};

export const PRODUCTGROUP = {
  'ADDON': 'addon'
};

export const CHATBOT = {
  'CHATBOTURL' : 'chatbotURL',
  'SECRETKEY' : 'secretKey'
};

export const JOURNEYIDS = {
  'REFILL': ['AccountRefill', 'AccountRefill_ForOthers_Beneficiary', 'AccountRefill_ForOthers_Anon', 'VoucherTopup_Others', 'VoucherTopup_Self', 'VoucherTopup_Anon', 'VoucherTopup_Beneficiary']
};

export const PERSISTANCEKEY = {
  CURRENTPLAN: 'currentplan',
  ACCESSTOKEN: 'accessToken',
  DUMMYTOKEN: 'dummyToken',
  MSISDN: 'msisdn',
  USERNAME: 'username',
  USER: 'user',
  USERADDON: 'useraddons',
  PROVISIONEDQUOTA: 'provisionedQuota',
  AVAILABLEQUOTA: 'availableQuota',
  MAINBALANCE: 'mainBalance',
  PERSONALISEDDEALS : 'personalisedDeals',
  USERDEALS : 'userDeals',
  PARTYID: 'partyId',
  REGISTEREMAILMSISDN: 'registeremailmsisdn',
  CUSTOMERID: 'customerid',
  USERPROFILEID: "userProfileId"

};

export const ONBOARDPERSISTANCEKEY = {
  MSISDN: 'msisdn',
  ENABLEREGISTER: 'enableRegister',
  ENABLEDELIVERY: 'enableDelivery',
  ENABLEADDON : 'enableAddOn',
  USERADDON: 'useraddons',
  SELECTEDADDONS: 'selectedaddons',
  CURRENTPLAN: 'currentplan',
  CUSTOMOFFER: 'customoffer',
  PREMIUM: 'premium',
  STANDARD: 'standard',
  INVENTORY: 'inventory',
  PINCODE: 'pincode',
  SELECTEDDEVICE: 'selecteddevice',
  ENABLECHECKOUT : 'enableCheckout',
  REGISTERDATA : 'registerData',
  CUSTOMPLANPRICE : 'customPrice',
  CUSTOMPLANINDEX : 'customPlanIndex',

};

export const ANNONYMOUSUSER = {
  USERNAME: 'anonymoususer@dxp.com',
  PASSWORD: 'Dxp@1234'
};

export const WEBCONTENTPERSISTANCEKEY = {
  WEBCONTENT: 'webcontent',
  PAYMENT_STATUS: 'paymentStatus'
};

export const LOCALIZATIONPERSISTANCEKEY = {
  LANGUAGE: 'language'
};

export const REGEX = {
  ALPHANUMERIC:new RegExp('[a-zA-Z0-9]'),
  ONLYDIGIT:new RegExp('^[0-9]*$'),
  ONLYALPHABATES:new RegExp('[a-zA-Z]'),
  EMAIL:new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/),
  PASSWORD:new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})'),
  FLOATNUMBER: new RegExp(/^[1-9]+\d*\.?\d*$/gm),
  ZEROEXCLUDEDNUMBER: new RegExp(/^[1-9]+\d*$/gm),
  DATEPICKERFORMAT: new RegExp(/^\d{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])$/gm)
};

export const PREPROVISIONEDOFFER = {
  OFFER: 'pre-provisionsedBaseOffer',

}

export const JOURNEYDATADETAILS = {
  JOURNEYSESSIONID: 'JOURNEYSESSIONID',
  JOURNEYDATA: 'JOURNEYDATA',
  CURRENTSTEP: "CURRENTSTEP",
  JOURNEYID: 'JourneyId',
  JOURNEYSTATUS: 'JourneyStatus',
  ONBOARDTYPE: 'onboarding',
  ADDONTYPE: 'addon'
}

export const SHAREDCONSUMER = {
  ADDSHAREDCONSUMER: 'Add Shared Consumer',
  UPDATESHAREDCONSUMER: 'Update Shared Consumer',
  DELETESHAREDCONSUMER: 'Delete Shared Consumer',
  ADDSHAREDCONSUMERJOURNEYID: 'AddSharedConsumer_Provider',
  UPDATESHAREDCONSUMERJOURNEYID: 'UpdateSharedConsumer_Provider',
  DELETESHAREDCONSUMERJOURNEYID: 'DeleteSharedConsumer_Provider',
  CUSTOMERSERVICEORDERSTATE: "InProgress",
  CUSTOMERSERVICEORDERTYPE:"ServiceOrder",
  DATAUNIT: "byte",
  VOICEUNIT: "second",
  DATAUNITS: "bytes",
  VOICEUNITS: "seconds",
  SMSUNIT: "unit",
  MINUTES: "minutes",
  DATA: "data",
  VOICE: "voice",
  SMS: "sms",
}
